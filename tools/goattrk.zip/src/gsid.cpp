/*
 * GOATTRACKER reSID interface
 */

#include <stdlib.h>

#include "sid.h"
#include "gsound.h"

#define PAL_CLOCK_RATE 985248
#define NTSC_CLOCK_RATE 1022727
SID *sid;

extern "C" {

int clockrate;
int samplerate;

/* "Our" SID registers */
unsigned char sidreg[32];

int sid_created = 0;

void sid_init(int speed, unsigned m, unsigned ntsc, unsigned ip);
int sid_fillbuffer(short *ptr, int samples);

void sid_init(int speed, unsigned m, unsigned ntsc, unsigned ip)
{
  int c;

  if (ntsc) clockrate = NTSC_CLOCK_RATE;
    else clockrate = PAL_CLOCK_RATE;
  samplerate = speed;

  if (!sid_created)
  {
    sid = new SID;
    sid_created = 1;
  }
  if (!ip)
    sid->set_sampling_parameters(clockrate, SAMPLE_FAST, speed, 20000);
  else
    sid->set_sampling_parameters(clockrate, SAMPLE_INTERPOLATE, speed, 20000);
  sid->reset();
  for (c = 0; c <= 0x18; c++)
  {
    sidreg[c] = 0x00;
  }
  if (m == 1)
  {
    sid->set_chip_model(MOS8580);
  }
  else
  {
    sid->set_chip_model(MOS6581);
  }
}

int sid_fillbuffer(short *ptr, int samples)
{
  int tdelta;
  int result;

  /* Filter */
  sid->write(0x15, sidreg[0x15]);
  sid->write(0x16, sidreg[0x16]);
  sid->write(0x17, sidreg[0x17]);
  sid->write(0x18, sidreg[0x18]);

  /* ADSR */
  sid->write(0x05, sidreg[0x05]);
  sid->write(0x0c, sidreg[0x0c]);
  sid->write(0x13, sidreg[0x13]);
  sid->write(0x06, sidreg[0x06]);
  sid->write(0x0d, sidreg[0x0d]);
  sid->write(0x14, sidreg[0x14]);
  sid->clock(4);

  /* Frequency */
  sid->write(0x00, sidreg[0x00]);
  sid->write(0x07, sidreg[0x07]);
  sid->write(0x0e, sidreg[0x0e]);
  sid->write(0x01, sidreg[0x01]);
  sid->write(0x08, sidreg[0x08]);
  sid->write(0x0f, sidreg[0x0f]);
  sid->clock(4);

  /* Pulse */
  sid->write(0x02, sidreg[0x02]);
  sid->write(0x09, sidreg[0x09]);
  sid->write(0x10, sidreg[0x10]);
  sid->write(0x03, sidreg[0x03]);
  sid->write(0x0a, sidreg[0x0a]);
  sid->write(0x11, sidreg[0x11]);
  sid->clock(4);

  /* Waveform */
  sid->write(0x04, sidreg[0x04]);
  sid->write(0x0b, sidreg[0x0b]);
  sid->write(0x12, sidreg[0x12]);

  tdelta = clockrate * samples / samplerate + 4;
  result = sid->clock(tdelta, ptr, samples);
  return result;
}

}
