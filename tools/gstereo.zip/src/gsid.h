void sid_init(int speed, unsigned m, unsigned ntsc, unsigned ip);
int sid_fillbuffer(short *l, short *r, int samples);
void sid_dumpregs(void);

extern unsigned char sidreg[32];
extern unsigned char sidreg2[32];
