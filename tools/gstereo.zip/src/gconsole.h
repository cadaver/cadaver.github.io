#define MAX_COLUMNS 100
#define MAX_ROWS 28

int initscreen(void);
void closescreen(void);
void clearscreen(void);
void fliptoscreen(void);
void printtext(int x, int y, int color, const unsigned char *text);
void printtextc(int y, int color, const unsigned char *text);
void printblank(int x, int y, int length);
void printblankc(int x, int y, int color, int length);
void drawbox(int x, int y, int color, int sx, int sy);
void printbg(int x, int y, int color, int length);
void getkey(void);

extern short *scrbuffer;
extern int key, rawkey, shiftpressed, cursorflashdelay;
