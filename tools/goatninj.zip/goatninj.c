/*
 * GoatTracker -> Ninjatracker converter V1.1
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "goattrk.h"

INSTR instr[MAX_INSTR];
unsigned char filtertable[256];
unsigned char wavetable[MAX_INSTR][MAX_WAVELEN*2];
unsigned char songorder[MAX_SONGS][MAX_CHN][MAX_SONGLEN+2];
unsigned char pattern[MAX_PATT][MAX_PATTROWS*3+3];
unsigned char patttempo[MAX_PATT][MAX_PATTROWS];
unsigned char pattinstr[MAX_PATT][MAX_PATTROWS];
unsigned char wavecopybuffer[MAX_WAVELEN*2];
unsigned char songname[MAX_STR];
unsigned char authorname[MAX_STR];
unsigned char copyrightname[MAX_STR];
int pattlen[MAX_PATT];
int songlen[MAX_SONGS][MAX_CHN];

int highestusedpattern;
int prevwritebyte = 0x100;
int blocklen = 0;
int wu = 0;
int pu = 0;
int fu = 0;

int main(int argc, char **argv);
int loadsong(char *name);
int savesong(char *name);
int processsong(void);
unsigned char nybblereverse(unsigned char n);
void processpulse(int e, int w);
void makeportaup(int data);
void makeportadown(int data);
void makearpeggio(int instr, int cdata);
void makevibrato(int data);
void getpatttempos(void);
void getfilteramount(void);
void countpatternlengths(void);
void countdestpatternlengths(void);
void clearsong(int cs, int cp, int ci, int cn);
void writeblock(unsigned char *adr, int len);
void writebyte(unsigned char c);

unsigned char wavtable[256];
unsigned char notetable[256];
unsigned char nexttable[256];

unsigned char pulsetimetable[256];
unsigned char pulseaddtable[256];
unsigned char pulsenexttable[256];

unsigned char filttimetable[256];
unsigned char filtspdtable[256];
unsigned char filtnexttable[256];

unsigned char ninjaorder[12288];
unsigned char ninjapattern[24576];

unsigned char ninjapattlen[128];
unsigned char ninjasonglen[48];

unsigned char temppattnote[256];
unsigned char temppattwave[256];
unsigned char temppattdur[256];

int instrwavelen[32]; // Wavetable length, for calculating start-moment of
                      // portamentos etc. upon note-start
int instrwaveptr[32];
int instrpulseptr[32];
int instrkeyoff[32];
int filteramount;

int wavearpptr[32][256];
int wavearpdone[32][256];
int vibptr[256];
int vibdone[256];
int portaupptr[256];
int portaupdone[256];
int portadownptr[256];
int portadowndone[256];

FILE *out;

unsigned char freqtblhi[] = {
  0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x02,
  0x02,0x02,0x02,0x02,0x02,0x02,0x03,0x03,0x03,0x03,0x03,0x04,
  0x04,0x04,0x04,0x05,0x05,0x05,0x06,0x06,0x06,0x07,0x07,0x08,
  0x08,0x09,0x09,0x0a,0x0a,0x0b,0x0c,0x0c,0x0d,0x0e,0x0f,0x10,
  0x11,0x12,0x13,0x14,0x15,0x17,0x18,0x19,0x1b,0x1d,0x1e,0x20,
  0x22,0x24,0x26,0x29,0x2b,0x2e,0x30,0x33,0x36,0x3a,0x3d,0x41,
  0x45,0x49,0x4d,0x52,0x57,0x5c,0x61,0x67,0x6d,0x74,0x7b,0x82,
  0x8a,0x92,0x9b,0xa4,0xae,0xb8,0xc3,0xcf,0xdb,0xe8,0xf6,0xff,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

int main(int argc, char **argv)
{
  if (argc < 3)
  {
    printf("GoatTracker->Ninjatracker convertor V1.1\n"
           "Usage: GOATNINJ <sourcesong> <dest.song>\n\n"
           "Converts Goattracker song to Ninjatracker V103 format. V102 no longer\n"
           "supported, because it is much more limited. See README.TXT for further\n"
           "information & limitations.\n");
    return 1;
  }
  if (!strcmp(argv[1], argv[2]))
  {
    printf("ERROR: Source and destination are not allowed to be the same.");
    return 1;
  }

  if (!loadsong(argv[1]))
  {
    printf("ERROR: Couldn't load source song.");
    return 1;
  }
  getpatttempos();

  out = fopen(argv[2], "wb");

  if (!processsong())
  {
    return 1;
  }
  fclose(out);
  return 0;
}

void getpatttempos(void)
{
  int e,c;

  memset(patttempo, 6, sizeof patttempo);
  memset(pattinstr, 0, sizeof pattinstr);

  // Simulates playroutine going through the songs
  for (e = 0; e < MAX_SONGS; e++)
  {
    int sp[3] = {-1,-1,-1};
    int pp[3] = {0xff,0xff,0xff};
    int pn[3] = {0,0,0};
    int rep[3] = {0,0,0};
    int stop[3] = {0,0,0};
    int instr[3] = {0,0,0};
    int tempo[3] = {6,6,6};
    int tick[3] = {0,0,0};

    while ((!stop[0])||(!stop[1])||(!stop[2]))
    {
      for (c = 0; c < MAX_CHN; c++)
      {
        if (!stop[c])
        {
          if (pp[c] == 0xff)
          {
            if (!rep[c])
            {
              sp[c]++;
              if (songorder[e][c][sp[c]] >= LOOPSONG)
              {
                stop[c] = 1;
                break;
              }
              while (songorder[e][c][sp[c]] >= TRANSDOWN) sp[c]++;
              while ((songorder[e][c][sp[c]] >= REPEAT) && (songorder[e][c][sp[c]] < TRANSDOWN))
              {
                  rep[c] = songorder[e][c][sp[c]] - REPEAT;
                  sp[c]++;
              }
            }
            else rep[c]--;

            pn[c] = songorder[e][c][sp[c]];
            pp[c] = 0;
          }
          if (pattern[pn[c]][pp[c]*3] == ENDPATT)
            pp[c] = 0xff;
          else
          {
            if (pattern[pn[c]][pp[c]*3+1] >> 3)
              instr[c] = pattern[pn[c]][pp[c]*3+1] >> 3;

            if (((pattern[pn[c]][pp[c]*3+1] & 0x7) == 0x7) && (!tick[c]))
            {
              int newtempo = pattern[pn[c]][pp[c]*3+2];
              if (newtempo < 0xc0)
              {
                if (newtempo < 0x80)
                {
                  tempo[0] = newtempo;
                  tempo[1] = newtempo;
                  tempo[2] = newtempo;
                }
                else tempo[c] = newtempo & 0x7f;
              }
            }
          }
        }
      }
      for (c = 0; c < MAX_CHN; c++)
      {
        if (!stop[c])
        {
          if (pp[c] != 0xff)
          {
            patttempo[pn[c]][pp[c]] = tempo[c];
            pattinstr[pn[c]][pp[c]] = instr[c];
            tick[c]++;
            if (tick[c] >= tempo[c])
            {
              tick[c] = 0;
              pp[c]++;
            }
          }
        }
      }
    }
  }
}

int loadsong(char *name)
{
  char ident[4];
  int c;

  FILE *srchandle = fopen(name, "rb");
  if (srchandle)
  {
    fread(ident, 4, 1, srchandle);
    if (!memcmp(ident, "GTS!", 4))
    {
      int d;
      unsigned char length;
      unsigned char amount;
      int loadbytes;
      clearsong(1,1,1,1);

      /* Read infotexts */
      fread(songname, sizeof songname, 1, srchandle);
      fread(authorname, sizeof authorname, 1, srchandle);
      fread(copyrightname, sizeof copyrightname, 1, srchandle);

      /* Read songorderlists */
      fread(&amount, sizeof amount, 1, srchandle);
      for (d = 0; d < amount; d++)
      {
        for (c = 0; c < MAX_CHN; c++)
        {
          fread(&length, sizeof length, 1, srchandle);
          loadbytes = length;
          loadbytes++;
          fread(songorder[d][c], loadbytes, 1, srchandle);
          /* Convert the old endmark */
          if (songorder[d][c][length] == 0xfe)
            songorder[d][c][length] = LOOPSONG;
        }
      }
      /* Read instruments */
      for (c = 1; c < MAX_INSTR; c++)
      {
        fread(&instr[c], sizeof(INSTR), 1, srchandle);
        loadbytes = instr[c].wavetableindex;
        instr[c].wavetableindex = 1;
        fread(wavetable[c], loadbytes, 1, srchandle);
      }
      /* Read patterns */
      fread(&amount, sizeof amount, 1, srchandle);
      for (c = 0; c < amount; c++)
      {
        fread(&length, sizeof length, 1, srchandle);
        fread(pattern[c], length, 1, srchandle);
      }
      /* Read filtertable */
      fread(filtertable, 256, 1, srchandle);

      countpatternlengths();
      getfilteramount();
      fclose(srchandle);
      return 1;
    }
    fclose(srchandle);
  }
  return 0;
}

void countpatternlengths(void)
{
  int c, d, e;

  highestusedpattern = 0;
  for (c = 0; c < MAX_PATT; c++)
  {
    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      if (pattern[c][d*3] == ENDPATT) break;
    }
    pattlen[c] = d;
  }
  for (e = 0; e < MAX_SONGS; e++)
  {
    for (c = 0; c < MAX_CHN; c++)
    {
      for (d = 0; d < MAX_SONGLEN; d++)
      {
        if (songorder[e][c][d] >= LOOPSONG) break;
        if (songorder[e][c][d] < MAX_PATT)
        {
          if (songorder[e][c][d] > highestusedpattern)
            highestusedpattern = songorder[e][c][d];
        }
      }
      songlen[e][c] = d;
    }
  }
}

void clearsong(int cs, int cp, int ci, int cn)
{
  int c;

  for (c = 0; c < MAX_CHN; c++)
  {
    int d;
    if (cs)
    {
      for (d = 0; d < MAX_SONGS; d++)
      {
        memset(&songorder[d][c][0], 0, MAX_SONGLEN);
        if (!d)
        {
          songorder[d][c][0] = c;
          songorder[d][c][1] = LOOPSONG;
          songorder[d][c][2] = 0;
        }
        else
        {
          songorder[d][c][0] = LOOPSONG;
          songorder[d][c][1] = 0;
        }
      }
    }
  }
  if (cn)
  {
    memset(songname, 0, sizeof songname);
    memset(authorname, 0, sizeof authorname);
    memset(copyrightname, 0, sizeof copyrightname);
  }

  if (cp)
  {
    for (c = 0; c < MAX_PATT; c++)
    {
      int d;
      memset(&pattern[c][0], 0, MAX_PATTROWS*3);
      for (d = 0; d < MAX_PATTROWS; d++) pattern[c][d*3] = REST;
      for (d = MAX_PATTROWS; d <= MAX_PATTROWS; d++) pattern[c][d*3] = ENDPATT;
    }
  }
  if (ci)
  {
    for (c = 0; c < MAX_INSTR; c++)
    {
      memset(&instr[c], 0, sizeof(INSTR));
      memset(&wavetable[c][0], 0, MAX_WAVELEN*2);
      wavetable[c][2] = 0xff;
      wavetable[c][MAX_WAVELEN*2-2] = 0xff;
    }
  }
  countpatternlengths();
}

void processpulse(int e, int w)
{
  if (instr[e].pulse)
  {
    int time;
    int dist;
    int pulseloopbegin;
    int c;

    for (c = 1; c < e; c++)
    {
      if ((instr[c].pulse == instr[e].pulse) &&
          (instr[c].pulseadd == instr[e].pulseadd) &&
          (instr[c].pulselimithigh == instr[e].pulselimithigh) &&
          (instr[c].pulselimitlow == instr[e].pulselimitlow))
      {
        notetable[w] = instrpulseptr[c]+1;
        return;
      }
    }

    instrpulseptr[c] = pu;
    pulsetimetable[pu] = 0x80;
    pulseaddtable[pu] = nybblereverse(instr[e].pulse);
    if (!instr[e].pulseadd)
    {
      pulsenexttable[pu] = 1;
      pu++;
    }
    else
    {
      pulsenexttable[pu] = pu+2;
      pu++;

      dist = instr[e].pulselimithigh - instr[e].pulse;
      time = dist / (instr[e].pulseadd >> 4);

      if (time > 0x7f)
      {
        pulsetimetable[pu] = 0x7f;
        pulseaddtable[pu] = nybblereverse(instr[e].pulseadd >> 4);
        pulsenexttable[pu] = pu+2;
        pu++;
        pulsetimetable[pu] = time - 0x7f;
        pulseaddtable[pu] = nybblereverse(instr[e].pulseadd >> 4);
        pulsenexttable[pu] = pu+2;
        pu++;
      }
      else
      {
        pulsetimetable[pu] = time;
        pulseaddtable[pu] = nybblereverse(instr[e].pulseadd >> 4);
        pulsenexttable[pu] = pu+2;
        pu++;
      }

      pulseloopbegin = pu;
      dist = instr[e].pulselimithigh - instr[e].pulselimitlow;
      time = dist / (instr[e].pulseadd >> 4);

      if (time > 0x7f)
      {
        pulsetimetable[pu] = 0x7f;
        pulseaddtable[pu] = nybblereverse(-(instr[e].pulseadd >> 4)-1);
        pulsenexttable[pu] = pu+2;
        pu++;
        pulsetimetable[pu] = time - 0x7f;
        pulseaddtable[pu] = nybblereverse(-(instr[e].pulseadd >> 4)-1);
        pulsenexttable[pu] = pu+2;
        pu++;
      }
      else
      {
        pulsetimetable[pu] = time;
        pulseaddtable[pu] = nybblereverse(-(instr[e].pulseadd >> 4)-1);
        pulsenexttable[pu] = pu+2;
        pu++;
      }

      if (time > 0x7f)
      {
        pulsetimetable[pu] = 0x7f;
        pulseaddtable[pu] = nybblereverse(instr[e].pulseadd >> 4);
        pulsenexttable[pu] = pu+2;
        pu++;
        pulsetimetable[pu] = time - 0x7f;
        pulseaddtable[pu] = nybblereverse(instr[e].pulseadd >> 4);
        pulsenexttable[pu] = pulseloopbegin+1;
        pu++;
      }
      else
      {
        pulsetimetable[pu] = time;
        pulseaddtable[pu] = nybblereverse(instr[e].pulseadd >> 4);
        pulsenexttable[pu] = pulseloopbegin+1;
        pu++;
      }
    }
  }
}

int processsong(void)
{
  int c,d,e;

  memset(wavtable, 0, 256);
  memset(notetable, 0, 256);
  memset(nexttable, 0, 256);
  memset(pulsetimetable, 0, 256);
  memset(pulseaddtable, 0, 256);
  memset(pulsenexttable, 0, 256);
  memset(filttimetable, 0, 256);
  memset(filtspdtable, 0, 256);
  memset(filtnexttable, 0, 256);

  memset(ninjaorder, 0, 12288);
  memset(ninjapattern, 0, 24576);

  memset(ninjasonglen, 0, 48);
  memset(ninjapattlen, 0, 128);
  memset(wavearpdone, 0, sizeof wavearpdone);
  memset(vibdone, 0, sizeof vibdone);
  memset(portaupdone, 0, sizeof portaupdone);
  memset(portadowndone, 0, sizeof portadowndone);
  portaupdone[0] = 1; // Zero speed portamento programs exist by default
  portaupptr[0] = 0;
  portadowndone[0] = 1;
  portadownptr[0] = 0;

  wavtable[wu] = 0xc0;
  notetable[wu] = 0x00;
  nexttable[wu] = 0x01;
  wu++;
  pulsetimetable[pu] = 0x7f;
  pulseaddtable[pu] = 0x00;
  pulsenexttable[pu] = 0x00;
  pu++;
  filttimetable[fu] = 0x80;
  fu++;

  // Convert filtertable (easy!)
  for (e = 1; e < filteramount; e++)
  {
    int fp = e * 4;
    // Control filter step
    if (filtertable[fp])
    {
      filttimetable[fu] = 0x80 | (filtertable[fp] & 0x0f) | (filtertable[fp+1] & 0xf0);
      filtspdtable[fu] = filtertable[fp+2];
      if (filtertable[fp+3])
        filtnexttable[fu] = filtertable[fp+3]+1;
      else
        filtnexttable[fu] = 0;
      fu++;
    }
    // Modulation filter step
    else
    {
      int time = filtertable[fp + 1];
      if (time < 0x1) time = 0x1;
      if (time > 0x7f) time = 0x7f;

      filttimetable[fu] = time;
      filtspdtable[fu] = filtertable[fp+2];
      if (filtertable[fp+3])
        filtnexttable[fu] = filtertable[fp+3]+1;
      else
        filtnexttable[fu] = 0;
      fu++;
    }
  }
  d = 0;

  for (e = 1; e < MAX_INSTR; e++)
  {
    if ((wavetable[e][0]) || (wavetable[e][1]))
    {
      int begin;
      int prevwave;
      int pulseloc;

      instrwavelen[e] = 0;
      instrwaveptr[e] = wu;
      wavtable[wu] = 0x00;
      pulseloc = wu;
      if (instr[e].pulse) notetable[wu] = pu+1;
        else notetable[wu] = 0;
      if (instr[e].filtertype)
        nexttable[wu] = instr[e].filtertype+1;
      else
        nexttable[wu] = 0; // No filter in instrument
      instrwavelen[e]++; // One length for the hardrestart
      wu++;
      wavtable[wu] = 0x02;
      notetable[wu] = instr[e].ad;
      nexttable[wu] = instr[e].sr;
      wu++;
      begin = wu;
      for (d = 0; d < MAX_WAVELEN*2; d += 2)
      {
        if (wavetable[e][d])
        {
          wavtable[wu] = wavetable[e][d];
          notetable[wu] = wavetable[e][d+1];
          prevwave = wavtable[wu];
          instrkeyoff[e] = prevwave & 0xfe;
        }
        else
        {
          notetable[wu] = wavetable[e][d+1];
          wavtable[wu] = 0x90;
        }
        instrwavelen[e]++; // Then one length for each wavetable row
        if (wavetable[e][d+2] == 0xff)
        {
          if (wavetable[e][d+3])
          {
            nexttable[wu] = wavetable[e][d+3]+begin;
            wu++;
            break;
          }
          else
          {
            nexttable[wu] = 0x01;
            wu++;
            break;
          }
        }
        else nexttable[wu] = wu+2;
        wu++;
      }
      processpulse(e, pulseloc);
    }
    if (wu >= 256)
    {
      printf("Too big wavetable!\n");
      return 1;
    }
  }

  for (e = 0; e < 16; e++)
  {
    for (c = 0; c < MAX_CHN; c++)
    {
      int o = 0;
      int repeat = 1;
      if (songlen[e][c])
      {
        for (d = 0; d < songlen[e][c]; d++)
        {
          if (songorder[e][c][d] < TRANSDOWN)
          {
            if (songorder[e][c][d] < REPEAT)
            {
              while (repeat--)
              {
                ninjaorder[e*768 + c*256 + o] = songorder[e][c][d]+1;
                o++;
              }
              repeat = 1;
            }
            else repeat = songorder[e][c][d] - REPEAT + 1;
          }
          else
          {
            int trans = songorder[e][c][d] - 0xf0;
            ninjaorder[e*768 + c*256 + o] = trans | 0x80;
            o++;
          }
        }
        ninjaorder[e*768 + c * 256 + o] = 0x00;
        o++;
        ninjaorder[e*768 + c * 256 + o] = 0x00;
        o++;
        ninjasonglen[e*3+c] = o;
      }
    }
  }

  ninjapattern[0] = 0xfe;
  ninjapattern[1] = 0x5c;
  ninjapattern[2] = 0x00;
  ninjapattern[3] = 0x00;
  ninjapattlen[0] = 4;

  for (e = 0; e <= highestusedpattern; e++)
  {
    int o = 0;
    int l = 0;
    int instr = 0;
    int lastdur = 0;
    int prevcommand = -1;
    int prevcdata = -1;
    int command = -1;
    int cdata = -1;
    memset(temppattnote, 0, 256);
    memset(temppattwave, 0, 256);
    memset(temppattdur, 0, 256);

    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      int newinstr = (pattern[e][d*3+1] & 0xf8) >> 3;

      prevcommand = command;
      prevcdata = cdata;
      command = pattern[e][d*3+1] & 0x07;
      cdata = pattern[e][d*3+2];

      if (newinstr) instr = newinstr;
      temppattdur[o] = patttempo[e][d];
      switch(pattern[e][d*3])
      {
        case ENDPATT:
        d = MAX_PATTROWS + 1;
        break;

        case REST:
        temppattnote[o] = 0x5b;
        switch(command)
        {
          case 0x0:
          if (!cdata)
          {
            // Stop vibrato + portamento
            if ((prevcommand == 1) || (prevcommand == 2) || (prevcommand == 4))
              temppattwave[o] = 0x01;
          }
          break;

          case 0x1: // Porta up
          if ((command != prevcommand) || (cdata != prevcdata))
          {
            makeportaup(cdata);
            temppattwave[o] = portaupptr[cdata]+1;
          }
          break;

          case 0x2: // Porta down
          if ((command != prevcommand) || (cdata != prevcdata))
          {
            makeportadown(cdata);
            temppattwave[o] = portadownptr[cdata]+1;
          }
          break;

          case 0x4: // Vibrato
          if ((command != prevcommand) || (cdata != prevcdata))
          {
            makevibrato(cdata);
            temppattwave[o] = vibptr[cdata]+1;
          }
          break;

          case 0x5: // Set Filter
          temppattnote[o] = 0x5f;
          temppattwave[o] = cdata+1;
          break;

          case 0x6: // Set Sustain/Release
          temppattnote[o] = 0x5e;
          temppattwave[o] = cdata;
          break;
        }
        o++;
        break;

        case KEYOFF:
        // Keyoff overrides all other effects
        temppattnote[o] = 0x5c;
        if (instr)
          temppattwave[o] = instrkeyoff[instr];
        else
          temppattwave[o] = instrkeyoff[pattinstr[e][d]];
        o++;
        break;

        default:
        if (!instr)
        {
          temppattnote[o] = pattern[e][d*3]+1;
        }
        else
        {
          temppattnote[o] = pattern[e][d*3]+1;
          temppattwave[o] = instrwaveptr[instr]+1;
        }
        switch(command)
        {
          case 0x3:
          temppattwave[o] = instrwaveptr[instr]+3; // Legato
          break;

          case 0x0:
          if (cdata) // Arpeggio notestart
          {
            makearpeggio(instr,cdata);
            temppattwave[o] = wavearpptr[instr][cdata]+1;
          }
          break;

          case 0x1:
          // Can the current note be split into two (beginning + effect)?
          if (instrwavelen[instr] < temppattdur[o])
          {
            makeportaup(cdata);
            temppattdur[o+1] = temppattdur[o] - instrwavelen[instr];
            temppattdur[o] = instrwavelen[instr];
            temppattnote[o+1] = 0x5b;
            temppattwave[o+1] = portaupptr[cdata]+1;
          }
          o++;
          break;

          case 0x2:
          // Can the current note be split into two (beginning + effect)?
          if (instrwavelen[instr] < temppattdur[o])
          {
            makeportadown(cdata);
            temppattdur[o+1] = temppattdur[o] - instrwavelen[instr];
            temppattdur[o] = instrwavelen[instr];
            temppattnote[o+1] = 0x5b;
            temppattwave[o+1] = portadownptr[cdata]+1;
          }
          o++;
          break;

          case 0x4:
          // Can the current note be split into two (beginning + effect)?
          if (instrwavelen[instr] < temppattdur[o])
          {
            makevibrato(cdata);
            temppattdur[o+1] = temppattdur[o] - instrwavelen[instr];
            temppattdur[o] = instrwavelen[instr];
            temppattnote[o+1] = 0x5b;
            temppattwave[o+1] = vibptr[cdata]+1;
          }
          o++;
          break;
        }
        o++;
        break;
      }
    }
    temppattnote[o] = 0x00;
    temppattwave[o] = 0x00;
    temppattdur[o] = 0x00;
    o++;
    // Coagulate durations of rests into larger units
    for(d = 0;; d++)
    {
      if (!temppattnote[d]) break;
      if ((d+1) < o)
      {
        for (;;)
        {
          if ((temppattnote[d+1] == 0x5b) && (temppattwave[d+1] == 0x00))
          {
            if (temppattdur[d] + temppattdur[d+1] <= 64)
            {
              int f;
              temppattdur[d] += temppattdur[d+1];
              for (f = d+1;; f++)
              {
                temppattnote[f] = temppattnote[f+1];
                temppattwave[f] = temppattwave[f+1];
                temppattdur[f] = temppattdur[f+1];

                if (!temppattnote[f]) break;
              }
              o--;
            }
            else break;
          }
          else break;
        }
      }
    }
    o = d+1;
    // Remove unnecessary durations
    for(d = 0; d < o; d++)
    {
      if (d)
      {
        if ((temppattdur[d]) && (temppattdur[d] == lastdur))
        {
          temppattdur[d] = 0;
        }
        else lastdur = temppattdur[d];
      }
      else lastdur = temppattdur[d];
    }
    // Remove unnecessary waves from notestarts
    {
      int lastwave = -1;
      for (d = 0; d < o; d++)
      {
        if ((temppattwave[d] == lastwave) && (temppattnote[d] < 0x5c))
        {
          temppattwave[d] = 0;
        }
        if ((temppattnote[d] < 0x5c) && (temppattwave[d]))
        {
          lastwave = temppattwave[d];
        }
      }
    }
    // Convert temp pattern to Ninjatracker format
    l = 0;
    for (d = 0; d >= 0; d++)
    {
      if (temppattdur[d])
      {
        ninjapattern[e*192+192+l] = (-temppattdur[d])+1;
        l++;
      }
      switch(temppattnote[d])
      {
        case 0:
        ninjapattern[e*192+192+l] = 0x00;
        l++;
        d = -2;
        break;

        case 0x5c:
        case 0x5d:
        case 0x5e:
        case 0x5f:
        ninjapattern[e*192+192+l] = temppattnote[d];
        l++;
        ninjapattern[e*192+192+l] = temppattwave[d];
        l++;
        break;

        case 0x5b:
        if (temppattwave[d])
        {
          ninjapattern[e*192+192+l] = 0x60;
          l++;
          ninjapattern[e*192+192+l] = temppattwave[d];
          l++;
        }
        else
        {
          ninjapattern[e*192+192+l] = 0x5b;
          l++;
        }
        break;

        default:
        if (temppattwave[d])
        {
          ninjapattern[e*192+192+l] = temppattnote[d]+0x60;
          l++;
          ninjapattern[e*192+192+l] = temppattwave[d];
          l++;
        }
        else
        {
          ninjapattern[e*192+192+l] = temppattnote[d];
          l++;
        }
        break;
      }
    }
    ninjapattlen[e+1] = l;
  }

  fputc('C', out);
  fputc('N', out);
  writeblock(wavtable, 256);
  writeblock(notetable, 256);
  writeblock(nexttable, 256);
  writeblock(pulsetimetable, 256);
  writeblock(pulseaddtable, 256);
  writeblock(pulsenexttable, 256);
  writeblock(filttimetable, 256);
  writeblock(filtspdtable, 256);
  writeblock(filtnexttable, 256);
  writeblock(ninjapattern, 24576);
  writeblock(ninjaorder, 12288);
  writeblock(ninjapattlen, 128);
  writeblock(ninjasonglen, 48);
  writebyte(wu);
  writebyte(pu);
  writebyte(fu);
  if (blocklen > 0)
  {
    fputc(0xbf, out);
    fputc(prevwritebyte, out);
    fputc(blocklen, out);
    blocklen = 0;
  }
  return 0;
}

void makearpeggio(int instr, int cdata)
{
  int loopbegin;
  int c;

  // Create new arpeggio version of instrument
  // Copy first rows directly, until a wavetable loop or end
  // encountered

  if (wavearpdone[instr][cdata]) return;
  wavearpdone[instr][cdata] = 1;
  wavearpptr[instr][cdata] = wu;
  wavtable[wu] = wavtable[instrwaveptr[instr]];
  notetable[wu] = notetable[instrwaveptr[instr]];
  nexttable[wu] = nexttable[instrwaveptr[instr]];
  wu++;
  wavtable[wu] = wavtable[instrwaveptr[instr]+1];
  notetable[wu] = notetable[instrwaveptr[instr]+1];
  nexttable[wu] = nexttable[instrwaveptr[instr]+1];
  wu++;
  for (c = 2;; c++)
  {
    wavtable[wu] = wavtable[instrwaveptr[instr]+c];
    notetable[wu] = notetable[instrwaveptr[instr]+c];
    nexttable[wu] = wu+2;
    wu++;
    if (nexttable[instrwaveptr[instr]+c] <= (instrwaveptr[instr]+c+1)) break;
  }
  loopbegin = wu;
  // Slow arpeggio
  if (cdata & 0x80)
  {
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00;
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00 + ((cdata >> 4) & 0x7);
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00 + ((cdata >> 4) & 0x7);
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00 + (cdata & 0xf);
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00 + (cdata & 0xf);
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00;
    nexttable[wu] = loopbegin + 1;
    wu++;
  }
  else
  {
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00 + ((cdata >> 4) & 0x7);
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00 + (cdata & 0xf);
    nexttable[wu] = wu+2;
    wu++;
    wavtable[wu] = 0x90;
    notetable[wu] = 0x00;
    nexttable[wu] = loopbegin + 1;
    wu++;
  }
}


void makevibrato(int data)
{
  int vibspeed;
  int vibdepth;
  if (vibdone[data]) return;
  vibdone[data] = 1;
  vibptr[data] = wu;

  vibspeed = (data >> 4) + 2;
  vibdepth = nybblereverse(data) >> 2; // Convert speed to Ninjatracker speed

  wavtable[wu] = -(vibspeed/2);
  notetable[wu] = vibdepth; // Start going up
  nexttable[wu] = wu+2;
  wu++;
  wavtable[wu] = -vibspeed;
  notetable[wu] = -vibdepth; // Then down
  nexttable[wu] = wu+2;
  wu++;
  wavtable[wu] = -vibspeed;
  notetable[wu] = vibdepth; // Then up again
  nexttable[wu] = vibptr[data]+2; // Loop indefinitely
  wu++;
}

void makeportaup(int data)
{
  if (portaupdone[data]) return;
  portaupdone[data] = 1;
  portaupptr[data] = wu;

  wavtable[wu] = 0x91; // Longest possible freqmod
  if (data > 0x7f) data = 0x7f;
  notetable[wu] = data; // Speed up, doesn't need to be converted
  nexttable[wu] = wu+1; // Loop the same step indefinitely
  wu++;
}

void makeportadown(int data)
{
  if (portadowndone[data]) return;
  portadowndone[data] = 1;
  portadownptr[data] = wu;

  wavtable[wu] = 0x91; // Longest possible freqmod
  if (data > 0x80) data = 0x80;
  notetable[wu] = -data; // Speed down, doesn't need to be converted
  nexttable[wu] = wu+1; // Loop the same step indefinitely
  wu++;
}

void writeblock(unsigned char *adr, int len)
{
  while(len--)
  {
    writebyte(*adr);
    adr++;
  }
}

void writebyte(unsigned char c)
{
  if (prevwritebyte == c)
  {
    blocklen++;
    if (blocklen == 255)
    {
      fputc(0xbf, out);
      fputc(prevwritebyte, out);
      fputc(blocklen, out);
      blocklen = 0;
    }
  }
  else
  {
    if (blocklen > 0)
    {
      fputc(0xbf, out);
      fputc(prevwritebyte, out);
      fputc(blocklen, out);
      blocklen = 0;
    }
    if (c == 0xbf)
    {
      fputc(0xbf, out);
      fputc(0xbf, out);
      fputc(0x01, out);
    }
    else
    {
      fputc(c, out);
    }
    prevwritebyte = c;
  }
}

unsigned char nybblereverse(unsigned char n)
{
  unsigned char highnybble = n >> 4;
  unsigned char lownybble = n & 0xf;

  return (lownybble << 4) | highnybble;
}

void getfilteramount(void)
{
  int amount = 0, c, d;
  for (c = 0; c < MAX_PATT; c++)
  {
    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      if (pattern[c][d*3] == ENDPATT) break;
      if ((pattern[c][d*3 + 1] & 0x07) == CMD_SETFILTER)
      {
        if (amount < pattern[c][d*3+2]) amount = pattern[c][d*3+2];
      }
    }
  }
  for (c = 0; c < MAX_INSTR; c++)
  {
    if (amount < instr[c].filtertype) amount = instr[c].filtertype;
  }
  for (c = 0; c < MAX_FILT; c++)
  {
    if (filtertable[c*4+3] > amount) amount = filtertable[c*4+3];
  }
  amount++;

  filteramount = amount;
}

