Goattracker -> Ninjatracker convertor V1.11
-------------------------------------------
by Cadaver (loorni@gmail.com)

Usage: goatninj <GT songfile> <NT songfile>

Converts a GoatTracker V1.4 song to Ninjatracker V1.03+ format. Following
limitations apply:

- If a pattern is played with two different tempos in the song, it will be
  still be converted only in one tempo as NinjaTracker is based on note
  durations (a copy of the pattern isn't made)

- If an instrument's wavetable (to be Goattracker-compatible, it has to be
  completely played before a portamento or vibrato can begin), including one
  more frame for the hardrestart, is as long as, or longer than the song's
  tempo, vibratos or portamentos can't be started in conjunction with a note.

- A keyoff will override all effects on its tick, as Ninjatracker doesn't
  support having a keyoff and a effect at the same time. However, if a vibrato
  or portamento has been started before, they'll continue just fine

Notes on specific effects:

Effect 0 (arpeggio)
- Arpeggio works only when beginning a note. Note that using many different
  arpeggios with many different instruments makes the wavetable grow very large.
- Stopping of arpeggio isn't supported

Effect 1 (portamento up)
- Should work correctly

Effect 2 (portamento down)
- Should work correctly

Effect 3 (toneportamento)
- Implemented only as legato note (skipping the 2 initialization rows in
  wavetable). You have to correct these manually. For example, a typical
  slide from one note into another:

  D-4 01120
  E-4 01320
  --- 00320
  --- 00320
  --- 00320

  will be converted as (assume tempo 6)

  D-4 02 02
  Rst 10 04 (assume 10 is the wavetable-pointer to the slide up with speed $20)
  E-4 04 24 (4 is the corresponding legato wavetable-pointer for the instrument)

  Now, you can modify the durations of the rest and note E-4 to make the
  toneportamento stop smoothly (the legato note start will stabilize the pitch
  to the correct one)

Effect 4 (vibrato)
- Should work correctly

Effect 5 (set filter)
- In editors that don't support it, such as NinjaTracker V1.03, the filter
  command will be erroneously shown as "End"

Effect 6 (set SR)
- Supported, but not in conjunction of a new note

Effect 7 (tempo)
- Supported transparently in the note durations


Changes in V1.11:
- Better handling of pattern tempos, especially when repeat-commands are used
- Duplicate pulse programs are created only once
