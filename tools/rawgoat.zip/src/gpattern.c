//
// GOATTRACKER v2 pattern editor
//

#include "goattrk2.h"

void patterncommands(void)
{
  int c;

  switch(key)
  {
    case '<':
    case '(':
    case '[':
    if (epnum[epchn] > 0)
    {
      epnum[epchn]--;
      if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
    }
    if (epchn == epmarkchn) epmarkchn = -1;
    break;

    case '>':
    case ')':
    case ']':
    if (epnum[epchn] < MAX_PATT-1)
    {
      epnum[epchn]++;
      if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
    }
    if (epchn == epmarkchn) epmarkchn = -1;
    break;
  }
  {
    int newnote = -1;
    switch (keypreset)
    {
      case KEY_TRACKER:
      for (c = 0; c < sizeof(notekeytbl1); c++)
      {
        if ((rawkey == notekeytbl1[c]) && (!epcolumn) && (!shiftpressed))
        {
          newnote = FIRSTNOTE+c+epoctave*12;
        }
      }
      for (c = 0; c < sizeof(notekeytbl2); c++)
      {
        if ((rawkey == notekeytbl2[c]) && (!epcolumn) && (!shiftpressed))
        {
          newnote = FIRSTNOTE+c+(epoctave+1)*12;
        }
      }
      break;

      case KEY_DMC:
      for (c = 0; c < sizeof(dmckeytbl); c++)
      {
        if ((rawkey == dmckeytbl[c]) && (!epcolumn) && (!shiftpressed))
        {
          newnote = FIRSTNOTE+c+epoctave*12;
        }
      }
      break;
    }

    if (newnote > LASTNOTE) newnote = -1;
    if ((rawkey == 0x08) && (!epcolumn)) newnote = REST;
    if ((rawkey == 0x14) && (!epcolumn)) newnote = KEYOFF;
    if (rawkey == KEY_ENTER)
    {
    	if (!epcolumn)
    	{
      	if (shiftpressed)
          newnote = KEYON;
        else
          newnote = KEYOFF;
      }
      else
      {
      	switch (pattern[epnum[epchn]][eppos*4+2])
      	{
      	  case CMD_SETWAVEPTR:
      		if (pattern[epnum[epchn]][eppos*4+3])
       		{
       			editmode = EDIT_TABLES;
       			etnum = 0;
       			etcolumn = 0;
       			etpos = pattern[epnum[epchn]][eppos*4+3] - 1;
            if (etpos - etview < 0)
              etview = etpos;
            if (etpos - etview >= VISIBLETABLEROWS)
              etview = etpos - VISIBLETABLEROWS + 1;
            return;
          }
          break;

      	  case CMD_SETPULSEPTR:
      		if (pattern[epnum[epchn]][eppos*4+3])
       		{
       			editmode = EDIT_TABLES;
       			etnum = 1;
       			etcolumn = 0;
       			etpos = pattern[epnum[epchn]][eppos*4+3] - 1;
            if (etpos - etview < 0)
              etview = etpos;
            if (etpos - etview >= VISIBLETABLEROWS)
              etview = etpos - VISIBLETABLEROWS + 1;
            return;
          }
          break;

      	  case CMD_SETFILTERPTR:
       		if (pattern[epnum[epchn]][eppos*4+3])
      		{
       			editmode = EDIT_TABLES;
       			etnum = 2;
       			etcolumn = 0;
       			etpos = pattern[epnum[epchn]][eppos*4+3] - 1;
            if (etpos - etview < 0)
              etview = etpos;
            if (etpos - etview >= VISIBLETABLEROWS)
              etview = etpos - VISIBLETABLEROWS + 1;
            return;
          }
          break;
        }
      }
    }

    if (newnote >= 0)
    {
      if ((recordmode) && (eppos < pattlen[epnum[epchn]]))
      {
        pattern[epnum[epchn]][eppos*4] = newnote;
        if (newnote < REST)
        {
          pattern[epnum[epchn]][eppos*4+1] = einum;
        }
        else
        {
          pattern[epnum[epchn]][eppos*4+1] = 0;
        }
        if ((shiftpressed) && (newnote == REST))
        {
          pattern[epnum[epchn]][eppos*4+2] = 0;
          pattern[epnum[epchn]][eppos*4+3] = 0;
        }
      }
      if (recordmode)
      {
        if (autoadvance < 2)
        {
          eppos++;
          if (eppos > pattlen[epnum[epchn]])
          {
            eppos = 0;
          }
        }
      }
      playtestnote(newnote);
    }
  }
  switch(rawkey)
  {
    case KEY_Z:
    if (shiftpressed)
    {
      autoadvance++;
      if (autoadvance > 2) autoadvance = 0;
      if (keypreset == KEY_TRACKER)
      {
        if (autoadvance == 1) autoadvance = 2;
      }
    }
    break;

    case KEY_E:
    if ((shiftpressed) && (eppos < pattlen[epnum[epchn]]))
    {
      cmdcopybuffer = pattern[epnum[epchn]][eppos*4+2];
      cmddatacopybuffer = pattern[epnum[epchn]][eppos*4+3];
      cmdcopymode = 0;
    }
    break;

    case KEY_R:
    if ((shiftpressed) && (eppos < pattlen[epnum[epchn]]))
    {
    	if (!cmdcopymode)
    	{
        pattern[epnum[epchn]][eppos*4+2] = cmdcopybuffer;
        pattern[epnum[epchn]][eppos*4+3] = cmddatacopybuffer;
        eppos++;
      }
      else
      {
      	for (c = 0; c < patterncopyrows; c++)
        {
          if (eppos >= pattlen[epnum[epchn]]) break;
          pattern[epnum[epchn]][eppos*4+2] = patterncopybuffer[c*4+2];
          pattern[epnum[epchn]][eppos*4+3] = patterncopybuffer[c*4+3];
          eppos++;
        }
      }
    }
    break;

    case KEY_I:
    if (shiftpressed)
    {
     	int d, e;
     	char temp;
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
        	e = epmarkend;
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            for (d = 0; d < 4; d++)
            {
            	temp = pattern[epnum[epmarkchn]][c*4+d];
              pattern[epnum[epmarkchn]][c*4+d] = pattern[epnum[epmarkchn]][e*4+d];
              pattern[epnum[epmarkchn]][e*4+d] = temp;
            }
            e--;
            if (e < c) break;
          }
        }
        else
        {
        	e = epmarkstart;
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            for (d = 0; d < 4; d++)
            {
            	temp = pattern[epnum[epmarkchn]][c*4+d];
              pattern[epnum[epmarkchn]][c*4+d] = pattern[epnum[epmarkchn]][e*4+d];
              pattern[epnum[epmarkchn]][e*4+d] = temp;
            }
            e--;
            if (e < c) break;
          }
        }
      }
      else
      {
      	e = pattlen[epnum[epchn]] - 1;
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          for (d = 0; d < 4; d++)
          {
          	temp = pattern[epnum[epchn]][c*4+d];
            pattern[epnum[epchn]][c*4+d] = pattern[epnum[epchn]][e*4+d];
            pattern[epnum[epchn]][e*4+d] = temp;
          }
          e--;
          if (e < c) break;          
        }
      }
    }
    break;

    case KEY_Q:
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] < LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] >= FIRSTNOTE))
              pattern[epnum[epmarkchn]][c*4]++;
          }
        }
        else
        {
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] < LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] >= FIRSTNOTE))
              pattern[epnum[epmarkchn]][c*4]++;
          }
        }
      }
      else
      {
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          if ((pattern[epnum[epchn]][c*4] < LASTNOTE) &&
              (pattern[epnum[epchn]][c*4] >= FIRSTNOTE))
            pattern[epnum[epchn]][c*4]++;
        }
      }
    }
    break;

    case KEY_A:
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] <= LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] > FIRSTNOTE))
              pattern[epnum[epmarkchn]][c*4]--;
          }
        }
        else
        {
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] <= LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] > FIRSTNOTE))
              pattern[epnum[epmarkchn]][c*4]--;
          }
        }
      }
      else
      {
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          if ((pattern[epnum[epchn]][c*4] <= LASTNOTE) &&
              (pattern[epnum[epchn]][c*4] > FIRSTNOTE))
            pattern[epnum[epchn]][c*4]--;
        }
      }
    }
    break;

    case KEY_W:
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] <= LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] >= FIRSTNOTE))
            {
              pattern[epnum[epmarkchn]][c*4] += 12;
              if (pattern[epnum[epmarkchn]][c*4] > LASTNOTE)
                pattern[epnum[epmarkchn]][c*4] = LASTNOTE;
            }
          }
        }
        else
        {
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] <= LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] >= FIRSTNOTE))
            {
              pattern[epnum[epmarkchn]][c*4] += 12;
              if (pattern[epnum[epmarkchn]][c*4] > LASTNOTE)
                pattern[epnum[epmarkchn]][c*4] = LASTNOTE;
            }
          }
        }
      }
      else
      {
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          if ((pattern[epnum[epchn]][c*4] <= LASTNOTE) &&
              (pattern[epnum[epchn]][c*4] >= FIRSTNOTE))
          {
            pattern[epnum[epchn]][c*4] += 12;
            if (pattern[epnum[epchn]][c*4] > LASTNOTE)
              pattern[epnum[epchn]][c*4] = LASTNOTE;
          }
        }
      }
    }
    break;
    
    case KEY_S:
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] <= LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] >= FIRSTNOTE))
            {
              pattern[epnum[epmarkchn]][c*4] -= 12;
              if (pattern[epnum[epmarkchn]][c*4] < FIRSTNOTE)
                pattern[epnum[epmarkchn]][c*4] = FIRSTNOTE;
            }
          }
        }
        else
        {
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*4] <= LASTNOTE) &&
                (pattern[epnum[epmarkchn]][c*4] >= FIRSTNOTE))
            {
              pattern[epnum[epmarkchn]][c*4] -= 12;
              if (pattern[epnum[epmarkchn]][c*4] < FIRSTNOTE)
                pattern[epnum[epmarkchn]][c*4] = FIRSTNOTE;
            }
          }
        }
      }
      else
      {
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          if ((pattern[epnum[epchn]][c*4] <= LASTNOTE) &&
              (pattern[epnum[epchn]][c*4] >= FIRSTNOTE))
          {
            pattern[epnum[epchn]][c*4] -= 12;
            if (pattern[epnum[epchn]][c*4] < FIRSTNOTE)
              pattern[epnum[epchn]][c*4] = FIRSTNOTE;
          }
        }
      }
    }
    break;

    case KEY_M:
    if (shiftpressed)
    {
      stepsize++;
      if (stepsize > MAX_PATTROWS) stepsize = MAX_PATTROWS;
    }
    break;

    case KEY_N:
    if (shiftpressed)
    {
      stepsize--;
      if (stepsize < 2) stepsize = 2;
    }
    break;

    case KEY_L:
    if (shiftpressed)
    {
      if (epmarkchn == -1)
      {
        epmarkchn = epchn;
        epmarkstart = 0;
        epmarkend = pattlen[epnum[epchn]];
      }
      else epmarkchn = -1;
    }
    break;

    case KEY_C:
    case KEY_X:
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          int d = 0;
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            patterncopybuffer[d*4] = pattern[epnum[epmarkchn]][c*4];
            patterncopybuffer[d*4+1] = pattern[epnum[epmarkchn]][c*4+1];
            patterncopybuffer[d*4+2] = pattern[epnum[epmarkchn]][c*4+2];
            patterncopybuffer[d*4+3] = pattern[epnum[epmarkchn]][c*4+3];
            if (rawkey == KEY_X)
            {
              pattern[epnum[epmarkchn]][c*4] = REST;
              pattern[epnum[epmarkchn]][c*4+1] = 0;
              pattern[epnum[epmarkchn]][c*4+2] = 0;
              pattern[epnum[epmarkchn]][c*4+3] = 0;
            }  
            d++;
          }
          patterncopyrows = d;
          cmdcopymode = 1;
        }
        else
        {
          int d = 0;
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            patterncopybuffer[d*4] = pattern[epnum[epmarkchn]][c*4];
            patterncopybuffer[d*4+1] = pattern[epnum[epmarkchn]][c*4+1];
            patterncopybuffer[d*4+2] = pattern[epnum[epmarkchn]][c*4+2];
            patterncopybuffer[d*4+3] = pattern[epnum[epmarkchn]][c*4+3];
            if (rawkey == KEY_X)
            {
              pattern[epnum[epmarkchn]][c*4] = REST;
              pattern[epnum[epmarkchn]][c*4+1] = 0;
              pattern[epnum[epmarkchn]][c*4+2] = 0;
              pattern[epnum[epmarkchn]][c*4+3] = 0;
            }
            d++;
          }
          patterncopyrows = d;
          cmdcopymode = 1;
        }
        epmarkchn = -1;
      }
      else
      {
        int d = 0;
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          patterncopybuffer[d*4] = pattern[epnum[epchn]][c*4];
          patterncopybuffer[d*4+1] = pattern[epnum[epchn]][c*4+1];
          patterncopybuffer[d*4+2] = pattern[epnum[epchn]][c*4+2];
          patterncopybuffer[d*4+3] = pattern[epnum[epchn]][c*4+3];
          if (rawkey == KEY_X)
          {
            pattern[epnum[epchn]][c*4] = REST;
            pattern[epnum[epchn]][c*4+1] = 0;
            pattern[epnum[epchn]][c*4+2] = 0;
            pattern[epnum[epchn]][c*4+3] = 0;
          }
          d++;
        }
        patterncopyrows = d;
        cmdcopymode = 1;
      }
    }
    break;

    case KEY_V:
    if ((shiftpressed) && (patterncopyrows))
    {
      for (c = 0; c < patterncopyrows; c++)
      {
        if (eppos >= pattlen[epnum[epchn]]) break;
        pattern[epnum[epchn]][eppos*4] = patterncopybuffer[c*4];
        pattern[epnum[epchn]][eppos*4+1] = patterncopybuffer[c*4+1];
        pattern[epnum[epchn]][eppos*4+2] = patterncopybuffer[c*4+2];
        pattern[epnum[epchn]][eppos*4+3] = patterncopybuffer[c*4+3];
        eppos++;
      }
    }
    break;

    case KEY_DEL:
    if ((pattlen[epnum[epchn]]-eppos)*4-4 >= 0)
    {
      memmove(&pattern[epnum[epchn]][eppos*4],
        &pattern[epnum[epchn]][eppos*4+4],
        (pattlen[epnum[epchn]]-eppos)*4-4);
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-4] = REST;
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-3] = 0x00;
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-2] = 0x00;
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-1] = 0x00;
    }
    else
    {
      if (eppos == pattlen[epnum[epchn]])
      {
        if (pattlen[epnum[epchn]] > 1)
        {
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-4] = ENDPATT;
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-3] = 0x00;
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-2] = 0x00;
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*4-1] = 0x00;
          countthispattern();
          eppos = pattlen[epnum[epchn]];
        }
      }
    }
    break;

    case KEY_INS:
    if ((pattlen[epnum[epchn]]-eppos)*4-4 >= 0)
    {
      memmove(&pattern[epnum[epchn]][eppos*4+4],
        &pattern[epnum[epchn]][eppos*4],
        (pattlen[epnum[epchn]]-eppos)*4-4);
      pattern[epnum[epchn]][eppos*4] = REST;
      pattern[epnum[epchn]][eppos*4+1] = 0x00;
      pattern[epnum[epchn]][eppos*4+2] = 0x00;
      pattern[epnum[epchn]][eppos*4+3] = 0x00;
    }
    else
    {
      if (eppos == pattlen[epnum[epchn]])
      {
        if (pattlen[epnum[epchn]] < MAX_PATTROWS)
        {
          pattern[epnum[epchn]][eppos*4] = REST;
          pattern[epnum[epchn]][eppos*4+1] = 0x00;
          pattern[epnum[epchn]][eppos*4+2] = 0x00;
          pattern[epnum[epchn]][eppos*4+3] = 0x00;
          pattern[epnum[epchn]][eppos*4+4] = ENDPATT;
          pattern[epnum[epchn]][eppos*4+5] = 0x00;
          pattern[epnum[epchn]][eppos*4+6] = 0x00;
          pattern[epnum[epchn]][eppos*4+7] = 0x00;
          countthispattern();
          eppos = pattlen[epnum[epchn]];
        }
      }
    }
    break;

    case KEY_SPACE:
    recordmode ^= 1;
    break;

    case KEY_RIGHT:
    if (!shiftpressed)
    {
      epcolumn++;
      if (epcolumn >= 6)
      {
        epcolumn = 0;
        epchn++;
        if (epchn >= MAX_CHN) epchn = 0;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
    }
    else
    {
      if (epnum[epchn] < MAX_PATT-1)
      {
        epnum[epchn]++;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
      if (epchn == epmarkchn) epmarkchn = -1;
    }
    break;

    case KEY_LEFT:
    if (!shiftpressed)
    {
      epcolumn--;
      if (epcolumn < 0)
      {
        epcolumn = 5;
        epchn--;
        if (epchn < 0) epchn = MAX_CHN-1;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
    }
    else
    {
      if (epnum[epchn] > 0)
      {
        epnum[epchn]--;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
      if (epchn == epmarkchn) epmarkchn = -1;
    }
    break;

    case KEY_PGDN:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    for (scrrep = PGUPDNREPEAT; scrrep; scrrep--)
    {
      eppos++;
      if (eppos > pattlen[epnum[epchn]])
      {
        eppos = 0;
      }
    }
    if (shiftpressed) epmarkend = eppos;
    break;

    case KEY_DOWN:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos++;
    if (eppos > pattlen[epnum[epchn]])
    {
      eppos = 0;
    }
    if (shiftpressed) epmarkend = eppos;
    break;

    case KEY_HOME:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos = 0;
    if (shiftpressed) epmarkend = eppos;
    break;

    case KEY_END:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos = pattlen[epnum[epchn]];
    if (shiftpressed) epmarkend = eppos;
    break;

    case KEY_PGUP:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    for (scrrep = PGUPDNREPEAT; scrrep; scrrep--)
    {
      eppos--;
      if (eppos < 0)
      {
        eppos = pattlen[epnum[epchn]];
      }
    }
    if (shiftpressed) epmarkend = eppos;
    break;

    case KEY_UP:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos--;
    if (eppos < 0)
    {
      eppos = pattlen[epnum[epchn]];
    }
    if (shiftpressed) epmarkend = eppos;
    break;
  }
  if ((keypreset != KEY_TRACKER) && (hexnybble >= 1) && (hexnybble <= 7) && (!epcolumn))
  {
    int oldbyte = pattern[epnum[epchn]][eppos*4];
    epoctave = hexnybble;
    if ((oldbyte >= FIRSTNOTE) && (oldbyte <= LASTNOTE))
    {
      int newbyte;
      int oldnote = (oldbyte - FIRSTNOTE) %12;

      if (recordmode)
      {
        newbyte = oldnote+epoctave*12 + FIRSTNOTE;
        if (newbyte <= LASTNOTE)
        {
          pattern[epnum[epchn]][eppos*4] = newbyte;
        }
      }
      if ((recordmode) && (autoadvance < 1))
      {
        eppos++;
        if (eppos > pattlen[epnum[epchn]])
        {
          eppos = 0;
        }
      }
    }
  }

  if ((hexnybble >= 0) && (epcolumn) && (recordmode))
  {
    if (eppos < pattlen[epnum[epchn]])
    {
      switch(epcolumn)
      {
        case 1:
        pattern[epnum[epchn]][eppos*4+1] &= 0x0f;
        pattern[epnum[epchn]][eppos*4+1] |= hexnybble << 4;
        pattern[epnum[epchn]][eppos*4+1] &= (MAX_INSTR - 1);
        break;

        case 2:
        pattern[epnum[epchn]][eppos*4+1] &= 0xf0;
        pattern[epnum[epchn]][eppos*4+1] |= hexnybble;
        pattern[epnum[epchn]][eppos*4+1] &= (MAX_INSTR - 1);        
        break;

        case 3:
        pattern[epnum[epchn]][eppos*4+2] = hexnybble;
        if (!pattern[epnum[epchn]][eppos*4+2])
          pattern[epnum[epchn]][eppos*4+3] = 0;
        break;

        case 4:
        pattern[epnum[epchn]][eppos*4+3] &= 0x0f;
        pattern[epnum[epchn]][eppos*4+3] |= hexnybble << 4;
        if (!pattern[epnum[epchn]][eppos*4+2])
          pattern[epnum[epchn]][eppos*4+3] = 0;
        break;

        case 5:
        pattern[epnum[epchn]][eppos*4+3] &= 0xf0;
        pattern[epnum[epchn]][eppos*4+3] |= hexnybble;
        if (!pattern[epnum[epchn]][eppos*4+2])
          pattern[epnum[epchn]][eppos*4+3] = 0;
        break;
      }
    }
    if (autoadvance < 2)
    {
      eppos++;
      if (eppos > pattlen[epnum[epchn]])
      {
        eppos = 0;
      }
    }
  }
  epview = eppos-VISIBLEPATTROWS/2;
}

void countpatternlengths(void)
{
  int c, d, e;

  highestusedpattern = 0;
  highestusedinstr = 0;
  for (c = 0; c < MAX_PATT; c++)
  {
    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      if (pattern[c][d*4] == ENDPATT) break;
      if ((pattern[c][d*4] != REST) || (pattern[c][d*4+1]) || (pattern[c][d*4+2]) || (pattern[c][d*4+3]))
        highestusedpattern = c;
      if (pattern[c][d*4+1] > highestusedinstr) highestusedinstr = pattern[c][d*4+1];
    }
    pattlen[c] = d;
  }

  for (e = 0; e < MAX_SONGS; e++)
  {
    for (c = 0; c < MAX_CHN; c++)
    {
      for (d = 0; d < MAX_SONGLEN; d++)
      {
        if (songorder[e][c][d] >= LOOPSONG) break;
        if ((songorder[e][c][d] < REPEAT) && (songorder[e][c][d] > highestusedpattern))
          highestusedpattern = songorder[e][c][d];       
      }
      songlen[e][c] = d;
    }
  }
}

void countthispattern(void)
{
  int c, d, e;

  c = epnum[epchn];
  for (d = 0; d <= MAX_PATTROWS; d++)
  {
    if (pattern[c][d*4] == ENDPATT) break;
  }
  pattlen[c] = d;

  e = esnum;
  c = eschn;
  for (d = 0; d < MAX_SONGLEN; d++)
  {
    if (songorder[e][c][d] >= LOOPSONG) break;
    if (songorder[e][c][d] > highestusedpattern)
      highestusedpattern = songorder[e][c][d];
  }
  songlen[e][c] = d;
}



