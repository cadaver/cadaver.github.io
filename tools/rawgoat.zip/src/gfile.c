//
// GOATTRACKER v2 file operations
//

#include "goattrk2.h"

void savesong(void)
{
  int c;
  char ident[] = {'G', 'T', 'S', '2'};
  FILE *handle;

  if (strlen(songfilename) < MAX_FILENAME-4)
  {
    int extfound = 0;
    for (c = strlen(songfilename)-1; c >= 0; c--)
    {
      if (songfilename[c] == '.') extfound = 1;
    }
    if (!extfound) strcat(songfilename, ".sng");
  }
  handle = fopen(songfilename, "wb");
  if (handle)
  {
    int d;
    int length;
    int amount;
    int writebytes;
    fwrite(ident, 4, 1, handle);

    // Determine amount of patterns & instruments
    countpatternlengths();
    for (c = 1; c < MAX_INSTR; c++)
    {
    	if ((instr[c].ad) || (instr[c].sr) || (instr[c].ptr[0]) || (instr[c].ptr[1]) ||
          (instr[c].ptr[2]) || (instr[c].vibdelay) || (instr[c].vibparam))
      {
      	if (c > highestusedinstr) highestusedinstr = c;
      }
    }

    // Write infotexts
    fwrite(songname, sizeof songname, 1, handle);
    fwrite(authorname, sizeof authorname, 1, handle);
    fwrite(copyrightname, sizeof copyrightname, 1, handle);

    // Determine amount of songs to be saved
    c = MAX_SONGS - 1;
    for (;;)
    {
      if ((songlen[c][0])&&
         (songlen[c][1])&&
         (songlen[c][2])) break;
      if (c == 0) break;
      c--;
    }
    amount = c + 1;

    fwrite8(handle, amount);
    // Write songorderlists
    for (d = 0; d < amount; d++)
    {
      for (c = 0; c < MAX_CHN; c++)
      {
        length = songlen[d][c]+1;
        fwrite8(handle, length);
        writebytes = length;
        writebytes++;
        fwrite(songorder[d][c], writebytes, 1, handle);
      }
    }
    // Write amount of instruments
    fwrite8(handle, highestusedinstr);
    // Write instruments
    for (c = 1; c <= highestusedinstr; c++)
    {
      fwrite8(handle, instr[c].ad);
      fwrite8(handle, instr[c].sr);
      fwrite8(handle, instr[c].ptr[WTBL]);
      fwrite8(handle, instr[c].ptr[PTBL]);
      fwrite8(handle, instr[c].ptr[FTBL]);
      fwrite8(handle, instr[c].vibdelay);
      fwrite8(handle, instr[c].vibparam);
      fwrite8(handle, instr[c].gatetimer);
      fwrite8(handle, instr[c].firstwave);
      fwrite(&instr[c].name, MAX_INSTRNAMELEN, 1, handle);
    }
    // Write tables
    for (c = 0; c < MAX_TABLES; c++)
    {
      writebytes = gettablelen(c);
      fwrite8(handle, writebytes);
      fwrite(ltable[c], writebytes, 1, handle);
      fwrite(rtable[c], writebytes, 1, handle);
    }
    // Write patterns
    amount = highestusedpattern + 1;
    fwrite8(handle, amount);
    for (c = 0; c < amount; c++)
    {
      length = pattlen[c]+1;
      fwrite8(handle, length);
      fwrite(pattern[c], length * 4, 1, handle);
    }
    fclose(handle);
    strcpy(loadedsongfilename, songfilename);
  }
}

void saveinstrument(void)
{
  int c;
  char ident[] = {'G', 'T', 'I', '2'};
  FILE *handle;

  if (strlen(instrfilename) < MAX_FILENAME-4)
  {
    int extfound = 0;
    for (c = strlen(instrfilename)-1; c >= 0; c--)
    {
      if (instrfilename[c] == '.') extfound = 1;
    }
    if (!extfound) strcat(instrfilename, ".ins");
  }

  handle = fopen(instrfilename, "wb");
  if (handle)
  {
    fwrite(ident, 4, 1, handle);

    // Write instrument
    fwrite8(handle, instr[einum].ad);
    fwrite8(handle, instr[einum].sr);
    fwrite8(handle, instr[einum].ptr[WTBL]);
    fwrite8(handle, instr[einum].ptr[PTBL]);
    fwrite8(handle, instr[einum].ptr[FTBL]);
    fwrite8(handle, instr[einum].vibdelay);
    fwrite8(handle, instr[einum].vibparam);
    fwrite8(handle, instr[einum].gatetimer);
    fwrite8(handle, instr[einum].firstwave);
    fwrite(&instr[einum].name, MAX_INSTRNAMELEN, 1, handle);
    for (c = 0; c < MAX_TABLES; c++)
    {
      if (instr[einum].ptr[c])
      {
      	int pos = instr[einum].ptr[c] - 1;
        int len = gettablepartlen(c, pos);
        fwrite8(handle, len);
        fwrite(&ltable[c][pos], len, 1, handle);
        fwrite(&rtable[c][pos], len, 1, handle);
      }
      else fwrite8(handle, 0);
    }
    fclose(handle);
  }
}

void loadsong(void)
{
  int c;
  int ok = 0;
  char ident[4];
  FILE *handle;

  handle = fopen(songfilename, "rb");
  if (handle)
  {
    fread(ident, 4, 1, handle);
    if (!memcmp(ident, "GTS2", 4))
    {
      int d;
      int length;
      int amount;
      int loadsize;
      clearsong(1,1,1,1,1);
      ok = 1;

      // Read infotexts
      fread(songname, sizeof songname, 1, handle);
      fread(authorname, sizeof authorname, 1, handle);
      fread(copyrightname, sizeof copyrightname, 1, handle);

      // Read songorderlists
      amount = fread8(handle);
      for (d = 0; d < amount; d++)
      {
        for (c = 0; c < MAX_CHN; c++)
        {
          length = fread8(handle);
          loadsize = length;
          loadsize++;
          fread(songorder[d][c], loadsize, 1, handle);
        }
      }
      // Read instruments
      amount = fread8(handle);
      for (c = 1; c <= amount; c++)
      {
        instr[c].ad = fread8(handle);
        instr[c].sr = fread8(handle);
        instr[c].ptr[WTBL] = fread8(handle);
        instr[c].ptr[PTBL] = fread8(handle);
        instr[c].ptr[FTBL] = fread8(handle);
        instr[c].vibdelay = fread8(handle);
        instr[c].vibparam = fread8(handle);
        instr[c].gatetimer = fread8(handle);
        instr[c].firstwave = fread8(handle);
        fread(&instr[c].name, MAX_INSTRNAMELEN, 1, handle);
      }
      // Read tables
      for (c = 0; c < MAX_TABLES; c++)
      {
        loadsize = fread8(handle);
        fread(ltable[c], loadsize, 1, handle);
        fread(rtable[c], loadsize, 1, handle);
      }
      // Read patterns
      amount = fread8(handle);
      for (c = 0; c < amount; c++)
      {
        length = fread8(handle) * 4;
        fread(pattern[c], length, 1, handle);
      }
      countpatternlengths();
      for (c = 0; c < MAX_CHN; c++)
      {
        espos[c] = 0;
        if (songlen[esnum][c])
        {
          eppos = 0;
          epview = - VISIBLEPATTROWS/2;
          if (songorder[esnum][c][0] < MAX_PATT)
            epnum[c] = songorder[esnum][c][0];
          else
          {
            if (songorder[esnum][c][1] < MAX_PATT)
              epnum[c] = songorder[esnum][c][1];
            else
              epnum[c] = c;
          }
        }
      }
    }
    // Goattracker 1.xx import
    if (!memcmp(ident, "GTS!", 4))
    {
      int d;
      int length;
      int amount;
      int loadsize;
      int fw = 0;
      int fp = 0;
      int ff = 0;
      int fi = 0;
      int numfilter = 0;
      unsigned char filtertable[256];
      unsigned char filtermap[64];
      int arpmap[32][256];
      unsigned char pulse[32], pulseadd[32], pulselimitlow[32], pulselimithigh[32];
      int filterjumppos[64];

      clearsong(1,1,1,1,1);
      ok = 1;

      // Read infotexts
      fread(songname, sizeof songname, 1, handle);
      fread(authorname, sizeof authorname, 1, handle);
      fread(copyrightname, sizeof copyrightname, 1, handle);

      // Read songorderlists
      amount = fread8(handle);
      for (d = 0; d < amount; d++)
      {
        for (c = 0; c < MAX_CHN; c++)
        {
          length = fread8(handle);
          loadsize = length;
          loadsize++;
          fread(songorder[d][c], loadsize, 1, handle);
        }
      }

      // Convert instruments
      for (c = 1; c < 32; c++)
      {
      	unsigned char wavelen;

 	      instr[c].ad = fread8(handle);
        instr[c].sr = fread8(handle);
        pulse[c] = fread8(handle);
        pulseadd[c] = fread8(handle);
        pulselimitlow[c] = fread8(handle);
        pulselimithigh[c] = fread8(handle);
        instr[c].ptr[FTBL] = fread8(handle); // Will be converted later
        if (instr[c].ptr[FTBL] > numfilter) numfilter = instr[c].ptr[FTBL];
        if (pulse[c] & 1) instr[c].firstwave |= 0x80; // "No hardrestart" flag
        pulse[c] &= 0xfe;
        wavelen = fread8(handle)/2;
        fread(&instr[c].name, MAX_INSTRNAMELEN, 1, handle);
        instr[c].ptr[WTBL] = fw+1;

        // Convert wavetable
        for (d = 0; d < wavelen; d++)
        {
          if (fw < MAX_TABLELEN)
          {
          	ltable[WTBL][fw] = fread8(handle);
          	rtable[WTBL][fw] = fread8(handle);
          	if (ltable[WTBL][fw] == 0xff)
          	  if (rtable[WTBL][fw]) rtable[WTBL][fw] += instr[c].ptr[WTBL]-1;
          	fw++;
          }
          else
          {
          	fread8(handle);
          	fread8(handle);
          }
        }

        // Remove empty wavetable afterwards
        if ((wavelen == 2) && (!ltable[WTBL][fw-2]) && (!rtable[WTBL][fw-2]))
        {
          instr[c].ptr[WTBL] = 0;
          fw -= 2;
          ltable[WTBL][fw] = 0;
          rtable[WTBL][fw] = 0;
          ltable[WTBL][fw+1] = 0;
          rtable[WTBL][fw+1] = 0;
        }

        // Convert pulsetable
        if (pulse[c])
        {
        	int pulsetime, pulsedist, hlpos;

          // Check for duplicate pulse settings
        	for (d = 1; d < c; d++)
        	{
        	  if ((pulse[d] == pulse[c]) && (pulseadd[d] == pulseadd[c]) && (pulselimitlow[d] == pulselimitlow[c]) &&
                (pulselimithigh[d] == pulselimithigh[c]))
            {
            	instr[c].ptr[PTBL] = instr[d].ptr[PTBL];
            	goto PULSEDONE;
            }
          }

        	// Initial pulse setting
        	if (fp >= MAX_TABLELEN) goto PULSEDONE;
        	instr[c].ptr[PTBL] = fp+1;
        	ltable[PTBL][fp] = 0x80 | (pulse[c] >> 4);
        	rtable[PTBL][fp] = pulse[c] << 4;
        	fp++;

        	// Pulse modulation
        	if (pulseadd[c])
        	{
        		int startpulse = pulse[c]*16;
            int currentpulse = pulse[c]*16;
        		// Phase 1: From startpos to high limit
            pulsedist = pulselimithigh[c]*16 - currentpulse;
            if (pulsedist > 0)
            {
              pulsetime = pulsedist/pulseadd[c];
              currentpulse += pulsetime*pulseadd[c];
              while (pulsetime)
              {
              	int acttime = pulsetime;
              	if (acttime > 127) acttime = 127;
              	if (fp >= MAX_TABLELEN) goto PULSEDONE;
                ltable[PTBL][fp] = acttime;
                rtable[PTBL][fp] = pulseadd[c] / 2;
                fp++;
                pulsetime -= acttime;
              }
            }

            hlpos = fp;
            // Phase 2: from high limit to low limit
            pulsedist = currentpulse - pulselimitlow[c]*16;
            if (pulsedist > 0)
            {
              pulsetime = pulsedist/pulseadd[c];
              currentpulse -= pulsetime*pulseadd[c];
              while (pulsetime)
              {
              	int acttime = pulsetime;
              	if (acttime > 127) acttime = 127;
              	if (fp >= MAX_TABLELEN) goto PULSEDONE;
                ltable[PTBL][fp] = acttime;
                rtable[PTBL][fp] = -(pulseadd[c] / 2);
                fp++;
                pulsetime -= acttime;
              }
            }

            // Phase 3: from low limit back to startpos/high limit
            if ((startpulse < pulselimithigh[c]*16) && (startpulse > currentpulse))
            {
              pulsedist = startpulse - currentpulse;
              if (pulsedist > 0)
              {
                pulsetime = pulsedist/pulseadd[c];
                while (pulsetime)
                {
                	int acttime = pulsetime;
                	if (acttime > 127) acttime = 127;
                	if (fp >= MAX_TABLELEN) goto PULSEDONE;
                  ltable[PTBL][fp] = acttime;
                  rtable[PTBL][fp] = pulseadd[c] / 2;
                  fp++;
                  pulsetime -= acttime;
                }
              }
              // Pulse jump back to beginning
            	if (fp >= MAX_TABLELEN) goto PULSEDONE;
             	ltable[PTBL][fp] = 0xff;
             	rtable[PTBL][fp] = instr[c].ptr[PTBL] + 1;
             	fp++;
            }
            else
            {
              pulsedist = pulselimithigh[c]*16 - currentpulse;
              if (pulsedist > 0)
              {
                pulsetime = pulsedist/pulseadd[c];
                while (pulsetime)
                {
                	int acttime = pulsetime;
                	if (acttime > 127) acttime = 127;
                	if (fp >= MAX_TABLELEN) goto PULSEDONE;
                  ltable[PTBL][fp] = acttime;
                  rtable[PTBL][fp] = pulseadd[c] / 2;
                  fp++;
                  pulsetime -= acttime;
                }
              }
              // Pulse jump back to beginning
            	if (fp >= MAX_TABLELEN) goto PULSEDONE;
             	ltable[PTBL][fp] = 0xff;
             	rtable[PTBL][fp] = hlpos + 1;
             	fp++;
            }
          }
          else
          {
          	// Pulse stopped
          	if (fp >= MAX_TABLELEN) goto PULSEDONE;
          	ltable[PTBL][fp] = 0xff;
          	rtable[PTBL][fp] = 0;
          	fp++;
          }
          PULSEDONE: {}
        }
      }
      // Convert patterns
      amount = fread8(handle);
      for (c = 0; c < amount; c++)
      {
        length = fread8(handle);
        for (d = 0; d < length/3; d++)
        {
        	unsigned char note, cmd, data, instr;
          note = fread8(handle);
          cmd = fread8(handle);
          data = fread8(handle);
          instr = cmd >> 3;
          cmd &= 7;

          switch(note)
          {
          	default:
          	note += FIRSTNOTE;
          	if (note > LASTNOTE) note = REST;
          	break;

            case OLDKEYOFF:
          	note = KEYOFF;
          	break;

            case OLDREST:
          	note = REST;
          	break;

           	case ENDPATT:
           	break;
          }
          switch(cmd)
          {
            case 5:
            cmd = CMD_SETFILTERPTR;
            if (data > numfilter) numfilter = data;
            break;

          	case 7:
          	if (data < 0xf0)
            	cmd = CMD_SETTEMPO;
            else
            {
            	cmd = CMD_SETMASTERVOL;
            	data &= 0x0f;
            }
           	break;
          }
          pattern[c][d*4] = note;
          pattern[c][d*4+1] = instr;
          pattern[c][d*4+2] = cmd;
          pattern[c][d*4+3] = data;
        }
      }
      countpatternlengths();
      fi = highestusedinstr + 1;
      for (c = 0; c < MAX_CHN; c++)
      {
        espos[c] = 0;
        if (songlen[esnum][c])
        {
          eppos = 0;
          epview = - VISIBLEPATTROWS/2;
          if (songorder[esnum][c][0] < MAX_PATT)
            epnum[c] = songorder[esnum][c][0];
          else
          {
            if (songorder[esnum][c][1] < MAX_PATT)
              epnum[c] = songorder[esnum][c][1];
            else
              epnum[c] = c;
          }
        }
      }
      // Read filtertable
      fread(filtertable, 256, 1, handle);

      // Convert filtertable
      for (c = 0; c < 64; c++)
      {
      	filterjumppos[c] = -1;
      	filtermap[c] = 0;
      	if (filtertable[c*4+3] > numfilter) numfilter = filtertable[c*4+3];
      }

      if (numfilter > 63) numfilter = 63;

      for (c = 1; c <= numfilter; c++)
      {
      	filtermap[c] = ff+1;

        if (filtertable[c*4]|filtertable[c*4+1]|filtertable[c*4+2]|filtertable[c*4+3])
        {
          // Filter set
        	if (filtertable[c*4])
        	{
        		ltable[FTBL][ff] = 0x80 + (filtertable[c*4+1] & 0x70) + (filtertable[c*4] & 0xf);
        		rtable[FTBL][ff] = filtertable[c*4+2];
        		ff++;
        	}
          else
          {
          	// Filter modulation
          	int time = filtertable[c*4+1];

          	while (time)
          	{
          		int acttime = time;
          		if (acttime > 127) acttime = 127;
          		ltable[FTBL][ff] = acttime;
          		rtable[FTBL][ff] = filtertable[c*4+2];
          		ff++;
          		time -= acttime;
          	}
          }

          // Jump to next step: unnecessary if follows directly
          if (filtertable[c*4+3] != c+1)
          {
            filterjumppos[c] = ff;
            ltable[FTBL][ff] = 0xff;
            rtable[FTBL][ff] = filtertable[c*4+3]; // Fix the jump later
            ff++;
          }
        }
      }

      // Now fix jumps as the filterstep mapping is known
      for (c = 1; c <= numfilter; c++)
      {
      	if (filterjumppos[c] != -1)
      		rtable[FTBL][filterjumppos[c]] = filtermap[rtable[FTBL][filterjumppos[c]]];
      }

      // Fix filterpointers in instruments
      for (c = 1; c < 32; c++)
      	instr[c].ptr[FTBL] = filtermap[instr[c].ptr[FTBL]];

      // Now fix filterjumps in patterns and convert arpeggios & funktempos
      memset(arpmap, 0, sizeof arpmap);
      for (c = 0; c < MAX_PATT; c++)
      {
      	unsigned char i = 0;
        for (d = 0; d <= MAX_PATTROWS; d++)
        {
        	if (pattern[c][d*4+1]) i = pattern[c][d*4+1];

          // Convert filterjump
          if (pattern[c][d*4+2] == CMD_SETFILTERPTR)
          	pattern[c][d*4+3] = filtermap[pattern[c][d*4+3]];

          // Convert funktempo
          if ((pattern[c][d*4+2] == CMD_SETTEMPO) && (!pattern[c][d*4+3]))
          {
            pattern[c][d*4+2] = CMD_DONOTHING;
            pattern[c][d*4+3] = 0;
          }
          // Convert arpeggio
          if ((pattern[c][d*4+2] == CMD_DONOTHING) && (pattern[c][d*4+3]))
          {
          	// Must be in conjunction with a note
          	if ((pattern[c][d*4] >= FIRSTNOTE) && (pattern[c][d*4] <= LASTNOTE))
          	{
            	unsigned char param = pattern[c][d*4+3];
              if (i)
              {
              	// Old arpeggio
              	if (arpmap[i][param])
                {
                  // As command, or as instrument?
                	if (arpmap[i][param] < 256)
                	{
                  	pattern[c][d*4+2] = CMD_SETWAVEPTR;
                  	pattern[c][d*4+3] = arpmap[i][param];
                  }
                  else
                  {
                  	pattern[c][d*4+1] = arpmap[i][param] - 256;
                  	pattern[c][d*4+3] = 0;
                  }
                }
                else
                {
                	int e;
                	unsigned char arpstart;
                  unsigned char arploop;

                  // New arpeggio
                  // Copy first the instrument's wavetable up to loop/end point
                	arpstart = fw + 1;
                  if (instr[i].ptr[WTBL])
                  {
                    for (e = instr[i].ptr[WTBL]-1;; e++)
                    {
                    	if (ltable[WTBL][e] == 0xff) break;
                    	if (fw < MAX_TABLELEN)
                    	{
                        ltable[WTBL][fw] = ltable[WTBL][e];
                        fw++;
                      }
                    }
                  }
                  // Then make the arpeggio
                  arploop = fw + 1;
                  if (fw < MAX_TABLELEN-3)
                  {
                  	ltable[WTBL][fw] = 0;
                  	rtable[WTBL][fw] = (param  & 0x70) >> 4;
                  	fw++;
                  	if (param & 0x80)
                  	{
                    	ltable[WTBL][fw] = 0;
                    	rtable[WTBL][fw] = (param  & 0x70) >> 4;
                    	fw++;
                    }
                  	ltable[WTBL][fw] = 0;
                  	rtable[WTBL][fw] = (param & 0xf);
                  	fw++;
                  	if (param & 0x80)
                  	{
                    	ltable[WTBL][fw] = 0;
                    	rtable[WTBL][fw] = (param & 0xf);
                    	fw++;
                    }
                  	ltable[WTBL][fw] = 0;
                  	rtable[WTBL][fw] = 0;
                  	fw++;
                  	if (param & 0x80)
                  	{
                    	ltable[WTBL][fw] = 0;
                    	rtable[WTBL][fw] = 0;
                    	fw++;
                    } 
                   	ltable[WTBL][fw] = 0xff;
                  	rtable[WTBL][fw] = arploop;
                  	fw++;

                    // Create new instrument if possible
                    if (fi < MAX_INSTR)
                    {
                    	arpmap[i][param] = fi + 256;
                    	instr[fi] = instr[i];
                    	instr[fi].ptr[WTBL] = arpstart;
                    	// Add arpeggio parameter to new instrument name
                      if (strlen(instr[fi].name) < MAX_INSTRNAMELEN-3)
                    	{
                    		char arpname[8];
                    		sprintf(arpname, "0%02X", param&0x7f);
                    		strcat(instr[fi].name, arpname);
                    	}
                    	fi++;
                    }
                    else
                    {
                    	arpmap[i][param] = arpstart;
                    }
                  }

                	if (arpmap[i][param])
                  {
                    // As command, or as instrument?
                  	if (arpmap[i][param] < 256)
                  	{
                    	pattern[c][d*4+2] = CMD_SETWAVEPTR;
                    	pattern[c][d*4+3] = arpmap[i][param];
                    }
                    else
                    {
                    	pattern[c][d*4+1] = arpmap[i][param] - 256;
                    	pattern[c][d*4+3] = 0;
                    }
                  }
                }
              }
            }
            // If arpeggio could not be converted, databyte zero
            if (!pattern[c][d*4+2])
              pattern[c][d*4+3] = 0;
          }
        }
      }
    }
    fclose(handle);
  }
  if (ok) strcpy(loadedsongfilename, songfilename);
}

void loadinstrument(void)
{
  char ident[4];
  FILE *handle;
  int c,d;

  handle = fopen(instrfilename, "rb");
  if (handle)
  {
    songinit = 0x04;
    fread(ident, 4, 1, handle);
    if (!memcmp(ident, "GTI2", 4))
    {
    	unsigned char optr[3];
      
      instr[einum].ad = fread8(handle);
      instr[einum].sr = fread8(handle);
      optr[0] = fread8(handle);
      optr[1] = fread8(handle);
      optr[2] = fread8(handle);
      instr[einum].vibdelay = fread8(handle);
      instr[einum].vibparam = fread8(handle);
      instr[einum].gatetimer = fread8(handle);
      instr[einum].firstwave = fread8(handle);
      fread(&instr[einum].name, MAX_INSTRNAMELEN, 1, handle);

      // Erase old tabledata
      deleteinstrtable(einum);

      // Load new tabledata
      for (c = 0; c < 3; c++)
      {
      	int start = gettablelen(c);
        int len = fread8(handle);

        if (len)
        {
          for (d = start; (d < start+len) && (d < MAX_TABLELEN); d++)
          	ltable[c][d] = fread8(handle);
          while (d < start+len)
          {
          	fread8(handle);
          	d++;
          }
          for (d = start; (d < start+len) && (d < MAX_TABLELEN); d++)
          	rtable[c][d] = fread8(handle);
          while (d < start+len)
          {
          	fread8(handle);
          	d++;
          }
          for (d = start; (d < start+len) && (d < MAX_TABLELEN); d++)
          {
          	if (ltable[c][d] == 0xff)
          	{
          		if (rtable[c][d])
             		rtable[c][d] = rtable[c][d] - optr[c] + start + 1;
            }
          }
          instr[einum].ptr[c] = start + 1;
        }
      }
    }
    // Goattracker 1.xx import
    if (!memcmp(ident, "GTI!", 4))
    {

    	unsigned char pulse, pulseadd, pulselimitlow, pulselimithigh, wavelen;
    	unsigned char filtertemp[4];
    	int fw, fp, ff;

      // Erase old tabledata
    	deleteinstrtable(einum);

      fw = gettablelen(WTBL);
      fp = gettablelen(PTBL);
      ff = gettablelen(FTBL);

      instr[einum].ad = fread8(handle);
      instr[einum].sr = fread8(handle);
      if (multiplier)
        instr[einum].gatetimer = 2 * multiplier;
      else
        instr[einum].gatetimer = 1;
      instr[einum].firstwave = 0x9;
      pulse = fread8(handle);
      pulseadd = fread8(handle);
      pulselimitlow = fread8(handle);
      pulselimithigh = fread8(handle);
      instr[einum].ptr[FTBL] = fread8(handle) ? ff+1 : 0;
      if (pulse & 1) instr[einum].firstwave |= 0x80; // "No hardrestart" flag
        wavelen = fread8(handle)/2;
      fread(&instr[einum].name, MAX_INSTRNAMELEN, 1, handle);
      instr[einum].ptr[WTBL] = fw+1;

      // Convert wavetable
      for (d = 0; d < wavelen; d++)
      {
        if (fw < MAX_TABLELEN)
        {
        	ltable[WTBL][fw] = fread8(handle);
         	rtable[WTBL][fw] = fread8(handle);
         	if (ltable[WTBL][fw] == 0xff)
         	  if (rtable[WTBL][fw]) rtable[WTBL][fw] += instr[einum].ptr[WTBL]-1;
         	fw++;
        }
        else
        {
        	fread8(handle);
        	fread8(handle);
        }
      }

      // Remove empty wavetable afterwards
      if ((wavelen == 2) && (!ltable[WTBL][fw-2]) && (!rtable[WTBL][fw-2]))
      {
        instr[einum].ptr[WTBL] = 0;
        fw -= 2;
        ltable[WTBL][fw] = 0;
        rtable[WTBL][fw] = 0;
        ltable[WTBL][fw+1] = 0;
        rtable[WTBL][fw+1] = 0;
      }

      // Convert pulsetable
      pulse &= 0xfe;
      if (pulse)
      {
      	int pulsetime, pulsedist, hlpos;

       	// Initial pulse setting
       	if (fp >= MAX_TABLELEN) goto PULSEDONE;
       	instr[einum].ptr[PTBL] = fp+1;
       	ltable[PTBL][fp] = 0x80 | (pulse >> 4);
       	rtable[PTBL][fp] = pulse << 4;
       	fp++;

      	// Pulse modulation
       	if (pulseadd)
       	{
       		int startpulse = pulse*16;
          int currentpulse = pulse*16;
      		// Phase 1: From startpos to high limit
          pulsedist = pulselimithigh*16 - currentpulse;
          if (pulsedist > 0)
          {
            pulsetime = pulsedist/pulseadd;
            currentpulse += pulsetime*pulseadd;
            while (pulsetime)
            {
            	int acttime = pulsetime;
            	if (acttime > 127) acttime = 127;
            	if (fp >= MAX_TABLELEN) goto PULSEDONE;
              ltable[PTBL][fp] = acttime;
              rtable[PTBL][fp] = pulseadd / 2;
              fp++;
              pulsetime -= acttime;
            }
          }

          hlpos = fp;
          // Phase 2: from high limit to low limit
          pulsedist = currentpulse - pulselimitlow*16;
          if (pulsedist > 0)
          {
            pulsetime = pulsedist/pulseadd;
            currentpulse -= pulsetime*pulseadd;
            while (pulsetime)
            {
            	int acttime = pulsetime;
            	if (acttime > 127) acttime = 127;
            	if (fp >= MAX_TABLELEN) goto PULSEDONE;
              ltable[PTBL][fp] = acttime;
              rtable[PTBL][fp] = -(pulseadd / 2);
              fp++;
              pulsetime -= acttime;
            }
          }

          // Phase 3: from low limit back to startpos/high limit
          if ((startpulse < pulselimithigh*16) && (startpulse > currentpulse))
          {
            pulsedist = startpulse - currentpulse;
            if (pulsedist > 0)
            {
              pulsetime = pulsedist/pulseadd;
              while (pulsetime)
              {
              	int acttime = pulsetime;
              	if (acttime > 127) acttime = 127;
              	if (fp >= MAX_TABLELEN) goto PULSEDONE;
                ltable[PTBL][fp] = acttime;
                rtable[PTBL][fp] = pulseadd / 2;
                fp++;
                pulsetime -= acttime;
              }
            }
            // Pulse jump back to beginning
          	if (fp >= MAX_TABLELEN) goto PULSEDONE;
           	ltable[PTBL][fp] = 0xff;
           	rtable[PTBL][fp] = instr[einum].ptr[PTBL] + 1;
           	fp++;
          }
          else
          {
            pulsedist = pulselimithigh*16 - currentpulse;
            if (pulsedist > 0)
            {
              pulsetime = pulsedist/pulseadd;
              while (pulsetime)
              {
              	int acttime = pulsetime;
              	if (acttime > 127) acttime = 127;
              	if (fp >= MAX_TABLELEN) goto PULSEDONE;
                ltable[PTBL][fp] = acttime;
                rtable[PTBL][fp] = pulseadd / 2;
                fp++;
                pulsetime -= acttime;
              }
            }
            // Pulse jump back to beginning
          	if (fp >= MAX_TABLELEN) goto PULSEDONE;
           	ltable[PTBL][fp] = 0xff;
           	rtable[PTBL][fp] = hlpos + 1;
           	fp++;
          }
        }
        else
        {
        	// Pulse stopped
        	if (fp >= MAX_TABLELEN) goto PULSEDONE;
        	ltable[PTBL][fp] = 0xff;
        	rtable[PTBL][fp] = 0;
        	fp++;
        }
        PULSEDONE: {}
      }

      // Convert filter (if any)
      if ((instr[einum].ptr[FTBL]) && (ff < MAX_TABLELEN-2))
      {
      	fread(filtertemp, sizeof filtertemp, 1, handle);
        // Filter set
        if (filtertemp[0])
        {
          ltable[FTBL][ff] = 0x80 + (filtertemp[1] & 0x70);
          rtable[FTBL][ff] = filtertemp[0];
          ff++;
          if (filtertemp[2])
          {
          	ltable[FTBL][ff] = 0x00;
          	rtable[FTBL][ff] = filtertemp[2];
          	ff++;
          }
        }
        else
        {
        	// Filter modulation
        	int time = filtertemp[1];

        	while (time)
        	{
        		int acttime = time;
        		if (acttime > 127) acttime = 127;
        		ltable[FTBL][ff] = acttime;
        		rtable[FTBL][ff] = filtertemp[2];
        		ff++;
        		time -= acttime;
        	}
        }

        // Jump to next step: always end the filter
        ltable[FTBL][ff] = 0xff;
        rtable[FTBL][ff] = 0;
        ff++;
      }
    }
    fclose(handle);
  }
}

int fileselector(char *name, char *path, char *filter, char *title, int initialmode)
{
  DIR *dir;
  struct dirent *de;
  struct stat st;

  int color;
  int c, d;
  int files;
  int filepos;
  int fileview;
  int lowest;
  int filemode = initialmode;
  int exitfilesel;
  #ifdef __WIN32__
  char drivestr[] = "A:\\";
  char driveexists[26];
  #endif
  char cmpbuf[MAX_PATHNAME];

  // Set initial path (if any)
  if (strlen(path)) chdir(path);

  // Init fileselector display
  for (c = 0; c < VISIBLEFILES+6; c++)
  {
    printblank(40-(MAX_FILENAME+10)/2, 2+c, MAX_FILENAME+10);
  }
  drawbox(40-(MAX_FILENAME+10)/2, 2, 15, MAX_FILENAME+10, VISIBLEFILES+6);
  printblankc(40-(MAX_FILENAME+10)/2+1, 3, 15+16,MAX_FILENAME+8);
  printtext(40-(MAX_FILENAME+10)/2+1, 3, 15+16, title);

  // Scan for all existing drives
  #ifdef __WIN32__
  for (c = 0; c < 26; c++)
  {
    drivestr[0] = 'A'+c;
    if (GetDriveType(drivestr) > 1) driveexists[c] = 1;
    else driveexists[c] = 0;
  }
  #endif

  // Read new directory
  NEWPATH:
  getcwd(path, MAX_PATHNAME);
  files = 0;
  // Deallocate old names
  for (c = 0; c < MAX_DIRFILES; c++)
  {
  	if (direntry[c].name)
  	{
  		free(direntry[c].name);
  		direntry[c].name = NULL;
  	}
  }
  #ifdef __WIN32__
  // Create drive letters
  for (c = 0; c < 26; c++)
  {
    if (driveexists[c])
    {
      drivestr[0] = 'A'+c;
      direntry[files].name = strdup(drivestr);
      direntry[files].attribute = 2;
      files++;
    }
  }
  #endif

  // Process directory
  dir = opendir(".");
  if (dir)
  {
    char *filtptr = strstr(filter, "*");
    if (!filtptr) filtptr = filter;
    else filtptr++;
    for (c = 0; c < strlen(filter); c++)
      filter[c] = tolower(filter[c]);

    while ((de = readdir(dir)))
    {
      if ((files < MAX_DIRFILES) && (strlen(de->d_name) < MAX_FILENAME))
      {
        direntry[files].name = strdup(de->d_name);
        direntry[files].attribute = 0;
        stat(de->d_name, &st);
        if (st.st_mode & S_IFDIR)
        {
          direntry[files].attribute = 1;
          files++;
        }
        else
        {
          int c;
          // If a file, must match filter
          strcpy(cmpbuf, de->d_name);
          if ((!strcmp(filtptr, "*")) || (!strcmp(filtptr, ".*")))
            files++;
          else
          {
            for (c = 0; c < strlen(cmpbuf); c++)
              cmpbuf[c] = tolower(cmpbuf[c]);
            if (strstr(cmpbuf, filtptr))
              files++;
            else
            {
            	free(direntry[files].name);
             	direntry[files].name = NULL;
            }
          }
        }
      }
    }
    closedir(dir);
  }
  // Sort the filelist in a most horrible fashion
  for (c = 0; c < files; c++)
  {
    lowest = c;
    for (d = c+1; d < files; d++)
    {
      if (direntry[d].attribute < direntry[lowest].attribute)
      {
        lowest = d;
      }
      else
      {
        if (direntry[d].attribute == direntry[lowest].attribute)
        {
          if (cmpname(direntry[d].name, direntry[lowest].name) < 0)
          {
            lowest = d;
          }
        }
      }
    }
    if (lowest != c)
    {
      DIRENTRY swaptemp = direntry[c];
      direntry[c] = direntry[lowest];
      direntry[lowest] = swaptemp;
    }
  }

  // Search for the current filename
  filepos = 0;
  for (c = 0; c < files; c++)
  {
    if ((!direntry[c].attribute) && (!cmpname(name, direntry[c].name)))
    {
      filepos = c;
    }
  }

  exitfilesel = -1;
  while (exitfilesel < 0)
  {
    int cc = cursorcolortable[cursorflash];

    if (cursorflashdelay >= 5)
    {
      cursorflashdelay %= 5;
      cursorflash++;
      cursorflash &= 3;
      fliptoscreen();
    }
    else
    {
      if (rawkey) fliptoscreen();
    }
    getkey();

    if (win_quitted)
    {
      exitprogram = 1;
      for (c = 0; c < MAX_DIRFILES; c++)
      {
      	if (direntry[c].name)
      	{
      		free(direntry[c].name);
      		direntry[c].name = NULL;
      	}
      }
      return 0;
    }

    switch(rawkey)
    {
      case KEY_ESC:
      exitfilesel = 0;
      break;

      case KEY_PGUP:
      for (scrrep = PGUPDNREPEAT; scrrep; scrrep--)
      {
        if ((!filemode) && (filepos > 0))
        {
          filepos--;
          if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
        }
      }
      break;

      case KEY_UP:
      if ((!filemode) && (filepos > 0))
      {
        filepos--;
        if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
      }
      break;

      case KEY_PGDN:
      for (scrrep = PGUPDNREPEAT; scrrep; scrrep--)
      {
        if ((!filemode) && (filepos < files-1))
        {
          filepos++;
          if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
        }
      }
      break;

      case KEY_DOWN:
      if ((!filemode) && (filepos < files-1))
      {
        filepos++;
        if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
      }
      break;

      case KEY_TAB:
      if (!shiftpressed)
      {
        filemode++;
        if (filemode > 3) filemode = 0;
      }
      else
      {
      	filemode--;
      	if (filemode < 0) filemode = 3;
      }
      break;

      case KEY_ENTER:
      switch(filemode)
      {
        case 0:
        switch (direntry[filepos].attribute)
        {
          case 0:
          strcpy(name, direntry[filepos].name);
          exitfilesel = 1;
          break;

          case 1:
          chdir(direntry[filepos].name);
          exitfilesel = 2;
          break;

          case 2:
          {
            char tempname[MAX_PATHNAME];
            strcpy(tempname, direntry[filepos].name);

            if (strlen(tempname))
            {
              if (tempname[strlen(tempname)-1] != '\\')
                strcat(tempname, "\\");
            }
            chdir(tempname);
            exitfilesel = 2;
          }
          break;
        }
        break;

        case 1:
        chdir(path);
        case 2:
        filemode = 0;
        exitfilesel = 2;
        break;

        case 3:
        exitfilesel = 1;
        break;
      }
      break;
    }

    switch(filemode)
    {
    	case 1:
      editstring(path, MAX_PATHNAME);
      break;
      
      case 2:
      editstring(filter, MAX_FILENAME);
      break;

      case 3:
      editstring(name, MAX_FILENAME);
      break;
    }

    fileview =-VISIBLEFILES/2+filepos;

    for (c = 0; c < VISIBLEFILES; c++)
    {
      if ((fileview+c >= 0) && (fileview+c < files))
      {
        switch (direntry[fileview+c].attribute)
        {
          case 0:
          sprintf(textbuffer, "%-60s        ", direntry[fileview+c].name);
          break;

          case 1:
          sprintf(textbuffer, "%-60s   <DIR>", direntry[fileview+c].name);
          break;

          case 2:
          sprintf(textbuffer, "%-60s   <DRV>", direntry[fileview+c].name);
          break;
        }
      }
      else
      {
        sprintf(textbuffer, "                                                                    ");
      }
      color = CNORMAL;
      if ((fileview+c) == filepos) color = CEDIT;
      textbuffer[68] = 0;
      printtext(40-(MAX_FILENAME+10)/2+1, 4+c, color, textbuffer);
      if ((!filemode) && ((fileview+c) == filepos)) printbg(40-(MAX_FILENAME+10)/2+1, 4+c, cc, 68);
    }

    printtext(40-(MAX_FILENAME+10)/2+1, 4+VISIBLEFILES, 15, "PATH:   ");
    sprintf(textbuffer, "%-60s", path);
    textbuffer[MAX_FILENAME] = 0;
    color = CNORMAL;
    if (filemode == 1) color = CEDIT;
    printtext(40-(MAX_FILENAME+10)/2+9, 4+VISIBLEFILES, color, textbuffer);
    if ((filemode == 1) && (strlen(path) < MAX_FILENAME)) printbg(40-(MAX_FILENAME+10)/2+9+strlen(path), 4+VISIBLEFILES, cc, 1);

    printtext(40-(MAX_FILENAME+10)/2+1, 5+VISIBLEFILES, 15, "FILTER: ");
    sprintf(textbuffer, "%-60s", filter);
    textbuffer[MAX_FILENAME] = 0;
    color = CNORMAL;
    if (filemode == 2) color = CEDIT;
    printtext(40-(MAX_FILENAME+10)/2+9, 5+VISIBLEFILES, color, textbuffer);
    if (filemode == 2) printbg(40-(MAX_FILENAME+10)/2+9+strlen(filter), 5+VISIBLEFILES, cc, 1);

    printtext(40-(MAX_FILENAME+10)/2+1, 6+VISIBLEFILES, 15, "NAME:   ");
    sprintf(textbuffer, "%-60s", name);
    textbuffer[MAX_FILENAME] = 0;
    color = CNORMAL;
    if (filemode == 3) color = CEDIT;
    printtext(40-(MAX_FILENAME+10)/2+9, 6+VISIBLEFILES, color, textbuffer);
    if (filemode == 3) printbg(40-(MAX_FILENAME+10)/2+9+strlen(name), 6+VISIBLEFILES, cc, 1);

    if (win_quitted) exitfilesel = 0;
  }
  if (exitfilesel == 2) goto NEWPATH;

  // Deallocate all used names
  for (c = 0; c < MAX_DIRFILES; c++)
  {
   	if (direntry[c].name)
   	{
   		free(direntry[c].name);
   		direntry[c].name = NULL;
   	}
  }

  // Restory screen & exit
  printmainscreen();
  return exitfilesel;
}

void editstring(char *buffer, int maxlength)
{
  int len = strlen(buffer);

  if (key)
  {
    if ((key >= 32) && (key < 256))
    {
      if (len < maxlength-1)
      {
        buffer[len] = key;
        buffer[len+1] = 0;
      }
    }
    if ((key == 8) && (len > 0))
    {
      buffer[len-1] = 0;
    }
  }
}

int cmpname(char *string1, char *string2)
{
  for (;;)
  {
    unsigned char char1 = tolower(*string1++);
    unsigned char char2 = tolower(*string2++);
    if (char1 < char2) return -1;
    if (char1 > char2) return 1;
    if ((!char1) || (!char2)) return 0;
  }
}


