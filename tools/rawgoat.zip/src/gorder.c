//
// GOATTRACKER v2 orderlist & songname editor
//

#include "goattrk2.h"

void orderlistcommands(void)
{
  int c;

  if (hexnybble >= 0)
  {
    if (eseditpos != songlen[esnum][eschn])
    {
      switch(escolumn)
      {
        case 0:
        songorder[esnum][eschn][eseditpos] &= 0x0f;
        songorder[esnum][eschn][eseditpos] |= hexnybble << 4;
        if (eseditpos < songlen[esnum][eschn])
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_PATT)
            songorder[esnum][eschn][eseditpos] = MAX_PATT - 1;
        }
        else
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_SONGLEN)
            songorder[esnum][eschn][eseditpos] = MAX_SONGLEN - 1;
        }
        break;

        case 1:
        songorder[esnum][eschn][eseditpos] &= 0xf0;
        if ((songorder[esnum][eschn][eseditpos] & 0xf0) == 0xd0)
        {
          hexnybble--;
          if (hexnybble < 0) hexnybble = 0xf;
        }
        if ((songorder[esnum][eschn][eseditpos] & 0xf0) == 0xe0)
        {
          hexnybble = 16 - hexnybble;
          hexnybble &= 0xf;
        }
        songorder[esnum][eschn][eseditpos] |= hexnybble;

        if (eseditpos < songlen[esnum][eschn])
        {
          if (songorder[esnum][eschn][eseditpos] == LOOPSONG)
            songorder[esnum][eschn][eseditpos] = LOOPSONG-1;
          if (songorder[esnum][eschn][eseditpos] == TRANSDOWN)
            songorder[esnum][eschn][eseditpos] = TRANSDOWN+0x0f;
        }
        else
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_SONGLEN)
            songorder[esnum][eschn][eseditpos] = MAX_SONGLEN - 1;
        }
        break;
      }
      escolumn++;
      if (escolumn > 1)
      {
        escolumn = 0;
        if (eseditpos < (songlen[esnum][eschn]+1))
        {
          eseditpos++;
          if (eseditpos == songlen[esnum][eschn]) eseditpos++;
        }
      }
    }
  }

  switch(key)
  {
    case '+':
    if (eseditpos < songlen[esnum][eschn])
    {
      songorder[esnum][eschn][eseditpos] = TRANSUP;
      escolumn = 1;
    }
    break;

    case '-':
    if (eseditpos < songlen[esnum][eschn])
    {
      songorder[esnum][eschn][eseditpos] = TRANSDOWN + 0x0F;
      escolumn = 1;
    }
    break;

    case '>':
    case ')':
    case ']':
    esnum++;
    if (esnum >= MAX_SONGS) esnum = MAX_SONGS - 1;
    for (c = 0; c < MAX_CHN; c++)
    {
      espos[c] = 0;
      if (songlen[esnum][c])
      {
        eppos = 0;
        epview = - VISIBLEPATTROWS/2;
        if (songorder[esnum][c][0] < MAX_PATT)
          epnum[c] = songorder[esnum][c][0];
        else
        {
          if (songorder[esnum][c][1] < MAX_PATT)
            epnum[c] = songorder[esnum][c][1];
          else epnum[c] = c;
        }
      }
    }
    eseditpos = 0;
    if (eseditpos == songlen[esnum][eschn]) eseditpos++;
    esview = 0;
    epmarkchn = -1;
    if (!songinit) songinit = 0x04;
    break;

    case '<':
    case '(':
    case '[':
    esnum--;
    if (esnum < 0) esnum = 0;
    for (c = 0; c < MAX_CHN; c++)
    {
      espos[c] = 0;
      if (songlen[esnum][c])
      {
        eppos = 0;
        epview = - VISIBLEPATTROWS/2;
        if (songorder[esnum][c][0] < MAX_PATT)
          epnum[c] = songorder[esnum][c][0];
        else
        {
          if (songorder[esnum][c][1] < MAX_PATT)
            epnum[c] = songorder[esnum][c][1];
          else epnum[c] = c;
        }
      }
    }
    eseditpos = 0;
    if (eseditpos == songlen[esnum][eschn]) eseditpos++;
    esview = 0;
    epmarkchn = -1;
    if (!songinit) songinit = 0x04;
    break;
  }
  switch(rawkey)
  {
    case KEY_1:
    case KEY_2:
    case KEY_3:
    if (shiftpressed)
    {
    	int schn = eschn;
    	int tchn = 0;

    	if (rawkey == KEY_1) tchn = 0;
    	if (rawkey == KEY_2) tchn = 1;
    	if (rawkey == KEY_3) tchn = 2;
    	if (schn != tchn)
    	{
    		for (c = 0; c < MAX_SONGLEN+2; c++)
    		{
    			unsigned char temp = songorder[esnum][schn][c];
    			songorder[esnum][schn][c] = songorder[esnum][tchn][c];
    			songorder[esnum][tchn][c] = temp;
    		}
    	}
    }
    break;

    case KEY_X:
    if (shiftpressed)
    {
      memcpy(trackcopybuffer, &songorder[esnum][eschn][0], MAX_SONGLEN+2);
      memset(&songorder[esnum][eschn][0], 0, MAX_SONGLEN+2);
      songorder[esnum][eschn][0] = LOOPSONG;
      countthispattern();
    }
    break;

    case KEY_C:
    if (shiftpressed)
    {
      memcpy(trackcopybuffer, &songorder[esnum][eschn][0], MAX_SONGLEN+2);
    }
    break;

    case KEY_V:
    if (shiftpressed)
    {
      memcpy(&songorder[esnum][eschn][0], trackcopybuffer, MAX_SONGLEN+2);
      countthispattern();
    }
    break;

    case KEY_SPACE:
    if (!shiftpressed)
    {
      if (eseditpos < songlen[esnum][eschn]) espos[eschn] = eseditpos;
    }
    else
    {
      if (eseditpos < songlen[esnum][0]) espos[0] = eseditpos;
      if (eseditpos < songlen[esnum][1]) espos[1] = eseditpos;
      if (eseditpos < songlen[esnum][2]) espos[2] = eseditpos;
    }
    break;

    case KEY_ENTER:
    if (eseditpos < songlen[esnum][eschn])
    {
      if (!shiftpressed)
      {
        if (songorder[esnum][eschn][eseditpos] < MAX_PATT)
          epnum[eschn] = songorder[esnum][eschn][eseditpos];
      }
      else
      {
        if (eseditpos != espos[eschn])
        {
          if ((eseditpos < songlen[esnum][0]) && (songorder[esnum][0][eseditpos] < MAX_PATT)) epnum[0] = songorder[esnum][0][eseditpos];
          if ((eseditpos < songlen[esnum][1]) && (songorder[esnum][1][eseditpos] < MAX_PATT)) epnum[1] = songorder[esnum][1][eseditpos];
          if ((eseditpos < songlen[esnum][2]) && (songorder[esnum][2][eseditpos] < MAX_PATT)) epnum[2] = songorder[esnum][2][eseditpos];
        }
        else
        {
          if ((espos[0] < songlen[esnum][0]) && (songorder[esnum][0][espos[0]] < MAX_PATT)) epnum[0] = songorder[esnum][0][espos[0]];
          if ((espos[1] < songlen[esnum][1]) && (songorder[esnum][1][espos[1]] < MAX_PATT))epnum[1] = songorder[esnum][1][espos[1]];
          if ((espos[2] < songlen[esnum][2]) && (songorder[esnum][2][espos[2]] < MAX_PATT))epnum[2] = songorder[esnum][2][espos[2]];
        }
      }
      epmarkchn = -1;
    }
    epchn = eschn;
    epcolumn = 0;
    eppos = 0;
    epview = - VISIBLEPATTROWS/2;
    editmode = EDIT_PATTERN;
    if (epchn == epmarkchn) epmarkchn = -1;
    break;

    case KEY_DEL:
    if ((songlen[esnum][eschn] - eseditpos)-1 >= 0)
    {
      int len;
      memmove(&songorder[esnum][eschn][eseditpos],
        &songorder[esnum][eschn][eseditpos+1],
        (songlen[esnum][eschn] - eseditpos)-1);
      songorder[esnum][eschn][songlen[esnum][eschn]-1] = 0x00;
      if (songlen[esnum][eschn] > 0)
      {
        songorder[esnum][eschn][songlen[esnum][eschn]-1] =
          songorder[esnum][eschn][songlen[esnum][eschn]];
        songorder[esnum][eschn][songlen[esnum][eschn]] =
          songorder[esnum][eschn][songlen[esnum][eschn]+1];
        countthispattern();
      }
      if (eseditpos == songlen[esnum][eschn]) eseditpos++;
      len = songlen[esnum][eschn]+1;
      if ((songorder[esnum][eschn][len] > eseditpos) &&
         (songorder[esnum][eschn][len] > 0))
         songorder[esnum][eschn][len]--;
    }
    else
    {
      if (eseditpos > songlen[esnum][eschn])
      {
        if (songlen[esnum][eschn] > 0)
        {
          songorder[esnum][eschn][songlen[esnum][eschn]-1] =
            songorder[esnum][eschn][songlen[esnum][eschn]];
          songorder[esnum][eschn][songlen[esnum][eschn]] =
            songorder[esnum][eschn][songlen[esnum][eschn]+1];
          countthispattern();
          eseditpos = songlen[esnum][eschn]+1;
        }
      }
    }
    break;

    case KEY_INS:
    if ((songlen[esnum][eschn] - eseditpos)-1 >= 0)
    {
      int len;
      if (songlen[esnum][eschn] < MAX_SONGLEN)
      {
        len = songlen[esnum][eschn]+1;
        songorder[esnum][eschn][len+1] =
          songorder[esnum][eschn][len];
        songorder[esnum][eschn][len] = LOOPSONG;
        if (len) songorder[esnum][eschn][len-1] = 0x00;
        countthispattern();
      }
      memmove(&songorder[esnum][eschn][eseditpos+1],
        &songorder[esnum][eschn][eseditpos],
        (songlen[esnum][eschn] - eseditpos)-1);
      songorder[esnum][eschn][eseditpos] = 0x00;
      len = songlen[esnum][eschn]+1;
      if ((songorder[esnum][eschn][len] > eseditpos) &&
         (songorder[esnum][eschn][len] < (len-2)))
         songorder[esnum][eschn][len]++;
    }
    else
    {
      if (eseditpos > songlen[esnum][eschn])
      {
        if (songlen[esnum][eschn] < MAX_SONGLEN)
        {
          songorder[esnum][eschn][eseditpos+1] =
            songorder[esnum][eschn][eseditpos];
          songorder[esnum][eschn][eseditpos] = LOOPSONG;
          if (eseditpos) songorder[esnum][eschn][eseditpos-1] = 0x00;
          countthispattern();
          eseditpos = songlen[esnum][eschn]+1;
        }
      }
    }
    break;

    case KEY_RIGHT:
    escolumn++;
    if (escolumn > 1)
    {
      escolumn = 0;
      if (eseditpos < (songlen[esnum][eschn]+1))
      {
        eseditpos++;
        if (eseditpos == songlen[esnum][eschn]) eseditpos++;
      }
      else escolumn = 1;
    }
    break;

    case KEY_PGDN:
    for (scrrep = PGUPDNREPEAT * 2; scrrep; scrrep--)
    {
      escolumn++;
      if (escolumn > 1)
      {
        escolumn = 0;
        if (eseditpos < (songlen[esnum][eschn]+1))
        {
          eseditpos++;
          if (eseditpos == songlen[esnum][eschn]) eseditpos++;
        }
        else escolumn = 1;
      }
    }
    break;

    case KEY_HOME:
    eseditpos = 0;
    escolumn = 0;
    if (eseditpos == songlen[esnum][eschn]) eseditpos++;
    break;

    case KEY_END:
    eseditpos = songlen[esnum][eschn]+1;
    escolumn = 0;
    break;

    case KEY_PGUP:
    for (scrrep = PGUPDNREPEAT * 2; scrrep; scrrep--)
    {
      escolumn--;
      if (escolumn < 0)
      {
        if (eseditpos > 0)
        {
          eseditpos--;
          if (eseditpos == songlen[esnum][eschn]) eseditpos--;
          escolumn = 1;
          if (eseditpos < 0)
          {
            eseditpos = 1;
            escolumn = 0;
          }
        }
        else escolumn = 0;
      }
    }
    break;

    case KEY_LEFT:
    escolumn--;
    if (escolumn < 0)
    {
      if (eseditpos > 0)
      {
        eseditpos--;
        if (eseditpos == songlen[esnum][eschn]) eseditpos--;
        escolumn = 1;
        if (eseditpos < 0)
        {
          eseditpos = 1;
          escolumn = 0;
        }
      }
      else escolumn = 0;
    }
    break;

    case KEY_UP:
    eschn--;
    if (eschn < 0) eschn = MAX_CHN - 1;
    if ((eseditpos == songlen[esnum][eschn]) || (eseditpos > songlen[esnum][eschn]+1))
    {
      eseditpos = songlen[esnum][eschn]+1;
      escolumn = 0;
    }
    break;

    case KEY_DOWN:
    eschn++;
    if (eschn >= MAX_CHN) eschn = 0;
    if ((eseditpos == songlen[esnum][eschn]) || (eseditpos > songlen[esnum][eschn]+1))
    {
      eseditpos = songlen[esnum][eschn]+1;
      escolumn = 0;
    }
    break;
  }
  if (eseditpos - esview < 0)
  {
    esview = eseditpos;
  }
  if (eseditpos - esview >= VISIBLEORDERLIST)
  {
    esview = eseditpos - VISIBLEORDERLIST + 1;
  }
}

void namecommands(void)
{
  switch(rawkey)
  {
    case KEY_DOWN:
    case KEY_ENTER:
    enpos++;
    if (enpos > 2) enpos = 0;
    break;

    case KEY_UP:
    enpos--;
    if (enpos < 0) enpos = 2;
    break;
  }
  switch(enpos)
  {
    case 0:
    editstring(songname, MAX_STR);
    break;

    case 1:
    editstring(authorname, MAX_STR);
    break;

    case 2:
    editstring(copyrightname, MAX_STR);
    break;
  }
}

