//
// GOATTRACKER v2 packer/relocator
//

#include "goattrk2.h"

static INSTRUCTION asmtable[] = {{0x69,2}, {0x65,0}, {0x75,0}, {0x6d,3}, {0x7d,3},
  {0x79,3}, {0x61,0}, {0x71,0}, {0x29,2}, {0x25,0}, {0x35,0}, {0x2d,3},
  {0x3d,3}, {0x39,3}, {0x21,0}, {0x31,0}, {0x0a,1}, {0x06,0}, {0x16,0},
  {0x0e,3}, {0x1e,3}, {0x90,2}, {0xb0,2}, {0xf0,2}, {0x24,0}, {0x2c,3},
  {0x30,2}, {0xd0,2}, {0x10,2}, {0x00,1}, {0x50,2}, {0x70,2}, {0x18,1},
  {0xd8,1}, {0x58,1}, {0xb8,1}, {0xc9,2}, {0xc5,0}, {0xd5,0}, {0xcd,3},
  {0xdd,3}, {0xd9,3}, {0xc1,0}, {0xd1,0}, {0xe0,2}, {0xe4,0}, {0xec,3},
  {0xc0,2}, {0xc4,0}, {0xcc,3}, {0xc6,0}, {0xd6,0}, {0xce,3}, {0xde,3},
  {0xca,1}, {0x88,1}, {0x49,2}, {0x45,0}, {0x55,0}, {0x4d,3}, {0x5d,3},
  {0x59,3}, {0x41,0}, {0x51,0}, {0xe6,0}, {0xf6,0}, {0xee,3}, {0xfe,3},
  {0xe8,1}, {0xc8,1}, {0x4c,3}, {0x6c,3}, {0x20,3}, {0xa9,2}, {0xa5,0},
  {0xb5,0}, {0xad,3}, {0xbd,3}, {0xb9,3}, {0xa1,0}, {0xb1,0}, {0xa2,2},
  {0xa6,0}, {0xb6,0}, {0xae,3}, {0xbe,3}, {0xa0,2}, {0xa4,0}, {0xb4,0},
  {0xac,3}, {0xbc,3}, {0x4a,1}, {0x46,0}, {0x56,0}, {0x4e,3}, {0x5e,3},
  {0xea,1}, {0x09,2}, {0x05,0}, {0x15,0}, {0x0d,3}, {0x1d,3}, {0x19,3},
  {0x11,0}, {0x48,1}, {0x08,1}, {0x68,1}, {0x28,1}, {0x2a,1}, {0x26,0},
  {0x36,0}, {0x2e,3}, {0x3e,3}, {0x6a,1}, {0x66,0}, {0x76,0}, {0x6e,3},
  {0x7e,3}, {0x40,1}, {0x60,1}, {0xe9,2}, {0xe5,0}, {0xf5,0}, {0xed,3},
  {0xfd,3}, {0xf9,3}, {0xe1,2}, {0xf1,2}, {0x38,1}, {0xf8,1}, {0x78,1},
  {0x85,0}, {0x95,0}, {0x8d,3}, {0x9d,3}, {0x99,3}, {0x81,0}, {0x91,0},
  {0x86,0}, {0x96,0}, {0x8e,3}, {0x84,0}, {0x94,0}, {0x8c,3}, {0xaa,1},
  {0xa8,1}, {0xba,1}, {0x8a,1}, {0x9a,1}, {0x98,1}, {0xff,2}, {0x100,0}};

static unsigned char pattused[MAX_PATT];
static unsigned char instrused[MAX_INSTR];
static unsigned char tableused[MAX_TABLES][MAX_TABLELEN+1];

static unsigned char pattmap[MAX_PATT];
static unsigned char instrmap[MAX_INSTR];
static unsigned char tablemap[MAX_TABLES][MAX_TABLELEN+1];

void relocator(void)
{
  unsigned char packedsongname[MAX_FILENAME];
  unsigned char packedfilter[MAX_FILENAME];

  int patterns = 0;
  int songs = 0;
  int instruments = 0;
  int numlegato = 0;
  int numnohr = 0;
  int numnormal = 0;
  int freenormal;
  int freenohr;
  int freelegato;
  int pattsize = 0;
  int patttblsize = 0;
  int songsize = 0;
  int songtblsize = 0;
  int instrsize = 0;
  int wavetblsize = 0;
  int pulsetblsize = 0;
  int filttblsize = 0;
  int playersize = 0;
  int totalsize = 0;
  int tableoverflow = 0;
  int playerhandle = -1;
  int plrparam = 0;  
  FILE *songhandle;
  int selectdone;
 	char playername[16];

  int c,d,e;

  unsigned instradr;
  unsigned wavetbladr;
  unsigned pulsetbladr;
  unsigned filttbladr;
  unsigned songtbladr;
  unsigned patttbladr;
  unsigned songadr;
  unsigned pattadr;

  unsigned char patttemp[512];
  unsigned char *playerwork = NULL;
  unsigned char *songwork = NULL;
  unsigned char *songtblwork = NULL;
  unsigned char *pattwork = NULL;
  unsigned char *patttblwork = NULL;
  unsigned char *instrwork = NULL;

  memset(pattused, 0, sizeof pattused);
  memset(instrused, 0, sizeof instrused);
  memset(tableused, 0, sizeof tableused);
  memset(tablemap, 0, sizeof tablemap);

  songinit = 0x04;

  // Process song-orderlists
  countpatternlengths();
  // Calculate amount of songs with nonzero length
  for (c = 0; c < MAX_SONGS; c++)
  {
    if ((songlen[c][0]) &&
        (songlen[c][1]) &&
        (songlen[c][2]))
    {
      // See which patterns are used in this song
      for (d = 0; d < MAX_CHN; d++)
      {
        songsize += songlen[c][d]+2;
      	for (e = 0; e < songlen[c][d]; e++)
      	{
      		if (songorder[c][d][e] < REPEAT)
      			pattused[songorder[c][d][e]] = 1;
      	}
      }
      songs++;
    }
  }

  if (!songs)
  {
    clearscreen();
    printtextc(12, 15, "NO SONGS, NO DATA TO SAVE!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  // Build the pattern-mapping
  // Instrument 1 is always used
  instrused[1] = 1;
  for (c = 0; c < MAX_PATT; c++)
  {
  	if (pattused[c])
  	{
  		pattmap[c] = patterns;
  		patterns++;

  		// See which instruments/tablecommands are used
  		for (d = 0; d < pattlen[c]; d++)
  		{
  			if (pattern[c][d*4+1])
  			  instrused[pattern[c][d*4+1]] = 1;
  			if ((pattern[c][d*4+2] >= CMD_SETWAVEPTR) && (pattern[c][d*4+2] <= CMD_SETFILTERPTR))
  			  exectable(pattern[c][d*4+2] - CMD_SETWAVEPTR, pattern[c][d*4+3]);
  		}
  	}
  }
  instrused[0x3f] = 0;

  // Count amount of normal, nohr, and legato instruments
  for (c = 0; c < MAX_INSTR; c++)
  {
  	if (instrused[c])
  	{
  		if (!(instr[c].firstwave & 0x7f)) numlegato++;
  		else
  		{
  			if (instr[c].firstwave >= 0x80) numnohr++;
  			else numnormal++;
  		}
  	}
  }
  freenormal = 1;
  freenohr = freenormal + numnormal;
  freelegato = freenohr + numnohr;

  // Build the instrument-mapping
  for (c = 0; c < MAX_INSTR; c++)
  {
  	if (instrused[c])
  	{
  		if (!(instr[c].firstwave & 0x7f)) instrmap[c] = freelegato++;
  		else
  		{
  			if (instr[c].firstwave >= 0x80) instrmap[c] = freenohr++;
  			else instrmap[c] = freenormal++;
  		}
  		instruments++;
  		for (d = 0; d < MAX_TABLES; d++)
    		exectable(d, instr[c].ptr[d]);
  	}
  }

  // Build the table-mapping
  for (c = 0; c < MAX_TABLES; c++)
  {
  	int e = 1;
  	for (d = 0; d < MAX_TABLELEN; d++)
  	{
  		if (tableused[c][d+1])
      {
      	tablemap[c][d+1] = e;
        e++;
      }
  	}

  	// Check for overflow
  	if ((tableused[c][255]) && (ltable[c][254] != 0xff))
  	  tableoverflow = 1;
  }

  if (tableoverflow)
  {
    clearscreen();
    printtextc(12, 15, "TABLE EXECUTION OVERFLOWS! PRESS Y TO GO ON ANYWAY.");
    fliptoscreen();
    waitkey2();
    if (key != KEY_Y) goto PRCLEANUP;
  }

  // Allocate memory for songtable & song-orderlists
  songtblsize = songs*6;
  songtblwork = malloc(songtblsize);
  songwork = malloc(songsize);
  if ((!songtblwork) || (!songwork))
  {
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  // Generate songorderlists & songtable
  songsize = 0;
  for (c = 0; c < songs; c++)
  {
    if ((songlen[c][0]) &&
        (songlen[c][1]) &&
        (songlen[c][2]))
    {
      for (d = 0; d < MAX_CHN; d++)
      {
      	songtblwork[c*3+d] = songsize & 0xff;
      	songtblwork[(c+songs)*3+d] = songsize >> 8;
      	for (e = 0; e < songlen[c][d]; e++)
      	{
      		// Pattern
      		if (songorder[c][d][e] < REPEAT)
      			songwork[songsize++] = pattmap[songorder[c][d][e]];
      		else
      		{
      			// Transpose
      			if (songorder[c][d][e] >= TRANSDOWN)
        		  songwork[songsize++] = songorder[c][d][e];
        		// Repeat sequence: must be swapped
            else
            {
              // See that repeat amount is more than 1
            	if (songorder[c][d][e] > REPEAT)
            	{
              	// Insanity check that a pattern indeed follows
              	if (songorder[c][d][e+1] < REPEAT)
              	{
                	songwork[songsize++] = pattmap[songorder[c][d][e+1]];
                	songwork[songsize++] = songorder[c][d][e];
                  e++;
                }
                else
                	songwork[songsize++] = songorder[c][d][e];
              }
            }
          }
      	}
      	// Endmark & repeat position
      	songwork[songsize++] = songorder[c][d][e++];
      	songwork[songsize++] = songorder[c][d][e++];
      }
    }
  }

  // Calculate total size of patterns
  for (c = 0; c <= MAX_PATT; c++)
  {
  	if (pattused[c])
  	{
      int result = packpattern(patttemp, pattern[c], pattlen[c]);

      if (result < 0)
      {
        clearscreen();
        sprintf(textbuffer, "PATTERN %02X IS TOO COMPLEX (OVER 256 BYTES PACKED)!", c);
        printtextc(12, 15, textbuffer);
        fliptoscreen();
        waitkey2();
        goto PRCLEANUP;
      }
      pattsize += result;
    }
  }

  patttblsize = patterns*2;
  patttblwork = malloc(patttblsize);
  pattwork = malloc(pattsize);
  if ((!patttblwork) || (!pattwork))
  {
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  // This time pack the patterns for real
  pattsize = 0;
  d = 0;
  for (c = 0; c < MAX_PATT; c++)
  {
  	if (pattused[c])
  	{
      patttblwork[d] = pattsize & 0xff;
      patttblwork[d+patterns] = pattsize >> 8;
      pattsize += packpattern(&pattwork[pattsize], pattern[c], pattlen[c]);
      d++;
    }
  }

  // Then process instruments
  instrsize = instruments*9;
  instrwork = malloc(instrsize);
  if (!instrwork)
  {
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  for (c = 1; c < MAX_INSTR; c++)
  {
  	if (instrused[c])
  	{
  		d = instrmap[c] - 1;
      instrwork[d] = instr[c].ad;
      instrwork[d+instruments] = instr[c].sr;
      instrwork[d+instruments*2] = tablemap[WTBL][instr[c].ptr[WTBL]];
      instrwork[d+instruments*3] = tablemap[PTBL][instr[c].ptr[PTBL]];
      instrwork[d+instruments*4] = tablemap[FTBL][instr[c].ptr[FTBL]];
      instrwork[d+instruments*5] = instr[c].vibdelay - 1;
      if (instr[c].vibdelay)
        instrwork[d+instruments*6] = swapnybbles(instr[c].vibparam);
      else
        instrwork[d+instruments*6] = 0;
      instrwork[d+instruments*7] = instr[c].gatetimer;
      instrwork[d+instruments*8] = instr[c].firstwave;
    }
  }
  instrsize = instruments*7;

  // Process tables
  for (c = 0; c < MAX_TABLELEN; c++)
    if (tableused[WTBL][c+1]) wavetblsize += 2;
  for (c = 0; c < MAX_TABLELEN; c++)
    if (tableused[PTBL][c+1]) pulsetblsize += 2;
  for (c = 0; c < MAX_TABLELEN; c++)
    if (tableused[FTBL][c+1]) filttblsize += 2;

  // Select playroutine
  clearscreen();
  printblankc(0, 0, 15+16, 80);
  if (!strlen(loadedsongfilename))
    sprintf(textbuffer, "%s Packer/Relocator", programname);
  else
    sprintf(textbuffer, "%s Packer/Relocator - %s", programname, loadedsongfilename);
  textbuffer[80] = 0;
  printtext(0, 0, 15+16, textbuffer);
  printtext(1, 2, 15, "SELECT PLAYROUTINE: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");
  selectdone = 0;
  if (playerversion > PLAYER_LAST) playerversion = PLAYER_FIRST;
  while (!selectdone)
  {
    switch(playerversion)
    {
      case 0:
      printtext(1, 3, 10, "Standard (no sound effect support)                                   ");
      break;

      case 1:
      printtext(1, 3, 10, "Gamemusic (sound effect support)                                     ");
      break;
    }

    fliptoscreen();
    waitkey2();

    if (win_quitted)
    {
      exitprogram = 1;
      return;
    }

    switch(rawkey)
    {
      case KEY_LEFT:
      case KEY_DOWN:
      playerversion--;
      if (playerversion < PLAYER_FIRST) playerversion = PLAYER_LAST;
      break;

      case KEY_RIGHT:
      case KEY_UP:
      playerversion++;
      if (playerversion > PLAYER_LAST) playerversion = PLAYER_FIRST;
      break;

      case KEY_ESC:
      selectdone = -1;
      break;

      case KEY_ENTER:
      selectdone = 1;
      break;
    }
  }
  if (selectdone == -1) goto PRCLEANUP;


	sprintf(playername, "player%d.bin", playerversion+1);
 	playerhandle = io_open(playername);

  if (playerhandle == -1)
  {
    clearscreen();
    printtextc(12, 15, "CANNOT READ PLAYROUTINE FROM DATAFILE");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  playersize = io_lseek(playerhandle, 0, SEEK_END);
  playerwork = malloc(playersize);
  if (!playerwork)
  {
    io_close(playerhandle);
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }
  io_lseek(playerhandle, 0, SEEK_SET);
  io_read(playerhandle, playerwork, playersize);
  io_close(playerhandle);

  totalsize = playersize+songtblsize+songsize+patttblsize+pattsize+instrsize+wavetblsize+pulsetblsize+filttblsize;

  clearscreen();
  printblankc(0, 0, 15+16, 80);
  if (!strlen(loadedsongfilename))
    sprintf(textbuffer, "%s Packer/Relocator", programname);
  else
    sprintf(textbuffer, "%s Packer/Relocator - %s", programname, loadedsongfilename);
  textbuffer[80] = 0;
  printtext(0, 0, 15+16, textbuffer);

  sprintf(textbuffer, "PACKING RESULTS:");
  printtext(1, 2, 15, textbuffer);

  sprintf(textbuffer, "(%s)", playername);
  printtext(18, 2, 7, textbuffer);

  sprintf(textbuffer, "Playroutine:     %d bytes", playersize);
  printtext(1, 4, 7, textbuffer);
  sprintf(textbuffer, "Songtable:       %d bytes", songtblsize);
  printtext(1, 5, 7, textbuffer);
  sprintf(textbuffer, "Song-orderlists: %d bytes", songsize);
  printtext(1, 6, 7, textbuffer);
  sprintf(textbuffer, "Patterntable:    %d bytes", patttblsize);
  printtext(1, 7, 7, textbuffer);
  sprintf(textbuffer, "Patterns:        %d bytes", pattsize);
  printtext(1, 8, 7, textbuffer);
  sprintf(textbuffer, "Instruments:     %d bytes", instrsize);
  printtext(1, 9, 7, textbuffer);
  sprintf(textbuffer, "Tables:          %d bytes", wavetblsize+pulsetblsize+filttblsize);
  printtext(1, 10, 7, textbuffer);
  sprintf(textbuffer, "Total size:      %d bytes", totalsize);
  printtext(1, 12, 7, textbuffer);
  fliptoscreen();

  sprintf(textbuffer, "SELECT START ADDRESS: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");
  printtext(1, 14, 15, textbuffer);

  selectdone = 0;
  while (!selectdone)
  {
    int badaddr = 0;

    if (playeradr+totalsize > 0x10000)
    {
      sprintf(textbuffer, "$%04X Goes past end of memory!   ", playeradr);
      printtext(1, 15, 14, textbuffer);
      badaddr = 1;
    }
    if (!badaddr)
    {
      sprintf(textbuffer, "$%04X Ok address.                ", playeradr);
      printtext(1, 15, 10, textbuffer);
    }
    fliptoscreen();
    waitkey2();

    if (win_quitted)
    {
      exitprogram = 1;
      return;
    }

    switch(rawkey)
    {
      case KEY_LEFT:
      playeradr -= 0x0400;
      playeradr &= 0xff00;
      break;

      case KEY_UP:
      playeradr += 0x0100;
      playeradr &= 0xff00;
      break;

      case KEY_RIGHT:
      playeradr += 0x0400;
      playeradr &= 0xff00;
      break;

      case KEY_DOWN:
      playeradr -= 0x0100;
      playeradr &= 0xff00;
      break;

      case KEY_ESC:
      selectdone = -1;
      break;

      case KEY_ENTER:
      if (!badaddr) selectdone = 1;
      break;
    }
  }

  if (selectdone == -1) goto PRCLEANUP;

  sprintf(textbuffer, "SELECT ZEROPAGE ADDRESS: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");
  printtext(1, 17, 15, textbuffer);

  selectdone = 0;
  while (!selectdone)
  {
    if (zeropageadr < 0x02) zeropageadr = 0xfe;
    if (zeropageadr > 0xfe) zeropageadr = 0x02;
    if (zeropageadr < 0x90)
      sprintf(textbuffer, "$%02X-$%02X (Used by BASIC interpreter)    ", zeropageadr, zeropageadr+1);
    if ((zeropageadr >= 0x90) && (zeropageadr < 0xfb))
      sprintf(textbuffer, "$%02X-$%02X (Used by KERNAL routines)      ", zeropageadr, zeropageadr+1);
    if ((zeropageadr >= 0xfb) && (zeropageadr < 0xfe))
      sprintf(textbuffer, "$%02X-$%02X (Unused)                       ", zeropageadr, zeropageadr+1);
    if (zeropageadr >= 0xfe)
      sprintf(textbuffer, "$%02X-$%02X ($FF used by BASIC interpreter)", zeropageadr, zeropageadr+1);

    printtext(1, 18, 10, textbuffer);

    fliptoscreen();
    waitkey2();

    if (win_quitted)
    {
      exitprogram = 1;
      return;
    }

    switch(rawkey)
    {
      case KEY_LEFT:
      zeropageadr -= 0x10;
      break;

      case KEY_UP:
      zeropageadr++;
      break;

      case KEY_RIGHT:
      zeropageadr += 0x10;
      break;

      case KEY_DOWN:
      zeropageadr--;
      break;

      case KEY_ESC:
      selectdone = -1;
      break;

      case KEY_ENTER:
      selectdone = 1;
      break;
    }
  }

  if (selectdone == -1) goto PRCLEANUP;

  instradr = playeradr+playersize;
  wavetbladr = instradr+instrsize;
  pulsetbladr = wavetbladr+wavetblsize;
  filttbladr = pulsetbladr+pulsetblsize;
  songtbladr = filttbladr+filttblsize;
  patttbladr = songtbladr+songtblsize;
  songadr = patttbladr+patttblsize;
  pattadr = songadr+songsize;

  // Relocate song & patterntables now that all addresses are known
  for (c = 0; c < songs; c++)
  {
    int adr;

    for (d = 0; d < MAX_CHN; d++)
    {
      adr = songtblwork[c*3+d] | (songtblwork[(c+songs)*3+d] << 8);
      adr += songadr;
      songtblwork[c*3+d] = adr & 0xff;
      songtblwork[(c+songs)*3+d] = adr >> 8;
    }
  }
  for (c = 0; c < patterns; c++)
  {
    int adr;

    adr = patttblwork[c] | (patttblwork[c+patterns] << 8);
    adr += pattadr;
    patttblwork[c] = adr & 0xff;
    patttblwork[c+patterns] = adr >> 8;
  }

  // Now relocate player
  c = 0;
  for (;;)
  {
    INSTRUCTION *opptr;
    unsigned char opcode;

    opcode = playerwork[c];
    if (opcode == 0x00) goto RELOCDONE; // Reached data, relocation complete
    if (opcode == 0x01) goto RELOCDONE; // Reached data, relocation complete
    opptr = &asmtable[0];

    for (;;)
    {
      if (opptr->opcode == 0x100)
      {
        clearscreen();
        printtextc(12, 15, "ILLEGAL OPCODE FOUND IN PLAYROUTINE!");
        fliptoscreen();
        waitkey2();
        goto PRCLEANUP;
      }

      if (opptr->opcode == opcode) break;
      opptr++;
    }

    // Player parameters
    if (opcode == 0xff)
    {
      switch(plrparam)
      {
        case 0:
        playerwork[c] = 0xa9;
        playerwork[c+1] = instr[1].firstwave; // Store default firstwave
        break;

        case 1:
        playerwork[c] = 0xc9;
        playerwork[c+1] = instr[1].gatetimer; // Store default gatetimer
        break;

        case 2:
        playerwork[c] = 0xa9;
        playerwork[c+1] = adparam>>8; // Store AD-param for hardrestart
        break;
      }

      plrparam++;
    }

    // Zeropage relocation
    if (!opptr->length)
    {
      playerwork[c+1] -= 0xfc;
      playerwork[c+1] += zeropageadr;

      c += 2;
    }

    // Address relocation
    if (opptr->length == 3)
    {
      unsigned char *adr = &playerwork[c+1];

      switch(playerwork[c+2])
      {
        // Player code
        default:
        sixteenbitsub(adr, 0x1000);
        sixteenbitadd(adr, playeradr);
        break;

        // Reference to instrument AD
        case 0x40:
        sixteenbitsub(adr, 0x4001);
        sixteenbitadd(adr, instradr);
        break;

        // Reference to instrument SR
        case 0x41:
        sixteenbitsub(adr, 0x4101);
        sixteenbitadd(adr, instradr+instruments);
        break;

        // Reference to instrument waveptr
        case 0x42:
        sixteenbitsub(adr, 0x4201);
        sixteenbitadd(adr, instradr+instruments*2);
        break;

        // Reference to instrument pulseptr
        case 0x43:
        sixteenbitsub(adr, 0x4301);
        sixteenbitadd(adr, instradr+instruments*3);
        break;

        // Reference to instrument filterptr
        case 0x44:
        sixteenbitsub(adr, 0x4401);
        sixteenbitadd(adr, instradr+instruments*4);
        break;

        // Reference to instrument vibdelay
        case 0x45:
        sixteenbitsub(adr, 0x4501);
        sixteenbitadd(adr, instradr+instruments*5);
        break;

        // Reference to instrument vibparam
        case 0x46:
        sixteenbitsub(adr, 0x4601);
        sixteenbitadd(adr, instradr+instruments*6);
        break;

        // Reference to instrument gatetimer
        case 0x47:
        sixteenbitsub(adr, 0x4701);
        sixteenbitadd(adr, instradr+instruments*7);
        break;

        // Reference to instrument firstwave param.
        case 0x48:
        sixteenbitsub(adr, 0x4801);
        sixteenbitadd(adr, instradr+instruments*8);
        break;

        // Reference to wavetable
        case 0x49:
        sixteenbitsub(adr, 0x4901);
        sixteenbitadd(adr, wavetbladr);
        break;

        // Reference to notetable
        case 0x4a:
        sixteenbitsub(adr, 0x4a02);
        sixteenbitadd(adr, wavetbladr+wavetblsize/2);
        break;

        // Reference to pulsetimetable
        case 0x4b:
        sixteenbitsub(adr, 0x4b01);
        sixteenbitadd(adr, pulsetbladr);
        break;

        // Reference to pulsespeedtable
        case 0x4c:
        sixteenbitsub(adr, 0x4c01);
        sixteenbitadd(adr, pulsetbladr+pulsetblsize/2);
        break;

        // Reference to filtertimetable
        case 0x4d:
        sixteenbitsub(adr, 0x4d01);
        sixteenbitadd(adr, filttbladr);
        break;

        // Reference to filterspeedtable
        case 0x4e:
        sixteenbitsub(adr, 0x4e01);
        sixteenbitadd(adr, filttbladr+filttblsize/2);
        break;

        // Reference to songtable, lowbytes
        case 0x4f:
        sixteenbitsub(adr, 0x4f00);
        sixteenbitadd(adr, songtbladr);
        break;

        // Reference to songtable, highbytes
        case 0x50:
        sixteenbitsub(adr, 0x5000);
        sixteenbitadd(adr, songtbladr+songs*3);
        break;

        // Reference to patterntable, lowbytes
        case 0x51:
        sixteenbitsub(adr, 0x5100);
        sixteenbitadd(adr, patttbladr);
        break;

        // Reference to patterntable, highbytes
        case 0x52:
        sixteenbitsub(adr, 0x5200);
        sixteenbitadd(adr, patttbladr+patterns);
        break;

        // Reference to SID registers
        case 0xd4:
        sixteenbitsub(adr, 0xd400);
        sixteenbitadd(adr, sidaddress);
        break;
      }
    }
    c += opptr->length;
  }
  RELOCDONE:

  // Now ask for fileformat
  printtext(1, 20, 15, "SELECT FORMAT TO SAVE IN: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");

  selectdone = 0;

  while (!selectdone)
  {
    switch(fileformat)
    {
      case FORMAT_SID:
      printtext(1, 21, 10, "SID - SIDPlay music file format          ");
      strcpy(packedfilter, "*.sid");
      break;

      case FORMAT_PRG:
      printtext(1, 21, 10, "PRG - C64 native format                  ");
      strcpy(packedfilter, "*.prg");
      break;

      case FORMAT_BIN:
      printtext(1, 21, 10, "BIN - Raw binary format (no startaddress)");
      strcpy(packedfilter, "*.bin");
      break;
    }

    fliptoscreen();
    waitkey2();

    if (win_quitted)
    {
      exitprogram = 1;
      return;
    }

    switch(rawkey)
    {
      case KEY_LEFT:
      case KEY_DOWN:
      fileformat--;
      if (fileformat < FORMAT_SID) fileformat = FORMAT_BIN;
      break;

      case KEY_RIGHT:
      case KEY_UP:
      fileformat++;
      if (fileformat > FORMAT_BIN) fileformat = FORMAT_SID;
      break;

      case KEY_ESC:
      selectdone = -1;
      break;

      case KEY_ENTER:
      selectdone = 1;
      break;
    }
  }
  if (selectdone == -1) goto PRCLEANUP;

  // By default, copy loaded song name up to the extension
  memset(packedsongname, 0, sizeof packedsongname);
  for (c = 0; c < strlen(loadedsongfilename); c++)
  {
    if (loadedsongfilename[c] == '.') break;
  	packedsongname[c] = loadedsongfilename[c];
  }
  switch (fileformat)
  {
    case FORMAT_PRG:
    strcat(packedsongname, ".prg");
    break;

    case FORMAT_BIN:
    strcat(packedsongname, ".bin");
    break;

    case FORMAT_SID:
    strcat(packedsongname, ".sid");
    break;
  }

  // Now ask for filename
  if (!fileselector(packedsongname, packedpath, packedfilter, "Save Music+Playroutine", 3))
    goto PRCLEANUP;

  if (strlen(packedsongname) < MAX_FILENAME-4)
  {
    int extfound = 0;
    for (c = strlen(packedsongname)-1; c >= 0; c--)
    {
      if (packedsongname[c] == '.') extfound = 1;
    }
    if (!extfound)
    {
      switch (fileformat)
      {
        case FORMAT_PRG:
        strcat(packedsongname, ".prg");
        break;

        case FORMAT_BIN:
        strcat(packedsongname, ".bin");
        break;

        case FORMAT_SID:
        strcat(packedsongname, ".sid");
        break;
      }
    }
  }
  songhandle = fopen(packedsongname, "wb");
  if (songhandle)
  {
    unsigned char speedcode[] = {0xa2,0x00,0x8e,0x04,0xdc,0xa2,0x00,0x8e,0x05,0xdc};

    if (fileformat == FORMAT_PRG)
    {
      fwritele16(songhandle, playeradr);
    }
    if (fileformat == FORMAT_SID)
    {
      unsigned char ident[] = {'P', 'S', 'I', 'D', 0x00, 0x02, 0x00, 0x7c};
      unsigned char byte;
      // Identification
      fwrite(ident, sizeof ident, 1, songhandle);

      // Load address
      byte = 0x00;
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);

      // Init address
      if ((multiplier > 1) || (!multiplier))
      {
        unsigned speedvalue;
        byte = (playeradr-10) >> 8;
        fwrite8(songhandle, byte);
        byte = (playeradr-10) & 0xff;
        fwrite8(songhandle, byte);

        if (multiplier)
        {
          if (ntsc) speedvalue = 0x42c6/multiplier;
          else speedvalue = 0x4cc7/multiplier;
        }
        else
        {
          if (ntsc) speedvalue = 0x42c6*2;
          else speedvalue = 0x4cc7*2;
        }
        speedcode[1] = speedvalue & 0xff;
        speedcode[6] = speedvalue >> 8;
      }
      else
      {
        byte = (playeradr) >> 8;
        fwrite8(songhandle, byte);
        byte = (playeradr) & 0xff;
        fwrite8(songhandle, byte);
      }

      // Play address
      byte = (playeradr+3) >> 8;
      fwrite8(songhandle, byte);
      byte = (playeradr+3) & 0xff;
      fwrite8(songhandle, byte);

      // Number of subtunes
      byte = 0x00;
      fwrite8(songhandle, byte);
      byte = songs;
      fwrite8(songhandle, byte);

      // Default subtune
      byte = 0x00;
      fwrite8(songhandle, byte);
      byte = 0x01;
      fwrite8(songhandle, byte);

      // Song speed bits
      byte = 0x00;
      if ((ntsc) || (multiplier > 1) || (!multiplier)) byte = 0xff;
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);

      // Songname etc.
      fwrite(songname, sizeof songname, 1, songhandle);
      fwrite(authorname, sizeof authorname, 1, songhandle);
      fwrite(copyrightname, sizeof copyrightname, 1, songhandle);

      // Flags
      byte = 0x00;
      fwrite8(songhandle, byte);
      if (ntsc) byte = 8;
        else byte = 4;
      if (sidmodel) byte |= 32;
        else byte |= 16;
      fwrite8(songhandle, byte);

      // Reserved longword
      byte = 0x00;
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);
      fwrite8(songhandle, byte);

      // Load address
      if ((multiplier > 1) || (!multiplier))
      {
        byte = (playeradr-10) & 0xff;
        fwrite8(songhandle, byte);
        byte = (playeradr-10) >> 8;
        fwrite8(songhandle, byte);
      }
      else
      {
        byte = (playeradr) & 0xff;
        fwrite8(songhandle, byte);
        byte = (playeradr) >> 8;
        fwrite8(songhandle, byte);
      }
      if ((multiplier > 1) || (!multiplier)) fwrite(speedcode, 10, 1, songhandle);
    }

    fwrite(playerwork, playersize, 1, songhandle);
    fwrite(instrwork, instrsize, 1, songhandle);
    for (c = 0; c < MAX_TABLES; c++)
    {
    	// Write table left side
    	for (d = 0; d < MAX_TABLELEN; d++)
    	{
    		if (tableused[c][d+1])
    		{
    			// Convert pulsetable
    			if ((c == PTBL) && (ltable[c][d] != 0xff) && (ltable[c][d] >= 0x80))
            fwrite8(songhandle, 0x80);
          else
      			fwrite8(songhandle, ltable[c][d]);
        }
    	}

    	// Write table right side, remapping jumps as necessary
    	for (d = 0; d < MAX_TABLELEN; d++)
    	{
    		if (tableused[c][d+1])
    		{
    			if (ltable[c][d] != 0xff)
    			{
            // In wavetable, reverse all right side high bits
            switch(c)
            {
            	case WTBL:
      		    fwrite8(songhandle, rtable[c][d] ^ 0x80);
      		    break;

              case PTBL:
              if (ltable[c][d] >= 0x80)
              {
              	int pulse = (rtable[c][d] & 0xf0) | (ltable[c][d] & 0xf);
              	fwrite8(songhandle, pulse);
              }
              else
              {
              	int pulsedir = rtable[c][d] & 0x80;
                int pulsespeed = (rtable[c][d] & 0xf8) >> 3;
                if (pulsedir)
                {
                	pulsespeed |= 0xe0;
                  pulsespeed--;
                }
                pulsespeed = swapnybbles(pulsespeed);
                fwrite8(songhandle, pulsespeed);
              }
              break;

              default:
              fwrite8(songhandle, rtable[c][d]);
            }
        	}
      		else
    				fwrite8(songhandle, tablemap[c][rtable[c][d]]);
        }
    	}
    }
    fwrite(songtblwork, songtblsize, 1, songhandle);
    fwrite(patttblwork, patttblsize, 1, songhandle);
    fwrite(songwork, songsize, 1, songhandle);
    fwrite(pattwork, pattsize, 1, songhandle);
    fclose(songhandle);
  }

  PRCLEANUP:
  if (pattwork) free(pattwork);
  if (patttblwork) free(patttblwork);
  if (songwork) free(songwork);
  if (songtblwork) free(songtblwork);
  if (instrwork) free(instrwork);
  if (playerwork) free(playerwork);
  printmainscreen();
}

void sixteenbitadd(unsigned char *adr, int value)
{
  int orglowbyte = adr[0];
  adr[0] += value;
  adr[1] += value >> 8;
  if (adr[0] < orglowbyte) adr[1] += 1;
}

void sixteenbitsub(unsigned char *adr, int value)
{
  int orglowbyte = adr[0];
  adr[0] -= value;
  adr[1] -= value >> 8;
  if (adr[0] > orglowbyte) adr[1] -= 1;
}

int packpattern(unsigned char *dest, unsigned char *src, int rows)
{
  unsigned char temp1[96*4];
  unsigned char temp2[512];
  unsigned char instr = 0;
  int command = -1;
  int databyte = -1;
  int destsizeim = 0;
  int destsize = 0;
  int c, d;

  // First optimize instrument changes
  for (c = 0; c < rows; c++)
  {
    if ((c) && (src[c*4+1]) && (src[c*4+1] == instr))
    {
      temp1[c*4] = src[c*4];
      temp1[c*4+1] = 0;
      temp1[c*4+2] = src[c*4+2];
      temp1[c*4+3] = src[c*4+3];
    }
    else
    {
      temp1[c*4] = src[c*4];
      temp1[c*4+1] = src[c*4+1];
      temp1[c*4+2] = src[c*4+2];
      temp1[c*4+3] = src[c*4+3];
      if (src[c*4+1])
        instr = src[c*4+1];
    }

    // Remap commands and convert databytes
    switch(temp1[c*4+2])
    {
      case CMD_PORTAUP:
      case CMD_PORTADOWN:
      case CMD_TONEPORTA:
      case CMD_SETSR:
      break;

      case CMD_VIBRATO:
      // Swap nybbles of vibrato command for the playroutine
      temp1[c*4+3] = swapnybbles(temp1[c*4+3]);
      break;

      case CMD_SETFILTERPTR:
      // Remap table commands
      temp1[c*4+3] = tablemap[temp1[c*4+2]-CMD_SETWAVEPTR][temp1[c*4+3]];
      temp1[c*4+2] = 0x5;
      break;

    	case CMD_SETTEMPO:
      // Decrease databyte of all tempo commands for the playroutine
      // Do not touch funktempo
      if ((temp1[c*4+3] & 0x7f) >= 3)
        temp1[c*4+3]--;
      temp1[c*4+3] = (temp1[c*4+3] << 1) | (temp1[c*4+3] >> 7);
      temp1[c*4+2] = 0x7;
      break;

      default:
    	temp1[c*4+2] = 0;
     	temp1[c*4+3] = 0;
      break;
    }
  }

  // Write in playroutine format
  for (c = 0; c < rows; c++)
  {
    // Instrument change with mapping
    if (temp1[c*4+1])
    {
      temp2[destsizeim++] = instrmap[INSTRCHG+temp1[c*4+1]];
    }
    // Rest+FX
    if (temp1[c*4] == REST)
    {
      if ((temp1[c*4+2] != command) || (temp1[c*4+3] != databyte))
      {
        command = temp1[c*4+2];
        databyte = temp1[c*4+3];
        temp2[destsizeim++] = FXONLY+command;
        if (command)
          temp2[destsizeim++] = databyte;
      }
      else
        temp2[destsizeim++] = REST;
    }
    else
    {
      // Normal note
      if ((temp1[c*4+2] != command) || (temp1[c*4+3] != databyte))
      {
        command = temp1[c*4+2];
        databyte = temp1[c*4+3];
        temp2[destsizeim++] = FX+command;
        if (command)
          temp2[destsizeim++] = databyte;
      }
      temp2[destsizeim++] = temp1[c*4];
    }
  }

  // Final step: optimize long singlebyte rests with "packed rest"
  for (c = 0; c < destsizeim;)
  {
    int packok = 1;

    // There must be no instrument or command changes on the row to be packed
    if (temp2[c] < FX)
    {
      dest[destsize++] = temp2[c++];
      packok = 0;
    }
    if ((temp2[c] >= FXONLY) && (temp2[c] < FIRSTNOTE))
    {
    	int fxnum = temp2[c++] - FXONLY;
      dest[destsize++] = FX + fxnum * 2 + 1;
      if (fxnum) dest[destsize++] = temp2[c++];
      packok = 0;
      goto NEXTROW;
    }
    if (temp2[c] < FXONLY)
     {
    	int fxnum = temp2[c++] - FX;
      dest[destsize++] = FX + fxnum * 2;
      if (fxnum) dest[destsize++] = temp2[c++];
      packok = 0;
    }

    if (temp2[c] != REST) packok = 0;

    if (!packok)
      dest[destsize++] = temp2[c++] + 0x20;
    else
    {
      for (d = c; d < destsizeim; )
      {
        if (temp2[d] == REST)
        {
          d++;
          if (d-c == 32) break;
        }
        else break;
      }
      d -= c;
      if (d > 1)
      {
        dest[destsize++] = -d;
        c += d;
      }
      else
        dest[destsize++] = temp2[c++] + 0x20;
    }
    NEXTROW: {}
  }
  // See if pattern too big
  if (destsize > 256) return -1;

  // If less than 256 bytes, insert endmark
  if (destsize < 256)
  dest[destsize++] = 0x00;

  return destsize;
}

int testoverlap(int area1start, int area1size, int area2start, int area2size)
{
  int area1last = area1start+area1size-1;
  int area2last = area2start+area2size-1;

  if (area1start == area2start) return 1;

  if (area1start < area2start)
  {
    if (area1last < area2start) return 0;
    else return 1;
  }
  else
  {
    if (area2last < area1start) return 0;
    else return 1;
  }
}

unsigned char swapnybbles(unsigned char n)
{
  unsigned char highnybble = n >> 4;
  unsigned char lownybble = n & 0xf;

  return (lownybble << 4) | highnybble;
}

void exectable(int num, int ptr)
{
  for (;;)
  {
  	// Exit when table stopped
    if (!ptr) return;
    // Safety check
    if (ptr > MAX_TABLELEN) return;
    // If were already here, exit
    if (tableused[num][ptr]) return;
    // Mark current position used
    tableused[num][ptr] = 1;
    // Go to next ptr.
    if (ltable[num][ptr-1] == 0xff)
      ptr = rtable[num][ptr-1];
    else ptr++;
  }
}
