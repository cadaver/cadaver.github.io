//
// GOATTRACKER v2 screen display routines
//

#include "goattrk2.h"

void printmainscreen(void)
{
  clearscreen();
  printstatus();
  fliptoscreen();
}

void printstatus(void)
{
  int c, d, color;
  int cc = cursorcolortable[cursorflash];

  printblankc(0, 0, 15+16, 80);
  if (!strlen(loadedsongfilename))
    sprintf(textbuffer, "%s", programname);
  else
    sprintf(textbuffer, "%s - %s", programname, loadedsongfilename);
  textbuffer[39 - ntsc] = 0;
  printtext(0, 0, 15+16, textbuffer);

  if (ntsc)
    printtext(49, 0, 15+16, "NTSC");
  else
    printtext(49, 0, 15+16, " PAL");

  if (!sidmodel)
    printtext(55, 0, 15+16, "6581");
  else
    printtext(55, 0, 15+16, "8580");

  sprintf(textbuffer, "ADSR:%04X", adparam);
  printtext(61, 0, 15+16, textbuffer);

  printtext(72, 0, 15+16, "F12=HELP");

  if (followplay)
  {
    for (c = 0; c < MAX_CHN; c++)
    {
    	int newpos = chn[c].pattptr / 4;
      epnum[c] = chn[c].pattnum;

      if (newpos > pattlen[epnum[c]]) newpos = pattlen[epnum[c]];

      if (c == epchn)
      {
        eppos = newpos;
        epview = newpos-VISIBLEPATTROWS/2;
      }

  	  newpos = chn[c].songptr;
      newpos--;
      if (newpos < 0) newpos = 0;
      if (newpos > songlen[esnum][c]) newpos = songlen[esnum][c];

      if (c == eschn)
      {
      	eseditpos = newpos;
        if (newpos - esview < 0)
        {
          esview = newpos;
        }
        if (newpos - esview >= VISIBLEORDERLIST)
        {
          esview = newpos - VISIBLEORDERLIST + 1;
        }
      }
    }
  }

  for (c = 0; c < MAX_CHN; c++)
  {
    sprintf(textbuffer, "CHN%d PATT%02X", c+1, epnum[c]);
    printtext(1+c*13, 2, CTITLE, textbuffer);
    for (d = 0; d < VISIBLEPATTROWS; d++)
    {
      int p = epview+d;
      color = CNORMAL;
      if ((epnum[c] == chn[c].pattnum) && (!songinit))
      {
        int chnrow = chn[c].pattptr/4;
        if (chnrow > pattlen[chn[c].pattnum]) chnrow = pattlen[chn[c].pattnum];
        if (chnrow == p) color = CPLAYING;
      }

      if (chn[c].mute) color = CMUTE;
      if (p == eppos) color = CEDIT;
      if ((p < 0) || (p > pattlen[epnum[c]]))
      {
        sprintf(textbuffer, "           ");
      }
      else
      {
        if (pattern[epnum[c]][p*4] == ENDPATT)
        {
          if (!patternhex)
            sprintf(textbuffer, "%02d PATT.END",
              p);
          else
            sprintf(textbuffer, "%02X PATT.END",
              p);
          if (color == CNORMAL) color = CCOMMAND;
        }
        else
        {
        	if (!patternhex)
            sprintf(textbuffer, "%02d %s%02X%01X%02X",
              p,
              notename[pattern[epnum[c]][p*4]-FIRSTNOTE],
              pattern[epnum[c]][p*4+1],
              pattern[epnum[c]][p*4+2],
              pattern[epnum[c]][p*4+3]);
          else
            sprintf(textbuffer, "%02X %s%02X%01X%02X",
              p,
              notename[pattern[epnum[c]][p*4]-FIRSTNOTE],
              pattern[epnum[c]][p*4+1],
              pattern[epnum[c]][p*4+2],
              pattern[epnum[c]][p*4+3]);
        }
      }
      textbuffer[2] = 0;
      if (p%stepsize)
      {
        printtext(1+c*13, 3+d, CNORMAL, textbuffer);
      }
      else
      {
        printtext(1+c*13, 3+d, CCOMMAND, textbuffer);
      }
      printtext(4+c*13, 3+d, color, &textbuffer[3]);
      if (c == epmarkchn)
      {
        if (epmarkstart <= epmarkend)
        {
          if ((p >= epmarkstart) && (p <= epmarkend))
            printbg(1+c*13+3, 3+d, 1, 8);
        }
        else
        {
          if ((p <= epmarkstart) && (p >= epmarkend))
            printbg(1+c*13+3, 3+d, 1, 8);
        }
      }
      if ((color == CEDIT) && (editmode == EDIT_PATTERN) && (epchn == c))
      {
        switch(epcolumn)
        {
          case 0:
          printbg(1+c*13+3, 3+d, cc, 3);
          break;

          default:
          printbg(1+c*13+5+epcolumn, 3+d, cc, 1);
          break;
        }
      }
    }
  }

  sprintf(textbuffer, "CHN ORDERLIST (SUBTUNE %02X, POS %02X)", esnum, eseditpos);
  printtext(40, 2, CTITLE, textbuffer);
  for (c = 0; c < MAX_CHN; c++)
  {
    sprintf(textbuffer, " %d ", c+1);
    printtext(40, 3+c, 15, textbuffer);
    for (d = 0; d < VISIBLEORDERLIST; d++)
    {
      int p = esview+d;
      color = CNORMAL;
      if (!songinit)
      {
        int chnpos = chn[c].songptr;
        chnpos--;
        if (chnpos < 0) chnpos = 0;
        if (p == chnpos) color = CPLAYING;
      }
      if (p == espos[c]) color = CEDIT;

      if ((p < 0) || (p > (songlen[esnum][c]+1)) || (p > MAX_SONGLEN+1))
      {
        sprintf(textbuffer, "   ");
      }
      else
      {
        if (songorder[esnum][c][p] < LOOPSONG)
        {
          if ((songorder[esnum][c][p] < REPEAT) || (p >= songlen[esnum][c]))
          {
            sprintf(textbuffer, "%02X ", songorder[esnum][c][p]);
            if ((p >= songlen[esnum][c]) && (color == CNORMAL)) color = CCOMMAND;
          }
          else
          {
            if (songorder[esnum][c][p] >= TRANSUP)
            {
              sprintf(textbuffer, "+%01X ", songorder[esnum][c][p]&0xf);
              if (color == CNORMAL) color = CCOMMAND;
            }
            else
            {
              if (songorder[esnum][c][p] >= TRANSDOWN)
              {
                sprintf(textbuffer, "-%01X ", 16-(songorder[esnum][c][p] & 0x0f));
                if (color == CNORMAL) color = CCOMMAND;
              }
              else
              {
                sprintf(textbuffer, "R%01X ", (songorder[esnum][c][p]+1) & 0x0f);
                if (color == CNORMAL) color = CCOMMAND;
              }
            }
          }
        }
        if (songorder[esnum][c][p] == LOOPSONG)
        {
          sprintf(textbuffer, "RST");
          if (color == CNORMAL) color = CCOMMAND;
        }
      }
      printtext(44+d*3, 3+c, color, textbuffer);
      if ((p == eseditpos) && (editmode == EDIT_ORDERLIST) && (eschn == c))
      {
        printbg(44+d*3+escolumn, 3+c, cc, 1);
      }
    }
  }

  sprintf(textbuffer, "INSTRUMENT NUM. %02X   %-16s", einum, instr[einum].name);
  printtext(40, 7, CTITLE, textbuffer);

  sprintf(textbuffer, "Attack/Decay    %02X", instr[einum].ad);
  if (eipos == 0) color = CEDIT; else color = CNORMAL;
  printtext(40, 8, color, textbuffer);

  sprintf(textbuffer, "Sustain/Release %02X", instr[einum].sr);
  if (eipos == 1) color = CEDIT; else color = CNORMAL;
  printtext(40, 9, color, textbuffer);

  sprintf(textbuffer, "Wavetable Pos   %02X", instr[einum].ptr[WTBL]);
  if (eipos == 2) color = CEDIT; else color = CNORMAL;
  printtext(40, 10, color, textbuffer);

  sprintf(textbuffer, "Pulsetable Pos  %02X", instr[einum].ptr[PTBL]);
  if (eipos == 3) color = CEDIT; else color = CNORMAL;
  printtext(40, 11, color, textbuffer);

  sprintf(textbuffer, "Filtertable Pos %02X", instr[einum].ptr[FTBL]);
  if (eipos == 4) color = CEDIT; else color = CNORMAL;
  printtext(40, 12, color, textbuffer);

  sprintf(textbuffer, "Vibrato Delay   %02X", instr[einum].vibdelay);
  if (eipos == 5) color = CEDIT; else color = CNORMAL;
  printtext(61, 8, color, textbuffer);

  sprintf(textbuffer, "Vibrato Spd/Dep %02X", instr[einum].vibparam);
  if (eipos == 6) color = CEDIT; else color = CNORMAL;
  printtext(61, 9, color, textbuffer);

  sprintf(textbuffer, "Gateoff Timer   %02X", instr[einum ? 1 : 0].gatetimer);
  if (eipos == 7) color = CEDIT; else color = CNORMAL;
  printtext(61, 10, color, textbuffer);

  sprintf(textbuffer, "HardRes/1stWave %02X", instr[einum ? 1 : 0].firstwave);
  if (eipos == 8) color = CEDIT; else color = CNORMAL;
  printtext(61, 11, color, textbuffer);

  if (editmode == EDIT_INSTRUMENT)
  {
    if (eipos < 9)
      printbg(56+eicolumn+21*(eipos/5), 8+(eipos%5), cc, 1);
    else
    {
      printbg(61+strlen(instr[einum].name), 7, cc, 1);
    }
  }

  sprintf(textbuffer, "WAVE  TABLE   PULSE TABLE   FILTERTABLE");
  printtext(40, 14, CTITLE, textbuffer);

  for (c = 0; c < MAX_TABLES; c++)
  {
    for (d = 0; d < VISIBLETABLEROWS; d++)
    {
      int p = etview+d;

      color = CNORMAL;
      switch (c)
      {
      	case WTBL:
        if (ltable[c][p] == 0xff) color = CCOMMAND;
        break;
        
      	case PTBL:
      	case FTBL:
        if (ltable[c][p] >= 0x80) color = CCOMMAND;
        break;
      }
      if ((p == etpos) && (etnum == c)) color = CEDIT;
      sprintf(textbuffer, " %02X: %02X %02X ", p+1, ltable[c][p], rtable[c][p]);
      printtext(40+14*c, 15+d, color, textbuffer);

      if (etmarknum == c)
      {
        if (etmarkstart <= etmarkend)
        {
          if ((p >= etmarkstart) && (p <= etmarkend))
            printbg(40+14*c+5, 15+d, 1, 5);
        }
        else
        {
          if ((p <= etmarkstart) && (p >= etmarkend))
            printbg(40+14*c+5, 15+d, 1, 5);
        }
      }
    }
  }

  if (editmode == EDIT_TABLES)
  {
    printbg(45+etnum*14+(etcolumn & 1)+(etcolumn/2)*3, 15+etpos-etview, cc, 1);
  }

  if (enpos == 0)
  {
    printtext(40, 21, CTITLE, "NAME   ");
    sprintf(textbuffer, "%-32s", songname);
    printtext(47, 21, CEDIT, textbuffer);
  }

  if (enpos == 1)
  {
    printtext(40, 21, CTITLE, "AUTHOR ");
    sprintf(textbuffer, "%-32s", authorname);
    printtext(47, 21, CEDIT, textbuffer);
  }

  if (enpos == 2)
  {
    printtext(40, 21, CTITLE, "COPYR. ");
    sprintf(textbuffer, "%-32s", copyrightname);
    printtext(47, 21, CEDIT, textbuffer);
  }

  if (editmode == EDIT_NAMES)
  {
    switch(enpos)
    {
      case 0:
      printbg(47+strlen(songname), 21, cc, 1);
      break;
      case 1:
      printbg(47+strlen(authorname), 21, cc, 1);
      break;
      case 2:
      printbg(47+strlen(copyrightname), 21, cc, 1);
      break;
    }
  }
  sprintf(textbuffer, "OCTAVE %d", epoctave);
  printtext(0, 23, CTITLE, textbuffer);

  switch(autoadvance)
  {
    case 0:
    color = 10;
    break;

    case 1:
    color = 14;
    break;

    case 2:
    color = 12;
    break;
  }

  if (recordmode) printtext(0, 24, color, "EDITMODE");
  else printtext(0, 24, color, "JAM MODE");

  if (!songinit) printtext(10, 23, CTITLE, "PLAYING");
  else printtext(10, 23, CTITLE, "STOPPED");
  if (multiplier)
  {
    if (!ntsc)
      sprintf(textbuffer, " %02d%c%02d ", timemin, timechar[timeframe/(25*multiplier)], timesec);
    else
      sprintf(textbuffer, " %02d%c%02d ", timemin, timechar[timeframe/(30*multiplier)], timesec);
  }
  else
  {
    if (!ntsc)
      sprintf(textbuffer, " %02d%c%02d ", timemin, timechar[timeframe/13], timesec);
    else
      sprintf(textbuffer, " %02d%c%02d ", timemin, timechar[timeframe/15], timesec);
  }

  printtext(10, 24, CEDIT, textbuffer);

  printtext(60, 23, CTITLE, " CHN1   CHN2   CHN3 ");
  for (c = 0; c < MAX_CHN; c++)
  {
    int chnpos = chn[c].songptr;
    int chnrow = chn[c].pattptr/4;
    chnpos--;
    if (chnpos < 0) chnpos = 0;
    if (chnrow > pattlen[chn[c].pattnum]) chnrow = pattlen[chn[c].pattnum];

    sprintf(textbuffer, "%03d/%02d",
      chnpos,chnrow);
    printtext(60+7*c, 24, CEDIT, textbuffer);
  }
}

void displayupdate(void)
{
  if (cursorflashdelay >= 5)
  {
    cursorflashdelay %= 5;
    cursorflash++;
    cursorflash &= 3;
    printstatus();
    fliptoscreen();
  }
  else
  {
    if (rawkey)
    {
      printstatus();
      fliptoscreen();
    }
  }
}

