//
// GOATTRACKER v2 instrument & table editor
//

#include "goattrk2.h"

int cutinstr = -1;

void instrumentcommands(void)
{
  switch(rawkey)
  {
  	case 0x8:
    case KEY_DEL:
    if ((einum) && (shiftpressed) && (eipos < 9))
    {
      deleteinstrtable(einum);
      memcpy(&instrcopybuffer, &instr[einum], sizeof(INSTR));
      memset(&instr[einum], 0, sizeof(INSTR));
      if (multiplier)
        instr[einum].gatetimer = 2 * multiplier;
      else
        instr[einum].gatetimer = 1;
      instr[einum].firstwave = 0x9;
    }
    break;

    case KEY_X:
    if ((einum) && (shiftpressed) && (eipos < 9))
    {
      cutinstr = einum;
      memcpy(&instrcopybuffer, &instr[einum], sizeof(INSTR));
      memset(&instr[einum], 0, sizeof(INSTR));
      if (multiplier)
        instr[einum].gatetimer = 2 * multiplier;
      else
        instr[einum].gatetimer = 1;
      instr[einum].firstwave = 0x9;
    }
    break;

    case KEY_C:
    if ((einum) && (shiftpressed) && (eipos < 9))
    {
      cutinstr = -1;
      memcpy(&instrcopybuffer, &instr[einum], sizeof(INSTR));
    }
    break;

    case KEY_S:
    if ((einum) && (shiftpressed) && (eipos < 9))
    {
      memcpy(&instr[einum], &instrcopybuffer, sizeof(INSTR));
      if (cutinstr != -1)
      {
       	int c, d;
    	  for (c = 0; c < MAX_PATT; c++)
        {
      		for (d = 0; d < pattlen[c]; d++)
      		  if (pattern[c][d*4+1] == cutinstr) pattern[c][d*4+1] = einum;
        }
      }
    }
    break;

    case KEY_V:
    if ((einum) && (shiftpressed) && (eipos < 9))
    {
      memcpy(&instr[einum], &instrcopybuffer, sizeof(INSTR));
    }
    break;

    case KEY_RIGHT:
    if (eipos < 9)
    {
      eicolumn++;
      if (eicolumn > 1)
      {
        eicolumn = 0;
        eipos += 5;
        if (eipos >= 9) eipos -= 10;
        if (eipos < 0) eipos = 8;
      }
    }
    break;

    case KEY_LEFT:
    if (eipos < 9)
    {
      eicolumn--;
      if (eicolumn < 0)
      {
      	eicolumn = 1;
      	eipos -= 5;
      	if (eipos < 0) eipos += 10;
      	if (eipos >= 9) eipos = 8;
      }
    }
    break;

    case KEY_DOWN:
    if (eipos < 9)
    {
    	eipos++;
    	if (eipos > 8) eipos = 0;
    }
    break;

    case KEY_UP:
    if (eipos < 9)
    {
    	eipos--;
    	if (eipos < 0) eipos = 8;
    }
    break;

    case KEY_N:
    if ((eipos != 9) && (shiftpressed))
    {
      eipos = 9;
      return;
    }
    break;

    case KEY_SPACE:
    if (eipos != 9)
    {
    	if (!shiftpressed)
        playtestnote(FIRSTNOTE + epoctave * 12);
      else
        chn[epchn].gate = 0xfe;
    }
    break;

    case KEY_ENTER:
    switch(eipos)
    {
    	case 2:
    	case 3:
    	case 4:
    	if (instr[einum].ptr[eipos-2])
      	etpos = instr[einum].ptr[eipos-2] - 1;
      else
      {
        etpos = gettablelen(eipos-2);
        if (etpos >= MAX_TABLELEN-1) etpos = MAX_TABLELEN - 1;
        if (shiftpressed) instr[einum].ptr[eipos-2] = etpos + 1;
      }
    	editmode = EDIT_TABLES;
    	etnum = eipos-2;
     	etcolumn = 0;
      if (etpos - etview < 0)
        etview = etpos;
      if (etpos - etview >= VISIBLETABLEROWS)
        etview = etpos - VISIBLETABLEROWS + 1;
      return;

      case 9:
      eipos = 0;
      break;
    }
    break;
  }

  if ((eipos == 9) && (einum)) editstring(instr[einum].name, MAX_INSTRNAMELEN);
  if ((hexnybble >= 0) && (eipos < 9) && (einum))
  {
    unsigned char *ptr = &instr[einum].ad;
    if ((einum != 1) && (eipos >= 7)) ptr = &instr[1].ad;
    ptr += eipos;
    
    switch(eicolumn)
    {
      case 0:
      *ptr &= 0x0f;
      *ptr |= hexnybble << 4;
      eicolumn++;
      break;

      case 1:
      *ptr &= 0xf0;
      *ptr |= hexnybble;
      eicolumn++;
      if (eicolumn > 1)
      {
        eicolumn = 0;
        eipos++;
        if (eipos >= 9) eipos = 0;
      }
      break;
    }
    // Validate instrument parameters
    if (instr[einum].gatetimer < 1) instr[einum].gatetimer = 1;
  }
}

void tablecommands(void)
{
  int c;

  switch(rawkey)
  {
    case KEY_SPACE:
  	if (!shiftpressed)
      playtestnote(FIRSTNOTE + epoctave * 12);
    else
      chn[epchn].gate = 0xfe;
    break;

  	case KEY_RIGHT:
  	etcolumn++;
  	if (etcolumn > 3)
    {
    	etcolumn = 0;
  		etnum++;
  		if (etnum > 2) etnum = 0;
    }
    if (shiftpressed) etmarknum = -1;
    break;

    case KEY_LEFT:
    etcolumn--;
    if (etcolumn < 0)
    {
    	etcolumn = 3;
  		etnum--;
   		if (etnum < 0) etnum = 2;
    }
    if (shiftpressed) etmarknum = -1;
    break;

    case KEY_UP:
    if (shiftpressed)
    {
      if ((etmarknum != etnum) || (etpos != etmarkend))
      {
        etmarknum = etnum;
        etmarkstart = etmarkend = etpos;
      }
    }
    etpos--;
    if (etpos < 0) etpos = 0;
    if (shiftpressed) etmarkend = etpos;
    break;

    case KEY_PGUP:
    if (shiftpressed)
    {
      if ((etmarknum != etnum) || (etpos != etmarkend))
      {
        etmarknum = etnum;
        etmarkstart = etmarkend = etpos;
      }
    }
    for (c = 0; c < PGUPDNREPEAT; c++)
    {
      etpos--;
      if (etpos < 0) etpos = 0;
    }
    if (shiftpressed) etmarkend = etpos;
    break;

    case KEY_DOWN:
    if (shiftpressed)
    {
      if ((etmarknum != etnum) || (etpos != etmarkend))
      {
        etmarknum = etnum;
        etmarkstart = etmarkend = etpos;
      }
    }
    etpos++;
    if (etpos >= MAX_TABLELEN) etpos = MAX_TABLELEN-1;
    if (shiftpressed) etmarkend = etpos;
    break;

    case KEY_PGDN:
    if (shiftpressed)
    {
      if ((etmarknum != etnum) || (etpos != etmarkend))
      {
        etmarknum = etnum;
        etmarkstart = etmarkend = etpos;
      }
    }
    for (c = 0; c < PGUPDNREPEAT; c++)
    {
      etpos++;
      if (etpos >= MAX_TABLELEN) etpos = MAX_TABLELEN-1;
    }
    if (shiftpressed) etmarkend = etpos;
    break;

    case KEY_X:
    case KEY_C:
    if (shiftpressed)
    {
      if (etmarknum != -1)
      {
      	int d = 0;
        if (etmarkstart <= etmarkend)
        {
        	for (c = etmarkstart; c <= etmarkend; c++)
        	{
        		ltablecopybuffer[d] = ltable[etmarknum][c];
        		rtablecopybuffer[d] = rtable[etmarknum][c];
        		if (rawkey == KEY_X)
        		{
        			ltable[etmarknum][c] = 0;
        			rtable[etmarknum][c] = 0;
        		}
        		d++;
        	}
        }
        else
        {
        	for (c = etmarkend; c <= etmarkstart; c++)
        	{
        		ltablecopybuffer[d] = ltable[etmarknum][c];
        		rtablecopybuffer[d] = rtable[etmarknum][c];
        		if (rawkey == KEY_X)
        		{
        			ltable[etmarknum][c] = 0;
        			rtable[etmarknum][c] = 0;
        		}
        		d++;
        	}
        }
        tablecopyrows = d;
      }
      etmarknum = -1;
    }
    break;

    case KEY_V:
    if (tablecopyrows)
    {
      for (c = 0; c < tablecopyrows; c++)
      {
        ltable[etnum][etpos] = ltablecopybuffer[c];
        rtable[etnum][etpos] = rtablecopybuffer[c];
        etpos++;
        if (etpos >= MAX_TABLELEN) etpos = MAX_TABLELEN-1;
      }
    }
    break;

    case KEY_L:
    if (etnum == PTBL)
    {
    	int c;
     	int currentpulse = -1;
      int targetpulse = ltable[etnum][etpos] << 4;
      int speed = rtable[etnum][etpos] & 0x7f;
      int time;
      int steps;

      if (!speed) break;

    	// Follow the chain of pulse commands backwards to the nearest set command so we know what current pulse is
    	for (c = etpos-1; c >= 0; c--)
    	{
    		if (ltable[etnum][c] == 0xff) break;
    		if (ltable[etnum][c] >= 0x80)
        {
    			currentpulse = (ltable[etnum][c] << 8) | rtable[etnum][c];
    			currentpulse &= 0xfff;
    			break;
    		}
      }
      if (currentpulse == -1) break;

      // Then follow the chain of modulation steps
      for (; c < etpos; c++)
      {
      	if (ltable[etnum][c] < 0x80)
      	{
      		currentpulse += ltable[etnum][c] * ((rtable[etnum][c] << 1) & 0xff);
      		if (rtable[etnum][c] >= 0x80) currentpulse -= 256 * ltable[etnum][c];
      		currentpulse &= 0xfff;
      	}
      }

      time = abs(targetpulse - currentpulse) / (speed * 2);
      steps = (time + 126) / 127;
      if (!steps) break;
      if (etpos + steps > MAX_TABLELEN) break;
      if (targetpulse < currentpulse) speed = -speed;

      // Make room in the table
      for (c = steps; c > 1; c--) inserttable(etnum, etpos, 1);

      while (time)
      {
      	if (time < 127)	ltable[etnum][etpos] = time;
      	  else ltable[etnum][etpos] = 127;
      	rtable[etnum][etpos] = speed;
        time -= ltable[etnum][etpos];
        etpos++;
      }
    }
    if (etnum == FTBL)
    {
    	int c;
     	int currentfilter = -1;
      int targetfilter = ltable[etnum][etpos];
      int speed = rtable[etnum][etpos] & 0x7f;
      int time;
      int steps;

      if (!speed) break;

    	// Follow the chain of filter commands backwards to the nearest set command so we know what current pulse is
    	for (c = etpos-1; c >= 0; c--)
    	{
    		if (ltable[etnum][c] == 0xff) break;
    		if (ltable[etnum][c] == 0x00)
        {
    			currentfilter = rtable[etnum][c];
    			break;
    		}
      }
      if (currentfilter == -1) break;

      // Then follow the chain of modulation steps
      for (; c < etpos; c++)
      {
      	if (ltable[etnum][c] < 0x80)
      	{
      		currentfilter += ltable[etnum][c] * rtable[etnum][c];
      		currentfilter &= 0xff;
      	}
      }

      time = abs(targetfilter - currentfilter) / speed;
      steps = (time + 126) / 127;
      if (!steps) break;
      if (etpos + steps > MAX_TABLELEN) break;
      if (targetfilter < currentfilter) speed = -speed;

      // Make room in the table
      for (c = steps; c > 1; c--) inserttable(etnum, etpos, 1);

      while (time)
      {
      	if (time < 127)	ltable[etnum][etpos] = time;
      	  else ltable[etnum][etpos] = 127;
      	rtable[etnum][etpos] = speed;
        time -= ltable[etnum][etpos];
        etpos++;
      }
    }
    break;

    case KEY_N:
    if ((etnum > WTBL) && (shiftpressed))
    {
    	if (ltable[etnum][etpos] < 0x80)
    	  rtable[etnum][etpos] = (rtable[etnum][etpos] ^ 0xff) + 1;
    }
    break;

    case KEY_DEL:
    deletetable(etnum, etpos);
    break;

    case KEY_INS:
  	inserttable(etnum, etpos, shiftpressed);
    break;

    case KEY_ENTER:
    editmode = EDIT_INSTRUMENT;
    eipos = etnum + 2;
    return;
  }

  if (hexnybble >= 0)
  {
		switch(etcolumn)
 		{
			case 0:
 			ltable[etnum][etpos] &= 0x0f;
 			ltable[etnum][etpos] |= hexnybble << 4;
 			break;
 			case 1:
 			ltable[etnum][etpos] &= 0xf0;
 			ltable[etnum][etpos] |= hexnybble;
 			break;
 			case 2:
 			rtable[etnum][etpos] &= 0x0f;
 			rtable[etnum][etpos] |= hexnybble << 4;
 			break;
 			case 3:
 			rtable[etnum][etpos] &= 0xf0;
 			rtable[etnum][etpos] |= hexnybble;
 			break;
 		}
    etcolumn++;
    if (etcolumn > 3)
    {
    	etcolumn = 0;
    	etpos++;
	    if (etpos >= MAX_TABLELEN) etpos = MAX_TABLELEN-1;
    }
  }

  if (etpos - etview < 0)
    etview = etpos;
  if (etpos - etview >= VISIBLETABLEROWS)
    etview = etpos - VISIBLETABLEROWS + 1;
}

void deletetable(int num, int pos)
{
  int c, d;

  // Shift tablepointers in instruments
	for (c = 1; c < MAX_INSTR; c++)
 	{
		if ((instr[c].ptr[num]-1) > pos) instr[c].ptr[num]--;
 	}

  // Shift tablepointers in patterns
  for (c = 0; c < MAX_PATT; c++)
  {
    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      if (pattern[c][d*4+2] == CMD_SETWAVEPTR+num)
      {
      	if ((pattern[c][d*4+3]-1) > pos) pattern[c][d*4+3]--;
      }
    }
  }

  // Shift jumppointers in the table itself
  for (c = 0; c < MAX_TABLELEN; c++)
  {
  	if (ltable[num][c] == 0xff)
  	  if ((rtable[num][c]-1) > pos) rtable[num][c]--;
  }

  for (c = pos; c < MAX_TABLELEN; c++)
  {
 		if (c+1 < MAX_TABLELEN)
 		{
   		ltable[num][c] = ltable[num][c+1];
   		rtable[num][c] = rtable[num][c+1];
    }
    else
		{
   		ltable[num][c] = 0;
   		rtable[num][c] = 0;
    }
  }
}

void inserttable(int num, int pos, int mode)
{
  int c, d;

  // Shift tablepointers in instruments
 	for (c = 1; c < MAX_INSTR; c++)
 	{
    if (!mode)
    {
      if ((instr[c].ptr[num]-1) >= pos) instr[c].ptr[num]++;
    }
    else
    {
      if ((instr[c].ptr[num]-1) > pos) instr[c].ptr[num]++;
    }
 	}

  // Shift tablepointers in patterns
  for (c = 0; c < MAX_PATT; c++)
  {
    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      if (pattern[c][d*4+2] == CMD_SETWAVEPTR+num)
      {
      	if (!mode)
      	{
        	if ((pattern[c][d*4+3]-1) >= pos) pattern[c][d*4+3]++;
        }
        else
      	{
        	if ((pattern[c][d*4+3]-1) > pos) pattern[c][d*4+3]++;
        }
      }
    }
  }

  // Shift jumppointers in the table itself
  for (c = 0; c < MAX_TABLELEN; c++)
  {
  	if (ltable[num][c] == 0xff)
  	{
  		if (!mode)
  		{
    	  if ((rtable[num][c]-1) >= pos) rtable[num][c]++;
      }
      else
  		{
    	  if ((rtable[num][c]-1) > pos) rtable[num][c]++;
      }
    }
  }

  for (c = MAX_TABLELEN-1; c >= pos; c--)
  {
		if (c > pos)
 		{
   		ltable[num][c] = ltable[num][c-1];
   		rtable[num][c] = rtable[num][c-1];
    }
    else
		{
			if ((num == 0) && (mode == 1))
			{
     		ltable[num][c] = 0x9;
     		rtable[num][c] = 0;
      }
      else
			{
     		ltable[num][c] = 0;
     		rtable[num][c] = 0;
      }
    }
  }
}

int gettablelen(int num)
{
  int c;

  for (c = MAX_TABLELEN-1; c >= 0; c--)
  {
		if (ltable[num][c] | rtable[num][c]) break;
 	}
 	return c+1;
}

int gettablepartlen(int num, int pos)
{
  int c;

  for (c = pos; c < MAX_TABLELEN; c++)
  {
		if (ltable[num][c] == 0xff)
    {
    	c++;
      break;
    }
	}
 	return c-pos;
}

void deleteinstrtable(int i)
{
  int c,d;
  int eraseok = 1;

  for (c = 0; c < 3; c++)
  {
    if (instr[i].ptr[c])
    {
    	int pos = instr[i].ptr[c]-1;
    	int len = gettablepartlen(c, pos);

    	// Check that this table area isn't used by another instrument
    	for (d = 1; d < MAX_INSTR; d++)
    	{
    		if ((d != i) && (instr[d].ptr[c]))
    		{
    			int cmppos = instr[d].ptr[c]-1;
    			if ((cmppos >= pos) && (cmppos < pos+len)) eraseok = 0;
    		}
    	}
      if (eraseok)
      	while (len--) deletetable(c, pos);
    }
  }
}




