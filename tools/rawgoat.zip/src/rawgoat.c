//
// RAWGOAT v2.0
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#define GOATTRK2_C

#include "goattrk2.h"

INSTR instr[MAX_INSTR];
unsigned char ltable[3][MAX_TABLELEN];
unsigned char rtable[3][MAX_TABLELEN];
unsigned char songorder[MAX_SONGS][MAX_CHN][MAX_SONGLEN+2];
unsigned char pattern[MAX_PATT][MAX_PATTROWS*4+4];
unsigned char funktable[2];
int pattlen[MAX_PATT];
int songlen[MAX_SONGS][MAX_CHN];

INSTR instrcopybuffer;
unsigned char patterncopybuffer[MAX_PATTROWS*4+4];
unsigned char trackcopybuffer[MAX_SONGLEN+2];
unsigned char cmdcopybuffer = 0;
unsigned char cmddatacopybuffer = 0;
unsigned char ltablecopybuffer[MAX_TABLELEN];
unsigned char rtablecopybuffer[MAX_TABLELEN];

unsigned char songname[MAX_STR];
unsigned char authorname[MAX_STR];
unsigned char copyrightname[MAX_STR];

unsigned char loadedsongfilename[MAX_FILENAME];
unsigned char songfilename[MAX_FILENAME];
unsigned char songfilter[MAX_FILENAME];
unsigned char songpath[MAX_PATHNAME];
unsigned char instrfilename[MAX_FILENAME];
unsigned char instrfilter[MAX_FILENAME];
unsigned char instrpath[MAX_PATHNAME];
unsigned char packedpath[MAX_PATHNAME];
DIRENTRY direntry[MAX_DIRFILES];

int espos[MAX_CHN];
int eseditpos;
int esview;
int escolumn;
int eschn;
int esnum;
int epnum[MAX_CHN];
int eppos;
int epview;
int epcolumn;
int epchn;
int epoctave = 2;
int einum;
int eipos;
int eicolumn;
int etnum;
int etview;
int etpos;
int etcolumn;

int ewtpos;
int ewtview;
int ewtcolumn;
int eptpos;
int eptview;
int eptcolumn;
int eftpos;
int eftview;
int eftolumn;

int enpos;
int editmode = EDIT_PATTERN;
int recordmode = 1;
int followplay = 0;
int hexnybble = -1;
int highestusedpattern;
int highestusedinstr;
int scrrep;
int stepsize = 4;
int epmarkchn = -1;
int epmarkstart;
int epmarkend;
int etmarknum = -1;
int etmarkstart;
int etmarkend;
int patterncopyrows = 0;
int tablecopyrows = 0;
int cmdcopymode = 0;
int autoadvance = 0;
int defaultpatternlength = 64;
int keypreset = KEY_TRACKER;
int playerversion = PLAYER_STD;
int fileformat = FORMAT_PRG;
int zeropageadr = 0xfc;
int playeradr = 0x1000;
unsigned sidmodel = 0;
unsigned multiplier = 1;
unsigned adparam = 0x0f00;
unsigned ntsc = 0;
unsigned patternhex = 0;
unsigned sidaddress = 0xd400;
char configbuf[MAX_PATHNAME];
char *configptr;

extern unsigned char datafile[];

CHN chn[MAX_CHN];
unsigned char filterctrl = 0;
unsigned char filtertype = 0;
unsigned char filtercutoff = 0;
unsigned char filtertime = 0;
unsigned char filterptr = 0;
unsigned char masterfader = 0x0f;
unsigned char songinit;
int psnum;
int timemin = 0;
int timesec = 0;
int timeframe = 0;

int cursorflash = 0;
int cursorcolortable[] = {1,2,7,2};
int exitprogram = 0;

char textbuffer[MAX_PATHNAME];
char *programname = "RawGoat v2.0";

unsigned char notekeytbl1[] = {KEY_Z, KEY_S, KEY_X, KEY_D, KEY_C, KEY_V,
  KEY_G, KEY_B, KEY_H, KEY_N, KEY_J, KEY_M, KEY_COMMA, KEY_L, KEY_COLON};

unsigned char notekeytbl2[] = {KEY_Q, KEY_2, KEY_W, KEY_3, KEY_E, KEY_R,
  KEY_5, KEY_T, KEY_6, KEY_Y, KEY_7, KEY_U, KEY_I, KEY_9, KEY_O, KEY_0, KEY_P};

unsigned char dmckeytbl[] = {KEY_A, KEY_W, KEY_S, KEY_E, KEY_D, KEY_F,
  KEY_T, KEY_G, KEY_Y, KEY_H, KEY_U, KEY_J, KEY_K, KEY_O, KEY_L, KEY_P};

unsigned char hexkeytbl[] = {'0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

char timechar[] = {':', ' '};

char *notename[] =
 {"C-0", "C#0", "D-0", "D#0", "E-0", "F-0", "F#0", "G-0", "G#0", "A-0", "A#0", "B-0",
  "C-1", "C#1", "D-1", "D#1", "E-1", "F-1", "F#1", "G-1", "G#1", "A-1", "A#1", "B-1",
  "C-2", "C#2", "D-2", "D#2", "E-2", "F-2", "F#2", "G-2", "G#2", "A-2", "A#2", "B-2",
  "C-3", "C#3", "D-3", "D#3", "E-3", "F-3", "F#3", "G-3", "G#3", "A-3", "A#3", "B-3",
  "C-4", "C#4", "D-4", "D#4", "E-4", "F-4", "F#4", "G-4", "G#4", "A-4", "A#4", "B-4",
  "C-5", "C#5", "D-5", "D#5", "E-5", "F-5", "F#5", "G-5", "G#5", "A-5", "A#5", "B-5",
  "C-6", "C#6", "D-6", "D#6", "E-6", "F-6", "F#6", "G-6", "G#6", "A-6", "A#6", "B-6",
  "C-7", "C#7", "D-7", "D#7", "E-7", "F-7", "F#7", "G-7", "G#7", "...", "---", "+++"};

unsigned char freqtbllo[] = {
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x2d,0x4e,0x71,0x96,0xbe,0xe8,0x14,0x43,0x74,0xa9,0xe1,0x1c,
  0x5a,0x9c,0xe2,0x2d,0x7c,0xcf,0x28,0x85,0xe8,0x52,0xc1,0x37,
  0xb4,0x39,0xc5,0x5a,0xf7,0x9e,0x4f,0x0a,0xd1,0xa3,0x82,0x6e,
  0x68,0x71,0x8a,0xb3,0xee,0x3c,0x9e,0x15,0xa2,0x46,0x04,0xdc,
  0xd0,0xe2,0x14,0x67,0xdd,0x79,0x3c,0x29,0x44,0x8d,0x08,0xb8,
  0xa1,0xc5,0x28,0xcd,0xba,0xf1,0x78,0x53,0x87,0x1a,0x10,0x71,
  0x42,0x89,0x4f,0x9b,0x74,0xe2,0xf0,0xa6,0x0e,0x33,0x20,0xff,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

unsigned char freqtblhi[] = {
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x02,0x02,0x02,0x02,0x02,0x02,0x03,0x03,0x03,0x03,0x03,0x04,
  0x04,0x04,0x04,0x05,0x05,0x05,0x06,0x06,0x06,0x07,0x07,0x08,
  0x08,0x09,0x09,0x0a,0x0a,0x0b,0x0c,0x0d,0x0d,0x0e,0x0f,0x10,
  0x11,0x12,0x13,0x14,0x15,0x17,0x18,0x1a,0x1b,0x1d,0x1f,0x20,
  0x22,0x24,0x27,0x29,0x2b,0x2e,0x31,0x34,0x37,0x3a,0x3e,0x41,
  0x45,0x49,0x4e,0x52,0x57,0x5c,0x62,0x68,0x6e,0x75,0x7c,0x83,
  0x8b,0x93,0x9c,0xa5,0xaf,0xb9,0xc4,0xd0,0xdd,0xea,0xf8,0xff,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};


int main(int argc, char **argv)
{
  unsigned b = DEFAULTBUFFER;
  unsigned mr = DEFAULTMIXRATE;
  unsigned writer = 0;
  unsigned hardsid = 0;
  unsigned catweasel = 0;
  unsigned interpolate = 0;
  char filename[MAX_PATHNAME];
  FILE *configfile;
  int c,d;
  int info = 0;

  io_openlinkeddatafile(datafile);

  #ifdef __WIN32__
  GetModuleFileName(NULL, filename, MAX_PATHNAME);
  filename[strlen(filename)-3] = 'c';
  filename[strlen(filename)-2] = 'f';
  filename[strlen(filename)-1] = 'g';
  #else
  strcpy(filename, getenv("HOME"));
  strcat(filename, "/.goattrk/goattrk2.cfg");
  #endif

  // Reset names
  memset(loadedsongfilename, 0, sizeof loadedsongfilename);
  memset(songfilename, 0, sizeof songfilename);
  memset(instrfilename, 0, sizeof instrfilename);
  memset(songpath, 0, sizeof songpath);
  memset(instrpath, 0, sizeof instrpath);
  memset(packedpath, 0, sizeof packedpath);
  for (c = 0; c < MAX_DIRFILES; c++)
     direntry[c].name = NULL;
  strcpy(songfilter, "*.sng");
  strcpy(instrfilter, "*.ins");

  // Load configuration
  configfile = fopen(filename, "rt");
  configptr = NULL;
  if (configfile)
  {
    getparam(configfile, &b);
    getparam(configfile, &mr);
    getparam(configfile, &hardsid);
    getparam(configfile, &sidmodel);
    getparam(configfile, &ntsc);
    getparam(configfile, &fileformat);
    getparam(configfile, &playeradr);
    getparam(configfile, &zeropageadr);
    getparam(configfile, &playerversion);
    getparam(configfile, &keypreset);
    getparam(configfile, &stepsize);
    getparam(configfile, &catweasel);
    getparam(configfile, &adparam);
    getparam(configfile, &interpolate);
    getparam(configfile, &patternhex);
    getparam(configfile, &sidaddress);
    fclose(configfile);
  }
  adparam &= 0xff00;
  zeropageadr &= 0xff;
  playeradr &= 0xff00;
  sidaddress &= 0xffff;
  if (!stepsize) stepsize = 4;
  if ((sidaddress < 1) ||(sidaddress > 0xffff)) sidaddress = 0xd400;

  if (!initscreen())
  {
    return 1;
  }

  // Scan command line
  for (c = 1; c < argc; c++)
  {
    if ((argv[c][0] == '-') || (argv[c][0] == '/'))
    {
      int y = 0;
      switch(toupper(argv[c][1]))
      {
        case '?':
        printtext(0,y++,15,"Usage: GOATTRK2 [songname] [options]");
        printtext(0,y++,15,"Options:");
        printtext(0,y++,15,"/Axx Set ADSR parameter for hardrestart in hex. DEFAULT=0F00");
        printtext(0,y++,15,"/Bxx Set sound buffer length in milliseconds DEFAULT=100");
        printtext(0,y++,15,"/Cxx Use CatWeasel MK3 PCI SID (0 = off, 1 = on)");
        printtext(0,y++,15,"/Dxx Pattern row display (0 = decimal, 1 = hexadecimal)");
        printtext(0,y++,15,"/Exx Set emulated SID model (0 = 6581 1 = 8580) DEFAULT=6581");
        printtext(0,y++,15,"/Hxx Use HardSID (0 = off, 1 = HardSID ID0 2 = HardSID ID1 etc.)");
        printtext(0,y++,15,"/Ixx Set reSID interpolation (0 = off, 1 = on) DEFAULT=off");
        printtext(0,y++,15,"/Kxx Note-entry mode (0 = PROTRACKER 1 = DMC) DEFAULT=PROTRK.");
        printtext(0,y++,15,"/Lxx SID memory location in hex. DEFAULT=D400");
        printtext(0,y++,15,"/Mxx Set sound mixing rate DEFAULT=44100");
        printtext(0,y++,15,"/N   Use NTSC timing");
        printtext(0,y++,15,"/P   Use PAL timing (DEFAULT)");
        printtext(0,y++,15,"/W   Write sound output to a file SIDAUDIO.RAW");
        printtext(0,y++,15,"/?   Show this info again");
        fliptoscreen();
        kbd_waitkey();
        info = 1;
        break;

        case 'A':
        sscanf(&argv[c][2], "%x", &adparam);
        break;

        case 'B':
        sscanf(&argv[c][2], "%u", &b);
        break;

        case 'D':
        sscanf(&argv[c][2], "%u", &patternhex);
        break;

        case 'E':
        sscanf(&argv[c][2], "%u", &sidmodel);
        break;

        case 'I':
        sscanf(&argv[c][2], "%u", &interpolate);
        break;

        case 'K':
        sscanf(&argv[c][2], "%u", &keypreset);
        break;

        case 'L':
        sscanf(&argv[c][2], "%x", &sidaddress);
        break;

        case 'N':
        ntsc = 1;
        break;

        case 'P':
        ntsc = 0;
        break;

        case 'M':
        sscanf(&argv[c][2], "%u", &mr);
        break;

        case 'H':
        sscanf(&argv[c][2], "%u", &hardsid);
        break;

        case 'W':
        writer = 1;
        break;

        case 'C':
        sscanf(&argv[c][2], "%u", &catweasel);
        break;
      }
    }
    else
    {
    	char startpath[MAX_PATHNAME];

    	strcpy(songfilename, argv[c]);
      for (d = strlen(argv[c])-1; d >= 0; d--)
      {
        if ((argv[c][d] == '/') || (argv[c][d] == '\\'))
        {
        	strcpy(startpath, argv[c]);
        	startpath[d+1] = 0;
        	chdir(startpath);
        	strcpy(songfilename, &argv[c][d+1]);
          break;
        }
      }
    }
    if (info) return 0;
  }

  // Init pathnames
  getcwd(songpath, MAX_PATHNAME);
  strcpy(instrpath, songpath);
  strcpy(packedpath, songpath);

  // Validate parameters
  sidmodel &= 1;
  adparam &= 0xffff;
  if ((sidaddress < 1) ||(sidaddress > 0xffff)) sidaddress = 0xd400;
  if (keypreset > 2) keypreset = 0;

  // Reset channels/song
  memset(chn, 0, sizeof chn);
  clearsong(1,1,1,1,1);

  // Init sound
  if (!sound_init(b, mr, writer, hardsid, sidmodel, ntsc, multiplier, catweasel, interpolate))
  {
    printtextc(11,15,"Sound init failed.");
    printtextc(12,15,"Check that soundcard drivers are installed.");
    fliptoscreen();
    kbd_waitkey();
    return 1;
  }
  atexit(sound_uninit);

  // Load song if applicable
  if (strlen(songfilename)) loadsong();

  // Start editor mainloop
  printmainscreen();
  while (!exitprogram)
  {
    waitkey();
    docommand();
  }

  // Save configuration
  #ifndef __WIN32__
  strcpy(filename, getenv("HOME"));
  strcat(filename, "/.goattrk");
  mkdir(filename, S_IRUSR | S_IWUSR | S_IXUSR);
  strcat(filename, "/goattrk2.cfg");
  #endif
  configfile = fopen(filename, "wt");
  if (configfile)
  {
    fprintf(configfile, ";------------------------------------------------------------------------------\n"
                        ";RAWGOAT config. Rows starting with ; are comments. Hexadecimal parameters are \n"
                        ";to be preceded with $ and decimal parameters with nothing.                    \n"
                        ";------------------------------------------------------------------------------\n"
                        "\n"
                        ";reSID buffer length (in milliseconds)\n%d\n\n"
                        ";reSID mixing rate (in Hz)\n%d\n\n"
                        ";Hardsid device number (0 = off)\n%d\n\n"
                        ";reSID model (0 = 6581, 1 = 8580)\n%d\n\n"
                        ";Timing mode (0 = PAL, 1 = NTSC)\n%d\n\n"
                        ";Packer/relocator fileformat (0 = SID, 1 = PRG, 2 = BIN)\n%d\n\n"
                        ";Packer/relocator player address\n$%04x\n\n"
                        ";Packer/relocator zeropage baseaddress\n$%02x\n\n"
                        ";Packer/relocator player type (0 = standard ... 3 = minimal)\n%d\n\n"
                        ";Key entry mode (0 = Protracker, 1 = DMC)\n%d\n\n"
                        ";Pattern highlight step size\n%d\n\n"
                        ";Use CatWeasel SID (0 = off, 1 = on)\n%d\n\n"
                        ";Hardrestart ADSR parameter\n$%04x\n\n"
                        ";reSID interpolation (0 = off, 1 = on)\n%d\n\n"
                        ";Hexadecimal pattern display (0 = off, 1 = on)\n%d\n\n"
                        ";SID baseaddress\n$%04x\n\n",

    b,
    mr,
    hardsid,
    sidmodel,
    ntsc,
    fileformat,
    playeradr,
    zeropageadr,
    playerversion,
    keypreset,
    stepsize,
    catweasel,
    adparam,
    interpolate,
    patternhex,
    sidaddress);
    fclose(configfile);
  }

  // Exit
  return 0;
}

void waitkey(void)
{
  for (;;)
  {
    displayupdate();
    getkey();
    if ((rawkey) || (key)) break;
    if (win_quitted) break;
  }
}

void waitkey2(void)
{
  for (;;)
  {
    getkey();
    if ((rawkey) || (key)) break;
    if (win_quitted) break;
  }
}

void docommand(void)
{
  int c;

  hexnybble = -1;
  for (c = 0; c < 16; c++)
  {
    if (tolower(key) == hexkeytbl[c])
    {
      if (c >= 10)
      {
        if (!shiftpressed) hexnybble = c;
      }
      else
      {
        hexnybble = c;
      }
    }
  }

  // Mode-specific commands
  switch(editmode)
  {
    case EDIT_ORDERLIST:
    orderlistcommands();
    break;

    case EDIT_INSTRUMENT:
    instrumentcommands();
    break;

    case EDIT_TABLES:
    tablecommands();
    break;

    case EDIT_PATTERN:
    patterncommands();
    break;

    case EDIT_NAMES:
    namecommands();
    break;
  }

  // General commands
  switch(key)
  {
    case '?':
    case '-':
    if ((editmode != EDIT_NAMES) && (editmode != EDIT_ORDERLIST))
    {
      if (!((editmode == EDIT_INSTRUMENT) && (eipos == 9)))
      {
        einum--;
        if (einum < 0) einum = 0;
      }
    }
    break;

    case '_':
    case '+':
    if ((editmode != EDIT_NAMES) && (editmode != EDIT_ORDERLIST))
    {
      if (!((editmode == EDIT_INSTRUMENT) && (eipos >= 9)))
      {
        einum++;
        if (einum >= MAX_INSTR) einum = MAX_INSTR - 1;
      }
    }
    break;
    
    case '*':
    if (editmode != EDIT_NAMES)
    {
      if (!((editmode == EDIT_INSTRUMENT) && (eipos >= 9)))
      {
        if (epoctave < 7) epoctave++;
      }
    }
    break;

    case '/':
    case '\'':
    if (editmode != EDIT_NAMES)
    {
      if (!((editmode == EDIT_INSTRUMENT) && (eipos >= 9)))
      {
        if (epoctave > 1) epoctave--;
      }
    }
    break;

    case '<':
    if (((editmode == EDIT_INSTRUMENT) && (eipos != 9)) || (editmode == EDIT_TABLES))
    {
      einum--;
      if (einum < 0) einum = 0;
    }
    break;

    case '>':
    if (((editmode == EDIT_INSTRUMENT) && (eipos != 9)) || (editmode == EDIT_TABLES))
    {
      einum++;
      if (einum >= MAX_INSTR) einum = MAX_INSTR - 1;
    }
    break;
  }
  if (win_quitted) exitprogram = 1;
  switch(rawkey)
  {
    case KEY_KPMULTIPLY:
    if ((editmode != EDIT_NAMES) && (!key))
    {
      if (!((editmode == EDIT_INSTRUMENT) && (eipos >= 9)))
      {
        if (epoctave < 7) epoctave++;
      }
    }
    break;

    case KEY_KPDIVIDE:
    if ((editmode != EDIT_NAMES) && (!key))
    {
      if (!((editmode == EDIT_INSTRUMENT) && (eipos >= 9)))
      {
        if (epoctave > 0) epoctave--;
      }
    }
    break;

    case KEY_ESC:
    if (!shiftpressed)
    {
      printtextc(24, 15, "Really Quit (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) exitprogram = 1;
      break;
    }
    else
    {
      int cs = 0;
      int cp = 0;
      int ci = 0;
      int ct = 0;
      int cn = 0;

      printtextc(24, 15, "Clear orderlists (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) cs = 1;

      printtextc(24, 15, "Clear patterns (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) cp = 1;

      printtextc(24, 15, "Clear instruments (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) ci = 1;

      printtextc(24, 15, "Clear tables (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) ct = 1;

      printtextc(24, 15, "Clear songname (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) cn = 1;

      if (cp == 1)
      {
        int selectdone = 0;
        int olddpl = defaultpatternlength;

        printtext(30, 24, 15,"Pattern length:");
        while (!selectdone)
        {
          sprintf(textbuffer, "%02d", defaultpatternlength);
          printtext(45, 24, 15, textbuffer);
          waitkey();
          switch(rawkey)
          {
            case KEY_LEFT:
            defaultpatternlength -= 3;
            case KEY_DOWN:
            defaultpatternlength--;
            if (defaultpatternlength < 1) defaultpatternlength = 1;
            break;

            case KEY_RIGHT:
            defaultpatternlength += 3;
            case KEY_UP:
            defaultpatternlength++;
            if (defaultpatternlength > MAX_PATTROWS) defaultpatternlength = MAX_PATTROWS;
            break;

            case KEY_ESC:
            defaultpatternlength = olddpl;
            selectdone = 1;
            break;

            case KEY_ENTER:
            selectdone = 1;
            break;
          }
        }
        printblank(20, 24, 40);
      }

      clearsong(cs, cp, ci, ct, cn);
      break;
    }

    case KEY_F12:
    onlinehelp();
    printmainscreen();
    break;

    case KEY_TAB:
    if (!shiftpressed) editmode++;
    else editmode--;
    if (editmode > EDIT_NAMES) editmode = EDIT_PATTERN;
    if (editmode < EDIT_PATTERN) editmode = EDIT_NAMES;
    break;

    case KEY_F1:
    songinit = 0x01;
    if (shiftpressed)
      followplay = 1;
    else
      followplay = 0;
    break;

    case KEY_F2:
    songinit = 0x02;
    if (shiftpressed)
      followplay = 1;
    else
      followplay = 0;
    break;

    case KEY_F3:
    songinit = 0x03;
    if (shiftpressed)
      followplay = 1;
    else
      followplay = 0;
    break;

    case KEY_F4:
    if (shiftpressed)
      chn[epchn].mute ^= 1;
    else
    songinit = 0x04;
    break;

    case KEY_F5:
    editmode = EDIT_PATTERN;
    break;

    case KEY_F6:
    editmode = EDIT_ORDERLIST;
    break;

    case KEY_F7:
    if (editmode == EDIT_INSTRUMENT)
      editmode = EDIT_TABLES;
    else
      editmode = EDIT_INSTRUMENT;
    break;

    case KEY_F8:
    editmode = EDIT_NAMES;
    break;

    case KEY_F9:
    relocator();
    break;

    case KEY_F10:
    if ((editmode != EDIT_INSTRUMENT) && (editmode != EDIT_TABLES))
    {
      if (fileselector(songfilename, songpath, songfilter, "LOAD SONG", 0))
        loadsong();
    }
    else
    {
      if (einum)
      {
        if (fileselector(instrfilename, instrpath, instrfilter, "LOAD INSTRUMENT", 0))
          loadinstrument();
      }
    }
    break;

    case KEY_F11:
    if ((editmode != EDIT_INSTRUMENT) && (editmode != EDIT_TABLES))
    {
    	if (strlen(loadedsongfilename)) strcpy(songfilename, loadedsongfilename);
      if (fileselector(songfilename, songpath, songfilter, "SAVE SONG", 3))
        savesong();
    }
    else
    {
      if (einum)
      {
      	int useinstrname = 0;
      	char tempfilename[MAX_FILENAME];

        if ((!strlen(instrfilename)) && (strlen(instr[einum].name)))
        {
          useinstrname = 1;
          strcpy(instrfilename, instr[einum].name);
          strcat(instrfilename, ".ins");
          strcpy(tempfilename, instrfilename);
        }

        if (fileselector(instrfilename, instrpath, instrfilter, "SAVE INSTRUMENT", 3))
          saveinstrument();

        if (useinstrname)
        {
        	if (!strcmp(tempfilename, instrfilename))
          	memset(instrfilename, 0, sizeof instrfilename);
        }
      }
    }
    break;
  }
}

void clearsong(int cs, int cp, int ci, int ct, int cn)
{
  int c;

  masterfader = 0x0f; // Reset masterfader
  songinit = 0x04;
  epmarkchn = -1;
  etmarknum = -1;
  followplay = 0;

  for (c = 0; c < MAX_CHN; c++)
  {
    int d;
    chn[c].mute = 0;
    if (multiplier)
      chn[c].tempo = multiplier*6-1;
    else
      chn[c].tempo = 6-1;
    chn[c].pattptr = 0;
    if (cs)
    {
    	memset(loadedsongfilename, 0, sizeof loadedsongfilename);
      for (d = 0; d < MAX_SONGS; d++)
      {
        memset(&songorder[d][c][0], 0, MAX_SONGLEN+2);
        if (!d)
        {
          songorder[d][c][0] = c;
          songorder[d][c][1] = LOOPSONG;
        }
        else
        {
          songorder[d][c][0] = LOOPSONG;
        }
      }
      epnum[c] = songorder[0][c][0];
      espos[c] = 0;
    }
  }
  if (cs)
  {
    esview = 0;
    eseditpos = 0;
    escolumn = 0;
    eschn = 0;
    esnum = 0;
    eppos = 0;
    epview =-VISIBLEPATTROWS/2;
    epcolumn = 0;
    epchn = 0;
  }
  if (cn)
  {
    memset(songname, 0, sizeof songname);
    memset(authorname, 0, sizeof authorname);
    memset(copyrightname, 0, sizeof copyrightname);
    enpos = 0;
  }

  if (cp)
  {
  	memset(loadedsongfilename, 0, sizeof loadedsongfilename);
    for (c = 0; c < MAX_PATT; c++)
    {
      int d;
      memset(&pattern[c][0], 0, MAX_PATTROWS*4);
      for (d = 0; d < defaultpatternlength; d++) pattern[c][d*4] = REST;
      for (d = defaultpatternlength; d <= MAX_PATTROWS; d++) pattern[c][d*4] = ENDPATT;
    }
  }
  if (ci)
  {
    for (c = 0; c < MAX_INSTR; c++)
    {
      memset(&instr[c], 0, sizeof(INSTR));
      if (c)
      {
      	if (multiplier)
          instr[c].gatetimer = 2 * multiplier;
        else
          instr[c].gatetimer = 1;
        instr[c].firstwave = 0x9;
      }
    }
    memset(&instrcopybuffer, 0, sizeof(INSTR));
    eipos = 0;
    eicolumn = 0;
    einum = 1;
    ewtpos = 0;
  }
  if (ct == 1)
  {
  	for (c = 0; c < MAX_TABLES; c++)
  	{
      memset(ltable[c], 0, MAX_TABLELEN);
      memset(rtable[c], 0, MAX_TABLELEN);
    }
  }
  countpatternlengths();
  psnum = 0;
}

void getparam(FILE *handle, int *value)
{
  *value = 0;

  for (;;)
  {
    while (!configptr)
    {
    	if (feof(handle)) return;
      fgets(configbuf, MAX_PATHNAME, handle);
      if ((configbuf[0]) && (configbuf[0] != ';')) configptr = configbuf;
    }

    if ((*configptr == '$') || ((*configptr >= '0') && (*configptr <= '9'))) break;
    if (!(*configptr)) configptr = NULL;
    else configptr++;
  }

  if (*configptr == '$')
  {
  	configptr++;
    for (;;)
    {
    	char c = tolower(*configptr++);
    	int h = -1;

    	if ((c >= 'a') && (c <= 'f')) h = c - 'a' + 10;
    	if ((c >= '0') && (c <= '9')) h = c - '0';

      if (h >= 0)
      {
      	*value *= 16;
      	*value += h;
      }
      else break;
    }
  }
  else
  {
    for (;;)
    {
    	char c = tolower(*configptr++);
    	int d = -1;

    	if ((c >= '0') && (c <= '9')) d = c - '0';

    	if (d >= 0)
      {
      	*value *= 10;
      	*value += d;
      }
      else break;
    }
  }

  if (!(*configptr)) configptr = NULL;
}

