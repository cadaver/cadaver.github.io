//
// GOATTRACKER v2 online help
//

#include "goattrk2.h"

#define HELP_LASTROW 113

void onlinehelp(void)
{
  int hv = -1;
  int c;

  for (;;)
  {
    clearscreen();
    printtext(0, hv+2, 15,  "GENERAL KEYS");
    printtext(0, hv+3, 7,   "TAB Cycle between editing modes");
    printtext(0, hv+4, 7,   "F1  Play from beginning    (w/ SHIFT = ");
    printtext(0, hv+5, 7,   "F2  Play from current pos. follow play)");
    printtext(0, hv+6, 7,   "F3  Play current pattern               ");
    printtext(0, hv+7, 7,   "F4  Stop playing (w/ SHIFT = mute chn.)");
    printtext(0, hv+8, 7,   "F5  Go to pattern editor");
    printtext(0, hv+9, 7,   "F6  Go to orderlist editor");
    printtext(0, hv+10, 7,  "F7  Go to instrument/table editor");
    printtext(0, hv+11, 7,  "F8  Go to songname editor");
    printtext(0, hv+12, 7,  "F9  Pack, relocate & save PRG,SID etc.");
    printtext(0, hv+13, 7,  "F10 Load song/instrument");
    printtext(0, hv+14, 7,  "F11 Save song/instrument");
    printtext(0, hv+15, 7,  "F12 This screen");
    printtext(0, hv+16, 7,  "INS Insert row (Press on endmark");
    printtext(0, hv+17, 7,  "DEL Delete row to change pat.len)");
    printtext(0, hv+18, 7,  "SHIFT+ESC Clear music/Set pat.length");
    printtext(0, hv+19, 7,  "ESC Exit program");
    printtext(40, hv+2, 15, "PATTERN EDIT MODE");
    printtext(40, hv+3, 7,  "Enter notes like on piano (PT or DMC)");
    printtext(40, hv+4, 7,  "0-9 & A-F to enter commands");
    printtext(40, hv+5, 7,  "SPC Switch between jam/editmode");
    printtext(40, hv+6, 7,  "BACKSPACE Insert rest");
    printtext(40, hv+7, 7,  "RET Keyoff (/w SHIFT = Keyon)");
    printtext(40, hv+8, 7,  "- + Select instrument");
    printtext(40, hv+9, 7,  "/ * Select octave");
    printtext(40, hv+10, 7, "< > Select pattern");
    printtext(40, hv+11, 7, "SHIFT+CRSR Mark pattern");
    printtext(40, hv+12, 7, "SHIFT+Q,W Transpose half/octave up");
    printtext(40, hv+13, 7, "SHIFT+A,S Transpose half/octave down");
    printtext(40, hv+14, 7, "SHIFT+I Invert selection/pattern");
    printtext(40, hv+15, 7, "SHIFT+L Mark/unmark whole pattern");
    printtext(40, hv+16, 7, "SHIFT+M,N Choose highlighting step");
    printtext(40, hv+17, 7, "SHIFT+X,C,V Cut,copy,paste pattern");
    printtext(40, hv+18, 7, "SHIFT+E,R Copy,paste effects");
    printtext(40, hv+19, 7, "SHIFT+Z Cycle autoadvance-mode");
    printtext(40, hv+21, 15,"SONG EDIT MODE");
    printtext(40, hv+22, 7, "0-9 & A-F to enter pattern numbers");
    printtext(40, hv+23, 7, "SPC Set start position for F2 key");
    printtext(40, hv+24, 7, "RET Go to pattern (/w SHIFT=all chns.)");
    printtext(40, hv+25, 7, "< > Select subtune");
    printtext(40, hv+26, 7, "- + Insert transpose down/up command");
    printtext(40, hv+27, 7, "SHIFT+R Insert repeat command");
    printtext(40, hv+28, 7, "SHIFT+1,2,3 Swap orderlist with chn.");
    printtext(40, hv+29, 7, "SHIFT+X,C,V Cut,copy,paste orderlist");
    printtext(40, hv+31, 15,"SONGNAME EDIT MODE");
    printtext(40, hv+32, 7, "Use cursor UP/DOWN to change rows");
    printtext(0, hv+21, 15, "INSTRUMENT/TABLE EDIT MODE");
    printtext(0, hv+22, 7,  "0-9 & A-F to enter parameters");
    printtext(0, hv+23, 7,  "SPC Play test note");
    printtext(0, hv+24, 7,  "SHIFT+SPC Silence test note");
    printtext(0, hv+25, 7,  "RET Go to table");
    printtext(0, hv+26, 7,  "- + Select instrument");
    printtext(0, hv+27, 7,  "/ * Select octave");
    printtext(0, hv+28, 7,  "SHIFT+CRSR Mark table");
    printtext(0, hv+29, 7,  "SHIFT+L Convert pulse/filter limit");
    printtext(0, hv+30, 7,  "SHIFT+N Edit instr.name/negate speed");
    printtext(0, hv+31, 7,  "SHIFT+X,C,V Cut,copy,paste instr./table");
    printtext(0, hv+32, 7,  "SHIFT+S ""Smart"" instrument paste");
    printtext(0, hv+33, 7,  "SHIFT+DEL Delete instrument+tabledata");

    printtext(0, hv+35,15,"PATTERN COMMANDS");

    printtext(0, hv+37, 7,"Command 0XY: Do nothing. Databyte will always be 00.                           ");
    printtext(0, hv+38, 7,"                                                                               ");
    printtext(0, hv+39, 7,"Command 1XY: Portamento up. Raise the pitch with XY * 4 each tick.             ");
    printtext(0, hv+40, 7,"                                                                               ");
    printtext(0, hv+41, 7,"Command 2XY: Portamento down. Lower the pitch with XY * 4 each tick.           ");
    printtext(0, hv+42, 7,"                                                                               ");
    printtext(0, hv+43, 7,"Command 3XY: Toneportamento. Raise or lower pitch until target note has been   ");
    printtext(0, hv+44, 7,"             reached. Speed 00 achieves a ""tie note"" effect, otherwise pitch ");
    printtext(0, hv+45, 7,"             change on each tick is XY * 4.                                    ");
    printtext(0, hv+46, 7,"                                                                               ");
    printtext(0, hv+47, 7,"Command 4XY: Vibrato. X determines how long until the direction changes (speed)");
    printtext(0, hv+48, 7,"             and Y * 16 is the amount of pitch change on each tick (depth).    ");
    printtext(0, hv+49, 7,"             In addition, the highest bit of X is used for fine depth control. ");
    printtext(0, hv+50, 7,"                                                                               ");
    printtext(0, hv+51, 7,"Command 6XY: Set sustain/release register to value XY.                         ");
    printtext(0, hv+52, 7,"                                                                               ");
    printtext(0, hv+53, 7,"Command AXY: Set filtertable pointer. 00 stops filtertable execution.          ");
    printtext(0, hv+54, 7,"                                                                               ");
    printtext(0, hv+55, 7,"Command FXY: Set tempo. Values 03-7F set tempo on all channels, values 83-FF   ");
    printtext(0, hv+56, 7,"             only on current channel (subtract 80 to get actual tempo). Tempos ");
    printtext(0, hv+57, 7,"             00 and 01 recall the funktempos set by EXY command.               ");

    printtext(0, hv+59,15,"INSTRUMENT PARAMETERS");

    printtext(0, hv+61, 7,"Attack/Decay          0 is fastest attack or decay, F is slowest               ");
    printtext(0, hv+62, 7,"                                                                               ");
    printtext(0, hv+63, 7,"Sustain/Release       Sustain level 0 is silent and F is the loudest. Release  ");
    printtext(0, hv+64, 7,"                      behaves like Attack & Decay (F slowest).                 ");
    printtext(0, hv+65, 7,"                                                                               ");
    printtext(0, hv+66, 7,"Wavetable Ptr         Wavetable startposition. Value 00 stops the wavetable    ");
    printtext(0, hv+67, 7,"                      execution and isn't very useful.                         ");
    printtext(0, hv+68, 7,"                                                                               ");
    printtext(0, hv+69, 7,"Pulsetable Ptr        Pulsetable startposition. Value 00 will leave pulse      ");
    printtext(0, hv+70, 7,"                      execution untouched.                                     ");
    printtext(0, hv+71, 7,"                                                                               ");
    printtext(0, hv+72, 7,"Filtertable Ptr       Filtertable startposition. Value 00 will leave filter    ");
    printtext(0, hv+73, 7,"                      execution untouched. In most cases it makes sense to have");
    printtext(0, hv+74, 7,"                      a filter-controlling instrument only on one channel at a ");
    printtext(0, hv+75, 7,"                      time.                                                    ");
    printtext(0, hv+76, 7,"                                                                               ");
    printtext(0, hv+77, 7,"Vibrato Delay         How many ticks until instrument vibrato starts. Value 00 ");
    printtext(0, hv+78,7,"                      turns instrument vibrato off.                            ");
    printtext(0, hv+79,7,"                                                                               ");
    printtext(0, hv+80,7,"Vibrato Speed/Depth   Instrument vibrato parameters. See command 4XY.          ");
    printtext(0, hv+81,7,"                                                                               ");
    printtext(0, hv+82,7,"Gateoff Timer         How many ticks before note start gateoff+hardrestart     ");
    printtext(0, hv+83,7,"                      happens. Can be at most tempo-2. So on tempo 4 highest   ");
    printtext(0, hv+84,7,"                      acceptable value is 2.                                   ");
    printtext(0, hv+85,7,"                                                                               ");
    printtext(0, hv+86,7,"Hardres/1st Wave      Waveform used on init frame of the note, usually 9 (gate+");
    printtext(0, hv+87,7,"                      testbit).                                                ");
    printtext(0, hv+88,7,"                                                                               ");

    printtext(0,hv+90,15,"TABLES");

    printtext(0,hv+92, 7,"Wavetable left side:  00    Leave waveform unchanged                           ");
    printtext(0,hv+93, 7,"                      01-FE Waveform values. Kindly refer to README.TXT, C64   ");
    printtext(0,hv+94, 7,"                            Programmer's Reference Guide or AAY64.             ");
    printtext(0,hv+95, 7,"                      FF    Jump. Right side tells jump position (00 = stop)   ");

    printtext(0,hv+97, 7,"Wavetable right side: 00-5F Relative notes                                     ");
    printtext(0,hv+98,7,"                      81-DF Absolute notes C#0 - B-7                           ");

    printtext(0,hv+100, 7,"Pulsetable left side: 01-7F Pulse modulation step. Left side indicates time and");
    printtext(0,hv+101, 7,"                            right side the speed (8bit signed value). Amount of");
    printtext(0,hv+102, 7,"                            pulse change each tick is speed*2.                 ");
    printtext(0,hv+103, 7,"                      8X-FX Set pulse width. X is the high 4 bits, right side  ");
    printtext(0,hv+104, 7,"                            tells the 8 low bits.                              ");
    printtext(0,hv+105, 7,"                      FF    Jump. Right side tells jump position (00 = stop)   ");

    printtext(0,hv+107, 7,"Filt.table left side: 01-7F Filter modulation step. Left side indicates time   ");
    printtext(0,hv+108, 7,"                            and right side the speed (signed 8bit value)       ");
    printtext(0,hv+109, 7,"                      80-F0 Set filter parameters. Left side high nybble tells ");
    printtext(0,hv+110, 7,"                            the passband (9X = lowpass, AX = bandpass etc.),   ");
    printtext(0,hv+111, 7,"                            low nybble is channel bitmask and right side is    ");
    printtext(0,hv+112, 7,"                            the starting cutoff.                               ");
    printtext(0,hv+113, 7,"                      FF    Jump. Right side tells jump position (00 = stop)   ");

    printblank(0, 0, MAX_COLUMNS);
    sprintf(textbuffer, "%s Online Help", programname);
    printtext(0, 0, 15, textbuffer);
    printtext(50, 0, 15, "Arrows scroll, other keys exit");
    printbg(0, 0, 1, MAX_COLUMNS);
    fliptoscreen();
    waitkey2();

    if (win_quitted)
    {
      exitprogram = 1;
      return;
    }

    switch(rawkey)
    {
      case KEY_LEFT:
      case KEY_UP:
      hv++;
      if (hv > -1) hv = -1;
      break;

      case KEY_RIGHT:
      case KEY_DOWN:
      hv--;
      if (hv < -(HELP_LASTROW-MAX_ROWS+1)) hv = -(HELP_LASTROW-MAX_ROWS+1);
      break;

      case KEY_PGUP:
      for (c = 0; c < PGUPDNREPEAT; c++)
      {
        hv++;
        if (hv > -1) hv = -1;
      }
      break;

      case KEY_PGDN:
      for (c = 0; c < PGUPDNREPEAT; c++)
      {
        hv--;
        if (hv < -(HELP_LASTROW-MAX_ROWS+1)) hv = -(HELP_LASTROW-MAX_ROWS+1);
      }
      break;

      case KEY_HOME:
      hv = -1;
      break;

      case KEY_END:
      hv = -(HELP_LASTROW-MAX_ROWS+1);
      break;

      default:
      if (key) goto EXITHELP;
      break;
    }
  }
  EXITHELP: ;
}

