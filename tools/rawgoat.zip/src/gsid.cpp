/*
 * GOATTRACKER reSID interface
 */

#include <stdlib.h>

#include "sid.h"
#include "gsound.h"

#define PAL_CLOCK_RATE 985248
#define NTSC_CLOCK_RATE 1022727
SID *sid;

extern "C" {

extern int sidorder[];

int clockrate;
int samplerate;

/* "Our" SID registers */
unsigned char sidreg[32];

int sid_created = 0;

void sid_init(int speed, unsigned m, unsigned ntsc, unsigned interpolate);
int sid_fillbuffer(short *ptr, int samples);

void sid_init(int speed, unsigned m, unsigned ntsc, unsigned interpolate)
{
  int c;

  if (ntsc) clockrate = NTSC_CLOCK_RATE;
    else clockrate = PAL_CLOCK_RATE;
  samplerate = speed;

  if (!sid_created)
  {
    sid = new SID;
    sid_created = 1;
  }

  switch(interpolate)
  {
  	case 0:
    sid->set_sampling_parameters(clockrate, SAMPLE_FAST, speed, 20000);
    break;

    default:
    sid->set_sampling_parameters(clockrate, SAMPLE_INTERPOLATE, speed, 20000);
    break;
  }

  sid->reset();
  for (c = 0; c <= 0x18; c++)
  {
    sidreg[c] = 0x00;
  }
  if (m == 1)
  {
    sid->set_chip_model(MOS8580);
  }
  else
  {
    sid->set_chip_model(MOS6581);
  }
}

int sid_fillbuffer(short *ptr, int samples)
{
  int tdelta;
  int tdelta2;
  int result;
  int total = 0;
  int c;

  tdelta = clockrate * samples / samplerate + 4;

  for (c = 0; c <= 0x18; c++)
  {
    tdelta2 = 9;
    sid->write(sidorder[c], sidreg[sidorder[c]]);
    result = sid->clock(tdelta2, ptr, samples);
    total += result;
    ptr += result;
    samples -= result;
    tdelta -= 9;
  }
  result = sid->clock(tdelta, ptr, samples);
  total += result;

  return total;
}


}
