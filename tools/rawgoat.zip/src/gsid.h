void sid_init(int speed, unsigned m, unsigned ntsc, unsigned interpolate);
int sid_fillbuffer(short *ptr, int samples);
void sid_dumpregs(void);

extern unsigned char sidreg[32];
