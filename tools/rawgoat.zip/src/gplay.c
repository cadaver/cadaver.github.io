//
// GOATTRACKER v2 playroutine
//

#include "goattrk2.h"

void playroutine(void)
{
  INSTR *iptr;
  CHN *cptr = &chn[0];
  int c;

  if (songinit == 0x04)
    followplay = 0;

  if ((songinit > 0) && (songinit < 0x80))
  {
    filterctrl = 0;
    filterptr = 0;
    timeframe = 0;
    timemin = 0;
    timesec = 0;
    psnum = esnum;

    if ((songinit == 0x02) || (songinit == 0x03))
    {
      if ((espos[0] >= songlen[psnum][0]) || (espos[1] >= songlen[psnum][1]) || (espos[2] >= songlen[psnum][2]))
         songinit = 0x01;
    }

    for (c = 0; c < MAX_CHN; c++)
    {
      cptr->songptr = 0;
      cptr->command = 0;
      cptr->cmddata = 0;
      cptr->newcommand = 0;
      cptr->newcmddata = 0;
      cptr->advance = 2;
      cptr->wave = 0;
      cptr->ptr[WTBL] = 0;
      cptr->newnote = 0;
      cptr->repeat = 0;
      cptr->tick = 6*multiplier-1;
      cptr->pattptr = 0x7fffffff;
      if (cptr->tempo < 2) cptr->tempo = 0;

      switch (songinit)
      {
      	case 0x01:
        if (multiplier)
        {
        	funktable[0] = 9*multiplier-1;
        	funktable[1] = 6*multiplier-1;
          cptr->tempo = 6*multiplier-1;
        }
        else
        {
          funktable[0] = 9-1;
          funktable[1] = 6-1;
          cptr->tempo = 6-1;
        }
        cptr->trans = 0;
      	cptr->instr = 1;
        sequencer(c, cptr);
      	break;

      	case 0x03:
      	cptr->advance = 1;
      	case 0x02:
      	cptr->songptr = espos[c];
        sequencer(c, cptr);
      	break;
      }
      cptr++;
    }
    if (songinit != 0x04)
      songinit = 0;
    else
      songinit = 0x80;
    if ((!songlen[psnum][0]) || (!songlen[psnum][1]) || (!songlen[psnum][2]))
      songinit = 0x80; // Zero length song
  }
  else
  {
  	if (filterptr)
  	{
      // Filter jump
   	  if (ltable[FTBL][filterptr-1] == 0xff)
      {
        filterptr = rtable[FTBL][filterptr-1];
        goto FILTERSTOP;
      }

      if (!filtertime)
      {
        // Filter set
        if (ltable[FTBL][filterptr-1] >= 0x80)
        {
          filtertype = ltable[FTBL][filterptr-1] & 0x70;
          filterctrl = ltable[FTBL][filterptr-1];
          filtercutoff = rtable[FTBL][filterptr-1];
          filterptr++;
        }
        else
        {
          // New modulation step
          if (ltable[FTBL][filterptr-1])
            filtertime = ltable[FTBL][filterptr-1];
        }
      }
      // Filter modulation
      if (filtertime)
      {
        filtercutoff += rtable[FTBL][filterptr-1];
        filtertime--;
        if (!filtertime) filterptr++;
      }
    }
    FILTERSTOP:
    sidreg[0x15] = 0x00;
    sidreg[0x16] = filtercutoff;
    sidreg[0x17] = filterctrl;
    sidreg[0x18] = filtertype | masterfader;

    for (c = 0; c < MAX_CHN; c++)
    {
      iptr = &instr[cptr->instr];

      // Reset tempo in jammode
      if ((songinit == 0x80) && (cptr->tempo < 2))
      {
      	if (multiplier)
      		cptr->tempo = 6*multiplier-1;
      	else
      	  cptr->tempo = 6-1;
      }

      // Decrease tick
      cptr->tick--;
      if (!cptr->tick) goto TICK0;

      // Tick N
      // Reload counter
      if (cptr->tick >= 0x80)
      {
        if (cptr->tempo >= 2)
          cptr->tick = cptr->tempo;
        else
        {
          // Set funktempo, switch between 2 values
          cptr->tick = funktable[cptr->tempo];
          cptr->tempo ^= 1;
        }
        // Check for illegally high gatetimer and stop the song in this case
        if (instr[1].gatetimer > cptr->tick)
        {
        	songinit = 0x04;
        }
      }
      goto WAVEEXEC;

      // Tick 0
      TICK0:
      // Advance in sequencer
      sequencer(c, cptr);

      // New note init
      if (cptr->newnote)
      {
        cptr->note = cptr->newnote-FIRSTNOTE;
        cptr->command = 0;
        cptr->vibtime = 0;
        cptr->vibdelay = iptr->vibdelay;
        if (cptr->newcommand != CMD_TONEPORTA)
        {
          cptr->wave = instr[1].firstwave;
          cptr->gate = 0xff;
          cptr->ptr[WTBL] = iptr->ptr[WTBL];
          if (iptr->ptr[PTBL])
          {
          	cptr->ptr[PTBL] = iptr->ptr[PTBL];
            cptr->pulsetime = 0;
          }
          if (iptr->ptr[FTBL])
          {
            filterptr = iptr->ptr[FTBL];
            filtertime = 0;
          }
          sidreg[0x5+7*c] = iptr->ad;
          sidreg[0x6+7*c] = iptr->sr;
        }
      }

      // Tick 0 effects

      switch (cptr->newcommand)
      {
        case CMD_DONOTHING:
        cptr->command = 0;
        cptr->cmddata = iptr->vibparam;
        break;

        case CMD_PORTAUP:
        case CMD_PORTADOWN:
        case CMD_TONEPORTA:
        case CMD_VIBRATO:
        cptr->command = cptr->newcommand;
        cptr->cmddata = cptr->newcmddata;
        break;

        case CMD_SETSR:
        sidreg[0x6+7*c] = cptr->newcmddata;
        break;

        case CMD_SETFILTERPTR:
        filterptr = cptr->newcmddata;
        filtertime = 0;
        break;

        case CMD_SETTEMPO:
        {
          unsigned char newtempo = cptr->newcmddata & 0x7f;

          if (newtempo >= 3) newtempo--;
          if (cptr->newcmddata >= 0x80)
            cptr->tempo = newtempo;
          else
          {
            chn[0].tempo = newtempo;
            chn[1].tempo = newtempo;
            chn[2].tempo = newtempo;
          }
        }
        break;
      }
      if (cptr->newnote)
      {
        cptr->newnote = 0;
        if (cptr->newcommand != CMD_TONEPORTA) goto NEXTCHN;
      }

      WAVEEXEC:
      if (cptr->ptr[WTBL])
      {
        unsigned char note;

        if (ltable[WTBL][cptr->ptr[WTBL]-1] > 0)
        {
          cptr->wave = ltable[WTBL][cptr->ptr[WTBL]-1];
        }
        note = rtable[WTBL][cptr->ptr[WTBL]-1];

        cptr->ptr[WTBL]++;
        // Wavetable jump
        if (ltable[WTBL][cptr->ptr[WTBL]-1] == 0xff)
        {
          cptr->ptr[WTBL] = rtable[WTBL][cptr->ptr[WTBL]-1];
        }

        if (note < 0x80)
          note += cptr->note;
        note &= 0x7f;
      	cptr->freq = freqtbllo[note] | (freqtblhi[note]<<8);
        goto PULSEEXEC;
      }

      // Tick N command
      if (cptr->tick)
      {
        switch(cptr->command)
        {
          case CMD_PORTAUP:
          {
            unsigned short speed = cptr->cmddata << 2;
            cptr->freq += speed;
          }
          break;

          case CMD_PORTADOWN:
          {
            unsigned short speed = cptr->cmddata << 2;
            cptr->freq -= speed;
          }
          break;

          case CMD_DONOTHING:
          if (!cptr->vibdelay)
            break;
          if (cptr->vibdelay > 1)
          {
          	cptr->vibdelay--;
          	break;
          }
          case CMD_VIBRATO:
          {
            unsigned char speed;
            unsigned char cmpvalue;

            speed = swapnybbles(cptr->cmddata);
            cmpvalue = (cptr->cmddata >> 4) & 0x07;

            if ((cptr->vibtime < 0x80) && (cptr->vibtime > cmpvalue))
              cptr->vibtime ^= 0xff;
            cptr->vibtime += 0x02;
            if (cptr->vibtime & 0x01)
              cptr->freq -= speed;
            else
              cptr->freq += speed;
          }
          break;

          case CMD_TONEPORTA:
          {
            unsigned short targetfreq = freqtbllo[cptr->note] | (freqtblhi[cptr->note] << 8);
            unsigned short speed = cptr->cmddata << 2;

            if (!cptr->cmddata)
            {
              cptr->freq = targetfreq;
              cptr->vibtime = 0;
            }
            else
            {
              if (cptr->freq < targetfreq)
              {
                cptr->freq += speed;
                if (cptr->freq > targetfreq)
                {
                  cptr->freq = targetfreq;
                  cptr->vibtime = 0;
                }
              }
              if (cptr->freq > targetfreq)
              {
                cptr->freq -= speed;
                if (cptr->freq < targetfreq)
                {
                  cptr->freq = targetfreq;
                  cptr->vibtime = 0;
                }
              }
            }
          }
          break;
        }
      }

      PULSEEXEC:
      if (songinit != 0x80)
      {
      	if (cptr->tick == instr[1].gatetimer) goto GETNEWNOTES;
      }

      if (cptr->ptr[PTBL])
      {
        // Skip pulse when sequencer has been executed
        if ((!cptr->tick) && (!cptr->pattptr)) goto NEXTCHN;

        // Pulsetable jump
        if (ltable[PTBL][cptr->ptr[PTBL]-1] == 0xff)
        {
          cptr->ptr[PTBL] = rtable[PTBL][cptr->ptr[PTBL]-1];
          goto NEXTCHN;
        }

        if (!cptr->pulsetime)
        {
          // Set pulse
          if (ltable[PTBL][cptr->ptr[PTBL]-1] >= 0x80)
          {
            cptr->pulse = (ltable[PTBL][cptr->ptr[PTBL]-1] & 0xf) << 8;
            cptr->pulse |= rtable[PTBL][cptr->ptr[PTBL]-1];
            cptr->pulse &= 0xff0;
            cptr->ptr[PTBL]++;
          }
          else
          {
            cptr->pulsetime = ltable[PTBL][cptr->ptr[PTBL]-1];
          }
        }
        // Pulse modulation
        if (cptr->pulsetime)
        {
          unsigned char speed = rtable[PTBL][cptr->ptr[PTBL]-1];
          if (speed < 0x80)
          {
          	speed <<= 1;
            cptr->pulse += speed;
            cptr->pulse &= 0xff0;
          }
          else
          {
          	speed <<= 1;
            cptr->pulse += speed;
            cptr->pulse -= 0x100;
            cptr->pulse &= 0xff0;
          }
          cptr->pulsetime--;
          if (!cptr->pulsetime) cptr->ptr[PTBL]++;
        }
      }

      goto NEXTCHN;

      // New notes processing
      GETNEWNOTES:
      {
        unsigned char newnote;

        newnote = pattern[cptr->pattnum][cptr->pattptr];
        if (pattern[cptr->pattnum][cptr->pattptr+1])
          cptr->instr = pattern[cptr->pattnum][cptr->pattptr+1];
        cptr->newcommand = pattern[cptr->pattnum][cptr->pattptr+2];
        cptr->newcmddata = pattern[cptr->pattnum][cptr->pattptr+3];
        cptr->pattptr += 4;
        if (pattern[cptr->pattnum][cptr->pattptr] == ENDPATT)
          cptr->pattptr = 0x7fffffff;

        if (newnote == KEYOFF)
          cptr->gate = 0xfe;
        if (newnote == KEYON)
          cptr->gate = 0xff;
        if (newnote <= LASTNOTE)
        {
          cptr->newnote = newnote+cptr->trans;
          if ((cptr->newcommand) != CMD_TONEPORTA)
          {
            cptr->gate = 0xfe;
            sidreg[0x5+7*c] = adparam>>8;
            sidreg[0x6+7*c] = adparam&0xff;
          }
        }
      }
      NEXTCHN:
      if (cptr->mute)
        sidreg[0x4+7*c] = cptr->wave = 0x08;
      else
      {
        sidreg[0x0+7*c] = cptr->freq & 0xff;
        sidreg[0x1+7*c] = cptr->freq >> 8;
        sidreg[0x2+7*c] = cptr->pulse & 0xfe;
        sidreg[0x3+7*c] = cptr->pulse >> 8;
        sidreg[0x4+7*c] = cptr->wave & cptr->gate;
      }
      cptr++;
    }
  }
  if (songinit != 0x80)
  {
    timeframe++;
    if (!ntsc)
    {
      if (((multiplier) && (timeframe == 50*multiplier))
          || ((!multiplier) && (timeframe == 25)))
      {
        timeframe = 0;
        timesec++;
      }
    }
    else
    {
      if (((multiplier) && (timeframe == 60*multiplier))
          || ((!multiplier) && (timeframe == 30)))
      {
        timeframe = 0;
        timesec++;
      }
    }
    if (timesec == 60)
    {
      timesec = 0;
      timemin++;
      timemin %= 60;
    }
  }
}

void sequencer(int c, CHN *cptr)
{
  if ((songinit != 0x80) && (cptr->pattptr == 0x7fffffff))
  {
  	cptr->pattptr = 0;
    if (!cptr->advance) goto SEQDONE;
    if (cptr->advance == 1) cptr->advance = 0;
    // Song loop
    if (songorder[psnum][c][cptr->songptr] == LOOPSONG)
    {
      cptr->songptr = songorder[psnum][c][cptr->songptr+1];
      if (cptr->songptr >= songlen[psnum][c])
      {
        songinit = 0x04;
        cptr->songptr = 0;
        goto SEQDONE;
      }
    }
    // Transpose
    if ((songorder[psnum][c][cptr->songptr] >= TRANSDOWN) && (songorder[psnum][c][cptr->songptr] < LOOPSONG))
    {
      cptr->trans = songorder[psnum][c][cptr->songptr]-TRANSUP;
      cptr->songptr++;
    }
    // Repeat (not supported)
    if ((songorder[psnum][c][cptr->songptr] >= REPEAT) && (songorder[psnum][c][cptr->songptr] < TRANSDOWN))
    {
      songinit = 0x04;
      cptr->songptr = 0;
      goto SEQDONE;
    }
    // Pattern number
    cptr->pattnum = songorder[psnum][c][cptr->songptr];
    cptr->songptr++;

    // Check for illegal pattern now
    if (cptr->pattnum >= MAX_PATT)
    {
      songinit = 0x04;
      cptr->pattnum = 0;
    }
  }
  SEQDONE: {}
}

void playtestnote(int note)
{
  if (instr[einum].firstwave & 0x7f)
  {
    chn[epchn].gate = 0xfe; // Keyoff
    sidreg[0x5+epchn*7] = adparam>>8;
    sidreg[0x6+epchn*7] = adparam&0xff;
  }
  if ((note == REST) || (note == KEYOFF) || (note == KEYON)) return;

  chn[epchn].instr = einum;
  chn[epchn].newnote = note;
  if (songinit == 0x80)
  {
  	chn[epchn].tick = instr[einum].gatetimer+1;
  }
}
