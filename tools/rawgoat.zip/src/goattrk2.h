#ifdef __WIN32__
#include <windows.h>
#include <io.h>
#else
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>

#include "endian.h"

#ifndef INS2SND2_C
#ifndef SNGSPLI2_C
#ifndef BETACONV_C
#include "bme.h"
#include "gconsole.h"
#include "gsound.h"
#include "gsid.h"
#endif
#endif
#endif

#define KEY_TRACKER 0
#define KEY_DMC 1

#define FORMAT_SID 0
#define FORMAT_PRG 1
#define FORMAT_BIN 2

#define PLAYER_STD 0
#define PLAYER_GAME 1
#define PLAYER_FIRST PLAYER_STD
#define PLAYER_LAST PLAYER_GAME

#define CMD_DONOTHING 0
#define CMD_PORTAUP 1
#define CMD_PORTADOWN 2
#define CMD_TONEPORTA 3
#define CMD_VIBRATO 4
#define CMD_SETAD 5
#define CMD_SETSR 6
#define CMD_SETWAVE 7
#define CMD_SETWAVEPTR 8
#define CMD_SETPULSEPTR 9
#define CMD_SETFILTERPTR 10
#define CMD_SETFILTERCTRL 11
#define CMD_SETFILTERCUTOFF 12
#define CMD_SETMASTERVOL 13
#define CMD_FUNKTEMPO 14
#define CMD_SETTEMPO 15

#define EDIT_PATTERN 0
#define EDIT_ORDERLIST 1
#define EDIT_INSTRUMENT 2
#define EDIT_TABLES 3
#define EDIT_NAMES 4

#define WTBL 0
#define PTBL 1
#define FTBL 2

#define CNORMAL 8
#define CMUTE 3
#define CEDIT 10
#define CPLAYING 12
#define CCOMMAND 7
#define CTITLE 15

#define MAX_DIRFILES 16384
#define MAX_FILENAME 60
#define MAX_PATHNAME 256
#define MAX_FILT 64
#define MAX_STR 32
#define MAX_INSTR 64
#define MAX_CHN 3
#define MAX_PATT 208
#define MAX_TABLES 3
#define MAX_TABLELEN 255
#define MAX_INSTRNAMELEN 16
#define MAX_PATTROWS 96
#define MAX_SONGLEN 254
#define MAX_SONGS 32

#define REPEAT 0xd0
#define TRANSDOWN 0xe0
#define TRANSUP 0xf0
#define LOOPSONG 0xff

#define ENDPATT 0xff
#define INSTRCHG 0x00
#define FX 0x40
#define FXONLY 0x50
#define FIRSTNOTE 0x60
#define LASTNOTE 0xbc
#define REST 0xbd
#define KEYOFF 0xbe
#define KEYON 0xbf
#define OLDKEYOFF 0x5e
#define OLDREST 0x5f

#define DEFAULTBUFFER 100
#define DEFAULTMIXRATE 44100

#define PGUPDNREPEAT 4

#define VISIBLEPATTROWS 19
#define VISIBLEORDERLIST 11
#define VISIBLETABLEROWS 5
#define VISIBLEFILES 15

typedef struct
{
  unsigned char ad;
  unsigned char sr;
  unsigned char ptr[3];
  unsigned char vibdelay;
  unsigned char vibparam;
  unsigned char gatetimer;
  unsigned char firstwave;
  unsigned char name[MAX_INSTRNAMELEN];
} INSTR;

typedef struct
{
  char *name;
  int attribute;
} DIRENTRY;

typedef struct
{
  unsigned opcode;
  int length;
} INSTRUCTION;

typedef struct
{
  unsigned char trans;
  unsigned char instr;
  unsigned char note;
  unsigned char newnote;
  unsigned pattptr;
  unsigned char pattnum;
  unsigned char songptr;
  unsigned char repeat;
  unsigned short freq;
  unsigned char gate;
  unsigned char wave;
  unsigned short pulse;
  unsigned char ptr[2];
  unsigned char pulsetime;
  unsigned char wavetime;
  unsigned char vibtime;
  unsigned char vibdelay;
  unsigned char command;
  unsigned char cmddata;
  unsigned char newcommand;
  unsigned char newcmddata;
  unsigned char tick;
  unsigned char tempo;
  unsigned char mute;
  unsigned char advance;
} CHN;

#ifndef INS2SND2_C
#ifndef SNGSPLI2_C
#ifndef BETACONV_C

void getparam(FILE *handle, int *value);
void waitkey(void);
void waitkey2(void);
void relocator(void);
int testoverlap(int area1start, int area1size, int area2start, int area2size);
int packpattern(unsigned char *dest, unsigned char *src, int rows);
void printmainscreen(void);
void docommand(void);
void loadsong(void);
void savesong(void);
void loadinstrument(void);
void saveinstrument(void);
void onlinehelp(void);
void orderlistcommands(void);
void patterncommands(void);
void tablecommands(void);
void instrumentcommands(void);
void inserttable(int num, int pos, int mode);
void deletetable(int num, int pos);
void deleteinstrtable(int i);
int gettablelen(int num);
int gettablepartlen(int num, int pos);
void playtestnote(int note);
void namecommands(void);
void displayupdate(void);
void editstring(char *buffer, int maxlength);
int fileselector(char *name, char *path, char *filter, char *title, int initialmode);
int cmpname(char *string1, char *string2);
void clearsong(int cs, int cp, int ci, int cf, int cn);
void countpatternlengths(void);
void countthispattern(void);
void exectable(int num, int ptr);
void printstatus(void);
void playroutine(void);
void sequencer(int c, CHN *cptr);
unsigned char swapnybbles(unsigned char n);
void sixteenbitadd(unsigned char *adr, int value);
void sixteenbitsub(unsigned char *adr, int value);

#ifndef GOATTRK2_C

extern INSTR instr[MAX_INSTR];
extern unsigned char ltable[3][MAX_TABLELEN];
extern unsigned char rtable[3][MAX_TABLELEN];
extern unsigned char songorder[MAX_SONGS][MAX_CHN][MAX_SONGLEN+2];
extern unsigned char pattern[MAX_PATT][MAX_PATTROWS*4+4];
extern unsigned char funktable[2];
extern int pattlen[MAX_PATT];
extern int songlen[MAX_SONGS][MAX_CHN];

extern INSTR instrcopybuffer;
extern unsigned char patterncopybuffer[MAX_PATTROWS*4+4];
extern unsigned char trackcopybuffer[MAX_SONGLEN+2];
extern unsigned char cmdcopybuffer;
extern unsigned char cmddatacopybuffer;
extern unsigned char ltablecopybuffer[MAX_TABLELEN];
extern unsigned char rtablecopybuffer[MAX_TABLELEN];

extern unsigned char songname[MAX_STR];
extern unsigned char authorname[MAX_STR];
extern unsigned char copyrightname[MAX_STR];

extern unsigned char loadedsongfilename[MAX_FILENAME];
extern unsigned char songfilename[MAX_FILENAME];
extern unsigned char songfilter[MAX_FILENAME];
extern unsigned char songpath[MAX_PATH];
extern unsigned char instrfilename[MAX_FILENAME];
extern unsigned char instrfilter[MAX_FILENAME];
extern unsigned char instrpath[MAX_PATH];
extern unsigned char packedpath[MAX_PATH];
extern DIRENTRY direntry[MAX_DIRFILES];

extern int espos[MAX_CHN];
extern int eseditpos;
extern int esview;
extern int escolumn;
extern int eschn;
extern int esnum;
extern int epnum[MAX_CHN];
extern int eppos;
extern int epview;
extern int epcolumn;
extern int epchn;
extern int epoctave;
extern int einum;
extern int eipos;
extern int eicolumn;
extern int etnum;
extern int etview;
extern int etpos;
extern int etcolumn;

extern int ewtpos;
extern int ewtview;
extern int ewtcolumn;
extern int eptpos;
extern int eptview;
extern int eptcolumn;
extern int eftpos;
extern int eftview;
extern int eftolumn;

extern int enpos;
extern int editmode;
extern int recordmode;
extern int followplay;
extern int hexnybble;
extern int highestusedpattern;
extern int highestusedinstr;
extern int scrrep;
extern int stepsize;
extern int epmarkchn;
extern int epmarkstart;
extern int epmarkend;
extern int etmarknum;
extern int etmarkstart;
extern int etmarkend;
extern int patterncopyrows;
extern int tablecopyrows;
extern int cmdcopymode;
extern int autoadvance;
extern int defaultpatternlength;
extern int keypreset;
extern int playerversion;
extern int fileformat;
extern int zeropageadr;
extern int playeradr;
extern unsigned multiplier;
extern unsigned adparam;
extern unsigned sidmodel;
extern unsigned ntsc;
extern unsigned patternhex;
extern unsigned sidaddress;
extern unsigned finevibrato;
extern unsigned usefinevib;

extern CHN chn[MAX_CHN];
extern unsigned char filterctrl;
extern unsigned char filtertype;
extern unsigned char filtercutoff;
extern unsigned char filtertime;
extern unsigned char filterptr;
extern unsigned char masterfader;
extern unsigned char songinit;
extern int psnum;
extern int timemin;
extern int timesec;
extern int timeframe;

extern int cursorflash;
extern int cursorcolortable[];
extern int exitprogram;

extern char textbuffer[];
extern char *programname;

extern unsigned char notekeytbl1[15];
extern unsigned char notekeytbl2[17];
extern unsigned char dmckeytbl[16];
extern unsigned char hexkeytbl[16];
extern char timechar[];
extern char *notename[];
extern unsigned char freqtbllo[];
extern unsigned char freqtblhi[];

#endif

#endif
#endif
#endif
