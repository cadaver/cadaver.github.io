RawGoat 2.0
-----------

Differences to normal GT2:

- Reduced player memory & rastertime use
- Octave 0 is not available
- Only commands 0,1,2,3,4,6,A,F available (same as in GT1.xx)
- Hardrestart is always on
- Gatetimer & firstwave are same for all instruments
  (controlled by instrument 1)
- No wavetable-delay
- No multispeeds
- No funktempo
- No speedtable
- No repeat command in orderlist
- Finevibrato mode is always on
- There is no separate "set cutoff" command in filtertable. Instead,
  the format for setting filter parameters is as follows:
  XY ZZ, where X = passband + $8, Y = channel bitmask and ZZ is cutoff.
  X gets also directly copied to resonance.
- Pulsemodulation discards least significant 4 bits (like Ninjatracker)
- Only 2 players: normal and gamemusic with sound effect support

Note: this program is unsupported! (originally meant for internal use only)

