#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_HANDLES 1

typedef struct
{
        unsigned offset;
        int length;
        char name[13];
} HEADER;

typedef struct
{
        HEADER *currentheader;
        int filepos;
        int open;
} HANDLE;

static char io_usedatafile = 0;
static HEADER *fileheaders;
static unsigned headeroffset;
static unsigned files;
static int datafilehandle;
static char ident[4];
static char *idstring = "DAT!";
static HANDLE handle[MAX_HANDLES];

void io_setfilemode(char usedf)
{
        io_usedatafile = usedf;
}

int io_opendatafile(char *name)
{
        int index;

        datafilehandle = open(name, O_RDONLY | O_BINARY);
        if (datafilehandle == -1)
        {
                return 0;
        }
        headeroffset = 0;
        read(datafilehandle, ident, 4);
        if (!memcmp(ident, idstring, 4)) goto HEADER_OK;

        // If header not in the beginning check offset from file end
        // (data linked with EXELINK)

        lseek(datafilehandle, -4, SEEK_END);
        read(datafilehandle, &headeroffset, sizeof headeroffset);
        lseek(datafilehandle, headeroffset, SEEK_SET);
        memset(ident, 0, 4);
        read(datafilehandle, ident, 4);

        if (memcmp(ident, idstring, 4))
        {
                return 0;
        }

        HEADER_OK:
        read(datafilehandle, &files, sizeof files);
        fileheaders = malloc(files * sizeof(HEADER));
        if (!fileheaders)
        {
                return 0;
        }
        read(datafilehandle, fileheaders, sizeof (HEADER) * files);

        for (index = 0; index < MAX_HANDLES; index++) handle[index].open = 0;
        io_usedatafile = 1;
        return 1;
}

// Returns nonnegative file handle if successful, -1 on error

int io_open(char *name)
{
        if (!name) return -1;

        if (!io_usedatafile) return open(name, O_RDONLY | O_BINARY);
        else
        {
                int index;
                int namelength;
                char namecopy[13];

                namelength = strlen(name);
                if (namelength > 12) namelength = 12;
                memcpy(namecopy, name, namelength + 1);
                strupr(namecopy);

                for (index = 0; index < MAX_HANDLES; index++)
                {
                        if (!handle[index].open)
                        {
                                int count = files;
                                handle[index].currentheader = fileheaders;

                                while (count)
                                {
                                        if (!strcmp(namecopy, handle[index].currentheader->name))
                                        {
                                                 handle[index].open = 1;
                                                 handle[index].filepos = 0;
                                                 return index;
                                        }
                                        count--;
                                        handle[index].currentheader++;
                                }
                                return -1;
                        }
                }
                return -1;
        }
}

// Returns file position after seek or -1 on error

int io_lseek(int index, int offset, int whence)
{
        if (!io_usedatafile) return lseek(index, offset, whence);
        else
        {
                int newpos;

                if ((index < 0) || (index >= MAX_HANDLES)) return -1;

                if (!handle[index].open) return -1;
                switch(whence)
                {
                        default:
                        case SEEK_SET:
                        newpos = offset;
                        break;

                        case SEEK_CUR:
                        newpos = offset + handle[index].filepos;
                        break;

                        case SEEK_END:
                        newpos = offset + handle[index].currentheader->length;
                        break;
                }
                if (newpos < 0) newpos = 0;
                if (newpos > handle[index].currentheader->length) newpos = handle[index].currentheader->length;
                handle[index].filepos = newpos;
                return newpos;
        }
}

// Returns number of bytes actually read, -1 on error

int io_read(int index, char *buffer, int length)
{
        if (!io_usedatafile) return read(index, buffer, length);
        else
        {
                int readbytes;

                if ((index < 0) || (index >= MAX_HANDLES)) return -1;

                if (!handle[index].open) return -1;
                if (length + handle[index].filepos > handle[index].currentheader->length)
                length = handle[index].currentheader->length - handle[index].filepos;
                lseek(datafilehandle, headeroffset + handle[index].currentheader->offset + handle[index].filepos, SEEK_SET);
                readbytes = read(datafilehandle, buffer, length);
                if (readbytes == -1) return -1;
                handle[index].filepos += readbytes;
                return readbytes;
        }
}

// Returns nothing

void io_close(int index)
{
        if (!io_usedatafile)
        {
                close(index);
                return;
        }
        else
        {
                if ((index < 0) || (index >= MAX_HANDLES)) return;

                handle[index].open = 0;
        }
}
