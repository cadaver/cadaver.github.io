/*
 * GoatTracker Instrument -> Sound effect convertor
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "goattrk.h"

int main(int argc, char **argv);
void outputbyte(unsigned char c);

int bytecount = 0;
FILE *out;

int main(int argc, char **argv)
{
  int src;
  int c,d;
  int prevwave = 0xff;
  int prevwave2 = 0xff;
  int prevnote = 0xff;
  int repeat = 0;

  unsigned char ident[4] = {0};
  unsigned char wavetable[MAX_WAVELEN*2];
  INSTR instr;

  if (argc < 3)
  {
    printf("Usage: INS2SND <instrumentfile> <sourcecodefile>\n"
           "Takes a GoatTracker instrument and outputs the corresponding sound effect data\n"
           "as source code. Things that can't be converted and will result in an error:\n"
           "- Waveforms greater than $81\n"
           "- Relative notes\n"
           "- Wavetable longer than 128 bytes\n"
           "- Absolute notes C-0 & C#0\n"
           "Things that will be lost in conversion:\n"
           "- Wavetable loops\n"
           "- Pulsewidth modulation\n"
           "- Filter settings\n");
    return 1;
  }

  src = open(argv[1], O_RDONLY | O_BINARY);
  if (src == -1)
  {
          printf("ERROR: Can't open instrumentfile\n");
          return 1;
  }

  read(src, ident, 4);
  if (!memcmp(ident, "GTI!", 4))
  {
          int loadbytes;

          read(src, &instr, sizeof(INSTR));
          loadbytes = instr.wavetableindex;
          instr.wavetableindex = 1;
          memset(wavetable, 0, MAX_WAVELEN*2);
          read(src, wavetable, loadbytes);
  }
  else
  {
          printf("ERROR: File is not a GoatTracker instrument!\n");
          return 1;
  }

  out = fopen(argv[2], "wt");
  if (!out)
  {
          printf("ERROR: Can't write to output file.\n");
          return 1;
  }

  close(src);
  d = 0;
  outputbyte(instr.ad);
  d++;
  outputbyte(instr.sr);
  d++;
  outputbyte(instr.pulse);
  d++;

  for (c = 0; c < MAX_WAVELEN; c++)
  {
    if (wavetable[c*2] == 0xff)
    {
      if (repeat > 0)
      {
        outputbyte(256 - repeat);
        d++;
      }
      outputbyte(0);
      d++;
      break;
    }
    if (wavetable[c*2+1] < 0x82)
    {
      printf("ERROR: Relative note or absolute C-0, C#0 found\n");
      fclose(out);
      return 1;
    }
    if (wavetable[c*2] > 0x81)
    {
      printf("ERROR: Waveform greater than $81 found\n");
      fclose(out);
      return 1;
    }
    if ((prevnote == wavetable[c*2+1]) && ((prevwave == wavetable[c*2]) || (!wavetable[c*2]))) repeat++;
    else
    {
      if (repeat > 0)
      {
        outputbyte(256 - repeat);
        d++;
      }
      repeat = 0;
      prevnote = wavetable[c*2+1];
      prevwave = wavetable[c*2];
    }
    if (repeat < 1)
    {
      outputbyte(wavetable[c*2+1]);
      d++;
      if ((wavetable[c*2]) && (wavetable[c*2] != prevwave2))
      {
        repeat = 0;
        prevwave2 = wavetable[c*2];
        outputbyte(wavetable[c*2]);
        d++;
      }
    }
    if (repeat == 32)
    {
      outputbyte(256 - repeat);
      d++;
      repeat = 0;
    }
  }
  fclose(out);
  if (d > 128)
  {
    printf("ERROR: Sound effect exceeds 128 bytes\n");
    return 1;
  }
  else return 0;
}

void outputbyte(unsigned char c)
{
  if (!bytecount)
  {
    fprintf(out, "        dc.b ");
  }
  else fprintf(out, ",");
  fprintf(out, "$%02X", c);
  bytecount++;
  if (bytecount == 16)
  {
    bytecount = 0;
    fprintf(out, "\n");
  }
}
