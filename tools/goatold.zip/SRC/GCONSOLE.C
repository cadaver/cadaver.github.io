/*
 * GOATTRACKER "console" output routines
 */

#define MAX_COLUMNS 80
#define MAX_ROWS 25

#include <windows.h>
#include <wincon.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gsound.h"

int initscreen(void);
BOOL __stdcall handler(DWORD dwCtrlType);
void closescreen(void);
void clearscreen(void);
void fliptoscreen(void);
void printtext(int x, int y, int color, const unsigned char *text);
void printtextc(int y, int color, const unsigned char *text);
void printblank(int x, int y, int length);
void printblankc(int x, int y, int color, int length);
void printbg(int x, int y, int color, int length);
void drawbox(int x, int y, int color, int sx, int sy);
void getkey(void);
static void checkmessages(void);

short *scrbuffer;
HANDLE hconsole;
HANDLE hconsoleinput;
int key = 0;
int rawkey = 0;
int virtualkey = 0;
int shiftpressed = 0;
int lasttime = 0;
int currenttime = 0;
int framecounter = 0;
int cursorflashdelay = 0;

static int gfxinitted = 0;

unsigned char oemtoansitbl[256];
unsigned char ansitooemtbl[256];

int initscreen(void)
{
  int c;

  unsigned char makexlattbl[224];

  CONSOLE_CURSOR_INFO ccinfo;
  scrbuffer = malloc(MAX_COLUMNS * MAX_ROWS * 2 * sizeof(short));

  if (!scrbuffer) return 0;

  hconsole = GetStdHandle(STD_OUTPUT_HANDLE);
  hconsoleinput = GetStdHandle(STD_INPUT_HANDLE);

  if (hconsole == INVALID_HANDLE_VALUE) return 0;
  if (hconsoleinput == INVALID_HANDLE_VALUE) return 0;

  ccinfo.dwSize = 20;
  ccinfo.bVisible = FALSE;

  SetConsoleTitle("GoatTracker");
  SetConsoleMode(hconsoleinput, 0);
  SetConsoleCursorInfo(hconsole, &ccinfo);
  SetConsoleCtrlHandler(handler, TRUE);

  for (c = 0; c < 32; c++)
  {
    oemtoansitbl[c] = c;
    ansitooemtbl[c] = c;
  }
  for (c = 0; c < 224; c++)
  {
    makexlattbl[c] = c+32;
  }
  CharToOemBuff(makexlattbl, &ansitooemtbl[32], 224);
  OemToCharBuff(makexlattbl, &oemtoansitbl[32], 224);

  gfxinitted = 1;
  clearscreen();
  return 1;
}

BOOL __stdcall handler(DWORD dwCtrlType)
{
  switch(dwCtrlType)
  {
    case CTRL_C_EVENT:
    case CTRL_BREAK_EVENT:
    case CTRL_LOGOFF_EVENT:
    case CTRL_CLOSE_EVENT:
    case CTRL_SHUTDOWN_EVENT:
    sound_uninit(); /* This is important */
    closescreen();
    break;
  }
  return FALSE;
}

void closescreen(void)
{
  CONSOLE_CURSOR_INFO ccinfo;
  COORD coord;

  if (gfxinitted)
  {
    clearscreen();
    fliptoscreen();
    if (scrbuffer)
    {
      free(scrbuffer);
      scrbuffer = NULL;
    }
    coord.X = 0;
    coord.Y = 0;
    ccinfo.dwSize = 20;
    ccinfo.bVisible = TRUE;
    SetConsoleCursorPosition(hconsole,coord);
    SetConsoleCursorInfo(hconsole, &ccinfo);
  }
  gfxinitted = 0;
}

void clearscreen(void)
{
  int c;
  short *dptr = scrbuffer;

  if (!gfxinitted) return;

  for (c = 0; c < MAX_ROWS * MAX_COLUMNS; c++)
  {
    *dptr++ = 0x20;
    *dptr++ = 0x7;
  }
}

void printtext(int x, int y, int color, const unsigned char *text)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  if (!gfxinitted) return;
  if (y < 0) return;
  if (y >= MAX_ROWS) return;
  while (*text)
  {
    *dptr++ = ansitooemtbl[*text];
    *dptr++ = color;
    text++;
  }
}

void printblank(int x, int y, int length)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  if (!gfxinitted) return;
  if (y < 0) return;
  if (y >= MAX_ROWS) return;
  while (length--)
  {
    *dptr++ = 32;
    *dptr++ = 0;
  }
}

void printblankc(int x, int y, int color, int length)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  if (!gfxinitted) return;
  if (y < 0) return;
  if (y >= MAX_ROWS) return;
  while (length--)
  {
    *dptr++ = 32;
    *dptr++ = color;
  }
}

void drawbox(int x, int y, int color, int sx, int sy)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);
  short *dptr2 = scrbuffer + ((x + (y+sy-1) * MAX_COLUMNS) << 1);
  int counter = sx;

  if (!gfxinitted) return;
  if (y < 0) return;
  if (y >= MAX_ROWS) return;
  if (y+sy > MAX_ROWS) return;
  while (counter--)
  {
    *dptr++ = 205;
    *dptr++ = color;
    *dptr2++ = 205;
    *dptr2++ = color;
  }

  dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);
  dptr2 = scrbuffer + (((x+sx-1) + y * MAX_COLUMNS) << 1);
  counter = sy;

  while (counter--)
  {
    dptr[0] = 186;
    dptr[1] = color;
    dptr2[0] = 186;
    dptr2[1] = color;
    dptr += (MAX_COLUMNS << 1);
    dptr2 += (MAX_COLUMNS << 1);
  }
  scrbuffer[(x + y * MAX_COLUMNS) << 1] = 201;
  scrbuffer[((x+sx-1) + y * MAX_COLUMNS) << 1] = 187;
  scrbuffer[(x + (y+sy-1) * MAX_COLUMNS) << 1] = 200;
  scrbuffer[((x+sx-1) + (y+sy-1) * MAX_COLUMNS) << 1] = 188;
}

void printbg(int x, int y, int color, int length)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  if (!gfxinitted) return;
  if (y < 0) return;
  if (y >= MAX_ROWS) return;
  while (length--)
  {
    dptr++;
    *dptr = 15 | (color << 4);
    dptr++;
  }
}

void printtextc(int y, int color, const unsigned char *text)
{
  int x = (80 - strlen(text)) / 2;
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  if (!gfxinitted) return;
  if (y < 0) return;
  if (y >= MAX_ROWS) return;
  while (*text)
  {
    *dptr++ = ansitooemtbl[*text];
    *dptr++ = color;
    text++;
  }
}

void fliptoscreen(void)
{
  SMALL_RECT writeregion = {0, 0, MAX_COLUMNS-1, MAX_ROWS-1};
  COORD buffersize = {MAX_COLUMNS, MAX_ROWS};
  COORD buffercoord = {0,0};
  WriteConsoleOutput(hconsole, (CHAR_INFO *)scrbuffer, buffersize, buffercoord, &writeregion);
}

void getkey(void)
{
  int frametime = 10000 / 50;
  int frames = 0;

  if (!gfxinitted) return;

  rawkey = 0;
  key = 0;
  virtualkey = 0;

  while (!frames)
  {
    checkmessages();

    lasttime = currenttime;
    currenttime = timeGetTime();

    framecounter += (currenttime - lasttime)*10;
    frames = framecounter / frametime;
    framecounter -= frames * frametime;

    if (!frames) Sleep((frametime - framecounter)/10);
  }
  cursorflashdelay += frames;
}

static void checkmessages(void)
{
  INPUT_RECORD record;
  DWORD events;
  DWORD readevents;

  if (!GetNumberOfConsoleInputEvents(hconsoleinput, &events)) return;

  while (events--)
  {
    ReadConsoleInput(hconsoleinput, &record, 1, &readevents);
    if (record.EventType == KEY_EVENT)
    {
      if (record.Event.KeyEvent.bKeyDown)
      {
        key = record.Event.KeyEvent.uChar.AsciiChar & 255;
        rawkey = record.Event.KeyEvent.wVirtualScanCode;
        virtualkey = record.Event.KeyEvent.wVirtualKeyCode;
        if (key == 224) key = 0;
        key &= 255;
        key = oemtoansitbl[key];
      }
      shiftpressed = record.Event.KeyEvent.dwControlKeyState &
        (LEFT_CTRL_PRESSED|RIGHT_CTRL_PRESSED|SHIFT_PRESSED);
      return;
    }
  }
}

