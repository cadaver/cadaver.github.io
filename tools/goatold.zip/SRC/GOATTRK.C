/*
 * GOATTRACKER v1.25
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <conio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "goattrk.h"
#include "gconsole.h"
#include "rawcodes.h"
#include "gsound.h"
#include "gsid.h"
#include "gio.h"

CHN chn[MAX_CHN];
INSTR instr[MAX_INSTR];
unsigned char wavetable[MAX_INSTR][MAX_WAVELEN*2];
unsigned char songorder[MAX_SONGS][MAX_CHN][MAX_SONGLEN+2];
unsigned char pattern[MAX_PATT][MAX_PATTROWS*3+3];
unsigned char patterncopybuffer[MAX_PATTROWS*3+3];
INSTR instrcopybuffer;
unsigned char wavecopybuffer[MAX_WAVELEN*2];
int pattlen[MAX_PATT];
int songlen[MAX_SONGS][MAX_CHN];

unsigned char songfilename[MAX_FILENAME];
unsigned char instrfilename[MAX_FILENAME];
unsigned char songfilter[MAX_FILENAME];
unsigned char instrfilter[MAX_FILENAME];
DIRENTRY direntry[MAX_FILES];

unsigned char songname[MAX_STR];
unsigned char authorname[MAX_STR];
unsigned char copyrightname[MAX_STR];

unsigned char cmdcopybuffer = 0;
unsigned char cmddatacopybuffer = 0;

int win_quitted = 0;

int espos[MAX_CHN];
int eseditpos;
int esview;
int escolumn;
int eschn;
int esnum;
int epnum[MAX_CHN];
int eppos;
int epview;
int epcolumn;
int epchn;
int epoctave = 2;
int einum;
int eipos;
int eicolumn;
int ewpos;
int ewview;
int enpos;
int editmode = EDIT_PATTERN;
int recordmode = 0;
int followplay = 0;
int hexnybble = -1;
int highestusedpattern;
int highestusedinstr;
int scrrep;
int stepsize = 4;
int epmarkchn = -1;
int epmarkstart;
int epmarkend;
int patterncopyrows = 0;
int autoadvance = 0;
int defaultpatternlength = 64;
int keypreset = KEY_TRACKER;
int playerversion = 2;
unsigned zeropageadr = 0xfc;
unsigned playeradr = 0x1000;
int fileformat = FORMAT_PRG;

unsigned char freqtbllo[] = {
  0x15,0x25,0x36,0x49,0x5c,0x71,0x87,0x9f,0xb7,0xd1,0xed,0x0a,
  0x2a,0x4a,0x6d,0x92,0xb9,0xe3,0x0f,0x3e,0x6f,0xa3,0xdb,0x15,
  0x54,0x95,0xdb,0x25,0x73,0xc7,0x1e,0x7c,0xde,0x47,0xb6,0x2b,
  0xa8,0x2b,0xb7,0x4b,0xe7,0x8e,0x3d,0xf8,0xbd,0x8e,0x6c,0x57,
  0x50,0x57,0x6e,0x96,0xcf,0x1c,0x7b,0xf0,0x7b,0x1d,0xd8,0xae,
  0xa0,0xaf,0xdd,0x2d,0x9f,0x38,0xf7,0xe0,0xf6,0x3b,0xb1,0x5d,
  0x40,0x5e,0xbb,0x5a,0x3f,0x70,0xef,0xc1,0xed,0x76,0x63,0xba,
  0x80,0xbc,0x76,0xb4,0x7f,0xe0,0xde,0x83,0xda,0xed,0xc7,0xff,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

unsigned char freqtblhi[] = {
  0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x02,
  0x02,0x02,0x02,0x02,0x02,0x02,0x03,0x03,0x03,0x03,0x03,0x04,
  0x04,0x04,0x04,0x05,0x05,0x05,0x06,0x06,0x06,0x07,0x07,0x08,
  0x08,0x09,0x09,0x0a,0x0a,0x0b,0x0c,0x0c,0x0d,0x0e,0x0f,0x10,
  0x11,0x12,0x13,0x14,0x15,0x17,0x18,0x19,0x1b,0x1d,0x1e,0x20,
  0x22,0x24,0x26,0x29,0x2b,0x2e,0x30,0x33,0x36,0x3a,0x3d,0x41,
  0x45,0x49,0x4d,0x52,0x57,0x5c,0x61,0x67,0x6d,0x74,0x7b,0x82,
  0x8a,0x92,0x9b,0xa4,0xae,0xb8,0xc3,0xcf,0xdb,0xe8,0xf6,0xff,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

INSTRUCTION asmtable[] = {{0x69,2}, //ADC immediate
                {0x65,4}, //ADC zeropage
                {0x75,4}, //ADC zeropage,X
                {0x6d,3}, //ADC absolute
                {0x7d,3}, //ADC absolute,X
                {0x79,3}, //ADC absolute,Y
                {0x61,4}, //ADC indirect,X
                {0x71,4}, //ADC indirect,Y

                {0x29,2}, //AND immediate
                {0x25,4}, //AND zeropage
                {0x35,4}, //AND zeropage,X
                {0x2d,3}, //AND absolute
                {0x3d,3}, //AND absolute,X
                {0x39,3}, //AND absolute,Y
                {0x21,4}, //AND indirect,X
                {0x31,4}, //AND indirect,Y

                {0x0a,1}, //ASL accumulator
                {0x06,4}, //ASL zeropage
                {0x16,4}, //ASL zeropage,X
                {0x0e,3}, //ASL absolute
                {0x1e,3}, //ASL absolute,X
                {0x90,2}, //BCC
                {0xb0,2}, //BCS
                {0xf0,2}, //BEQ

                {0x24,4}, //BIT zeropage
                {0x2c,3}, //BIT absolute
                {0x30,2}, //BMI
                {0xd0,2}, //BNE
                {0x10,2}, //BPL
                {0x00,1}, //BRK
                {0x50,2}, //BVC
                {0x70,2}, //BVS

                {0x18,1}, //CLC
                {0xd8,1}, //CLD
                {0x58,1}, //CLI
                {0xb8,1}, //CLV
                {0xc9,2}, //CMP immediate
                {0xc5,4}, //CMP zeropage
                {0xd5,4}, //CMP zeropage,X
                {0xcd,3}, //CMP absolute

                {0xdd,3}, //CMP absolute,X
                {0xd9,3}, //CMP absolute,Y
                {0xc1,4}, //CMP indirect,X
                {0xd1,4}, //CMP indirect,Y
                {0xe0,2}, //CPX immediate
                {0xe4,4}, //CPX zeropage
                {0xec,3}, //CPX absolute
                {0xc0,2}, //CPY immediate

                {0xc4,4}, //CPY zeropage
                {0xcc,3}, //CPY absolute
                {0xc6,4}, //DEC zeropage
                {0xd6,4}, //DEC zeropage,X
                {0xce,3}, //DEC absolute
                {0xde,3}, //DEC absolute,X
                {0xca,1}, //DEX
                {0x88,1}, //DEY

                {0x49,2}, //EOR immediate
                {0x45,4}, //EOR zeropage
                {0x55,4}, //EOR zeropage,X
                {0x4d,3}, //EOR absolute
                {0x5d,3}, //EOR absolute,X
                {0x59,3}, //EOR absolute,Y
                {0x41,4}, //EOR indirect,X
                {0x51,4}, //EOR indirect,Y

                {0xe6,4}, //INC zeropage
                {0xf6,4}, //INC zeropage,X
                {0xee,3}, //INC absolute
                {0xfe,3}, //INC absolute,X
                {0xe8,1}, //INX
                {0xc8,1}, //INY
                {0x4c,3}, //JMP absolute
                {0x6c,3}, //JMP indirect

                {0x20,3}, //JSR absolute
                {0xa9,2}, //LDA immediate
                {0xa5,4}, //LDA zeropage
                {0xb5,4}, //LDA zeropage,X
                {0xad,3}, //LDA absolute
                {0xbd,3}, //LDA absolute,X
                {0xb9,3}, //LDA absolute,Y
                {0xa1,4}, //LDA indirect,X

                {0xb1,4}, //LDA indirect,Y
                {0xa2,2}, //LDX immediate
                {0xa6,4}, //LDX zeropage
                {0xb6,4}, //LDX zeropage,Y
                {0xae,3}, //LDX absolute
                {0xbe,3}, //LDX absolute,Y
                {0xa0,2}, //LDY immediate
                {0xa4,4}, //LDY zeropage

                {0xb4,4}, //LDY zeropage,Y
                {0xac,3}, //LDY absolute
                {0xbc,3}, //LDY absolute,Y
                {0x4a,1}, //LSR accumulator
                {0x46,4}, //LSR zeropage
                {0x56,4}, //LSR zeropage,X
                {0x4e,3}, //LSR absolute
                {0x5e,3}, //LSR absolute,X

                {0xea,1}, //NOP
                {0x09,2}, //ORA immediate
                {0x05,4}, //ORA zeropage
                {0x15,4}, //ORA zeropage,X
                {0x0d,3}, //ORA absolute
                {0x1d,3}, //ORA absolute,X
                {0x19,3}, //ORA absolute,Y

                {0x11,4}, //ORA indirect,Y
                {0x48,1}, //PHA
                {0x08,1}, //PHP
                {0x68,1}, //PLA
                {0x28,1}, //PLP
                {0x2a,1}, //ROL accumulator
                {0x26,4}, //ROL zeropage

                {0x36,4}, //ROL zeropage,X
                {0x2e,3}, //ROL absolute
                {0x3e,3}, //ROL absolute,X
                {0x6a,1}, //ROR accumulator
                {0x66,4}, //ROR zeropage
                {0x76,4}, //ROR zeropage,X
                {0x6e,3}, //ROR absolute
                {0x7e,3}, //ROR absolute,X

                {0x40,1}, //RTI
                {0x60,1}, //RTS
                {0xe9,2}, //SBC immediate
                {0xe5,4}, //SBC zeropage
                {0xf5,4}, //SBC zeropage,X
                {0xed,3}, //SBC absolute
                {0xfd,3}, //SBC absolute,X
                {0xf9,3}, //SBC absolute,Y

                {0xe1,4}, //SBC indirect,X
                {0xf1,4}, //SBC indirect,Y
                {0x38,1}, //SEC
                {0xf8,1}, //SED
                {0x78,1}, //SEI
                {0x85,4}, //STA zeropage
                {0x95,4}, //STA zeropage,X
                {0x8d,3}, //STA absolute

                {0x9d,3}, //STA absolute,X
                {0x99,3}, //STA absolute,Y
                {0x81,4}, //STA indirect,X
                {0x91,4}, //STA indirect,Y
                {0x86,4}, //STX zeropage
                {0x96,4}, //STX zeropage,Y
                {0x8e,3}, //STX absolute
                {0x84,4}, //STY zeropage

                {0x94,4}, //STY zeropage,X
                {0x8c,3}, //STY absolute
                {0xaa,1}, //TAX
                {0xa8,1}, //TAY
                {0xba,1}, //TSX
                {0x8a,1}, //TXA
                {0x9a,1}, //TXS
                {0x98,1}, //TYA
                {0xff,0}};


unsigned char volume = 15;
unsigned char filterctrl = 0;
unsigned char filtertype = 0;
unsigned char filtercutoff = 0;
unsigned char filtercutoffadd = 0;
unsigned char songinit;
int playsongnum;
unsigned multiplier = 1;

int timemin = 0;
int timesec = 0;
int timeframe = 0;
int cursorflash = 0;
int cursorcolortable[] = {1,2,7,2};
unsigned ntsc = 0;

unsigned char notekeytbl1[] = {KEY_Z, KEY_S, KEY_X, KEY_D, KEY_C, KEY_V,
  KEY_G, KEY_B, KEY_H, KEY_N, KEY_J, KEY_M, KEY_COMMA, KEY_L, KEY_COLON};

unsigned char notekeytbl2[] = {KEY_Q, KEY_2, KEY_W, KEY_3, KEY_E, KEY_R,
  KEY_5, KEY_T, KEY_6, KEY_Y, KEY_7, KEY_U, KEY_I, KEY_9, KEY_O, KEY_0, KEY_P};

unsigned char dmckeytbl[] = {KEY_A, KEY_W, KEY_S, KEY_E, KEY_D, KEY_F,
  KEY_T, KEY_G, KEY_Y, KEY_H, KEY_U, KEY_J, KEY_K, KEY_O, KEY_L, KEY_P};

unsigned char hexkeytbl[] = {'0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

char timechar[] = {':', ' '};

char *notename[] =
 {"C-0", "C#0", "D-0", "D#0", "E-0", "F-0", "F#0", "G-0", "G#0", "A-0", "A#0", "B-0",
  "C-1", "C#1", "D-1", "D#1", "E-1", "F-1", "F#1", "G-1", "G#1", "A-1", "A#1", "B-1",
  "C-2", "C#2", "D-2", "D#2", "E-2", "F-2", "F#2", "G-2", "G#2", "A-2", "A#2", "B-2",
  "C-3", "C#3", "D-3", "D#3", "E-3", "F-3", "F#3", "G-3", "G#3", "A-3", "A#3", "B-3",
  "C-4", "C#4", "D-4", "D#4", "E-4", "F-4", "F#4", "G-4", "G#4", "A-4", "A#4", "B-4",
  "C-5", "C#5", "D-5", "D#5", "E-5", "F-5", "F#5", "G-5", "G#5", "A-5", "A#5", "B-5",
  "C-6", "C#6", "D-6", "D#6", "E-6", "F-6", "F#6", "G-6", "G#6", "A-6", "A#6", "B-6",
  "C-7", "C#7", "D-7", "D#7", "E-7", "F-7", "F#7", "G-7", "G#7", "A-7", "===", "---"};

char textbuffer[80];
char exitprogram = 0;
char *programname = "GOATTRACKER v1.25 by Lasse ��rni (reSID by Dag Lem)";

int main(int argc, char **argv);
void waitkey(void);
void waitkey2(void);
void relocator(void);
int testoverlap(int area1start, int area1size, int area2start, int area2size);
int packpattern(unsigned char *dest, unsigned char *src, int rows);
void printmainscreen(void);
void docommand(void);
void onlinehelp(void);
void orderlistcommands(void);
void patterncommands(void);
void instrumentcommands(void);
void playtestnote(int note, int filter);
void namecommands(void);
void display_update(void);
void editstring(char *buffer, int maxlength);
int fileselector(char *name, char *filter, char *title, int initialmode);
void clearsong(int cs, int cp, int ci, int cn);
void countpatternlengths(void);
void countthispattern(void);
void printpatterns(void);
void playroutine(void);
void freqadd(int c, CHN *cptr, unsigned char speed);
void freqsub(int c, CHN *cptr, unsigned char speed);
unsigned char swapnybbles(unsigned char n);

int main(int argc, char **argv)
{
  unsigned b = DEFAULTBUFFERS;
  unsigned mr = DEFAULTMIXRATE;
  unsigned m = 0;
  unsigned writer = 0;
  unsigned hardsid = 0;
  char filename[MAX_PATH];
  FILE *configfile;
  unsigned c;
  int info = 0;

  GetModuleFileName(NULL, (TCHAR *)filename, MAX_PATH);
  io_opendatafile(filename);

  /* Get configuration info */
  filename[strlen(filename)-3] = 'c';
  filename[strlen(filename)-2] = 'f';
  filename[strlen(filename)-1] = 'g';
  configfile = fopen(filename, "rt");
  if (configfile)
  {
        fscanf(configfile, "%d", &b);
        fscanf(configfile, "%d", &mr);
        fscanf(configfile, "%d", &hardsid);
        fscanf(configfile, "%d", &m);
        fscanf(configfile, "%d", &ntsc);
        fscanf(configfile, "%d", &fileformat);
        fscanf(configfile, "%d", &playeradr);
        fscanf(configfile, "%d", &zeropageadr);
        fscanf(configfile, "%d", &playerversion);
        fscanf(configfile, "%d", &keypreset);
        fscanf(configfile, "%d", &stepsize);
        fscanf(configfile, "%d", &multiplier);
        fclose(configfile);
  }
  if (!stepsize) stepsize = 4;

  /* Scan command line */
  for (c = 1; c < (unsigned)argc; c++)
  {
    if ((argv[c][0] == '-') || (argv[c][0] == '/'))
    {
      switch(toupper(argv[c][1]))
      {
        case '?':
        printf("Usage: GOATTRK [options]\n\n"
               "Options:\n"
               "/Bxx Set number of 20ms sound buffers DEFAULT=10\n"
               "/Exx Set emulated SID model (0 = 6581 1 = 8580) DEFAULT=6581\n"
               "/Hxx Use HardSID (0 = off, 1 = HardSID ID0 2 = HardSID ID1 etc.)\n"
               "/Kxx Note-entry mode (0 = PROTRK. 1 = DMC) DEFAULT=PROTRK.\n"
               "/Mxx Set sound mixing rate DEFAULT=44100\n"
               "/Sxx Set speed multiplier (2 for 2x tunes, 4 for 4x tunes etc.)\n"
               "/N   Use NTSC timing\n"
               "/P   Use PAL timing (DEFAULT)\n"
               "/W   Write sound output to a file SIDAUDIO.RAW\n"
               "/?   Show this info again\n\n"
               "Settings will be stored into a file called GOATTRK.CFG in the same\n"
               "directory as the executable file.\n");
        info = 1;
        break;

        case 'S':
        sscanf(&argv[c][2], "%u", &multiplier);
        if (multiplier == 0) multiplier = 1;
        if (multiplier > 32) multiplier = 32;
        break;

        case 'B':
        sscanf(&argv[c][2], "%u", &b);
        break;

        case 'E':
        sscanf(&argv[c][2], "%u", &m);
        break;

        case 'K':
        sscanf(&argv[c][2], "%u", &keypreset);
        if (keypreset > 2) keypreset = 0;
        break;

        case 'N':
        ntsc = 1;
        break;

        case 'P':
        ntsc = 0;
        break;

        case 'M':
        sscanf(&argv[c][2], "%u", &mr);
        break;

        case 'H':
        sscanf(&argv[c][2], "%u", &hardsid);
        break;

        case 'W':
        writer = 1;
        break;

      }
    }
    if (info) return 0;
  }

  if (!sound_init(b, mr, writer, hardsid, m, ntsc, multiplier))
  {
    printf("Sound init failed.\n");
    return 1;
  }
  atexit(sound_uninit);

  if (!initscreen())
  {
    printf("Console graphics init failed.\n");
    return 1;
  }
  atexit(closescreen);

  memset(songfilename, 0, sizeof songfilename);
  memset(instrfilename, 0, sizeof instrfilename);
  strcpy(songfilter, "*.sng");
  strcpy(instrfilter, "*.ins");
  memset(chn, 0, sizeof chn);
  clearsong(1,1,1,1);
  printmainscreen();

  while (!exitprogram)
  {
    waitkey();
    docommand();
  }

  /* Store configuration to config file */
  configfile = fopen(filename, "wt");
  if (configfile)
  {
    fprintf(configfile, "%d %d %d %d %d %d %d %d %d %d %d %d",
    b,
    mr,
    hardsid,
    m,
    ntsc,
    fileformat,
    playeradr,
    zeropageadr,
    playerversion,
    keypreset,
    stepsize,
    multiplier);
    fclose(configfile);
  }

  END:
  return 0;
}

void waitkey(void)
{
  for (;;)
  {
    display_update();
    getkey();
    if (virtualkey) break;
    if (win_quitted) break;
  }
}

void waitkey2(void)
{
  for (;;)
  {
    getkey();
    if (virtualkey) break;
    if (win_quitted) break;
  }
}

void display_update(void)
{
  if (cursorflashdelay >= 5)
  {
    cursorflashdelay %= 5;
    cursorflash++;
    cursorflash &= 3;
    printpatterns();
    fliptoscreen();
  }
  else
  {
    if (virtualkey)
    {
      printpatterns();
      fliptoscreen();
    }
  }
}

void docommand(void)
{
  int c;

  hexnybble = -1;
  for (c = 0; c < 16; c++)
  {
    if ((tolower(key) == hexkeytbl[c]) && (!shiftpressed)) hexnybble = c;
  }

  /* Mode-specific commands */
  switch(editmode)
  {
    case EDIT_ORDERLIST:
    orderlistcommands();
    break;

    case EDIT_INSTRUMENT:
    instrumentcommands();
    break;

    case EDIT_PATTERN:
    patterncommands();
    break;

    case EDIT_NAMES:
    namecommands();
    break;
  }

  /* General commands */
  switch(key)
  {
    case '*':
    if ((eipos != 7) || (editmode != EDIT_INSTRUMENT))
    {
      if (editmode != EDIT_NAMES)
      {
        if (epoctave < 7) epoctave++;
      }
    }
    break;

    case '/':
    if ((eipos != 7) || (editmode != EDIT_INSTRUMENT))
    {
      if (editmode != EDIT_NAMES)
      {
        if (epoctave > 0) epoctave--;
      }
    }
    break;

    case '-':
    if ((eipos != 7) || (editmode != EDIT_INSTRUMENT))
    {
      if (editmode != EDIT_NAMES)
      {
        einum--;
        if (einum < 0) einum = 0;
        ewpos = 0;
        ewview = 0;
      }
    }
    break;

    case '+':
    if ((eipos != 7) || (editmode != EDIT_INSTRUMENT))
    {
      if (editmode != EDIT_NAMES)
      {
        einum++;
        if (einum >= MAX_INSTR) einum = MAX_INSTR - 1;
        ewpos = 0;
        ewview = 0;
      }
    }
    break;
  }
  if (win_quitted) exitprogram = 1;
  switch(virtualkey)
  {
    case VK_ESCAPE:
    if (!shiftpressed)
    {
      printtextc(24, 15, "Really Quit (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) exitprogram = 1;
      break;
    }
    else
    {
      int cs = 0;
      int cp = 0;
      int ci = 0;
      int cn = 0;

      printtextc(24, 15, "Clear orderlists (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) cs = 1;

      printtextc(24, 15, "Clear patterns (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) cp = 1;

      printtextc(24, 15, "Clear instruments (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) ci = 1;

      printtextc(24, 15, "Clear songname (y/n)?");
      waitkey();
      printblank(20, 24, 40);
      if ((key == 'y') || (key == 'Y')) cn = 1;

      if (cp == 1)
      {
        int selectdone = 0;
        int olddpl = defaultpatternlength;

        printtext(30, 24, 15,"Pattern length:");
        while (!selectdone)
        {
          sprintf(textbuffer, "%02d", defaultpatternlength);
          printtext(45, 24, 15, textbuffer);
          waitkey();
          switch(virtualkey)
          {
            case VK_LEFT:
            defaultpatternlength -= 3;
            case VK_DOWN:
            defaultpatternlength--;
            if (defaultpatternlength < 1) defaultpatternlength = 1;
            break;

            case VK_RIGHT:
            defaultpatternlength += 3;
            case VK_UP:
            defaultpatternlength++;
            if (defaultpatternlength > 80) defaultpatternlength = 80;
            break;

            case VK_ESCAPE:
            defaultpatternlength = olddpl;
            selectdone = 1;
            break;

            case VK_RETURN:
            selectdone = 1;
            break;
          }
        }
        printblank(20, 24, 40);
      }

      clearsong(cs, cp, ci, cn);
      break;
    }


    case VK_F12:
    onlinehelp();
    printmainscreen();
    break;

    case VK_F1:
    songinit = 0x01;
    if (shiftpressed)
      followplay = 1;
    else
      followplay = 0;
    break;

    case VK_F2:
    songinit = 0x02;
    if (shiftpressed)
      followplay = 1;
    else
      followplay = 0;
    break;

    case VK_F3:
    songinit = 0x03;
    break;

    case VK_F4:
    chn[epchn].mute ^= 1;
    break;

    case VK_F5:
    editmode = EDIT_PATTERN;
    break;

    case VK_F6:
    editmode = EDIT_ORDERLIST;
    break;

    case VK_F7:
    editmode = EDIT_INSTRUMENT;
    break;

    case VK_F8:
    editmode = EDIT_NAMES;
    break;

    case VK_F9:
    relocator();
    break;

    case VK_F10:
    if (editmode != EDIT_INSTRUMENT)
    {
      if (fileselector(songfilename, songfilter, "LOAD SONG", 0))
      {
        char ident[4];
        int handle;

        handle = open(songfilename, O_RDONLY | O_BINARY);
        if (handle != -1)
        {
          read(handle, ident, 4);
          if (!memcmp(ident, "GTS!", 4))
          {
            int d;
            unsigned char length;
            unsigned char amount;
            int loadbytes;
            clearsong(1,1,1,1);

            /* Read infotexts */
            read(handle, songname, sizeof songname);
            read(handle, authorname, sizeof authorname);
            read(handle, copyrightname, sizeof copyrightname);

            /* Read songorderlists */
            read(handle, &amount, sizeof amount);
            for (d = 0; d < amount; d++)
            {
              for (c = 0; c < MAX_CHN; c++)
              {
                read(handle, &length, sizeof length);
                loadbytes = length;
                loadbytes++;
                read(handle, songorder[d][c], loadbytes);
                /* Convert the old endmark */
                if (songorder[d][c][length] == 0xfe)
                  songorder[d][c][length] = LOOPSONG;
              }
            }
            /* Read instruments */
            for (c = 1; c < MAX_INSTR; c++)
            {
              read(handle, &instr[c], sizeof(INSTR));
              loadbytes = instr[c].wavetableindex;
              instr[c].wavetableindex = 1;
              read(handle, wavetable[c], loadbytes);
            }
            /* Read patterns */
            read(handle, &amount, sizeof amount);
            for (c = 0; c < amount; c++)
            {
              read(handle, &length, sizeof length);
              read(handle, pattern[c], length);
            }
            countpatternlengths();
            for (c = 0; c < MAX_CHN; c++)
            {
              espos[c] = 0;
              if (songlen[esnum][c])
              {
                eppos = 0;
                epview = - VISIBLEPATTROWS / 2;
                epnum[c] = songorder[esnum][c][0];
              }
            }
          }
          close(handle);
        }
      }
    }
    else
    {
      if (einum)
      {
        if (fileselector(instrfilename, instrfilter, "LOAD INSTRUMENT", 0))
        {
          char ident[4];
          int handle;

          handle = open(instrfilename, O_RDONLY | O_BINARY);
          if (handle != -1)
          {
            read(handle, ident, 4);
            if (!memcmp(ident, "GTI!", 4))
            {
              int d;
              int loadbytes;

              read(handle, &instr[einum], sizeof(INSTR));
              loadbytes = instr[einum].wavetableindex;
              instr[einum].wavetableindex = 1;
              memset(wavetable[einum], 0, MAX_WAVELEN*2);
              read(handle, wavetable[einum], loadbytes);
            }
            close(handle);
          }
        }
      }
    }
    break;

    case VK_F11:
    if (editmode != EDIT_INSTRUMENT)
    {
      if (fileselector(songfilename, songfilter, "SAVE SONG", 2))
      {
        char ident[] = {'G', 'T', 'S', '!'};
        int handle;

        if (strlen(songfilename) < MAX_FILENAME-4)
        {
          int extfound = 0;
          for (c = strlen(songfilename)-1; c >= 0; c--)
          {
            if (songfilename[c] == '.') extfound = 1;
          }
          if (!extfound) strcat(songfilename, ".sng");
        }
        handle = open(songfilename, O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        if (handle != -1)
        {
          int d;
          unsigned char length;
          unsigned char amount;
          int writebytes;
          write(handle, ident, 4);

          countpatternlengths();

          /* Write infotexts */
          write(handle, songname, sizeof songname);
          write(handle, authorname, sizeof authorname);
          write(handle, copyrightname, sizeof copyrightname);

          /* Determine amount of songs to be saved */
          c = 0;
          for (;;)
          {
            if (c == MAX_SONGS) break;
            if ((!songlen[c][0])||
               (!songlen[c][1])||
               (!songlen[c][2])) break;
            c++;
          }
          amount = c;

          write(handle, &amount, sizeof amount);
          /* Write songorderlists */
          for (d = 0; d < amount; d++)
          {
            for (c = 0; c < MAX_CHN; c++)
            {
              length = songlen[d][c]+1;
              write(handle, &length, sizeof length);
              writebytes = length;
              writebytes++;
              write(handle, songorder[d][c], writebytes);
            }
          }
          /* Write instruments */
          for (c = 1; c < MAX_INSTR; c++)
          {
            instr[c].wavetableindex = 2;
            for (d = 0; d < MAX_WAVELEN*2; d+= 2)
            {
              if (wavetable[c][d] == 0xff) break;
              instr[c].wavetableindex += 2;
            }
            write(handle, &instr[c], sizeof(INSTR));
            write(handle, wavetable[c], instr[c].wavetableindex);
            instr[c].wavetableindex = 1;
          }
          /* Write patterns */
          amount = highestusedpattern + 1;
          write(handle, &amount, sizeof amount);
          for (c = 0; c < amount; c++)
          {
            length = pattlen[c]*3+3;
            write(handle, &length, sizeof length);
            write(handle, pattern[c], length);
          }
          close(handle);
        }
      }
    }
    else
    {
      if (einum)
      {
        if (fileselector(instrfilename, instrfilter, "SAVE INSTRUMENT", 2))
        {
          char ident[] = {'G', 'T', 'I', '!'};
          int handle;

          if (strlen(instrfilename) < MAX_FILENAME-4)
          {
            int extfound = 0;
            for (c = strlen(instrfilename)-1; c >= 0; c--)
            {
              if (instrfilename[c] == '.') extfound = 1;
            }
            if (!extfound) strcat(instrfilename, ".ins");
          }

          handle = open(instrfilename, O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
          if (handle != -1)
          {
            int d;
            int writebytes;
            write(handle, ident, 4);

            /* Write instrument */
            instr[einum].wavetableindex = 2;
            for (d = 0; d < MAX_WAVELEN*2; d+= 2)
            {
              if (wavetable[einum][d] == 0xff) break;
              instr[einum].wavetableindex += 2;
            }
            write(handle, &instr[einum], sizeof(INSTR));
            write(handle, wavetable[einum], instr[einum].wavetableindex);
            instr[einum].wavetableindex = 1;
            close(handle);
          }
        }
      }
    }
    break;
  }
}

void onlinehelp(void)
{
  int hv = -1;

  for (;;)
  {
    clearscreen();
    printtext(0, hv+2, 15, "GENERAL KEYS");
    printtext(0, hv+3, 7,  "TAB Cycle between editing modes");
    printtext(0, hv+4, 7,  "F1  Play from beginning    (With SHIFT=");
    printtext(0, hv+5, 7,  "F2  Play from current pos. follow play)");
    printtext(0, hv+6, 7,  "F3  Stop playing/silence all sounds");
    printtext(0, hv+7, 7, "F4  Mute current channel");
    printtext(0, hv+8, 7, "F5  Go to pattern editor");
    printtext(0, hv+9, 7, "F6  Go to orderlist editor");
    printtext(0, hv+10, 7, "F7  Go to instrument editor");
    printtext(0, hv+11, 7, "F8  Go to songname editor");
    printtext(0, hv+12, 7, "F9  Pack, relocate & save PRG,SID etc.");
    printtext(0, hv+13, 7, "F10 Load song/instrument");
    printtext(0, hv+14, 7, "F11 Save song/instrument");
    printtext(0, hv+15, 7, "F12 This screen");
    printtext(0, hv+16,  7, "INS Insert row (Press on endmark");
    printtext(0, hv+17,  7, "DEL Delete row to change pat.len)");
    printtext(0, hv+18, 7, "SHIFT+ESC Clear music/Set pat.length");
    printtext(0, hv+19, 7, "ESC Exit program");
    printtext(40, hv+2, 15, "PATTERN EDIT MODE");
    printtext(40, hv+3,  7, "Enter notes like on piano (PT or DMC)");
    printtext(40, hv+4,  7, "0-9 & A-F to enter commands");
    printtext(40, hv+5,  7, "SPC Switch between jam/editmode");
    printtext(40, hv+6,  7, "RET (or CAPSLOCK) Insert keyoff");
    printtext(40, hv+7,  7, "BKS Insert rest");
    printtext(40, hv+8,  7, "- + Select instrument");
    printtext(40, hv+9,  7, "/ * Select octave");
    printtext(40, hv+10,  7, "< > Select pattern");
    printtext(40, hv+11,  7, "SHIFT+Q Transpose halfstep up");
    printtext(40, hv+12,  7, "SHIFT+A Transpose halfstep down");
    printtext(40, hv+13,  7, "SHIFT+CRSR Mark pattern");
    printtext(40, hv+14,  7, "SHIFT+L Mark/unmark whole pattern");
    printtext(40, hv+15,  7, "SHIFT+M,N Choose highlighting step");
    printtext(40, hv+16,  7, "SHIFT+X,C,V Cut,copy,paste pattern");
    printtext(40, hv+17,  7, "SHIFT+E,R Copy,paste effects");
    printtext(40, hv+18,  7, "SHIFT+Z Cycle autoadvance-mode");
    printtext(40, hv+20, 15, "SONG EDIT MODE");
    printtext(40, hv+21,  7, "0-9 & A-F to enter pattern numbers");
    printtext(40, hv+22,  7, "SPC Set start position for F2 key");
    printtext(40, hv+23,  7, "RET Go to pattern (With SHIFT=all chns.)");
    printtext(40, hv+24,  7, "< > Select subtune");
    printtext(0, hv+21, 15, "INSTRUMENT EDIT MODE");
    printtext(0, hv+22, 7, "0-9 & A-F to enter parameters");
    printtext(0, hv+23, 7, "SPC Play test note");
    printtext(0, hv+24, 7, "RET Silence test note");
    printtext(0, hv+25, 7, "- + Select instrument");
    printtext(0, hv+26, 7, "/ * Select octave");
    printtext(0, hv+27, 7, "SHIFT+N Edit instrument name");
    printtext(0, hv+28, 7, "SHIFT+X,C,V Cut,copy,paste instrument");
    printtext(40, hv+26, 15,"SONGNAME EDIT MODE");
    printtext(40, hv+27, 7,"Use cursor UP/DOWN to move between");
    printtext(40, hv+28, 7,"song, author & copyright strings");

    printtext(0, hv+30, 15, "COMMAND 0XY: ");
    printtext(13,hv+30, 7, "Arpeggio. Arpeggiates with the root note, then root note + X      ");
    printtext(13,hv+31, 7, "halftones and then root note + Y halftones. If the X value        ");
    printtext(13,hv+32, 7, "is 8 or higher, the arpeggio will be at half speed (8 will        ");
    printtext(13,hv+33, 7, "be subtracted from the value of X to get the amount of halftones) ");
    printtext(0, hv+34, 15, "COMMAND 1XY: ");
    printtext(13,hv+34, 7, "Portamento. Raises the pitch with (XY and 7F) * 2 each tick.      ");
    printtext(13,hv+35, 7, "Highest bit of XY decides direction: 0 is up and 1 is down.       ");
    printtext(0, hv+36,15, "COMMAND 2XY: ");
    printtext(13,hv+36, 7, "Set filter cutoff speed. The cutoff speed will be added to the    ");
    printtext(13,hv+37, 7, "cutoff frequency each tick, until stopped with a 200 command.     ");
    printtext(13,hv+38,7, "(Values 80 and greater subtract the cutoff frequency because the  ");
    printtext(13,hv+39,7, "cutoff frequency is only 8 bits)                                  ");
    printtext(0, hv+40,15, "COMMAND 3XY: ");
    printtext(13,hv+40, 7, "Toneportamento. Raises or lowers pitch until target note has been ");
    printtext(13,hv+41, 7, "reached. Highest bit of XY decides direction of toneportamento    ");
    printtext(13,hv+42, 7, "(this is an optimization for the C64 playroutine, to keep it fast:");
    printtext(13,hv+43, 7, "you must know the direction yourself) and the actual speed used   ");
    printtext(13,hv+44, 7, "is (XY and 7F) * 2. By specifying the 'wrong' direction you can   ");
    printtext(13,hv+45, 7, "get infinitely fast toneportamentos for 'tie note' effect.        ");
    printtext(0, hv+46,15, "COMMAND 4XY: ");
    printtext(13,hv+46,7,  "Vibrato. X determines how fast the direction will change (E is    ");
    printtext(13,hv+47, 7, "slowest, lowest bit doesn't matter) and Y*16+X is the amount of   ");
    printtext(13,hv+48, 7, "pitch change on each tick.                                        ");
    printtext(0, hv+49,15, "COMMAND 5XY: ");
    printtext(13,hv+49,7, "Set filter parameters. X is the filter resonance and Y is the     ");
    printtext(13,hv+50, 7, "bitmask of channels to be filtered.                               ");
    printtext(13,hv+51, 7, "  Bitvalue 01 = Channel 1                                         ");
    printtext(13,hv+52, 7, "  Bitvalue 02 = Channel 2                                         ");
    printtext(13,hv+53, 7, "  Bitvalue 04 = Channel 3                                         ");
    printtext(0, hv+54,15, "COMMAND 6XY: ");
    printtext(13,hv+54,7, "Set sustain/release. Sets the channel's sustain/release register  ");
    printtext(13,hv+55, 7, "to XY.                                                            ");
    printtext(0, hv+56,15, "COMMAND 7XY: ");
    printtext(13,hv+56,7, "Set tempo. If highest bit is 1 (values 80-FF), tempo (XY and 7F)  ");
    printtext(13,hv+57,7, "will be set on current channel only, otherwise on all channels.   ");
    printtext(0,hv+59,7, "                      0 is fastest attack or decay, F is slowest                ");
    printtext(0,hv+59,15,"Attack/Decay          ");
    printtext(0,hv+61,7, "                      Sustain level 0 is silent and F is the loudest. Release   ");
    printtext(0,hv+61,15,"Sustain/Release       ");
    printtext(0,hv+62,7, "                      is a speed like attack & decay.                           ");
    hv++;
    printtext(0,hv+63,7, "                      The starting value of pulsewidth (00-FF)                  ");
    printtext(0,hv+63,15,"Pulse                 ");
    printtext(0,hv+64,7, "                      If this is 0 the current pulsewidth and pulsewidth        ");
    printtext(0,hv+65,7, "                      direction are left untouched.                             ");
    printtext(0,hv+67,7, "                      The value that will be added to pulsewidth each tick      ");
    printtext(0,hv+67,15,"Pulse Speed           ");
    printtext(0,hv+68,7, "                      (0-F)                                                     ");
    printtext(0,hv+70,7, "                      The pulsewidths where pulsewidth modulation will change   ");
    printtext(0,hv+70,15,"Pulse Limit Low       ");
    printtext(0,hv+71,7, "                      its direction. The low nybble will be always 0 because of ");
    printtext(0,hv+71,15,"Pulse Limit High      ");
    printtext(0,hv+72,7, "                      optimizations.                                            ");
    printtext(0,hv+73,7, "                      If both limits are 0 the pulse will always be going in    ");
    printtext(0,hv+74,7, "                      decreasing direction.                                     ");
    printtext(0,hv+76,7, "                      Frequency is the highest 8 bits of cutoff frequency.      ");
    printtext(0,hv+76,15,"Filter Freq/Type      ");
    printtext(0,hv+77,7, "                      Filter type is a bitmask consisting of:                   ");
    printtext(0,hv+79,7, "                        Bitvalue 01 = Lowpass filter                            ");
    printtext(0,hv+80,7, "                        Bitvalue 02 = Bandpass filter                           ");
    printtext(0,hv+81,7, "                        Bitvalue 04 = Highpass filter                           ");
    printtext(0,hv+83,7, "                      This byte comes into effect when a new note is played.    ");
    printtext(0,hv+84,7, "                      If its value is 0 then filter cutoff & type will be       ");
    printtext(0,hv+85,7, "                      unchanged. Because there's only one filter, it's a good   ");
    printtext(0,hv+86,7, "                      idea to have filter-controlling instruments only on one   ");
    printtext(0,hv+87,7, "                      channel at a time :-)                                     ");
    printtext(0,hv+89,7, "                      NOTE: The low 4 bits (type) also affect cutoff frequency. ");
    printtext(0,hv+90,7, "                      This is a playroutine optimization.                       ");
    printtext(0,hv+92,7, "In addition to these parameters, each instrument has a wave/note table that     ");
    printtext(0,hv+93,7, "determines the waveforms and pitches to be used when a note starts. With        ");
    printtext(0,hv+94,7, "this table you can make either a simple sound that just has one waveform and    ");
    printtext(0,hv+95,7, "the note's base pitch, or a complex sound that has many waveform changes        ");
    printtext(0,hv+96,7, "(to make good-sounding drums), or anything in between.                          ");
    printtext(0,hv+98,7, "The wave/note table consists of byte pairs. The leftmost byte is always the     ");
    printtext(0,hv+99,7, "waveform and the rightmost is the note. A pair that has FF in the waveform      ");
    printtext(0,hv+100,7, "ends wavetable execution (if note number is 0) or loops to position n (if note  ");
    printtext(0,hv+101,7, "number n > 0) NOTE: before the table ends, no portamento, vibrato or arpeggio   ");
    printtext(0,hv+102,7, "will be executed! Pulsemodulation will be executed, as of V0.94 onwards.        ");
    printtext(0,hv+104,7, "A waveform of 0 tells not to change the waveform, this is useful if you use     ");
    printtext(0,hv+105,7, "keyoffs (gatebit off) during wavetable execution.                               ");
    printtext(0,hv+107,7, "Waveform byte consists of these bits:                                           ");
    printtext(0,hv+109,7, "  Bitvalue 01 = Gate bit. THIS IS IMPORTANT TO GET AN AUDIBLE SOUND! Gate bit   ");
    printtext(0,hv+110,7, "                initiates the attack/decay/sustain phase of a sound. When it    ");
    printtext(0,hv+111,7, "                goes zero, the release phase begins.                            ");
    printtext(0,hv+112,7, "  Bitvalue 02 = Synchronize bit. Will synchronize with an another channel       ");
    printtext(0,hv+113,7, "                (Consult C64 Programmer's Reference Guide for details)          ");
    printtext(0,hv+114,7, "  Bitvalue 04 = Ring-modulation bit. Will ring-modulate with an another channel ");
    printtext(0,hv+115,7, "                (Consult C64 Programmer's Reference Guide for details)          ");
    printtext(0,hv+116,7, "  Bitvalue 08 = Test bit. Will silence the channel and reset the random-seed    ");
    printtext(0,hv+117,7, "                of a channel if the noise random generator has ""locked up""      ");
    printtext(0,hv+118,7, "                because of using noise waveform in combination with another     ");
    printtext(0,hv+119,7, "                waveform. This value is automatically used when a song starts   ");
    printtext(0,hv+120,7, "                playing!                                                        ");
    printtext(0,hv+121,7, "  Bitvalue 10 = Triangle waveform                                               ");
    printtext(0,hv+122,7, "  Bitvalue 20 = Sawtooth waveform                                               ");
    printtext(0,hv+123,7, "  Bitvalue 40 = Pulse waveform. There must be nonzero pulsewidth on the         ");
    printtext(0,hv+124,7, "                instrument or else this waveform will be silent!                ");
    printtext(0,hv+125,7, "  Bitvalue 80 = Noise waveform. Don't combine with other waveforms!             ");
    printtext(0,hv+127,7, "Note byte consists of these values:                                             ");
    printtext(0,hv+129,7, "  00-5F       = Relative notes. Will be added to the current note playing       ");
    printtext(0,hv+130,7, "                on that channel to get the final pitch                          ");
    printtext(0,hv+131,7, "  80-DF       = Absolute notes C-0 - B-7.                                       ");
    hv--;
    printblank(0, 0, MAX_COLUMNS);
    printtextc(0, 15, "GOATTRACKER online help: Arrows scroll, other keys exit");
    printbg(0, 0, 1, MAX_COLUMNS);
    fliptoscreen();
    waitkey2();

    switch(virtualkey)
    {
      case VK_LEFT:
      case VK_UP:
      hv++;
      if (hv > -1) hv = -1;
      break;

      case VK_RIGHT:
      case VK_DOWN:
      hv--;
      if (hv < -(132-MAX_ROWS+1)) hv = -(132-MAX_ROWS+1);
      break;

      default:
      if (key) goto EXITHELP;
      break;
    }
  }
  EXITHELP:
}

void orderlistcommands(void)
{
  int c;

  if (followplay)
  {
    if (virtualkey == VK_TAB)
    {
      if (!shiftpressed) editmode++;
      else editmode--;
      editmode &= 3;
    }
    return;
  }

  if (hexnybble >= 0)
  {
    if (eseditpos != songlen[esnum][eschn])
    {
      switch(escolumn)
      {
        case 0:
        songorder[esnum][eschn][eseditpos] &= 0x0f;
        songorder[esnum][eschn][eseditpos] |= hexnybble << 4;
        if (eseditpos < songlen[esnum][eschn])
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_PATT)
            songorder[esnum][eschn][eseditpos] = MAX_PATT - 1;
        }
        else
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_SONGLEN)
            songorder[esnum][eschn][eseditpos] = MAX_SONGLEN - 1;
        }
        break;

        case 1:
        songorder[esnum][eschn][eseditpos] &= 0xf0;
        songorder[esnum][eschn][eseditpos] |= hexnybble;
        if (eseditpos < songlen[esnum][eschn])
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_PATT)
            songorder[esnum][eschn][eseditpos] = MAX_PATT - 1;
        }
        else
        {
          if (songorder[esnum][eschn][eseditpos] >= MAX_SONGLEN)
            songorder[esnum][eschn][eseditpos] = MAX_SONGLEN - 1;
        }
        break;
      }
      escolumn++;
      if (escolumn > 1)
      {
        escolumn = 0;
        if (eseditpos < (songlen[esnum][eschn]+1))
        {
          eseditpos++;
          if (eseditpos == songlen[esnum][eschn]) eseditpos++;
        }
      }
    }
  }

  switch(key)
  {
    case '>':
    case ')':
    case ']':
    esnum++;
    if (esnum >= MAX_SONGS) esnum = MAX_SONGS - 1;
    for (c = 0; c < MAX_CHN; c++)
    {
      espos[c] = 0;
      if (songlen[esnum][c])
      {
        eppos = 0;
        epview = - VISIBLEPATTROWS / 2;
        epnum[c] = songorder[esnum][c][0];
      }
    }
    eseditpos = 0;
    if (eseditpos == songlen[esnum][eschn]) eseditpos++;
    esview = 0;
    epmarkchn = -1;
    break;

    case '<':
    case '(':
    case '[':
    esnum--;
    if (esnum < 0) esnum = 0;
    for (c = 0; c < MAX_CHN; c++)
    {
      espos[c] = 0;
      if (songlen[esnum][c])
      {
        eppos = 0;
        epview = - VISIBLEPATTROWS / 2;
        epnum[c] = songorder[esnum][c][0];
      }
    }
    eseditpos = 0;
    if (eseditpos == songlen[esnum][eschn]) eseditpos++;
    esview = 0;
    epmarkchn = -1;
    break;
  }
  switch(virtualkey)
  {
    case VK_TAB:
    if (!shiftpressed) editmode++;
    else editmode--;
    editmode &= 3;
    break;

    case VK_SPACE:
    if (!shiftpressed)
    {
      if (eseditpos < songlen[esnum][eschn]) espos[eschn] = eseditpos;
    }
    else
    {
      if (eseditpos < songlen[esnum][0]) espos[0] = eseditpos;
      if (eseditpos < songlen[esnum][1]) espos[1] = eseditpos;
      if (eseditpos < songlen[esnum][2]) espos[2] = eseditpos;
    }
    break;

    case VK_RETURN:
    if (eseditpos < songlen[esnum][eschn])
    {
      if (!shiftpressed)
      {
        epnum[eschn] = songorder[esnum][eschn][eseditpos];
      }
      else
      {
        if (eseditpos < songlen[esnum][0]) epnum[0] = songorder[esnum][0][eseditpos];
        if (eseditpos < songlen[esnum][1]) epnum[1] = songorder[esnum][1][eseditpos];
        if (eseditpos < songlen[esnum][2]) epnum[2] = songorder[esnum][2][eseditpos];
        epmarkchn = -1;
      }
    }
    epchn = eschn;
    epcolumn = 0;
    eppos = 0;
    epview = - VISIBLEPATTROWS / 2;
    editmode = EDIT_PATTERN;
    if (epchn == epmarkchn) epmarkchn = -1;
    break;

    case VK_DELETE:
    if (!songinit) songinit = 0x03;
    if ((songlen[esnum][eschn] - eseditpos)-1 >= 0)
    {
      int len;
      memmove(&songorder[esnum][eschn][eseditpos],
        &songorder[esnum][eschn][eseditpos+1],
        (songlen[esnum][eschn] - eseditpos)-1);
      songorder[esnum][eschn][songlen[esnum][eschn]-1] = 0x00;
      if (songlen[esnum][eschn] > 0)
      {
        songorder[esnum][eschn][songlen[esnum][eschn]-1] =
          songorder[esnum][eschn][songlen[esnum][eschn]];
        songorder[esnum][eschn][songlen[esnum][eschn]] =
          songorder[esnum][eschn][songlen[esnum][eschn]+1];
        countthispattern();
      }
      if (eseditpos == songlen[esnum][eschn]) eseditpos++;
      len = songlen[esnum][eschn]+1;
      if ((songorder[esnum][eschn][len] > eseditpos) &&
         (songorder[esnum][eschn][len] > 0))
         songorder[esnum][eschn][len]--;
    }
    else
    {
      if (eseditpos > songlen[esnum][eschn])
      {
        if (songlen[esnum][eschn] > 0)
        {
          songorder[esnum][eschn][songlen[esnum][eschn]-1] =
            songorder[esnum][eschn][songlen[esnum][eschn]];
          songorder[esnum][eschn][songlen[esnum][eschn]] =
            songorder[esnum][eschn][songlen[esnum][eschn]+1];
          countthispattern();
          eseditpos = songlen[esnum][eschn]+1;
        }
      }
    }
    break;

    case VK_INSERT:
    if (!songinit) songinit = 0x03;
    if ((songlen[esnum][eschn] - eseditpos)-1 >= 0)
    {
      int len;
      if (songlen[esnum][eschn] < MAX_SONGLEN)
      {
        len = songlen[esnum][eschn]+1;
        songorder[esnum][eschn][len+1] =
          songorder[esnum][eschn][len];
        songorder[esnum][eschn][len] = LOOPSONG;
        if (len) songorder[esnum][eschn][len-1] = 0x00;
        countthispattern();
      }
      memmove(&songorder[esnum][eschn][eseditpos+1],
        &songorder[esnum][eschn][eseditpos],
        (songlen[esnum][eschn] - eseditpos)-1);
      songorder[esnum][eschn][eseditpos] = 0x00;
      len = songlen[esnum][eschn]+1;
      if ((songorder[esnum][eschn][len] > eseditpos) &&
         (songorder[esnum][eschn][len] < (len-2)))
         songorder[esnum][eschn][len]++;
    }
    else
    {
      if (eseditpos > songlen[esnum][eschn])
      {
        if (songlen[esnum][eschn] < MAX_SONGLEN)
        {
          songorder[esnum][eschn][eseditpos+1] =
            songorder[esnum][eschn][eseditpos];
          songorder[esnum][eschn][eseditpos] = LOOPSONG;
          if (eseditpos) songorder[esnum][eschn][eseditpos-1] = 0x00;
          countthispattern();
          eseditpos = songlen[esnum][eschn]+1;
        }
      }
    }
    break;

    case VK_RIGHT:
    escolumn++;
    if (escolumn > 1)
    {
      escolumn = 0;
      if (eseditpos < (songlen[esnum][eschn]+1))
      {
        eseditpos++;
        if (eseditpos == songlen[esnum][eschn]) eseditpos++;
      }
      else escolumn = 1;
    }
    break;

    case VK_PAGEDOWN:
    for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
    {
      escolumn++;
      if (escolumn > 1)
      {
        escolumn = 0;
        if (eseditpos < (songlen[esnum][eschn]+1))
        {
          eseditpos++;
          if (eseditpos == songlen[esnum][eschn]) eseditpos++;
        }
        else escolumn = 1;
      }
    }
    break;

    case VK_HOME:
    eseditpos = 0;
    escolumn = 0;
    if (eseditpos == songlen[esnum][eschn]) eseditpos++;
    break;

    case VK_END:
    eseditpos = songlen[esnum][eschn]+1;
    escolumn = 0;
    break;

    case VK_PAGEUP:
    for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
    {
      escolumn--;
      if (escolumn < 0)
      {
        if (eseditpos > 0)
        {
          eseditpos--;
          if (eseditpos == songlen[esnum][eschn]) eseditpos--;
          escolumn = 1;
          if (eseditpos < 0)
          {
            eseditpos = 1;
            escolumn = 0;
          }
        }
        else escolumn = 0;
      }
    }
    break;

    case VK_LEFT:
    escolumn--;
    if (escolumn < 0)
    {
      if (eseditpos > 0)
      {
        eseditpos--;
        if (eseditpos == songlen[esnum][eschn]) eseditpos--;
        escolumn = 1;
        if (eseditpos < 0)
        {
          eseditpos = 1;
          escolumn = 0;
        }
      }
      else escolumn = 0;
    }
    break;

    case VK_UP:
    eschn--;
    if (eschn < 0) eschn = MAX_CHN - 1;
    if ((eseditpos == songlen[esnum][eschn]) || (eseditpos > songlen[esnum][eschn]+1))
    {
      eseditpos = songlen[esnum][eschn]+1;
      escolumn = 0;
    }
    break;

    case VK_DOWN:
    eschn++;
    if (eschn >= MAX_CHN) eschn = 0;
    if ((eseditpos == songlen[esnum][eschn]) || (eseditpos > songlen[esnum][eschn]+1))
    {
      eseditpos = songlen[esnum][eschn]+1;
      escolumn = 0;
    }
    break;
  }
  if (eseditpos - esview < 0)
  {
    esview = eseditpos;
  }
  if (eseditpos - esview >= VISIBLEORDERLIST)
  {
    esview = eseditpos - VISIBLEORDERLIST + 1;
  }
}

void instrumentcommands(void)
{
  switch(virtualkey)
  {
    case VK_TAB:
    if (!shiftpressed) editmode++;
    else editmode--;
    editmode &= 3;
    break;

    case 'X':
    if ((einum) && (shiftpressed) && (eipos != 7))
    {
      memcpy(&instrcopybuffer, &instr[einum], sizeof(INSTR));
      memcpy(wavecopybuffer, wavetable[einum], MAX_WAVELEN*2);
      memset(&instr[einum], 0, sizeof(INSTR));
      memset(wavetable[einum], 0, MAX_WAVELEN*2);
      wavetable[einum][2] = 0xff;
    }
    break;

    case 'C':
    if ((einum) && (shiftpressed) && (eipos != 7))
    {
      memcpy(&instrcopybuffer, &instr[einum], sizeof(INSTR));
      memcpy(wavecopybuffer, wavetable[einum], MAX_WAVELEN*2);
    }
    break;

    case 'V':
    if ((einum) && (shiftpressed) && (eipos != 7))
    {
      memcpy(&instr[einum], &instrcopybuffer, sizeof(INSTR));
      memcpy(wavetable[einum], wavecopybuffer, MAX_WAVELEN*2);
    }
    break;

    case VK_INSERT:
    if ((eicolumn >= 2) && (ewpos < (MAX_WAVELEN-1)))
    {
      memmove(&wavetable[einum][ewpos*2+2],
        &wavetable[einum][ewpos*2],
        (MAX_WAVELEN-1 - ewpos)*2-2);
      wavetable[einum][ewpos*2] = 0x00;
      wavetable[einum][ewpos*2 + 1] = 0x00;
    }
    break;

    case VK_DELETE:
    if ((eicolumn >= 2) && (ewpos < (MAX_WAVELEN-1)))
    {
      memmove(&wavetable[einum][ewpos*2],
        &wavetable[einum][ewpos*2+2],
        (MAX_WAVELEN-1 - ewpos)*2-2);
      wavetable[einum][(MAX_WAVELEN-2)*2] = 0x00;
      wavetable[einum][(MAX_WAVELEN-2)*2 + 1] = 0x00;
    }
    break;

    case VK_RIGHT:
    if (eipos != 7)
    {
      eicolumn++;
      if (eicolumn > 5) eicolumn = 0;
    }
    break;

    case VK_LEFT:
    if (eipos != 7)
    {
      eicolumn--;
      if (eicolumn < 0) eicolumn = 5;
    }
    break;

    case VK_PAGEDOWN:
    for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
    {
      if (eicolumn < 2)
      {
        eipos++;
        if (eipos > 6) eipos = 0;
      }
      else
      {
        if (ewpos < MAX_WAVELEN-1)
        {
          ewpos++;
        }
      }
    }
    break;

    case VK_DOWN:
    if (eicolumn < 2)
    {
      eipos++;
      if (eipos > 6) eipos = 0;
    }
    else
    {
      if (ewpos < MAX_WAVELEN-1)
      {
        ewpos++;
      }
    }
    break;

    case VK_PAGEUP:
    for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
    {
      if (eicolumn < 2)
      {
        eipos--;
        if (eipos < 0) eipos = 6;
      }
      else
      {
        if (ewpos > 0)
        {
          ewpos--;
        }
      }
    }
    break;

    case VK_UP:
    if (eicolumn < 2)
    {
      eipos--;
      if (eipos < 0) eipos = 6;
    }
    else
    {
      if (ewpos > 0)
      {
        ewpos--;
      }
    }
    break;

    case 'N':
    if ((eipos != 7) && (shiftpressed))
    {
      eipos = 7;
      goto INSTREDIT_END;
    }
    break;

    case VK_SPACE:
    if (eipos != 7)
    {
      playtestnote(epoctave * 12, shiftpressed);
    }
    break;

    case VK_RETURN:
    if (eipos != 7)
    {
      chn[epchn].wave &= 0xfe;
      sidreg[0x4 + epchn * 7] = chn[epchn].wave; /* Gate off */
    }
    if (eipos == 7)
    {
      eipos = 0;
    }
    break;
  }
  if ((eipos == 7) && (einum)) editstring(instr[einum].name, MAX_INSTRNAMELEN);
  if ((hexnybble >= 0) && (eipos != 7) && (einum))
  {
    unsigned char *ptr = &instr[einum].ad;
    ptr += eipos;

    switch(eicolumn)
    {
      case 0:
      if ((eipos < 2) || (eipos > 5))
      {
        *ptr &= 0x0f;
        *ptr |= hexnybble << 4;
      }
      else
      {
        *ptr &= 0xf0;
        *ptr |= hexnybble;
      }
      eicolumn++;
      if (eicolumn > 1)
      {
        eicolumn = 0;
        eipos++;
        if (eipos > 6) eipos = 0;
      }
      break;

      case 1:
      if ((eipos < 2) || (eipos > 5))
      {
        *ptr &= 0xf0;
        *ptr |= hexnybble;
      }
      else
      {
        *ptr &= 0x0f;
        *ptr |= hexnybble << 4;
      }
      eicolumn++;
      if (eicolumn > 1)
      {
        eicolumn = 0;
        eipos++;
        if (eipos > 6) eipos = 0;
      }
      break;

      case 2:
      if (ewpos < MAX_WAVELEN-1)
      {
        wavetable[einum][ewpos*2] &= 0x0f;
        wavetable[einum][ewpos*2] |= hexnybble << 4;
        eicolumn++;
        if (eicolumn > 5)
        {
          eicolumn = 2;
          ewpos++;
        }
      }
      break;

      case 3:
      if (ewpos < MAX_WAVELEN-1)
      {
        wavetable[einum][ewpos*2] &= 0xf0;
        wavetable[einum][ewpos*2] |= hexnybble;
        eicolumn++;
        if (eicolumn > 5)
        {
          eicolumn = 2;
          ewpos++;
        }
      }
      break;

      case 4:
      if (ewpos < MAX_WAVELEN-1)
      {
        wavetable[einum][ewpos*2+1] &= 0x0f;
        wavetable[einum][ewpos*2+1] |= hexnybble << 4;
        eicolumn++;
        if (eicolumn > 5)
        {
          eicolumn = 2;
          ewpos++;
        }
      }
      break;

      case 5:
      if (ewpos < MAX_WAVELEN-1)
      {
        wavetable[einum][ewpos*2+1] &= 0xf0;
        wavetable[einum][ewpos*2+1] |= hexnybble;
        eicolumn++;
        if (eicolumn > 5)
        {
          eicolumn = 2;
          ewpos++;
        }
      }
      break;
    }
  }

  INSTREDIT_END:
  if (ewpos - ewview < 0)
  {
    ewview = ewpos;
  }
  if (ewpos - ewview >= VISIBLEWAVEROWS)
  {
    ewview = ewpos - VISIBLEWAVEROWS + 1;
  }

  /* Make sure there aren't illegal parameters */
  instr[einum].pulseadd &= 0xf0;
  instr[einum].pulselimitlow &= 0x0f;
  instr[einum].pulselimithigh &= 0x0f;
}

void playtestnote(int note, int filter)
{
  sidreg[0x4 + epchn * 7] = chn[epchn].wave & 0xfe; /* Hard restart */
  sidreg[0x5 + epchn * 7] = 0;
  sidreg[0x6 + epchn * 7] = 0;
  if ((note == REST) || (note == KEYOFF)) return;

  chn[epchn].newnote = 0 - multiplier*2; /* Trigger note delayed by two updates */
  chn[epchn].instrnum = einum;
  chn[epchn].note = note;

  if (!songinit) return; /* Don't disturb filter when playing */
  if ((instr[einum].filtertype) && (!filter))
  {
    filterctrl &= 0x0f;
    filterctrl |= 0x80;

    switch(epchn)
    {
      case 0:
      filterctrl |= 0x01;
      break;

      case 1:
      filterctrl |= 0x02;
      break;

      case 2:
      filterctrl |= 0x04;
      break;
    }
    filtercutoffadd = 0;
  }
  else
  {
    switch(epchn)
    {
      case 0:
      filterctrl &= 0xff - 0x01;
      break;

      case 1:
      filterctrl &= 0xff - 0x02;
      break;

      case 2:
      filterctrl &= 0xff - 0x04;
      break;
    }
  }
}

void namecommands(void)
{
  switch(virtualkey)
  {
    case VK_TAB:
    if (!shiftpressed) editmode++;
    else editmode--;
    editmode &= 3;
    break;

    case VK_DOWN:
    case VK_RETURN:
    enpos++;
    if (enpos > 2) enpos = 0;
    break;

    case VK_UP:
    enpos--;
    if (enpos < 0) enpos = 2;
    break;
  }
  switch(enpos)
  {
    case 0:
    editstring(songname, MAX_STR);
    break;

    case 1:
    editstring(authorname, MAX_STR);
    break;

    case 2:
    editstring(copyrightname, MAX_STR);
    break;
  }
}

void patterncommands(void)
{
  int c;

  if (followplay)
  {
    if (virtualkey == VK_TAB)
    {
      if (!shiftpressed) editmode++;
      else editmode--;
      editmode &= 3;
    }
    return;
  }

  switch(key)
  {
    case '<':
    case '(':
    case '[':
    if (epnum[epchn] > 0)
    {
      epnum[epchn]--;
      if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
    }
    if (epchn == epmarkchn) epmarkchn = -1;
    break;

    case '>':
    case ')':
    case ']':
    if (epnum[epchn] < MAX_PATT - 1)
    {
      epnum[epchn]++;
      if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
    }
    if (epchn == epmarkchn) epmarkchn = -1;
    break;
  }
  {
    int newnote = -1;
    switch (keypreset)
    {
      case KEY_TRACKER:
      for (c = 0; c < sizeof(notekeytbl1); c++)
      {
        if ((rawkey == notekeytbl1[c]) && (!epcolumn) && (!shiftpressed))
        {
          newnote = c + epoctave * 12;
        }
      }
      for (c = 0; c < sizeof(notekeytbl2); c++)
      {
        if ((rawkey == notekeytbl2[c]) && (!epcolumn) && (!shiftpressed))
        {
          newnote = c + (epoctave+1) * 12;
        }
      }
      break;

      case KEY_DMC:
      for (c = 0; c < sizeof(dmckeytbl); c++)
      {
        if ((rawkey == dmckeytbl[c]) && (!epcolumn) && (!shiftpressed))
        {
          newnote = c + epoctave * 12;
        }
      }
      break;

    }

    if (newnote >= KEYOFF) newnote = -1;
    if (virtualkey == 0x08) newnote = REST;
    if (virtualkey == 0x14) newnote = KEYOFF;
    if (virtualkey == VK_RETURN) newnote = KEYOFF;
    if (newnote >= 0)
    {
      if ((recordmode) && (eppos < pattlen[epnum[epchn]]))
      {
        pattern[epnum[epchn]][eppos * 3] = newnote;
        if (newnote < KEYOFF)
        {
          pattern[epnum[epchn]][eppos * 3 + 1] &= 0x07;
          pattern[epnum[epchn]][eppos * 3 + 1] |= einum << 3;
        }
        if (newnote == REST)
        {
          pattern[epnum[epchn]][eppos * 3 + 1] &= 0x07;
        }
      }
      if (recordmode)
      {
        if (autoadvance < 2)
        {
          eppos++;
          if (eppos > pattlen[epnum[epchn]])
          {
            eppos = 0;
          }
        }
      }
      playtestnote(newnote, 1);
    }
  }
  switch(virtualkey)
  {
    case VK_TAB:
    if (!shiftpressed) editmode++;
    else editmode--;
    editmode &= 3;
    break;

    case 'Z':
    if (shiftpressed)
    {
      autoadvance++;
      if (autoadvance > 2) autoadvance = 0;
      if (keypreset == KEY_TRACKER)
      {
        if (autoadvance == 1) autoadvance = 2;
      }
    }
    break;

    case 'A':
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*3] < KEYOFF) &&
                (pattern[epnum[epmarkchn]][c*3] > 0))
              pattern[epnum[epmarkchn]][c*3]--;
          }
        }
        else
        {
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if ((pattern[epnum[epmarkchn]][c*3] < KEYOFF) &&
                (pattern[epnum[epmarkchn]][c*3] > 0))
              pattern[epnum[epmarkchn]][c*3]--;
          }
        }
      }
      else
      {
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          if ((pattern[epnum[epchn]][c*3] < KEYOFF) &&
              (pattern[epnum[epchn]][c*3] > 0))
            pattern[epnum[epchn]][c*3]--;
        }
      }
    }
    break;

    case 'E':
    if ((shiftpressed) && (eppos < pattlen[epnum[epchn]]))
    {
      cmdcopybuffer = pattern[epnum[epchn]][eppos*3+1] & 7;
      cmddatacopybuffer = pattern[epnum[epchn]][eppos*3+2];
    }
    break;

    case 'R':
    if ((shiftpressed) && (eppos < pattlen[epnum[epchn]]))
    {
      pattern[epnum[epchn]][eppos*3+1] &= 0xf8;
      pattern[epnum[epchn]][eppos*3+1] |= cmdcopybuffer;
      pattern[epnum[epchn]][eppos*3+2] = cmddatacopybuffer;
      eppos++;
    }
    break;

    case 'Q':
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if (pattern[epnum[epmarkchn]][c*3] < KEYOFF-1)
              pattern[epnum[epmarkchn]][c*3]++;
          }
        }
        else
        {
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            if (pattern[epnum[epmarkchn]][c*3] < KEYOFF-1)
              pattern[epnum[epmarkchn]][c*3]++;
          }
        }
      }
      else
      {
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          if (pattern[epnum[epchn]][c*3] < KEYOFF-1)
            pattern[epnum[epchn]][c*3]++;
        }
      }
    }
    break;

    case 'M':
    if (shiftpressed)
    {
      stepsize++;
      if (stepsize > MAX_PATTROWS) stepsize = MAX_PATTROWS;
    }
    break;

    case 'N':
    if (shiftpressed)
    {
      stepsize--;
      if (stepsize < 2) stepsize = 2;
    }
    break;

    case 'L':
    if (shiftpressed)
    {
      if (epmarkchn == -1)
      {
        epmarkchn = epchn;
        epmarkstart = 0;
        epmarkend = pattlen[epnum[epchn]];
      }
      else epmarkchn = -1;
    }
    break;

    case 'C':
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          int d = 0;
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            patterncopybuffer[d*3] = pattern[epnum[epmarkchn]][c*3];
            patterncopybuffer[d*3+1] = pattern[epnum[epmarkchn]][c*3+1];
            patterncopybuffer[d*3+2] = pattern[epnum[epmarkchn]][c*3+2];
            d++;
          }
          patterncopyrows = d;
        }
        else
        {
          int d = 0;
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            patterncopybuffer[d*3] = pattern[epnum[epmarkchn]][c*3];
            patterncopybuffer[d*3+1] = pattern[epnum[epmarkchn]][c*3+1];
            patterncopybuffer[d*3+2] = pattern[epnum[epmarkchn]][c*3+2];
            d++;
          }
          patterncopyrows = d;
        }
        epmarkchn = -1;
      }
      else
      {
        int d = 0;
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          patterncopybuffer[d*3] = pattern[epnum[epchn]][c*3];
          patterncopybuffer[d*3+1] = pattern[epnum[epchn]][c*3+1];
          patterncopybuffer[d*3+2] = pattern[epnum[epchn]][c*3+2];
          d++;
        }
        patterncopyrows = d;
      }
    }
    break;

    case 'X':
    if (shiftpressed)
    {
      if (epmarkchn != -1)
      {
        if (epmarkstart <= epmarkend)
        {
          int d = 0;
          for (c = epmarkstart; c <= epmarkend; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            patterncopybuffer[d*3] = pattern[epnum[epmarkchn]][c*3];
            patterncopybuffer[d*3+1] = pattern[epnum[epmarkchn]][c*3+1];
            patterncopybuffer[d*3+2] = pattern[epnum[epmarkchn]][c*3+2];
            pattern[epnum[epmarkchn]][c*3] = REST;
            pattern[epnum[epmarkchn]][c*3+1] = 0;
            pattern[epnum[epmarkchn]][c*3+2] = 0;
            d++;
          }
          patterncopyrows = d;
        }
        else
        {
          int d = 0;
          for (c = epmarkend; c <= epmarkstart; c++)
          {
            if (c >= pattlen[epnum[epmarkchn]]) break;
            patterncopybuffer[d*3] = pattern[epnum[epmarkchn]][c*3];
            patterncopybuffer[d*3+1] = pattern[epnum[epmarkchn]][c*3+1];
            patterncopybuffer[d*3+2] = pattern[epnum[epmarkchn]][c*3+2];
            pattern[epnum[epmarkchn]][c*3] = REST;
            pattern[epnum[epmarkchn]][c*3+1] = 0;
            pattern[epnum[epmarkchn]][c*3+2] = 0;
            d++;
          }
          patterncopyrows = d;
        }
        epmarkchn = -1;
      }
      else
      {
        int d = 0;
        for (c = 0; c < pattlen[epnum[epchn]]; c++)
        {
          patterncopybuffer[d*3] = pattern[epnum[epchn]][c*3];
          patterncopybuffer[d*3+1] = pattern[epnum[epchn]][c*3+1];
          patterncopybuffer[d*3+2] = pattern[epnum[epchn]][c*3+2];
          pattern[epnum[epchn]][c*3] = REST;
          pattern[epnum[epchn]][c*3+1] = 0;
          pattern[epnum[epchn]][c*3+2] = 0;
          d++;
        }
        patterncopyrows = d;
      }
    }
    break;

    case 'V':
    if ((shiftpressed) && (patterncopyrows))
    {
      for (c = 0; c < patterncopyrows; c++)
      {
        if (eppos >= pattlen[epnum[epchn]]) break;
        pattern[epnum[epchn]][eppos*3] = patterncopybuffer[c*3];
        pattern[epnum[epchn]][eppos*3+1] = patterncopybuffer[c*3+1];
        pattern[epnum[epchn]][eppos*3+2] = patterncopybuffer[c*3+2];
        eppos++;
      }
    }
    break;

    case VK_DELETE:
    if ((pattlen[epnum[epchn]] - eppos)*3-3 >= 0)
    {
      memmove(&pattern[epnum[epchn]][eppos*3],
        &pattern[epnum[epchn]][eppos*3+3],
        (pattlen[epnum[epchn]] - eppos)*3-3);
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*3-3] = REST;
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*3-2] = 0x00;
      pattern[epnum[epchn]][pattlen[epnum[epchn]]*3-1] = 0x00;
    }
    else
    {
      if (eppos == pattlen[epnum[epchn]])
      {
        if (pattlen[epnum[epchn]] > 1)
        {
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*3-3] = ENDPATT;
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*3-2] = 0x00;
          pattern[epnum[epchn]][pattlen[epnum[epchn]]*3-1] = 0x00;
          countthispattern();
          eppos = pattlen[epnum[epchn]];
        }
      }
    }
    break;

    case VK_INSERT:
    if ((pattlen[epnum[epchn]] - eppos)*3-3 >= 0)
    {
      memmove(&pattern[epnum[epchn]][eppos*3+3],
        &pattern[epnum[epchn]][eppos*3],
        (pattlen[epnum[epchn]] - eppos)*3-3);
      pattern[epnum[epchn]][eppos*3] = REST;
      pattern[epnum[epchn]][eppos*3+1] = 0x00;
      pattern[epnum[epchn]][eppos*3+2] = 0x00;
    }
    else
    {
      if (eppos == pattlen[epnum[epchn]])
      {
        if (pattlen[epnum[epchn]] < MAX_PATTROWS)
        {
          pattern[epnum[epchn]][eppos*3] = REST;
          pattern[epnum[epchn]][eppos*3+1] = 0x00;
          pattern[epnum[epchn]][eppos*3+2] = 0x00;
          pattern[epnum[epchn]][eppos*3+3] = ENDPATT;
          pattern[epnum[epchn]][eppos*3+4] = 0x00;
          pattern[epnum[epchn]][eppos*3+5] = 0x00;
          countthispattern();
          eppos = pattlen[epnum[epchn]];
        }
      }
    }
    break;

    case VK_SPACE:
    recordmode ^= 1;
    break;

    case VK_RIGHT:
    if (!shiftpressed)
    {
      epcolumn++;
      if (epcolumn >= 6)
      {
        epcolumn = 0;
        epchn++;
        if (epchn >= MAX_CHN) epchn = 0;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
    }
    else
    {
      if (epnum[epchn] < MAX_PATT - 1)
      {
        epnum[epchn]++;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
      if (epchn == epmarkchn) epmarkchn = -1;
    }
    break;

    case VK_LEFT:
    if (!shiftpressed)
    {
      epcolumn--;
      if (epcolumn < 0)
      {
        epcolumn = 5;
        epchn--;
        if (epchn < 0) epchn = MAX_CHN - 1;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
    }
    else
    {
      if (epnum[epchn] > 0)
      {
        epnum[epchn]--;
        if (eppos > pattlen[epnum[epchn]]) eppos = pattlen[epnum[epchn]];
      }
      if (epchn == epmarkchn) epmarkchn = -1;
    }
    break;

    case VK_PAGEDOWN:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
    {
      eppos++;
      if (eppos > pattlen[epnum[epchn]])
      {
        eppos = 0;
      }
    }
    if (shiftpressed) epmarkend = eppos;
    break;

    case VK_DOWN:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos++;
    if (eppos > pattlen[epnum[epchn]])
    {
      eppos = 0;
    }
    if (shiftpressed) epmarkend = eppos;
    break;

    case VK_HOME:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos = 0;
    if (shiftpressed) epmarkend = eppos;
    break;

    case VK_END:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos = pattlen[epnum[epchn]];
    if (shiftpressed) epmarkend = eppos;
    break;

    case VK_PAGEUP:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
    {
      eppos--;
      if (eppos < 0)
      {
        eppos = pattlen[epnum[epchn]];
      }
    }
    if (shiftpressed) epmarkend = eppos;
    break;

    case VK_UP:
    if (shiftpressed)
    {
      if ((epmarkchn != epchn) || (eppos != epmarkend))
      {
        epmarkchn = epchn;
        epmarkstart = epmarkend = eppos;
      }
    }
    eppos--;
    if (eppos < 0)
    {
      eppos = pattlen[epnum[epchn]];
    }
    if (shiftpressed) epmarkend = eppos;
    break;
  }
  if ((keypreset != KEY_TRACKER) && (hexnybble >= 0) && (hexnybble <= 7) && (!epcolumn))
  {
    int oldbyte = pattern[epnum[epchn]][eppos * 3];
    int newbyte;
    int oldnote = oldbyte % 12;
    epoctave = hexnybble;
    if ((oldbyte < KEYOFF) && (recordmode))
    {
      newbyte = oldnote + epoctave * 12;
      if (newbyte < KEYOFF)
      {
        pattern[epnum[epchn]][eppos * 3] = newbyte;
      }
    }
    if ((recordmode) && (autoadvance < 1))
    {
      eppos++;
      if (eppos > pattlen[epnum[epchn]])
      {
        eppos = 0;
      }
    }
  }

  if ((hexnybble >= 0) && (epcolumn) && (recordmode))
  {
    if (eppos < pattlen[epnum[epchn]])
    {
      switch(epcolumn)
      {
        case 1:
        if (hexnybble < 2)
        {
          pattern[epnum[epchn]][eppos * 3 + 1] &= 0x7f;
          pattern[epnum[epchn]][eppos * 3 + 1] |= hexnybble << 7;
        }
        break;

        case 2:
        pattern[epnum[epchn]][eppos * 3 + 1] &= 0x87;
        pattern[epnum[epchn]][eppos * 3 + 1] |= hexnybble << 3;
        break;

        case 3:
        if (hexnybble < 8)
        {
          pattern[epnum[epchn]][eppos * 3 + 1] &= 0xf8;
          pattern[epnum[epchn]][eppos * 3 + 1] |= hexnybble;
          /* Check for illegal command data */
          if ((pattern[epnum[epchn]][eppos * 3 + 1] & 0x7) == CMD_SETTEMPO)
          {
            int tempo = pattern[epnum[epchn]][eppos * 3 + 2] & 0x7f;
            if (tempo < 3) tempo = 3;
            pattern[epnum[epchn]][eppos * 3 + 2] &= 0x80;
            pattern[epnum[epchn]][eppos * 3 + 2] |= tempo;
          }
        }
        break;

        case 4:
        pattern[epnum[epchn]][eppos * 3 + 2] &= 0x0f;
        pattern[epnum[epchn]][eppos * 3 + 2] |= hexnybble << 4;
        /* Check for illegal command data */
        if ((pattern[epnum[epchn]][eppos * 3 + 1] & 0x7) == CMD_SETTEMPO)
        {
          int tempo = pattern[epnum[epchn]][eppos * 3 + 2] & 0x7f;
          if (tempo < 3) tempo = 3;
          pattern[epnum[epchn]][eppos * 3 + 2] &= 0x80;
          pattern[epnum[epchn]][eppos * 3 + 2] |= tempo;
        }
        break;

        case 5:
        pattern[epnum[epchn]][eppos * 3 + 2] &= 0xf0;
        pattern[epnum[epchn]][eppos * 3 + 2] |= hexnybble;
        /* Check for illegal command data */
        if ((pattern[epnum[epchn]][eppos * 3 + 1] & 0x7) == CMD_SETTEMPO)
        {
          int tempo = pattern[epnum[epchn]][eppos * 3 + 2] & 0x7f;
          if (tempo < 3) tempo = 3;
          pattern[epnum[epchn]][eppos * 3 + 2] &= 0x80;
          pattern[epnum[epchn]][eppos * 3 + 2] |= tempo;
        }
        break;
      }
    }
    if (autoadvance < 2)
    {
      eppos++;
      if (eppos > pattlen[epnum[epchn]])
      {
        eppos = 0;
      }
    }
  }
  epview = eppos - VISIBLEPATTROWS / 2;
}

void printmainscreen(void)
{
  clearscreen();
  printblankc(0, 0, 15+16, 80);
  printtext(0, 0, 15+16, programname);
  if (multiplier != 1)
  {
    sprintf(textbuffer, "%dX-mode", multiplier);
    printtext(60, 0, 15+16, textbuffer);
  }
  printtext(70, 0, 15+16, "F12 = HELP");
  printpatterns();
  fliptoscreen();
}

void editstring(char *buffer, int maxlength)
{
  int len = strlen(buffer);

  if (key)
  {
    if ((key >= 32) && (key < 256))
    {
      if (len < maxlength-1)
      {
        buffer[len] = key;
        buffer[len+1] = 0;
      }
    }
    if ((key == 8) && (len > 0))
    {
      buffer[len-1] = 0;
    }
  }
}

void playroutine(void)
{
  INSTR *iptr;
  CHN *cptr = &chn[0];
  int c;

  if (songinit == 0x03) followplay = 0;

  if ((songinit > 0) && (songinit < 0x80))
  {
    timeframe = 0;
    timemin = 0;
    timesec = 0;
    playsongnum = esnum;
    if (songinit == 0x02)
    {
      if ((espos[0] >= songlen[playsongnum][0]) ||
         (espos[1] >= songlen[playsongnum][1]) ||
         (espos[2] >= songlen[playsongnum][2]))
         songinit = 0x01;
    }

    for (c = 0; c < MAX_CHN; c++)
    {
      if (songinit == 0x02) cptr->songptr = espos[c];
      else cptr->songptr = 0;
      cptr->wavetable = 0;
      cptr->tick = 5;
      cptr->newnote = 5;
      if (songinit == 0x01) cptr->tempo = 5;
      sidreg[0x4 + c*7] = cptr->wave = 0x08; /* Testbit */
      cptr->pattptr = ENDPATT;
      cptr++;
    }
    sidreg[0x15] = 0;
    filterctrl = 0;
    filtercutoffadd = 0;
    if (songinit != 0x03) songinit = 0;
    else songinit = 0x80;
    if ((!songlen[playsongnum][0]) ||
       (!songlen[playsongnum][1]) ||
       (!songlen[playsongnum][2])) songinit = 0x80; /* Zero length song */
  }
  else
  {
    filtercutoff += filtercutoffadd;
    sidreg[0x16] = filtercutoff;
    sidreg[0x17] = filterctrl;
    sidreg[0x18] = volume | filtertype;

    for (c = 0; c < MAX_CHN; c++)
    {
      iptr = &instr[cptr->instrnum];
      if (cptr->newnote >= 0x80)
      {
        cptr->wavetable = 0;
        cptr->pulsedir = 0;
        cptr->newnote++;
      }
      /* In jammode, don't advance song */
      if (songinit == 0x80)
      {
        cptr->command = 0;
        cptr->cmddata = 0;
        goto EFFECTS;
      }

      /* Decrease tick */
      if (cptr->tick >= 0x80) cptr->tick = cptr->tempo;
      cptr->tick--;
      if (cptr->tick >= 0x80) goto NEWNOTES;

      /* Check for end of pattern */
      if (cptr->pattptr != ENDPATT) goto EFFECTS;
      cptr->pattptr = 0;
      if (songorder[playsongnum][c][cptr->songptr] < LOOPSONG)
      {
        cptr->pattnum = songorder[playsongnum][c][cptr->songptr];
        cptr->songptr++;
      }
      else
      {
        cptr->songptr = songorder[playsongnum][c][cptr->songptr+1];
        if (cptr->songptr >= songlen[playsongnum][c])
        {
          songinit = 0x03;
          cptr->songptr = 0;
        }
        cptr->pattnum = songorder[playsongnum][c][cptr->songptr];
        cptr->songptr++;
      }
      if (!cptr->newnote) goto EFFECTS;
      goto PULSEDONE;

      /* New notes processing */
      NEWNOTES:
      {
        unsigned char newinstrnum;
        unsigned char newnote;

        newnote = pattern[cptr->pattnum][cptr->pattptr];
        newinstrnum = pattern[cptr->pattnum][cptr->pattptr+1] >> 3;
        if (newinstrnum) cptr->instrnum = newinstrnum;
        cptr->command = pattern[cptr->pattnum][cptr->pattptr+1] & 0x7;
        cptr->cmddata = pattern[cptr->pattnum][cptr->pattptr+2];
        cptr->pattptr += 3;
        if (pattern[cptr->pattnum][cptr->pattptr] == ENDPATT)
          cptr->pattptr = ENDPATT;

        if (newnote < REST)
        {
          if (newnote == KEYOFF)
            sidreg[0x4 + 7*c] = cptr->wave & 0xfe;
          else
          {
            cptr->note = newnote;
            if (cptr->command != CMD_TONEPORTA)
            {
              cptr->newnote = 2 - multiplier*2;
              sidreg[0x4 + 7*c] = cptr->wave & 0xfe;
              sidreg[0x5 + 7*c] = 0; /* Hard restart */
              sidreg[0x6 + 7*c] = 0;
            }
          }
        }
      }
      /* Tick 0 effects */
      switch (cptr->command)
      {
        case CMD_SETCUTOFFADD:
        filtercutoffadd = cptr->cmddata;
        break;

        case CMD_TONEPORTA:
        cptr->vibdir = 0xfe;
        break;

        case CMD_SETFILTER:
        filterctrl = cptr->cmddata;
        break;

        case CMD_SETSUSTAIN:
        sidreg[0x6 + 7*c] = cptr->cmddata;
        break;

        case CMD_SETTEMPO:
        /* Refuse to use tempo < 3 because it wouldn't work correctly */
        if ((cptr->cmddata & 0x7f) >= 3)
        {
          if (cptr->cmddata >= 0x80)
          {
            /* Timing mark in player 3 */
            if (cptr->cmddata < 0xc0)
            {
              cptr->tempo = (cptr->cmddata & 0x7f) - 1;
            }
          }
          else
          {
            chn[0].tempo = cptr->cmddata - 1;
            chn[1].tempo = cptr->cmddata - 1;
            chn[2].tempo = cptr->cmddata - 1;
          }
        }
        break;
      }
      goto NEXTCHN;

      /* Continuous effects */
      EFFECTS:
      if (!cptr->newnote)
      {
        cptr->newnote = 0x3f;
        cptr->arpcount = 0xfe;
        cptr->vibdir = 0xfe;
        cptr->wavetable = 1;
        cptr->waveinstr = cptr->instrnum;
        if (iptr->pulse)
        {
          cptr->pulsedir = 0x80;
          cptr->pulse = iptr->pulse;
          sidreg[0x2 + 7*c] = cptr->pulse;
          sidreg[0x3 + 7*c] = cptr->pulse;
        } else cptr->pulsedir |= 0x80;
        if (iptr->filtertype)
        {
          filtercutoff = iptr->filtertype & 0xf0;
          filtertype = iptr->filtertype << 4;
        }
        goto NEXTCHN;
      }
      PULSEMOD:
      {
        int newpulse;

        if (cptr->pulsedir >= 0x80)
        {
          sidreg[0x5 + 7*c] = iptr->ad;
          sidreg[0x6 + 7*c] = iptr->sr;
          cptr->pulsedir &= 0x7f;
        }
        else
        {
          if (!cptr->pulsedir)
          {
            newpulse = cptr->pulse;
            newpulse += iptr->pulseadd;
            if (newpulse > 0xff) newpulse++;
            cptr->pulse = newpulse & 0xff;
            if ((cptr->pulse & 0xf) >= iptr->pulselimithigh)
              cptr->pulsedir = 0x01;
            sidreg[0x2 + 7*c] = cptr->pulse;
            sidreg[0x3 + 7*c] = cptr->pulse;
          }
          else
          {
            newpulse = cptr->pulse;
            newpulse -= iptr->pulseadd;
            if (newpulse < 0) newpulse--;
            cptr->pulse = newpulse & 0xff;
            if ((cptr->pulse & 0xf) < iptr->pulselimitlow)
              cptr->pulsedir = 0x00;
            sidreg[0x2 + 7*c] = cptr->pulse;
            sidreg[0x3 + 7*c] = cptr->pulse;
          }
        }
      }
      PULSEDONE:
      if (cptr->wavetable) goto WAVETABLE;
      if (!cptr->command) goto ARPEGGIO;
      switch(cptr->command)
      {
        case CMD_PORTAMENTO:
        {
          unsigned char speed = cptr->cmddata << 1;
          if (cptr->cmddata < 0x80) freqadd(c, cptr, speed);
          else freqsub(c, cptr, speed);
        }
        break;

        case CMD_VIBRATO:
        {
          unsigned char speed = swapnybbles(cptr->cmddata);

          if ((cptr->vibdir < 0x80) && (cptr->vibdir >= ((cptr->cmddata >> 4) & 0x0e)))
          {
            cptr->vibdir ^= 0xff;
          }
          else
          {
            cptr->vibdir += 0x02;
          }
          if (cptr->vibdir & 0x01) freqsub(c, cptr, speed);
          else freqadd(c, cptr, speed);
        }
        break;

        case CMD_TONEPORTA:
        {
          unsigned short targetfreq = freqtbllo[cptr->note] | (freqtblhi[cptr->note] << 8);
          unsigned short currentfreq = cptr->freqlo | (cptr->freqhi << 8);
          unsigned char speed = cptr->cmddata << 1;

          if (cptr->cmddata < 0x80)
          {
            if (currentfreq < targetfreq) freqadd(c, cptr, speed);
            else
            {
              sidreg[0x0 + 7*c] = cptr->freqlo = targetfreq & 0xff;
              sidreg[0x1 + 7*c] = cptr->freqhi = targetfreq >> 8;
            }
          }
          else
          {
            if (currentfreq > targetfreq) freqsub(c, cptr, speed);
            else
            {
              sidreg[0x0 + 7*c] = cptr->freqlo = targetfreq & 0xff;
              sidreg[0x1 + 7*c] = cptr->freqhi = targetfreq >> 8;
            }
          }
        }
        break;
      }
      goto NEXTCHN;

      WAVETABLE:
      {
        unsigned char note;

        if (wavetable[cptr->waveinstr][cptr->wavetable - 1])
        {
          if (!cptr->mute) sidreg[0x4 + 7*c] = cptr->wave = wavetable[cptr->waveinstr][cptr->wavetable - 1];
          else sidreg[0x4 + 7*c] = cptr->wave = 0x08;
        }
        note = wavetable[cptr->waveinstr][cptr->wavetable];
        if (note < 0x80)
          note += cptr->note;
        note &= 0x7f;

        switch (wavetable[cptr->waveinstr][cptr->wavetable+1])
        {
          case 0xff:
          if (wavetable[cptr->waveinstr][cptr->wavetable+2])
          {
            cptr->waveinstr = cptr->instrnum;
            cptr->wavetable = (wavetable[cptr->waveinstr][cptr->wavetable+2] - 1) * 2 + 1;
          }
          else
          {
            cptr->wavetable = 0;
          }
          break;

          default:
          cptr->wavetable += 2;
          break;
        }
        sidreg[0x0 + 7*c] = cptr->freqlo = freqtbllo[note];
        sidreg[0x1 + 7*c] = cptr->freqhi = freqtblhi[note];
      }
      goto NEXTCHN;

      ARPEGGIO:
      if (cptr->cmddata)
      {
        unsigned char note = cptr->note;

        /* Slow arpeggio */
        if (cptr->cmddata >= 0x80)
        {
          if (cptr->tick & 1) goto SLOWARPDELAY;
        }

        if (!cptr->arpcount)
        {
          cptr->arpcount = 0x01;
          goto ARPDONE;
        }
        if (cptr->arpcount < 0x80)
        {
          note += (cptr->cmddata & 0x70) >> 4;
          cptr->arpcount = 0xff;
          goto ARPDONE;
        }
        note += (cptr->cmddata & 0xf);
        cptr->arpcount = 0;

        ARPDONE:
        note &= 0x7f;
        sidreg[0x0 + 7*c] = cptr->freqlo = freqtbllo[note];
        sidreg[0x1 + 7*c] = cptr->freqhi = freqtblhi[note];
        SLOWARPDELAY:
      }
      NEXTCHN:
      if (cptr->mute) sidreg[0x4 + 7*c] = cptr->wave = 0x08;

      cptr++;
    }
  }
  if (songinit != 0x80)
  {
    timeframe++;
    if (!ntsc)
    {
      if (timeframe == 50*multiplier)
      {
        timeframe = 0;
        timesec++;
      }
    }
    else
    {
      if (timeframe == 60*multiplier)
      {
        timeframe = 0;
        timesec++;
      }
    }
    if (timesec == 60)
    {
      timesec = 0;
      timemin++;
      timemin %= 60;
    }
  }
}

void freqadd(int c, CHN *cptr, unsigned char speed)
{
  int newlowbyte = cptr->freqlo;
  newlowbyte += speed;

  sidreg[0x0 + 7*c] = cptr->freqlo;
  sidreg[0x1 + 7*c] = cptr->freqhi;
  if (newlowbyte > 0xff) cptr->freqhi++;
  cptr->freqlo = newlowbyte & 0xff;
}

void freqsub(int c, CHN *cptr, unsigned char speed)
{
  int newlowbyte = cptr->freqlo;
  newlowbyte -= speed;

  sidreg[0x0 + 7*c] = cptr->freqlo;
  sidreg[0x1 + 7*c] = cptr->freqhi;
  if (newlowbyte < 0) cptr->freqhi--;
  cptr->freqlo = newlowbyte & 0xff;
}

unsigned char swapnybbles(unsigned char n)
{
  unsigned char highnybble = n >> 4;
  unsigned char lownybble = n & 0xf;

  return (lownybble << 4) | highnybble;
}

void clearsong(int cs, int cp, int ci, int cn)
{
  int c;

  songinit = 0x03;

  epmarkchn = -1;

  for (c = 0; c < MAX_CHN; c++)
  {
    int d;
    chn[c].mute = 0;
    chn[c].tempo = 5;
    if (cs)
    {
      for (d = 0; d < MAX_SONGS; d++)
      {
        memset(&songorder[d][c][0], 0, MAX_SONGLEN+2);
        if (!d)
        {
          songorder[d][c][0] = c;
          songorder[d][c][1] = LOOPSONG;
        }
        else
        {
          songorder[d][c][0] = LOOPSONG;
        }
      }
      epnum[c] = songorder[0][c][0];
      espos[c] = 0;
    }
  }
  if (cs)
  {
    esview = 0;
    eseditpos = 0;
    escolumn = 0;
    eschn = 0;
    esnum = 0;
    eppos = 0;
    epview = - VISIBLEPATTROWS / 2;
    epcolumn = 0;
    epchn = 0;
  }
  if (cn)
  {
    memset(songname, 0, sizeof songname);
    memset(authorname, 0, sizeof authorname);
    memset(copyrightname, 0, sizeof copyrightname);
    enpos = 0;
  }

  if (cp)
  {
    for (c = 0; c < MAX_PATT; c++)
    {
      int d;
      memset(&pattern[c][0], 0, MAX_PATTROWS*3);
      for (d = 0; d < defaultpatternlength; d++) pattern[c][d*3] = REST;
      for (d = defaultpatternlength; d <= MAX_PATTROWS; d++) pattern[c][d*3] = ENDPATT;
    }
    patterncopyrows = 0;
  }
  if (ci)
  {
    for (c = 0; c < MAX_INSTR; c++)
    {
      memset(&instr[c], 0, sizeof(INSTR));
      memset(&wavetable[c][0], 0, MAX_WAVELEN*2);
      wavetable[c][2] = 0xff;
      wavetable[c][MAX_WAVELEN*2-2] = 0xff;
    }
    memset(&instrcopybuffer, 0, sizeof(INSTR));
    memset(wavecopybuffer, 0, MAX_WAVELEN*2);
    eipos = 0;
    eicolumn = 0;
    einum = 1;
    ewpos = 0;
  }
  countpatternlengths();
  playsongnum = 0;
}

void countpatternlengths(void)
{
  int c, d, e;

  highestusedpattern = 0;
  for (c = 0; c < MAX_PATT; c++)
  {
    for (d = 0; d <= MAX_PATTROWS; d++)
    {
      if (pattern[c][d*3] == ENDPATT) break;
    }
    pattlen[c] = d;
  }
  for (e = 0; e < MAX_SONGS; e++)
  {
    for (c = 0; c < MAX_CHN; c++)
    {
      for (d = 0; d < MAX_SONGLEN; d++)
      {
        if (songorder[e][c][d] >= LOOPSONG) break;
        if (songorder[e][c][d] > highestusedpattern)
          highestusedpattern = songorder[e][c][d];
      }
      songlen[e][c] = d;
    }
  }
}

void countthispattern(void)
{
  int c, d, e;

  c = epnum[epchn];
  for (d = 0; d <= MAX_PATTROWS; d++)
  {
    if (pattern[c][d*3] == ENDPATT) break;
  }
  pattlen[c] = d;

  e = esnum;
  c = eschn;
  for (d = 0; d < MAX_SONGLEN; d++)
  {
    if (songorder[e][c][d] >= LOOPSONG) break;
    if (songorder[e][c][d] > highestusedpattern)
      highestusedpattern = songorder[e][c][d];
  }
  songlen[e][c] = d;
}


void printpatterns(void)
{
  int c, d, color;
  int cc = cursorcolortable[cursorflash];

  for (c = 0; c < MAX_CHN; c++)
  {
    if (!followplay)
    {
      sprintf(textbuffer, "CHN%d PATT%02X", c+1, epnum[c]);
      printtext(1+c*13, 2, 15, textbuffer);
      for (d = 0; d < VISIBLEPATTROWS; d++)
      {
        int rownum = epview + d;
        color = 7;
        if ((epnum[c] == chn[c].pattnum) && (!songinit))
        {
          int chnrow = chn[c].pattptr;
          if (chnrow != ENDPATT)
          {
            chnrow /= 3;
            if (chnrow == rownum) color = 12;
          }
        }

        if (chn[c].mute) color = 8;
        if (rownum == eppos) color = 10;
        if ((rownum < 0) || (rownum > pattlen[epnum[c]]))
        {
          sprintf(textbuffer, "           ");
        }
        else
        {
          if (pattern[epnum[c]][rownum*3] == ENDPATT)
          {
            sprintf(textbuffer, "%02d PATT.END",
              rownum,
              pattern[epnum[c]][rownum*3+1] >> 3,
              pattern[epnum[c]][rownum*3+1] & 0x7,
              pattern[epnum[c]][rownum*3+2]);
          }
          else
          {
            sprintf(textbuffer, "%02d %s%02X%01X%02X",
              rownum,
              notename[pattern[epnum[c]][rownum*3]],
              pattern[epnum[c]][rownum*3+1] >> 3,
              pattern[epnum[c]][rownum*3+1] & 0x7,
              pattern[epnum[c]][rownum*3+2]);
          }
        }
        textbuffer[2] = 0;
        if (rownum % stepsize)
        {
          printtext(1+c*13, 3+d, 7, textbuffer);
        }
        else
        {
          printtext(1+c*13, 3+d, 10, textbuffer);
        }
        printtext(4+c*13, 3+d, color, &textbuffer[3]);
        if (c == epmarkchn)
        {
          if (epmarkstart <= epmarkend)
          {
            if ((rownum >= epmarkstart) && (rownum <= epmarkend))
              printbg(1+c*13+3, 3+d, 1, 8);
          }
          else
          {
            if ((rownum <= epmarkstart) && (rownum >= epmarkend))
              printbg(1+c*13+3, 3+d, 1, 8);
          }
        }
        if ((color == 10) && (editmode == EDIT_PATTERN) && (epchn == c))
        {
          switch(epcolumn)
          {
            case 0:
            printbg(1+c*13+3, 3+d, cc, 3);
            break;

            default:
            printbg(1+c*13+5+epcolumn, 3+d, cc, 1);
            break;
          }
        }
      }
    }
    else
    {
      int pos = chn[c].pattptr;
      int view;
      if (pos == ENDPATT) pos = pattlen[chn[c].pattnum];
        else pos /= 3;
      view = pos - VISIBLEPATTROWS / 2;
      epnum[c] = chn[c].pattnum;
      if (epchn == c)
      {
        eppos = pos;
        epview = view;
      }

      sprintf(textbuffer, "CHN%d PATT%02X", c+1, chn[c].pattnum);
      printtext(1+c*13, 2, 15, textbuffer);
      for (d = 0; d < VISIBLEPATTROWS; d++)
      {
        int rownum;

        rownum = view + d;
        color = 7;
        if (chn[c].mute) color = 8;
        if (rownum == pos) color = 12;
        if ((rownum < 0) || (rownum > pattlen[chn[c].pattnum]))
        {
          sprintf(textbuffer, "           ");
        }
        else
        {
          if (pattern[chn[c].pattnum][rownum*3] == ENDPATT)
          {
            sprintf(textbuffer, "%02d PATT.END",
              rownum,
              pattern[chn[c].pattnum][rownum*3+1] >> 3,
              pattern[chn[c].pattnum][rownum*3+1] & 0x7,
              pattern[chn[c].pattnum][rownum*3+2]);
          }
          else
          {
            sprintf(textbuffer, "%02d %s%02X%01X%02X",
              rownum,
              notename[pattern[chn[c].pattnum][rownum*3]],
              pattern[chn[c].pattnum][rownum*3+1] >> 3,
              pattern[chn[c].pattnum][rownum*3+1] & 0x7,
              pattern[chn[c].pattnum][rownum*3+2]);
          }
        }
        textbuffer[2] = 0;
        if (rownum % stepsize)
        {
          printtext(1+c*13, 3+d, 7, textbuffer);
        }
        else
        {
          printtext(1+c*13, 3+d, 10, textbuffer);
        }
        printtext(4+c*13, 3+d, color, &textbuffer[3]);
      }
    }
  }
  if (!followplay)
  {
    sprintf(textbuffer, "CHN ORDERLIST (SUBTUNE %02X, POS %02X)", esnum, eseditpos);
    printtext(40, 2, 15, textbuffer);
    for (c = 0; c < MAX_CHN; c++)
    {
      sprintf(textbuffer, " %d ", c+1);
      printtext(40, 3+c, 15, textbuffer);
      for (d = 0; d < VISIBLEORDERLIST; d++)
      {
        int rownum = esview + d;
        color = 7;
        if (!songinit)
        {
          int chnpos = chn[c].songptr;
          chnpos--;
          if (chnpos < 0) chnpos = 0;
          if (rownum == chnpos) color = 12;
        }
        if (rownum == espos[c]) color = 10;

        if ((rownum < 0) || (rownum > (songlen[esnum][c]+1)) || (rownum > MAX_SONGLEN + 1))
        {
          sprintf(textbuffer, "   ");
        }
        else
        {
          if (songorder[esnum][c][rownum] < LOOPSONG)
          {
            sprintf(textbuffer, "%02X ", songorder[esnum][c][rownum]);
          }
          if (songorder[esnum][c][rownum] == LOOPSONG)
          {
            sprintf(textbuffer, "RST", songorder[esnum][c][rownum]);
          }
        }
        printtext(44+d*3, 3+c, color, textbuffer);
        if ((rownum == eseditpos) && (editmode == EDIT_ORDERLIST) && (eschn == c))
        {
          printbg(44+d*3+escolumn, 3+c, cc, 1);
        }
      }
    }
  }
  else
  {
    int chnpos = chn[eschn].songptr;
    int chnview;
    chnpos--;
    if (chnpos < 0) chnpos = 0;
    sprintf(textbuffer, "CHN ORDERLIST (SUBTUNE %02X, POS %02X)", esnum, chnpos);
    printtext(40, 2, 15, textbuffer);
    for (c = 0; c < MAX_CHN; c++)
    {
      chnpos = chn[c].songptr;
      chnpos--;
      if (chnpos < 0) chnpos = 0;
      chnview = 0;
      if (chnpos >= VISIBLEORDERLIST) chnview = chnpos - VISIBLEORDERLIST + 1;
      if (eschn == c)
      {
        if (chnpos <= songlen[esnum][c]) eseditpos = chnpos;
        esview = chnview;
      }

      sprintf(textbuffer, " %d ", c+1);
      printtext(40, 3+c, 15, textbuffer);
      for (d = 0; d < VISIBLEORDERLIST; d++)
      {
        int rownum = chnview + d;
        color = 7;
        if (rownum == chnpos) color = 12;
        if (rownum == espos[c]) color = 10;
        if ((rownum < 0) || (rownum > (songlen[esnum][c]+1)) || (rownum > MAX_SONGLEN + 1))
        {
          sprintf(textbuffer, "   ");
        }
        else
        {
          if (songorder[esnum][c][rownum] < LOOPSONG)
          {
            sprintf(textbuffer, "%02X ", songorder[esnum][c][rownum]);
          }
          if (songorder[esnum][c][rownum] == LOOPSONG)
          {
            sprintf(textbuffer, "RST", songorder[esnum][c][rownum]);
          }
        }
        printtext(44+d*3, 3+c, color, textbuffer);
      }
    }
  }
  sprintf(textbuffer, "INSTRUMENT NUM. %02X  %-16s", einum, instr[einum].name);
  printtext(40, 7, 15, textbuffer);

  sprintf(textbuffer, "Attack/Decay    %02X", instr[einum].ad);
  if (eipos == 0) color = 10; else color = 7;
  printtext(40, 8, color, textbuffer);

  sprintf(textbuffer, "Sustain/Release %02X", instr[einum].sr);
  if (eipos == 1) color = 10; else color = 7;
  printtext(40, 9, color, textbuffer);

  sprintf(textbuffer, "Pulse Width     %02X", swapnybbles(instr[einum].pulse));
  if (eipos == 2) color = 10; else color = 7;
  printtext(40, 10, color, textbuffer);

  sprintf(textbuffer, "Pulse Speed     %02X", swapnybbles(instr[einum].pulseadd));
  if (eipos == 3) color = 10; else color = 7;
  printtext(40, 11, color, textbuffer);

  sprintf(textbuffer, "Pulse Limit Min %02X", swapnybbles(instr[einum].pulselimitlow));
  if (eipos == 4) color = 10; else color = 7;
  printtext(40, 12, color, textbuffer);

  sprintf(textbuffer, "Pulse Limit Max %02X", swapnybbles(instr[einum].pulselimithigh));
  if (eipos == 5) color = 10; else color = 7;
  printtext(40, 13, color, textbuffer);

  sprintf(textbuffer, "Filt. Freq/Type %02X", instr[einum].filtertype);
  if (eipos == 6) color = 10; else color = 7;
  printtext(40, 14, color, textbuffer);

  printtext(60, 8, 15, "W       N POS");
  sprintf(textbuffer,"A       O %02X", ewpos+1);
  printtext(60, 9,  15, textbuffer);
  printtext(60, 10, 15, "V       T");
  printtext(60, 11, 15, "E       E");
  printtext(60, 12, 15, "T       T");
  printtext(60, 13, 15, "B       B");
  printtext(60, 14, 15, "L       L");
  for (d = 0; d < VISIBLEWAVEROWS; d++)
  {
    int rownum = ewview + d;
    color = 7;
    if (rownum == ewpos) color = 10;
    if ((rownum < 0) || (rownum >= MAX_WAVELEN))
    {
      sprintf(textbuffer, "     ");
    }
    else
    {
      sprintf(textbuffer, "%02X %02X",
      wavetable[einum][rownum*2],
      wavetable[einum][rownum*2+1]);
    }
    printtext(62, 8+d, color, textbuffer);
  }
  if (editmode == EDIT_INSTRUMENT)
  {
    if (eipos < 7)
    {
      switch (eicolumn)
      {
        case 0:
        case 1:
        printbg(56+eicolumn, 8+eipos, cc, 1);
        break;

        case 2:
        case 3:
        printbg(60+eicolumn, 8+ewpos-ewview, cc, 1);
        break;

        case 4:
        case 5:
        printbg(61+eicolumn, 8+ewpos-ewview, cc, 1);
        break;
      }
    }
    else
    {
      printbg(60+strlen(instr[einum].name), 7, cc, 1);
    }
  }

  if (enpos == 0) color = 10; else color = 7;
  printtext(40, 16, 15, "SONG NAME");
  sprintf(textbuffer, "%-32s", songname);
  printtext(40, 17, color, textbuffer);

  if (enpos == 1) color = 10; else color = 7;
  printtext(40, 18, 15, "AUTHOR");
  sprintf(textbuffer, "%-32s", authorname);
  printtext(40, 19, color, textbuffer);

  if (enpos == 2) color = 10; else color = 7;
  printtext(40, 20, 15, "COPYRIGHT");
  sprintf(textbuffer, "%-32s", copyrightname);
  printtext(40, 21, color, textbuffer);

  if (editmode == EDIT_NAMES)
  {
    switch(enpos)
    {
      case 0:
      printbg(40+strlen(songname), 17, cc, 1);
      break;

      case 1:
      printbg(40+strlen(authorname), 19, cc, 1);
      break;

      case 2:
      printbg(40+strlen(copyrightname), 21, cc, 1);
      break;
    }
  }
  sprintf(textbuffer, "OCTAVE %d", epoctave);
  printtext(0, 23, 15, textbuffer);

  switch(autoadvance)
  {
    case 0:
    color = 10;
    break;

    case 1:
    color = 14;
    break;

    case 2:
    color = 12;
    break;
  }

  if (recordmode) printtext(0, 24, color, "EDITMODE");
  else printtext(0, 24, color, "JAM MODE");

  if (!songinit) printtext(10, 23, 15, "PLAYING");
  else printtext(10, 23, 15, "STOPPED");
  if (!ntsc)
    sprintf(textbuffer, " %02d%c%02d ", timemin, timechar[timeframe / (25*multiplier)], timesec);
  else
    sprintf(textbuffer, " %02d%c%02d ", timemin, timechar[timeframe / (30*multiplier)], timesec);

  printtext(10, 24, 10, textbuffer);

  printtext(60, 23, 15, " CHN1   CHN2   CHN3 ");
  for (c = 0; c < MAX_CHN; c++)
  {
    int chnpos = chn[c].songptr;
    int chnrow = chn[c].pattptr;
    chnpos--;
    if (chnpos < 0) chnpos = 0;
    if (chnrow == ENDPATT) chnrow = 0;
    chnrow /= 3;

    sprintf(textbuffer, "%03d/%02d",
      chnpos,chnrow);
    printtext(60+7*c, 24, 10, textbuffer);
  }
}

int fileselector(char *name, char *filter, char *title, int initialmode)
{
  WIN32_FIND_DATA findfiledata;
  HANDLE findhandle;
  DIRENTRY swaptemp;
  int color;
  int c, d;
  int files;
  int filepos;
  int fileview;
  int lowest;
  int filemode = initialmode;
  int exitfilesel;
  char drivestr[] = "A:\\";
  char driveexists[26];

  for (c = 0; c < VISIBLEFILES+6; c++)
  {
    printblank(40 - (MAX_FILENAME+10)/2, 2+c, MAX_FILENAME+10);
  }
  drawbox(40-(MAX_FILENAME+10)/2, 2, 15, MAX_FILENAME+10, VISIBLEFILES+6);
  printblankc(40 - (MAX_FILENAME+10)/2+1, 3, 15+16,MAX_FILENAME+8);
  printtext(40-(MAX_FILENAME+10)/2+1, 3, 15+16, title);

  /* Scan for all existing drives */
  for (c = 0; c < 26; c++)
  {
    drivestr[0] = 'A' + c;
    if (GetDriveType(drivestr) > 1) driveexists[c] = 1;
    else driveexists[c] = 0;
  }

  NEWPATH:
  files = 0;
  for (c = 0; c < 26; c++)
  {
    if (driveexists[c])
    {
      drivestr[0] = 'A' + c;
      strcpy(direntry[files].name, drivestr);
      direntry[files].attribute = 2;
      files++;
    }
  }
  /* Scan for subdirectories in the current path */
  findhandle = FindFirstFile("*.*", &findfiledata);
  if (findhandle != INVALID_HANDLE_VALUE)
  {
    for (;;)
    {
      int result;
      if ((files < MAX_FILES) && (strlen(findfiledata.cFileName) < MAX_FILENAME) && (findfiledata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
      {
        strcpy(direntry[files].name, findfiledata.cFileName);
        direntry[files].attribute = 1;
        files++;
      }
	    result = FindNextFile(findhandle, &findfiledata);
      if (!result) break;
    }
    FindClose(findhandle);
  }
  /* Scan for files in the current path */
  findhandle = FindFirstFile(filter, &findfiledata);
  if (findhandle != INVALID_HANDLE_VALUE)
  {
    for (;;)
    {
      int result;
      if ((files < MAX_FILES) && (strlen(findfiledata.cFileName) < MAX_FILENAME) && (!(findfiledata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)))
      {
        strcpy(direntry[files].name, findfiledata.cFileName);
        direntry[files].attribute = 0;
        files++;
      }
	    result = FindNextFile(findhandle, &findfiledata);
      if (!result) break;
    }
    FindClose(findhandle);
  }
  /* Sort the filelist in a most horrible fashion */
  for (c = 0; c < files; c++)
  {
    lowest = c;
    for (d = c+1; d < files; d++)
    {
      if (direntry[d].attribute < direntry[lowest].attribute)
      {
        lowest = d;
      }
      else
      {
        if (direntry[d].attribute == direntry[lowest].attribute)
        {
          if (stricmp(direntry[d].name, direntry[lowest].name) < 0)
          {
            lowest = d;
          }
        }
      }
    }
    if (lowest != c)
    {
      swaptemp = direntry[c];
      direntry[c] = direntry[lowest];
      direntry[lowest] = swaptemp;
    }
  }

  /* Search for the current filename */
  filepos = 0;
  for (c = 0; c < files; c++)
  {
    if ((!direntry[c].attribute) && (!strcmp(name, direntry[c].name)))
    {
      filepos = c;
    }
  }

  exitfilesel = -1;
  while (exitfilesel < 0)
  {
    int cc = cursorcolortable[cursorflash];

    if (cursorflashdelay >= 5)
    {
      cursorflashdelay %= 5;
      cursorflash++;
      cursorflash &= 3;
      fliptoscreen();
    }
    else
    {
      if (virtualkey) fliptoscreen();
    }
    getkey();

    switch(virtualkey)
    {
      case VK_ESCAPE:
      exitfilesel = 0;
      break;

      case VK_PAGEUP:
      for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
      {
        if ((!filemode) && (filepos > 0))
        {
          filepos--;
          if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
        }
      }
      break;

      case VK_UP:
      if ((!filemode) && (filepos > 0))
      {
        filepos--;
        if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
      }
      break;

      case VK_PAGEDOWN:
      for (scrrep = PAGEUPDNREPEAT; scrrep; scrrep--)
      {
        if ((!filemode) && (filepos < files-1))
        {
          filepos++;
          if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
        }
      }
      break;

      case VK_DOWN:
      if ((!filemode) && (filepos < files-1))
      {
        filepos++;
        if (!direntry[filepos].attribute) strcpy(name, direntry[filepos].name);
      }
      break;

      case VK_TAB:
      filemode++;
      if (filemode > 2) filemode = 0;
      break;

      case VK_RETURN:
      switch(filemode)
      {
        case 0:
        switch (direntry[filepos].attribute)
        {
          case 0:
          strcpy(name, direntry[filepos].name);
          exitfilesel = 1;
          break;

          case 1:
          SetCurrentDirectory(direntry[filepos].name);
          exitfilesel = 2;
          break;

          case 2:
          if (strlen(direntry[filepos].name))
          {
            if (direntry[filepos].name[strlen(direntry[filepos].name)-1] != '\\')
              strcat(direntry[filepos].name, "\\");
          }
          SetCurrentDirectory(direntry[filepos].name);
          exitfilesel = 2;
          break;
        }
        break;

        case 1:
        filemode = 0;
        exitfilesel = 2;
        break;

        case 2:
        exitfilesel = 1;
        break;
      }
      break;
    }
    if (filemode == 1)
    {
      editstring(filter, MAX_FILENAME);
    }
    if (filemode == 2)
    {
      editstring(name, MAX_FILENAME);
    }
    fileview = - VISIBLEFILES / 2 + filepos;


    for (c = 0; c < VISIBLEFILES; c++)
    {
      if ((fileview + c >= 0) && (fileview + c < files))
      {
        switch (direntry[fileview+c].attribute)
        {
          case 0:
          sprintf(textbuffer, "%-60s        ", direntry[fileview+c].name);
          break;

          case 1:
          sprintf(textbuffer, "%-60s   <DIR>", direntry[fileview+c].name);
          break;

          case 2:
          sprintf(textbuffer, "%-60s   <DRV>", direntry[fileview+c].name);
          break;
        }
      }
      else
      {
        sprintf(textbuffer, "                                                                    ");
      }
      color = 7;
      if ((fileview + c) == filepos) color = 10;
      printtext(40-(MAX_FILENAME+10)/2+1, 4+c, color, textbuffer);
      if ((!filemode) && ((fileview + c) == filepos)) printbg(40-(MAX_FILENAME+10)/2+1, 4+c, cc, 68);
    }

    printtext(40-(MAX_FILENAME+10)/2+1, 5+VISIBLEFILES, 15, "FILTER: ");
    sprintf(textbuffer, "%-60s", filter);
    color = 7;
    if (filemode == 1) color = 10;
    printtext(40-(MAX_FILENAME+10)/2+9, 5+VISIBLEFILES, color, textbuffer);
    if (filemode == 1) printbg(40-(MAX_FILENAME+10)/2+9+strlen(filter), 5+VISIBLEFILES, cc, 1);

    printtext(40-(MAX_FILENAME+10)/2+1, 6+VISIBLEFILES, 15, "NAME:   ");
    sprintf(textbuffer, "%-60s", name);
    color = 7;
    if (filemode == 2) color = 10;
    printtext(40-(MAX_FILENAME+10)/2+9, 6+VISIBLEFILES, color, textbuffer);
    if (filemode == 2) printbg(40-(MAX_FILENAME+10)/2+9+strlen(name), 6+VISIBLEFILES, cc, 1);

    if (win_quitted) exitfilesel = 0;
  }
  if (exitfilesel == 2) goto NEWPATH;

  printmainscreen();
  return exitfilesel;
}

void relocator(void)
{
  unsigned char packedsongname[MAX_FILENAME];
  unsigned char packedfilter[MAX_FILENAME];
  unsigned char wavetemp[MAX_WAVELEN * 2];

  int patterns = 0;
  int songs = 0;
  int pattsize = 0;
  int patttblsize = 0;
  int songsize = 0;
  int songtblsize = 0;
  int instrsize = 0;
  int wavetblsize = 0;
  int playersize = 0;
  int totalsize;
  int playerhandle;
  int songhandle;
  int selectdone;

  int c;

  unsigned instradr;
  unsigned wavetbladr;
  unsigned songtbladr;
  unsigned songadr;
  unsigned patttbladr;
  unsigned pattadr;

  unsigned char initpattern[4] = {KEYOFF, 0x06, 0x00, 0xff};
  unsigned char patttemp[256];

  unsigned char *playerwork = NULL;
  unsigned char *songwork = NULL;
  unsigned char *songtblwork = NULL;
  unsigned char *pattwork = NULL;
  unsigned char *patttblwork = NULL;
  unsigned char *instrwork = NULL;
  unsigned char *wavetblwork = NULL;

  songinit = 0x03;

  clearscreen();
  printblankc(0, 0, 15+16, 80);
  printtext(0, 0, 15+16, "GoatTracker PACKER/RELOCATOR");

  printtext(1, 2, 15, "SELECT PLAYROUTINE: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");

  selectdone = 0;
  if (multiplier > 1) playerversion = 4;
  if ((multiplier == 1) && (playerversion == 4)) playerversion &= 3;

  while (!selectdone)
  {
    switch(playerversion)
    {
      case 0:
      printtext(1, 3, 10, "Routine 1: Original (smallest size)                               ");
      break;

      case 1:
      printtext(1, 3, 10, "Routine 2: Game (sound effect support)                            ");
      break;

      case 2:
      printtext(1, 3, 10, "Routine 3: Scene (author-info + timing marks)                     ");
      break;

      case 3:
      printtext(1, 3, 10, "Routine 4: Everything (author-info + timing marks + sound effects)");
      break;

      case 4:
      printtext(1, 3, 10, "Routine 5: Multispeed (author-info + timing marks)                ");
      break;

      case 5:
      printtext(1, 3, 10, "Save only musicdata (need special playroutine)                    ");
      break;
    }

    fliptoscreen();
    waitkey2();

    switch(virtualkey)
    {
      case VK_LEFT:
      case VK_DOWN:
      playerversion--;
      if (playerversion < 0) playerversion = 3;
      break;

      case VK_RIGHT:
      case VK_UP:
      playerversion++;
      if (playerversion > 3) playerversion = 0;
      break;

      case VK_SPACE:
      if (multiplier == 1) playerversion = 5;
      break;

      case VK_ESCAPE:
      selectdone = -1;
      break;

      case VK_RETURN:
      selectdone = 1;
      break;
    }
    if (multiplier > 1) playerversion = 4;
  }
  if (selectdone == -1) goto PRCLEANUP;

  clearscreen();
  printtextc(12, 7, "Packing song...");
  fliptoscreen();

  /* Process song-orderlists */

  /* Calculate amount of songs with nonzero length */
  countpatternlengths();
  for (c = 0; c < MAX_SONGS; c++)
  {
    if ((songlen[c][0]) &&
        (songlen[c][1]) &&
        (songlen[c][2]))
    {
      songs++;
      songsize += songlen[c][0]+2;
      songsize += songlen[c][1]+2;
      songsize += songlen[c][2]+2;
    }
  }

  /* Allocate memory for songtable & song-orderlists */
  songtblsize = songs * 6;
  songtblwork = malloc(songtblsize);
  songwork = malloc(songsize);
  if ((!songtblwork) || (!songwork))
  {
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  /* Generate songorderlists & songtable */
  songsize = 0;
  for (c = 0; c < songs; c++)
  {
    if ((songlen[c][0]) &&
        (songlen[c][1]) &&
        (songlen[c][2]))
    {
      songtblwork[c*3] = songsize & 0xff;
      songtblwork[(c+songs)*3] = songsize >> 8;
      memcpy(&songwork[songsize], songorder[c][0], songlen[c][0]+2);
      if (playerversion == 5)
      {
        int d;
        for (d = 0; d < songlen[c][0]; d++)
        {
          songwork[songsize+d]++;
        }
      }
      songsize += songlen[c][0]+2;

      songtblwork[c*3 + 1] = songsize & 0xff;
      songtblwork[(c+songs)*3 + 1] = songsize >> 8;
      memcpy(&songwork[songsize], songorder[c][1], songlen[c][1]+2);
      if (playerversion == 5)
      {
        int d;
        for (d = 0; d < songlen[c][1]; d++)
        {
          songwork[songsize+d]++;
        }
      }
      songsize += songlen[c][1]+2;

      songtblwork[c*3 + 2] = songsize & 0xff;
      songtblwork[(c+songs)*3 + 2] = songsize >> 8;
      memcpy(&songwork[songsize], songorder[c][2], songlen[c][2]+2);
      if (playerversion == 5)
      {
        int d;
        for (d = 0; d < songlen[c][2]; d++)
        {
          songwork[songsize+d]++;
        }
      }
      songsize += songlen[c][2]+2;
    }
  }

  /* Calculate total size of patterns */
  for (c = 0; c <= highestusedpattern; c++)
  {
    pattsize += packpattern(patttemp, pattern[c], pattlen[c]);
    patterns++;
  }

  if ((patterns == 254) && (playerversion == 5))
  {
    clearscreen();
    printtextc(12, 15, "MUST BE ONE PATTERN FREE FOR INIT PATTERN IN MW4 MODE");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  patttblsize = patterns * 2;
  if (playerversion == 5) patttblsize += 2;

  patttblwork = malloc(patttblsize);
  pattwork = malloc(pattsize);
  if ((!patttblwork) || (!pattwork))
  {
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  /* This time pack the patterns for real */
  highestusedinstr = 0;
  pattsize = 0;
  for (c = 0; c < patterns; c++)
  {
    if (playerversion == 5)
    {
      patttblwork[c+1] = pattsize & 0xff;
      patttblwork[c+patterns+1+1] = pattsize >> 8;
    }
    else
    {
      patttblwork[c] = pattsize & 0xff;
      patttblwork[c+patterns] = pattsize >> 8;
    }
    pattsize += packpattern(&pattwork[pattsize], pattern[c], pattlen[c]);
  }
  highestusedinstr >>= 3;

  /* Then process instruments */
  if (!highestusedinstr) highestusedinstr = 1;

  instrsize = highestusedinstr * 8;
  if (playerversion == 5) instrsize += 4;
  instrwork = malloc(instrsize);
  wavetblwork = malloc((MAX_WAVELEN*2) * highestusedinstr);
  if ((!instrwork) || (!wavetblwork))
  {
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }
  for (c = 1; c <= highestusedinstr; c++)
  {
    int d;
    int instrwavesize;

    instrwork[(c-1)*8+0] = instr[c].ad;
    instrwork[(c-1)*8+1] = instr[c].sr;
    instrwork[(c-1)*8+2] = instr[c].pulse;
    instrwork[(c-1)*8+3] = instr[c].pulseadd;
    instrwork[(c-1)*8+4] = instr[c].pulselimitlow;
    instrwork[(c-1)*8+5] = instr[c].pulselimithigh;
    instrwork[(c-1)*8+6] = instr[c].filtertype;

    memcpy(wavetemp, wavetable[c], MAX_WAVELEN*2);

    for (d = 0; d < MAX_WAVELEN; d++)
    {
      if (wavetemp[d*2] == 0xff)
      {
        break;
      }
    }
    instrwavesize = d*2 + 2;

    if (wavetblsize < instrwavesize)
    {
      memcpy(&wavetblwork[wavetblsize], wavetemp, instrwavesize);
      instrwork[(c-1)*8+7] = wavetblsize/2 + 1;
      wavetblsize += instrwavesize;
    }
    else
    {
      int duplicate = 0;
      /* Search for duplicate from the bytes already in the wavetable */
      for (d = 0; d <= wavetblsize-instrwavesize; d++)
      {
        if (!memcmp(&wavetblwork[d], wavetemp, instrwavesize))
        {
          duplicate = 1;
          instrwork[(c-1)*8+7] = d/2 + 1;
          break;
        }
      }
      if (!duplicate)
      {
        memcpy(&wavetblwork[wavetblsize], wavetemp, instrwavesize);
        instrwork[(c-1)*8+7] = wavetblsize/2 + 1;
        wavetblsize += instrwavesize;
      }
    }
  }
  if (wavetblsize > 512)
  {
    clearscreen();
    printtextc(12, 15, "WAVETABLE EXCEEDS 512 BYTES - SONG WOULDN'T PLAY PROPERLY ON C64");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }
  if (playerversion == 5)
  {
    instrwork[instrsize-4] = initpattern[0];
    instrwork[instrsize-3] = initpattern[1];
    instrwork[instrsize-2] = initpattern[2];
    instrwork[instrsize-1] = initpattern[3];
  }

  switch (playerversion)
  {
    case 0:
    playerhandle = io_open("player1.bin");
    break;

    case 1:
    playerhandle = io_open("player2.bin");
    break;

    case 2:
    playerhandle = io_open("player3.bin");
    break;

    case 3:
    playerhandle = io_open("player4.bin");
    break;

    case 4:
    playerhandle = io_open("player5.bin");
    break;

    case 5:
    playerhandle = io_open("player6.bin");
    break;
  }

  if (playerhandle == -1)
  {
    clearscreen();
    printtextc(12, 15, "CANNOT READ PLAYER.BIN FROM DATAFILE");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }

  playersize = io_lseek(playerhandle, 0, SEEK_END);
  playerwork = malloc(playersize);
  if (!playerwork)
  {
    io_close(playerhandle);
    clearscreen();
    printtextc(12, 15, "OUT OF MEMORY IN PACKER/RELOCATOR!");
    fliptoscreen();
    waitkey2();
    goto PRCLEANUP;
  }
  io_lseek(playerhandle, 0, SEEK_SET);
  io_read(playerhandle, playerwork, playersize);
  io_close(playerhandle);

  totalsize = playersize+songtblsize+songsize+patttblsize+pattsize+instrsize+wavetblsize;

  clearscreen();
  printblankc(0, 0, 15+16, 80);
  printtext(0, 0, 15+16, "GoatTracker PACKER/RELOCATOR");

  sprintf(textbuffer, "PACKING RESULTS:");
  printtext(1, 2, 15, textbuffer);
  sprintf(textbuffer, "Playroutine:     %d bytes", playersize);
  printtext(1, 4, 7, textbuffer);
  sprintf(textbuffer, "Songtable:       %d bytes", songtblsize);
  printtext(1, 5, 7, textbuffer);
  sprintf(textbuffer, "Song-orderlists: %d bytes", songsize);
  printtext(1, 6, 7, textbuffer);
  sprintf(textbuffer, "Patterntable:    %d bytes", patttblsize);
  printtext(1, 7, 7, textbuffer);
  sprintf(textbuffer, "Patterns:        %d bytes", pattsize);
  printtext(1, 8, 7, textbuffer);
  sprintf(textbuffer, "Instruments:     %d bytes", instrsize);
  printtext(1, 9, 7, textbuffer);
  sprintf(textbuffer, "Wavetables:      %d bytes", wavetblsize);
  printtext(1, 10, 7, textbuffer);
  sprintf(textbuffer, "Total size:      %d bytes", totalsize);
  printtext(1, 12, 7, textbuffer);
  fliptoscreen();

  sprintf(textbuffer, "SELECT START ADDRESS: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");
  printtext(1, 14, 15, textbuffer);

  selectdone = 0;
  while (!selectdone)
  {
    int badaddr = 0;

    if (testoverlap(playeradr, totalsize, 0x100, 0x100))
    {
      sprintf(textbuffer, "$%04X Overlaps stack!            ", playeradr);
      printtext(1, 15, 14, textbuffer);
      badaddr = 1;
    }
    if (testoverlap(playeradr, totalsize, 0x0, 0x100))
    {
      sprintf(textbuffer, "$%04X Overlaps zeropage!         ", playeradr);
      printtext(1, 15, 14, textbuffer);
      badaddr = 1;
    }

    if (testoverlap(playeradr, totalsize, 0xd000, 0x1000))
    {
      sprintf(textbuffer, "$%04X Overlaps I/O area!         ", playeradr);
      printtext(1, 15, 14, textbuffer);
      badaddr = 1;
    }
    if (testoverlap(playeradr, totalsize, 0xfffa, 0x6))
    {
      sprintf(textbuffer, "$%04X Overlaps interrupt vectors!", playeradr);
      printtext(1, 15, 14, textbuffer);
      badaddr = 1;
    }
    if (playeradr + totalsize > 0x10000)
    {
      sprintf(textbuffer, "$%04X Goes past end of memory!   ", playeradr);
      printtext(1, 15, 14, textbuffer);
      badaddr = 1;
    }
    if (!badaddr)
    {
      sprintf(textbuffer, "$%04X Ok address.                ", playeradr);
      printtext(1, 15, 10, textbuffer);
    }
    fliptoscreen();
    waitkey2();

    switch(virtualkey)
    {
      case VK_LEFT:
      playeradr -= 0x0400;
      playeradr &= 0xff00;
      break;

      case VK_UP:
      playeradr += 0x0100;
      playeradr &= 0xff00;
      break;

      case VK_RIGHT:
      playeradr += 0x0400;
      playeradr &= 0xff00;
      break;

      case VK_DOWN:
      playeradr -= 0x0100;
      playeradr &= 0xff00;
      break;

      case VK_ESCAPE:
      selectdone = -1;
      break;

      case VK_RETURN:
      if (!badaddr) selectdone = 1;
      break;
    }
  }

  if (selectdone == -1) goto PRCLEANUP;

  sprintf(textbuffer, "SELECT ZEROPAGE BASEADDRESS: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");
  printtext(1, 17, 15, textbuffer);

  selectdone = 0;
  while (!selectdone)
  {
    sprintf(textbuffer, "$%02X", zeropageadr);
    printtext(1, 18, 10, textbuffer);
    fliptoscreen();
    waitkey2();

    switch(virtualkey)
    {
      case VK_LEFT:
      zeropageadr -= 3;
      case VK_DOWN:
      zeropageadr -= 1;
      if (zeropageadr < 0x02) zeropageadr = 0xfc;
      break;

      case VK_RIGHT:
      zeropageadr += 3;
      case VK_UP:
      zeropageadr += 1;
      if (zeropageadr > 0xfc) zeropageadr = 0x02;
      break;

      case VK_ESCAPE:
      selectdone = -1;
      break;

      case VK_RETURN:
      selectdone = 1;
      break;
    }
  }

  if (selectdone == -1) goto PRCLEANUP;

  instradr = playeradr + playersize;
  wavetbladr = instradr + instrsize;
  songtbladr = wavetbladr + wavetblsize;
  patttbladr = songtbladr + songtblsize;
  songadr = patttbladr + patttblsize;
  pattadr = songadr + songsize;

  /* Relocate song & patterntables now that all addresses are known */
  for (c = 0; c < songs; c++)
  {
    int adr;

    adr = songtblwork[c*3] | (songtblwork[(c+songs)*3] << 8);
    adr += songadr;
    songtblwork[c*3] = adr & 0xff;
    songtblwork[(c+songs)*3] = adr >> 8;

    adr = songtblwork[c*3+1] | (songtblwork[(c+songs)*3+1] << 8);
    adr += songadr;
    songtblwork[c*3+1] = adr & 0xff;
    songtblwork[(c+songs)*3+1] = adr >> 8;

    adr = songtblwork[c*3+2] | (songtblwork[(c+songs)*3+2] << 8);
    adr += songadr;
    songtblwork[c*3+2] = adr & 0xff;
    songtblwork[(c+songs)*3+2] = adr >> 8;
  }
  for (c = 0; c < patterns; c++)
  {
    int adr;

    if (playerversion == 5)
    {
      adr = patttblwork[c+1] | (patttblwork[c+patterns+1+1] << 8);
      adr += pattadr;
      patttblwork[c+1] = adr & 0xff;
      patttblwork[c+patterns+1+1] = adr >> 8;
    }
    else
    {
      adr = patttblwork[c] | (patttblwork[c+patterns] << 8);
      adr += pattadr;
      patttblwork[c] = adr & 0xff;
      patttblwork[c+patterns] = adr >> 8;
    }
  }
  if (playerversion == 5)
  {
    patttblwork[0] = (wavetbladr - 4) & 0xff;
    patttblwork[patterns+1] = (wavetbladr - 4) >> 8;
  }

  /* Copy author info to player 3, 4 & 5 */
  if ((playerversion >= 2) && (playerversion <= 4))
  {
    for (c = 0; c < 32; c++)
    {
      playerwork[32+c] = authorname[c];
      /* Convert 0 to space */
      if (playerwork[32+c] == 0) playerwork[32+c] = 0x20;
    }
  }

  /* Now relocate player */

  /* MW4 mode: only save offsets */
  if (playerversion == 5)
  {
    playerwork[0] = instrsize;
    playerwork[1] = wavetblsize/2;
    playerwork[2] = songtblsize/2;
    playerwork[3] = patttblsize/2;
    goto RELOCDONE;
  }

  c = 0;
  for (;;)
  {
    INSTRUCTION *opptr;
    unsigned char opcode;

    if ((playerversion == 2) && (c == 17)) c = 64; /* Hop over author-info */
    if ((playerversion == 3) && (c == 32)) c = 64; /* Hop over author-info */
    if ((playerversion == 4) && (c == 17))
    {
      playerwork[64] = multiplier * 2 - 2; /* Store hard restart-counter */
      c = 65; /* Hop over author-info */
    }

    opcode = playerwork[c];
    if (opcode == 0x00) break; /* Reached data, relocation complete */
    if (opcode == 0x01) break; /* Reached data, relocation complete */
    if (opcode == 0x97) break; /* Reached data, relocation complete */
    opptr = &asmtable[0];

    for (;;)
    {
      if (opptr->opcode == 0xff)
      {
        clearscreen();
        printblankc(0, 0, 15+16, 80);
        printtext(0, 0, 15+16, "GoatTracker PACKER/RELOCATOR");
        printtextc(12, 15, "ILLEGAL OPCODE FOUND IN PLAYROUTINE!");
        fliptoscreen();
        waitkey2();
        goto PRCLEANUP;
      }

      if (opptr->opcode == opcode) break;
      opptr++;
    }

    /* 4 is the special code for zeropage relocation */
    if (opptr->length == 4)
    {
      playerwork[c+1] -= 0xfc;
      playerwork[c+1] += zeropageadr;
      c -= 2;
    }

    /* 3 bytes long instructions need relocation */
    if (opptr->length == 3)
    {
      unsigned short *adr = (unsigned short *)&playerwork[c+1];

      switch(playerwork[c+2])
      {
        /* Player code */
        default:
        *adr -= 0x1000;
        *adr += playeradr;
        break;

        /* Reference to instrument data */
        case 0x40:
        *adr -= 0x4000;
        *adr += instradr - 8; /* First tableindex player uses is 8 */
        break;

        /* Reference to wavetable data */
        case 0x50:
        *adr -= 0x5000;
        *adr += wavetbladr - 1;
        break;

        /* Reference to notetable data */
        case 0x51:
        *adr -= 0x5100;
        *adr += wavetbladr+wavetblsize/2 - 1;
        break;

        /* Reference to songtable, lowbytes */
        case 0x60:
        *adr -= 0x6000;
        *adr += songtbladr;
        break;

        /* Reference to songtable, highbytes */
        case 0x70:
        *adr -= 0x7000;
        *adr += songtbladr + songs*3;
        break;

        /* Reference to patterntable, lowbytes */
        case 0x80:
        *adr -= 0x8000;
        *adr += patttbladr;
        break;

        /* Reference to patterntable, highbytes */
        case 0x90:
        *adr -= 0x9000;
        *adr += patttbladr + patterns;
        break;

        /* Reference to SID registers */
        case 0xd4:
        break;
      }
    }
    c += opptr->length;
  }

  RELOCDONE:

  /* Now ask for fileformat */

  printtext(1, 20, 15, "SELECT FORMAT TO SAVE IN: (CURSORS=MOVE, ENTER=SELECT, ESC=CANCEL)");

  selectdone = 0;

  while (!selectdone)
  {
    switch(fileformat)
    {
      case FORMAT_SID:
      printtext(1, 21, 10, "SID - SIDPlay music file format          ");
      strcpy(packedfilter, "*.sid");
      break;

      case FORMAT_PRG:
      printtext(1, 21, 10, "PRG - C64 native format                  ");
      strcpy(packedfilter, "*.prg");
      break;

      case FORMAT_BIN:
      printtext(1, 21, 10, "BIN - Raw binary format (no startaddress)");
      strcpy(packedfilter, "*.bin");
      break;
    }

    fliptoscreen();
    waitkey2();

    switch(virtualkey)
    {
      case VK_LEFT:
      case VK_DOWN:
      fileformat--;
      if (fileformat < FORMAT_SID) fileformat = FORMAT_BIN;
      break;

      case VK_RIGHT:
      case VK_UP:
      fileformat++;
      if (fileformat > FORMAT_BIN) fileformat = FORMAT_SID;
      break;

      case VK_ESCAPE:
      selectdone = -1;
      break;

      case VK_RETURN:
      selectdone = 1;
      break;
    }
  }
  if (selectdone == -1) goto PRCLEANUP;

  memset(packedsongname, 0, sizeof packedsongname);

  /* Now ask for filename */
  if (!fileselector(packedsongname, packedfilter, "Save Music+Playroutine", 2))
    goto PRCLEANUP;

  if (strlen(packedsongname) < MAX_FILENAME-4)
  {
    int extfound = 0;
    for (c = strlen(packedsongname)-1; c >= 0; c--)
    {
      if (packedsongname[c] == '.') extfound = 1;
    }
    if (!extfound)
    {
      switch (fileformat)
      {
        case FORMAT_PRG:
        strcat(packedsongname, ".prg");
        break;

        case FORMAT_BIN:
        strcat(packedsongname, ".bin");
        break;

        case FORMAT_SID:
        strcat(packedsongname, ".sid");
        break;
      }
    }
  }
  songhandle = open(packedsongname, O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (songhandle != -1)
  {
    unsigned char speedcode[] = {0xa2,0x00,0x8e,0x04,0xdc,0xa2,0x00,0x8e,0x05,0xdc};

    if (fileformat == FORMAT_PRG)
    {
      write(songhandle, &playeradr, 2);
    }
    if (fileformat == FORMAT_SID)
    {
      unsigned char ident[] = {'P', 'S', 'I', 'D', 0x00, 0x02, 0x00, 0x7c};
      unsigned char byte;
      /* For making multispeed SIDs */

      /* Identification */
      write(songhandle, ident, sizeof ident);

      /* Load address */
      byte = 0x00;
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);

      /* Init address */
      if (multiplier > 1)
      {
        unsigned speedvalue;
        byte = (playeradr-10) >> 8;
        write(songhandle, &byte, sizeof byte);
        byte = (playeradr-10) & 0xff;
        write(songhandle, &byte, sizeof byte);

        if (ntsc) speedvalue = 0x4025 / multiplier;
        else speedvalue = 0x4cc7 / multiplier;
        speedcode[1] = speedvalue & 0xff;
        speedcode[6] = speedvalue >> 8;
      }
      else
      {
        byte = (playeradr) >> 8;
        write(songhandle, &byte, sizeof byte);
        byte = (playeradr) & 0xff;
        write(songhandle, &byte, sizeof byte);
      }

      /* Play address */
      byte = (playeradr+3) >> 8;
      write(songhandle, &byte, sizeof byte);
      byte = (playeradr+3) & 0xff;
      write(songhandle, &byte, sizeof byte);

      /* Number of subtunes */
      byte = 0x00;
      write(songhandle, &byte, sizeof byte);
      byte = songs;
      write(songhandle, &byte, sizeof byte);

      /* Default subtune */
      byte = 0x00;
      write(songhandle, &byte, sizeof byte);
      byte = 0x01;
      write(songhandle, &byte, sizeof byte);

      /* Song speed bits */
      byte = 0x00;
      if ((ntsc) || (multiplier > 1)) byte = 0xff;
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);

      /* Songname etc. */
      write(songhandle, songname, sizeof songname);
      write(songhandle, authorname, sizeof authorname);
      write(songhandle, copyrightname, sizeof copyrightname);

      /* Flags */
      byte = 0x00;
      write(songhandle, &byte, sizeof byte);
      if (ntsc) byte = 0x02;
        else byte = 0x00;
      write(songhandle, &byte, sizeof byte);

      /* Reserved longword */
      byte = 0x00;
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);
      write(songhandle, &byte, sizeof byte);

      /* Load address */
      if (multiplier > 1)
      {
        byte = (playeradr - 10) & 0xff;
        write(songhandle, &byte, sizeof byte);
        byte = (playeradr - 10) >> 8;
        write(songhandle, &byte, sizeof byte);
      }
      else
      {
        byte = (playeradr) & 0xff;
        write(songhandle, &byte, sizeof byte);
        byte = (playeradr) >> 8;
        write(songhandle, &byte, sizeof byte);
      }
    }

    if (multiplier > 1) write(songhandle, speedcode, 10);
    write(songhandle, playerwork, playersize);
    write(songhandle, instrwork, instrsize);
    for (c = 0; c < wavetblsize/2; c++)
    {
      write(songhandle, &wavetblwork[c*2], 1);
    }
    for (c = 0; c < wavetblsize/2; c++)
    {
      write(songhandle, &wavetblwork[c*2+1], 1);
    }
    write(songhandle, songtblwork, songtblsize);
    write(songhandle, patttblwork, patttblsize);
    write(songhandle, songwork, songsize);
    write(songhandle, pattwork, pattsize);
    close(songhandle);
  }

  PRCLEANUP:
  if (pattwork) free(pattwork);
  if (patttblwork) free(patttblwork);
  if (songwork) free(songwork);
  if (songtblwork) free(songtblwork);
  if (instrwork) free(instrwork);
  if (wavetblwork) free(wavetblwork);
  if (playerwork) free(playerwork);
  printmainscreen();
}

int packpattern(unsigned char *dest, unsigned char *src, int rows)
{
  unsigned char temp1[256];
  unsigned char temp2[256];
  int count;
  unsigned char instr;
  int command;
  int databyte;
  int destsizeim;
  int destsize;

  /*
   * First write the pattern in such format that zero instruments are
   * eliminated
   */
  for (count = 0; count < rows; count++)
  {
    if (!count)
    {
      temp1[count*3] = src[count*3];
      temp1[count*3+1] = src[count*3+1];
      temp1[count*3+2] = src[count*3+2];
      instr = src[count*3+1] & 0xf8;
      if (instr > highestusedinstr) highestusedinstr = instr;
    }
    else
    {
      if (src[count*3+1] & 0xf8)
      {
        temp1[count*3] = src[count*3];
        temp1[count*3+1] = src[count*3+1];
        temp1[count*3+2] = src[count*3+2];
        instr = src[count*3+1] & 0xf8;
        if (instr > highestusedinstr) highestusedinstr = instr;
      }
      else
      {
        temp1[count*3] = src[count*3];
        temp1[count*3+1] = src[count*3+1] | instr;
        temp1[count*3+2] = src[count*3+2];
      }
    }
    /* Decrease databyte of all tempo commands for the playroutine */
    if ((temp1[count*3+1] & 0x07) == CMD_SETTEMPO)
    {
      /* Do not decrease timing mark */
      if (temp1[count*3+2] < 0xc0) temp1[count*3+2]--;
      else
      {
        /* Playroutines 1-2 don't understand timing marks so remove them */
        if (playerversion < 2)
        {
          temp1[count*3+1] &= 0xf8;
          temp1[count*3+2] = 0;
        }
      }
    }
    /* Swap nybbles of vibrato command for the playroutine */
    if ((temp1[count*3+1] & 0x07) == CMD_VIBRATO)
    {
      temp1[count*3+2] = swapnybbles(temp1[count*3+2]);
    }
  }

  /*
   * Then optimize rows where command & databyte don't change
   */
  command = -1;
  databyte = -1;

  destsizeim = 0;
  for (count = 0; count < rows; count++)
  {
    if ((temp1[count*3+1] != command) ||
        (temp1[count*3+2] != databyte))
    {
      command = temp1[count*3+1];
      databyte = temp1[count*3+2];
      temp2[destsizeim++] = temp1[count*3];
      temp2[destsizeim++] = command;
      temp2[destsizeim++] = databyte;
    }
    else
    {
      temp2[destsizeim++] = temp1[count*3] + 0x60;
    }
  }

  /*
   * Then optimize long singlebyte rests with "packed rest" (final phase)
   */
  destsize = 0;
  for (count = 0; count < destsizeim;)
  {
    if (temp2[count] < 0x60)
    {
      dest[destsize++] = temp2[count++];
      dest[destsize++] = temp2[count++];
      dest[destsize++] = temp2[count++];
    }
    else
    {
      /* Never pack the last row with a packed rest */
      if ((temp2[count] != 0x60+REST) || (count >= destsizeim - 1))
      {
        dest[destsize++] = temp2[count++];
      }
      else
      {
        int d;
        for (d = count; d < destsizeim-1; )
        {
          if (temp2[d] == 0x60+REST)
          {
            d++;
            if (d - count == 64) break;
          }
          else break;
        }
        d -= count;

        if (d > 1)
        {
          dest[destsize++] = -d;
          count += d;
        }
        else
        {
          dest[destsize++] = temp2[count++];
        }
      }
    }
  }
  dest[destsize++] = ENDPATT;

  return destsize;
}

int testoverlap(int area1start, int area1size, int area2start, int area2size)
{
  int area1last = area1start+area1size-1;
  int area2last = area2start+area2size-1;

  if (area1start == area2start) return 1;

  if (area1start < area2start)
  {
    if (area1last < area2start) return 0;
    else return 1;
  }
  else
  {
    if (area2last < area1start) return 0;
    else return 1;
  }
}
