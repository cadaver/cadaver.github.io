/*
 * GOATTRACKER sound routines
 */

#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mem.h>
#include <conio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "gsid.h"
#include "goattrk.h"

#define MINSPEED 11025
#define MAXSPEED 48000
#define MAXBUFFERS 128

unsigned framerate = 50;

/*
 * HardSID stuff
 * from http://homepages.fh-giessen.de/~hg11001/
 */
void InitHardDLL(void);

HINSTANCE hardsiddll = 0;
typedef void (CALLBACK* lpWriteToHardSID)(byte DeviceID, byte SID_reg, byte data);
typedef byte (CALLBACK* lpReadFromHardSID)(byte DeviceID, byte SID_reg);
typedef void (CALLBACK* lpInitHardSID_Mapper)(void);
typedef void (CALLBACK* lpMuteHardSID_Line)(boolean mute);

lpWriteToHardSID WriteToHardSID;
lpReadFromHardSID ReadFromHardSID;
lpInitHardSID_Mapper InitHardSID_Mapper;
lpMuteHardSID_Line MuteHardSID_Line;

boolean dll_initialized = FALSE;

/* Configurable from command line */
int buffers;

int buffernum = 0;
int maxfragment;
int outsamplesize;
int bfragment;
int initted = 0;
int playspeed;
int usehardsid = 0;

char *outbuffer[MAXBUFFERS] = {NULL};
HWAVEOUT hwaveout = NULL;
WAVEHDR waveouthdr[MAXBUFFERS] = {NULL};
int outbufferprepared[MAXBUFFERS] = {0};
WAVEFORMATEX waveoutfmt;

static HANDLE snd_mixerthread = NULL;
static DWORD snd_mixerthreadid;
static int snd_mixerexit = 0;
static int writehandle = -1;

int sound_init(unsigned b, unsigned mr, unsigned writer, unsigned hardsid, unsigned m, unsigned ntsc, unsigned multiplier);
void sound_uninit(void);
static void sound_update(void);
static DWORD WINAPI snd_mixer(LPVOID parameter);
static int openwaveout(void);
static void closewaveout(void);


int sound_init(unsigned b, unsigned mr, unsigned writer, unsigned hardsid, unsigned m, unsigned ntsc, unsigned multiplier)
{
  int c;

  framerate = 50 * multiplier;
  if (ntsc) framerate = 60 * multiplier;

  if (hardsid)
  {
    InitHardDLL();
    if (dll_initialized)
    {
      usehardsid = hardsid;
      for (c = 0; c <= 0x18; c++)
      {
        sidreg[c] = 0;
        WriteToHardSID(usehardsid-1, c, 0x00);
      }
      MuteHardSID_Line(FALSE);
      goto SOUNDOK;
    }
    else
    return 0;
  }

  if (writer)
  {
    writehandle = open("sidaudio.raw", O_WRONLY | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  }
  buffers = b * multiplier;
  playspeed = mr;
  if (playspeed < MINSPEED) playspeed = MINSPEED;
  if (playspeed > MAXSPEED) playspeed = MAXSPEED;

  if (buffers < 2) buffers = 2;
  if (buffers > MAXBUFFERS) buffers = MAXBUFFERS;

  maxfragment = MAXSPEED / framerate;
  bfragment = playspeed / framerate;

  sid_init(playspeed, m, ntsc);

  for (c = 0; c < buffers; c++)
  {
    outbuffer[c] = malloc(maxfragment * sizeof(short));
    if (!outbuffer[c])
    {
      return 0;
    }
    memset(outbuffer[c], 0, maxfragment);
  }

  if (!openwaveout())
  {
    return 0;
  }

  buffernum = 0;

  SOUNDOK:
  initted = 1;
  /* Create a separate thread for mixing */

  snd_mixerexit = 0;
  snd_mixerthread = CreateThread(NULL, 0, snd_mixer, NULL, 0, &snd_mixerthreadid);
  if (!snd_mixerthread)
  {
    closewaveout();
    return 0;
  }
  SetThreadPriority(snd_mixerthread, THREAD_PRIORITY_TIME_CRITICAL);

  return 1;
}

void sound_uninit(void)
{
  int c;

  if (writehandle != -1)
  {
    close(writehandle);
    writehandle = -1;
  }

  if (!initted) return;

  /* Signal exit to mixer thread and wait for it to finish */

  if (snd_mixerthread)
  {
    snd_mixerexit = 1;

    for (;;)
    {
      DWORD exitcode;

      if (GetExitCodeThread(snd_mixerthread, &exitcode))
      {
        if (exitcode != STILL_ACTIVE) break;
      }
    }
    CloseHandle(snd_mixerthread);
    snd_mixerthread = NULL;
  }

  if (usehardsid)
  {
    for (c = 0; c <= 0x18; c++)
    {
      WriteToHardSID(usehardsid-1, c, 0x00);
    }
    MuteHardSID_Line(TRUE);
    initted = 0;
    return;
  }

  closewaveout();

  for (c = 0; c < buffers; c++)
  {
    if (outbuffer[c])
    {
      free(outbuffer[c]);
      outbuffer[c] = NULL;
    }
  }

  initted = 0;
}

static DWORD WINAPI snd_mixer(LPVOID parameter)
{
  int timecounter = 0;
  int framelength = 10000 / framerate;
  int updates;
  DWORD time;
  DWORD prevtime;

  if (!framelength) framelength = 1;

  time = timeGetTime();

  while (!snd_mixerexit)
  {
    if (!usehardsid)
    {
      sound_update();
    }
    else
    {
      int c;

      playroutine();
      for (c = 0; c <= 0x18; c++)
      {
        WriteToHardSID(usehardsid-1, c, sidreg[c]);
      }
    }

    /* Timing */
    updates = 0;
    while (!updates)
    {
      prevtime = time;
      time = timeGetTime();
      timecounter += (time - prevtime) * 10;
      updates = timecounter / framelength;
      timecounter -= updates * framelength;
      if (!updates) Sleep((framelength - timecounter)/10);
    }
  }
  return 0;
}

void sound_update(void)
{
  int workcount = 0;
  int sendcount = 0;
  int firstbuffer;
  int samples;

  if (!initted) return;

  firstbuffer = buffernum;
  while ((waveouthdr[buffernum].dwFlags & WHDR_DONE) && (workcount < buffers))
  {
    if (outbufferprepared[buffernum])
    {
      waveOutUnprepareHeader(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
      outbufferprepared[buffernum] = 0;
    }
    playroutine();
    sid_dumpregs();
    samples = sid_fillbuffer((short *)waveouthdr[buffernum].lpData, bfragment);
    if (writehandle != -1)
    {
      write(writehandle, waveouthdr[buffernum].lpData, samples * outsamplesize);
    }
    waveouthdr[buffernum].dwBufferLength = samples * outsamplesize;
    workcount++;
    buffernum++;
    buffernum %= buffers;
  }

  buffernum = firstbuffer;
  while (sendcount < workcount)
  {
    waveouthdr[buffernum].dwFlags = 0;
    waveOutPrepareHeader(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
    outbufferprepared[buffernum] = 1;

    waveOutWrite(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
    sendcount++;
    buffernum++;
    buffernum %= buffers;
  }
}

static int openwaveout(void)
{
  int c;

  closewaveout();

  outsamplesize = 2;
  waveoutfmt.wFormatTag = WAVE_FORMAT_PCM;
  waveoutfmt.nChannels = 1;
  waveoutfmt.wBitsPerSample = 16;
  waveoutfmt.nSamplesPerSec = playspeed;
  waveoutfmt.nAvgBytesPerSec = outsamplesize * playspeed;
  waveoutfmt.nBlockAlign = outsamplesize;
  if (waveOutOpen(&hwaveout, WAVE_MAPPER, &waveoutfmt, NULL, NULL, CALLBACK_NULL | WAVE_ALLOWSYNC) != MMSYSERR_NOERROR) return 0;

  /* Set up waveout buffers */
  for (c = 0; c < buffers; c++)
  {
    waveouthdr[c].lpData = outbuffer[c];
    waveouthdr[c].dwBufferLength = bfragment * outsamplesize;
    waveouthdr[c].dwFlags = WHDR_DONE;
    waveouthdr[c].dwLoops = 0;
  }
  return 1;
}

static void closewaveout(void)
{
  int c;

  if (hwaveout)
  {
    waveOutReset(hwaveout);
    for (c = 0; c < MAXBUFFERS; c++)
    {
      if (outbufferprepared[c])
      {
        waveOutUnprepareHeader(hwaveout, &waveouthdr[c], sizeof(WAVEHDR));
        outbufferprepared[c] = 0;
      }
    }
    waveOutClose(hwaveout);
    hwaveout = NULL;
  }
}

// Intializing the DLL
void InitHardDLL()
{
      if (!(hardsiddll=LoadLibrary("HARDSID.DLL"))) return;

      WriteToHardSID = (lpWriteToHardSID) GetProcAddress(hardsiddll, "WriteToHardSID");
      ReadFromHardSID = (lpReadFromHardSID) GetProcAddress(hardsiddll, "ReadFromHardSID");
      InitHardSID_Mapper = (lpInitHardSID_Mapper) GetProcAddress(hardsiddll, "InitHardSID_Mapper");
      MuteHardSID_Line = (lpMuteHardSID_Line) GetProcAddress(hardsiddll, "MuteHardSID_Line");

      if (!WriteToHardSID) return;
  
      InitHardSID_Mapper(); 
      dll_initialized = TRUE;
}


