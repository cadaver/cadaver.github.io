/*---------------------------------
    SidDasm v. 1.0
    (poorly) coded by Gufino, 2003
    Hiya guyz, Gufine here:
    this is the source code for SidDasm 1.0
    Have fun with it, and if you improve
    or modify something please send me a copy of the
    modified source at bugsman@libero.it .
    See ya!
-----------------------------------*/
#include<errno.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<malloc.h>
// Header of a Psid file
struct Psid_header{
       char head[4];
       unsigned int version;
       unsigned int dataOffset;
       unsigned int loadAddr;
       unsigned int initAddr;
       unsigned int playAddr;
       unsigned int songs;
       unsigned int startSong;
       unsigned long speed;
       char name[32];
       char author[32];
       char copyright[32];
       unsigned int flags;
       unsigned long reserved;
} sid;
FILE *fptr=0,*dptr=0,*aptr=0,*tptr=0;
//Code Dumping vars
unsigned char error=0;
unsigned char decode_mode=0;
unsigned char block_end=0;
unsigned int written=0;
unsigned int di=0,cur_section=0;
unsigned int j_to_do=0,j_ind=0,s_ins=0,e_ins=0;
unsigned int starts[512];
unsigned int ends2[512];
unsigned int app_offs[512];
//End of Code Dumping vars
unsigned int code_loc=0;
char nomefile[256],nomefile2[256],nomefile3[256];
unsigned int i=0;
unsigned long length=0,file_pos=0,data_length=0;
unsigned char opcode1=0,byte_param=0;
unsigned int word_param=0,pos=0,op_pos=0,app_pos=0;
unsigned char *c64mem=0; //This one emulates c64 mem
unsigned char *c64mem2=0;// This one is used to mark instruction bytes

// This procedure is called when an error occours
// and frees memory and file pointers
int exit_error(char *message){
	printf("%s",message);
	if(fptr!=NULL)
		fclose(fptr);
	if(dptr!=NULL)
		fclose(dptr);
	if(tptr!=NULL)
		fclose(tptr);
	if(c64mem!=NULL)
		free(c64mem);
	if(c64mem2!=NULL)
		free(c64mem);
	exit(1);
	return(0);
}
//This procedure reads an opcode from c64 memory and
//if in decode mode it marks the opcode location as checked
unsigned char read_opcode()
{
    unsigned char byteop=0;
    if(decode_mode)
	c64mem2[pos]=1;
    byteop=(unsigned char)c64mem[pos];
    pos++;
    return(byteop);
}
//This procedure reads 1 byte of data from c64 mem and
//if in decode mode marks its position as checked
unsigned char read_byte_param()
{
    unsigned char bytepar=0;
    if(decode_mode)
	c64mem2[pos]=1;
    bytepar=(unsigned char)c64mem[pos];
    pos++;
    return(bytepar);
}
//This procedure reads 2 bytes of data from c64 mem and
//if in decode mode marks its position as checked
unsigned int read_word_param()
{
    unsigned int wordpar=0;
    if(decode_mode){
	c64mem2[pos]=1;
	c64mem2[pos+1]=1;
    }
    wordpar=(unsigned char)c64mem[pos];
    pos ++;
    wordpar=wordpar+((unsigned char)c64mem[pos])*256;
    pos++;
    return(wordpar);
}
//This procedure decodes the opcode, prints the result and when it
//meets some particular instructions it sets the next ASM block to check.
//It is just a big switch (very slow). I will turn it in a full
//byte decoder ASAP
void decode_opcode(unsigned char opcode)
{
	switch(opcode)
	  {
	      //ADC opcodes
	      case 0x69: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ADC #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x65: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ADC $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x75: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ADC $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x6D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ADC $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x7D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ADC $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x79: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ADC $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x61: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ADC ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x71: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ADC ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //AND opcodes
	      case 0x29: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :AND #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x25: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :AND $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x35: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :AND $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x2D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :AND $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x3D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :AND $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0x39: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :AND $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x21: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :AND ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x31: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :AND ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //ASL opcodes
	      case 0x0A: fprintf(dptr,"%4.4X: %2.2X       :ASL A\n",op_pos,opcode);
			 break;
	      case 0x06: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ASL $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x16: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ASL $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x1E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ASL $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x0E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ASL $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //BCC opcode
	      case 0x90: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BCC $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //BCS opcode
	      case 0xB0: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BCS $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //BEQ opcode
	      case 0xF0: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BEQ $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }

			 break;
	      //BIT opcodes
	      case 0x24: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BIT $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x2C: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :BIT $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //BMI opcode
	      case 0x30: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BMI $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //BNE opcode
	      case 0xD0: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BNE $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //BPL opcode
	      case 0x10: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BPL $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //BRK opcode
	      case 0x00: fprintf(dptr,"%4.4X: %2.2X       :BRK\n",op_pos,opcode);
			 break;
	      //BVC opcode
	      case 0x50: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BVC $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //BVS opcode
	      case 0x70: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :BVS $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 if(decode_mode){
				if(byte_param>0x7f)
					app_pos=pos+byte_param-0x0100;
				else
					app_pos=pos+byte_param;
				if(c64mem2[app_pos]==0){
					starts[s_ins]=app_pos;
					s_ins++;
					j_to_do++;
					c64mem2[app_pos]=1;
				}
			 }
			 break;
	      //CLC opcode
	      case 0x18: fprintf(dptr,"%4.4X: %2.2X       :CLC\n",op_pos,opcode);
			 break;
	      //CLD opcode
	      case 0xD8: fprintf(dptr,"%4.4X: %2.2X       :CLD\n",op_pos,opcode);
			 break;
	      //CLI opcode
	      case 0x58: fprintf(dptr,"%4.4X: %2.2X       :CLI\n",op_pos,opcode);
			 break;
	      //CLV opcode
	      case 0xB8: fprintf(dptr,"%4.4X: %2.2X       :CLV\n",op_pos,opcode);
			 break;
	      //CMP opcodes
	      case 0xC9: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CMP #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xC5: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CMP $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xC1: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CMP ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xD5: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CMP $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;

	      case 0xD1: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CMP ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xCD: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :CMP $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xDD: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :CMP $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0xD9: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :CMP $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //CPX opcodes
	      case 0xE0: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CPX #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xE4: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CPX $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xEC: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :CPX $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //CPY opcodes
	      case 0xC0: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CPY #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xC4: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :CPY $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xCC: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :CPY $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //DEC opcodes
	      case 0xC6: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :DEC %2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xD6: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :DEC $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xCE: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :DEC $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xDE: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :DEC $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //DEX opcode
	      case 0xCA: fprintf(dptr,"%4.4X: %2.2X       :DEX\n",op_pos,opcode);
			 break;
	      //DEY opcode
	      case 0x88: fprintf(dptr,"%4.4X: %2.2X       :DEY\n",op_pos,opcode);
			 break;
	      //EOR opcodes
	      case 0x49: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :EOR #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x45: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :EOR $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x55: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :EOR $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x4D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :EOR $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x5D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :EOR $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0x59: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :EOR $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x41: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :EOR ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x51: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :EOR ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //INC opcodes
	      case 0xE6: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :INC %2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xF6: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :INC $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xEE: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :INC $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xFE: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :INC $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //INX opcode
	      case 0xE8: fprintf(dptr,"%4.4X: %2.2X       :INX\n",op_pos,opcode);
			 break;
	      //DEY opcode
	      case 0xC8: fprintf(dptr,"%4.4X: %2.2X       :INY\n",op_pos,opcode);
			 break;
	      //JMP opcode
	      case 0x4C: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :JMP $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 if((decode_mode)&&(c64mem2[word_param]==0)){
				ends2[e_ins]=pos;
				starts[s_ins]=word_param;
				e_ins++;
				s_ins++;
				j_to_do++;
				block_end=1;
			 }
			 break;
	      case 0x6C: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :JMP ($%4.4X)\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 if(decode_mode){
			 fprintf(dptr,"JMP defined at run-time: possibly incorrect code dumping!\n");
			 printf("Found a JMP instruction defined at run-time: possibly incorrect code dumping!\n");
			 error=1;
			 }
			 break;
	      //JSR opcode
	      case 0x20: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :JSR $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 if((decode_mode)&&(c64mem2[word_param]==0)){
				starts[s_ins]=word_param;
				s_ins++;
				j_to_do++;
				c64mem2[word_param]=1;
			 }
			 break;
	      //LDA opcodes
	      case 0xA9: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDA #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xA5: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDA $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xB5: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDA $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xAD: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDA $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xBD: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDA $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0xB9: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDA $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xA1: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDA ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xB1: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDA ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //LDX opcodes
	      case 0xA2: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDX #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xA6: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDX $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xB6: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDX $%2.2X,Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xAE: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDX $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xBE: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDX $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //LDY opcodes
	      case 0xA0: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDY #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xA4: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDY $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xB4: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LDY $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xAC: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDY $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xBC: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LDY $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //LSR opcodes
	      case 0x4A: fprintf(dptr,"%4.4X: %2.2X       :LSR A\n",op_pos,opcode);
			 break;
	      case 0x46: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LSR $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x56: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :LSR $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x4E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LSR $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x5E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :LSR $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //NOP opcode
	      case 0xEA: fprintf(dptr,"%4.4X: %2.2X       :NOP\n",op_pos,opcode);
			 break;
	      //ORA opcodes
	      case 0x09: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ORA #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x05: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ORA $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x15: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ORA $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x0D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ORA $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x1D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ORA $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0x19: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ORA $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x01: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ORA ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x11: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ORA ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //PHA opcode
	      case 0x48: fprintf(dptr,"%4.4X: %2.2X       :PHA\n",op_pos,opcode);
			 break;
	      //PHP opcode
	      case 0x08: fprintf(dptr,"%4.4X: %2.2X       :PHP\n",op_pos,opcode);
			 break;
	      //PLA opcode
	      case 0x68: fprintf(dptr,"%4.4X: %2.2X       :PLA\n",op_pos,opcode);
			 break;
	      //PLP opcode
	      case 0x28: fprintf(dptr,"%4.4X: %2.2X       :PLP\n",op_pos,opcode);
			 break;
	      //ROL opcodes
	      case 0x2A: fprintf(dptr,"%4.4X: %2.2X       :ROL A\n",op_pos,opcode);
			 break;
	      case 0x26: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ROL $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x36: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ROL $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x2E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ROL $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x3E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ROL $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //ROR opcodes
	      case 0x6A: fprintf(dptr,"%4.4X: %2.2X       :ROR A\n",op_pos,opcode);
			 break;
	      case 0x66: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ROR $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x76: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :ROR $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x6E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ROR $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x7E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :ROR $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //RTI opcode
	      case 0x40: fprintf(dptr,"%4.4X: %2.2X       :RTI\n",op_pos,opcode);
			 break;
	      //RTS opcode
	      case 0x60: fprintf(dptr,"%4.4X: %2.2X       :RTS\n",op_pos,opcode);
			 if(decode_mode){
				ends2[e_ins]=pos;
				e_ins++;
				block_end=1;
			 }
			 break;
	      //SBC opcodes
	      case 0xE9: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :SBC #$%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xE5: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :SBC $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xF5: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :SBC $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xED: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :SBC $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xFD: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :SBC $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0xF9: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :SBC $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0xE1: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :SBC ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0xF1: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :SBC ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //SEC opcode
	      case 0x38: fprintf(dptr,"%4.4X: %2.2X       :SEC\n",op_pos,opcode);
			 break;
	      //SED opcode
	      case 0xF8: fprintf(dptr,"%4.4X: %2.2X       :SED\n",op_pos,opcode);
			 break;
	      //SEI opcode
	      case 0x78: fprintf(dptr,"%4.4X: %2.2X       :SEI\n",op_pos,opcode);
			 break;
	      //STA opcode
	      case 0x85: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STA $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x95: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STA $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x8D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :STA $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x9D: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :STA $%4.4X,X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;

	      case 0x99: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :STA $%4.4X,Y\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      case 0x81: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STA ($%2.2X,X)\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x91: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STA ($%2.2X),Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      //STX opcode
	      case 0x86: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STX $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x96: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STX $%2.2X,Y\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x8E: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :STX $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //STY opcode
	      case 0x84: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STY $%2.2X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x94: byte_param=read_byte_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X    :STY $%2.2X,X\n",op_pos,opcode,byte_param,byte_param);
			 break;
	      case 0x8C: word_param=read_word_param();
			 fprintf(dptr,"%4.4X: %2.2X %2.2X %2.2X :STY $%4.4X\n",op_pos,opcode,word_param%256,word_param/256,word_param);
			 break;
	      //TAX opcode
	      case 0xAA: fprintf(dptr,"%4.4X: %2.2X       :TAX\n",op_pos,opcode);
			 break;
	      //TAY opcode
	      case 0xA8: fprintf(dptr,"%4.4X: %2.2X       :TAY\n",op_pos,opcode);
			 break;
	      //TSX opcode
	      case 0xBA: fprintf(dptr,"%4.4X: %2.2X       :TSX\n",op_pos,opcode);
			 break;
	      //TXA opcode
	      case 0x8A: fprintf(dptr,"%4.4X: %2.2X       :TXA\n",op_pos,opcode);
			 break;
	      //TXS opcode
	      case 0x9A: fprintf(dptr,"%4.4X: %2.2X       :TXS\n",op_pos,opcode);
			 break;
	      //TYA opcode
	      case 0x98: fprintf(dptr,"%4.4X: %2.2X       :TYA\n",op_pos,opcode);
			 break;
			    //BMI opcode
	      default:   fprintf(dptr,"%4.4X: %2.2X        :Illegal opcode\n",op_pos,opcode);
			 break;
	  }
}
//This procedure writes lines to the output file
//Note: it is called fill screen 'coz it is a modified
//version of a proc I used to dump data on screen and
//I was too lazy to change the proc name. Sorry :)
void fill_screen(unsigned int start_addr)
{
      length=length+start_addr;
      pos=start_addr;
      printf("Start at: $%4X; End at: $%4X; ",pos,length-1);
      printf("Length: %d bytes;\n",(length-pos));
      do{
	  if(c64mem2[pos]==1){
	  if(written!=0){
		fprintf(dptr,"\n-------\n");
		written=0;
	  }
	  op_pos=pos;
	  opcode1=read_opcode();
	  decode_opcode(opcode1);
	  }
	  else
	  {
		if(written==0)
			fprintf(dptr,"-------\n");
		op_pos=pos;
		if(written==4){
			fprintf(dptr,"\n");
			written=0;
		}
		if(written==0)
			fprintf(dptr,"%4.4X: %2.2X ",op_pos,read_opcode());
		else
			fprintf(dptr,"%2.2X ",read_opcode());
		written++;
	  }
      }while(pos<length);
}
//This procedure crawls through code and separate instruction from
//data marking them in c64mem2. Marking is also useful to avoid infinite
//loops caused by some branches, jmp and rts
void dump_code(){
	for(di=0;di<512;di++){
		starts[di]=0;
		ends2[di]=0;
		app_offs[di]=0;
	}
	decode_mode=1;
	block_end=0;
	if(sid.initAddr==sid.playAddr){
		j_to_do=1;
		starts[0]=sid.initAddr;
		s_ins=1;
	}
	else
	{
		j_to_do=2;
		starts[0]=sid.initAddr;
		starts[1]=sid.playAddr;
		s_ins=2;
	}
	j_ind=0;
	do{
		pos=starts[j_ind];
		block_end=0;
		cur_section=pos;
		do{
			op_pos=pos;
			decode_opcode(read_opcode());
			if((e_ins>512)||(s_ins>512)){
				error=1;
				block_end=1;
				j_to_do=1;
			}
		}while(block_end==0);
		j_ind++;
		j_to_do--;
		fprintf(dptr,"----------\n");
	}while(j_to_do!=0);
    decode_mode=0;
    if(error!=0)
	exit_error("Critical Error: too much jumps!\nDumping Aborted! Bye...\n");
}
//Simple proc to detect file length
unsigned long file_length(FILE *point)
{
    unsigned long lungaz=0;
    fseek(point,0,SEEK_END);
    lungaz=ftell(point);
    fseek(point,0,SEEK_SET);
    return(lungaz);
}
//This proc turns 2 Big-endian bytes into 2 Little-endian bytes.
//I guess all this mess with Big Endian comes from Amiga architecture :)
unsigned int ba2la(unsigned int argum)
{
	 unsigned char app=0;
	 app=argum%256;
	 argum=argum/256;
	 argum=argum+(app*256);
	 return(argum);
}
//This one sets data into header changing B.Endian to L.Endian
struct Psid_header setHead(struct Psid_header header)
{
       header.version=ba2la(header.version);
       header.dataOffset=ba2la(header.dataOffset);
       header.loadAddr=ba2la(header.loadAddr);
       header.initAddr=ba2la(header.initAddr);
       header.playAddr=ba2la(header.playAddr);

       return(header);
}
//This proc extract PSID header from source file
void readPsidHeader(FILE *fptr2)
{
      struct Psid_header header_1;
      fseek(fptr2,0,SEEK_SET);
      fread(&sid.head,4,1,fptr2);
      fread(&sid.version,2,1,fptr2);
      fread(&sid.dataOffset,2,1,fptr2);
      fread(&sid.loadAddr,2,1,fptr2);
      fread(&sid.initAddr,2,1,fptr2);
      fread(&sid.playAddr,2,1,fptr2);
      fread(&sid.songs,2,1,fptr2);
      fread(&sid.startSong,2,1,fptr2);
      fread(&sid.speed,4,1,fptr2);
      fread(&sid.name,32,1,fptr2);
      fread(&sid.author,32,1,fptr2);
      fread(&sid.copyright,32,1,fptr2);
      if(sid.version==0x0200)
      {
	  fread(&sid.flags,2,1,fptr2);
	  fread(&sid.reserved,4,1,fptr2);
      }
}
//Simple proc to check if source file is a correct PSID file
void checkHeader()
{
     if((sid.head[0]!='P')||(sid.head[1]!='S')||(sid.head[2]!='I')||(sid.head[3]!='D'))
	 exit_error("Not a PSID file!!!\n");

     if(sid.songs<1)
	 exit_error("Invalid numbero fo songs!!!\n");

     if((sid.startSong<1)||(sid.startSong>sid.songs))
	 exit_error("Invalid starting song");
}
//Main procedure. Nothing more than opening files and calling previous
//procedures to achieve the tasks needed.
int main(int argc, char *argv[])
{
      if(argc<2){
	printf("Usage: siddasm filename-of-SID-file\n");
	exit(1);
      }
      printf("Gufino's SID disassembler version 1.0 --- GufoSoft 2003\n");

      strncpy(nomefile,argv[1],252);
      nomefile[252]=0;
      fptr=fopen(nomefile,"rb");
      if(fptr==NULL)
      {
	  printf("Unable to open input file %s!!!\n",nomefile);
	  exit(1);
      }
      length=file_length(fptr);
      readPsidHeader(fptr);
      sid=setHead(sid);
      checkHeader();
      length=length-sid.dataOffset;
      if(sid.loadAddr==0)
      {
	  fread(&code_loc,2,1,fptr);
	  sid.loadAddr=code_loc;
      }
      else
	  code_loc=sid.loadAddr;
      data_length=length+sid.loadAddr;
      c64mem=(unsigned char *)malloc(data_length);
      c64mem2=(unsigned char *)malloc(data_length);
      if((c64mem==0)||(c64mem2==0))
	  exit_error("Error: Not enough memory");
      memset(c64mem,0,data_length);
      memset(c64mem2,0,data_length);
      fread(c64mem+sid.loadAddr,1,length,fptr);
      fclose(fptr);
      strncpy(nomefile2,nomefile,256);
      i=0;
      while(nomefile2[i]!=0)
	i++;
      nomefile2[i]='.';
      nomefile2[i+1]='c';
      nomefile2[i+2]='a';
      nomefile2[i+3]='s';
      printf("Writing 6510 ASM source for %s into %s\n",nomefile,nomefile2);
      dptr=fopen(nomefile2,"wb");
      if(dptr==NULL)
	exit_error("Unable to create output file!\n");
      strncpy(nomefile3,nomefile2,256);
      nomefile3[i+3]='t';
      tptr=fopen(nomefile3,"wb");
      if(tptr==NULL)
       exit_error("Unable to create temp file!\n");
      length=length-2;
      if(length>65535){
	fclose(fptr);
	fclose(dptr);
	fclose(tptr);
	if(c64mem!=NULL)
		free(c64mem);
	if(c64mem2!=NULL)
		free(c64mem2);
	exit_error("File too big for C64 memory. Cannot disassemble it\n");
      }
      fprintf(dptr,"#ASM source for file %s\n",nomefile);
      fprintf(dptr,"#Init addr: $%4X, Play addr: $%4X\n",sid.initAddr,sid.playAddr);
      fprintf(dptr,"#Load addr: $%4X, End addr: $%4X, ",sid.loadAddr,(sid.loadAddr+length-1));
      fprintf(dptr,"Length: %d bytes\n",length);
      fprintf(dptr,"#----------------------------------------------------------------\n");
      aptr=dptr;
      dptr=tptr;
      dump_code();
      fclose(tptr);
      if(unlink(nomefile3)!=0){
	printf("Error deleting temporary file %s\n",nomefile3);
	printf("Please delete it by hand if it still exist...\n");
      }
      dptr=aptr;
      fill_screen(sid.loadAddr);
      printf("For any comment, suggestion or bugs report, mail me at: bugsman@libero.it\n");
      printf("Version 1.1 will be released soon, don't miss it!\n");
      printf("Thank you for using Siddasm!!!\n");
      fclose(dptr);
      free(c64mem);
      free(c64mem2);
      return(0);
}
