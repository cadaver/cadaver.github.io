//
// BME (Blasphemous Multimedia Engine) main module
//

#include "bme_err.h"
#include "bme_cfg.h"

int bme_error = BME_OK;
