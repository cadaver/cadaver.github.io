Notes for NinjaTracker V1.02 gamemusic version
----------------------------------------------

Has added sound effect capability. Octave 0 has been removed from the
playroutine to conserve memory.

Sound effects can be made with GoatTracker and converted with the included
INS2SND utility. Note: this utility is not the same that comes with GT!


Sound effect data format
------------------------

Offset  Meaning
0       Pulsewidth, nybbles reversed
1       Attack/Decay
2       Sustain/Release
3-n     Notes & Waves

A note has the byte range $8C-$DF (C-1 - B-7). To also change waveform on the
same frame, a byte in the range $01-$81 must follow the note. Byte $00 ends
the sound effect.

Example:
$08, $00, $C9 ;Pulsewidth 80, Attack/Decay 00, Sustain/Release C9
$C8, $81      ;Note + Waveform
$B0, $41      ;  --||--
$A8           ;Note only
$C4, $80      ;Note + Waveform
$C2           ;Note only
$C0           ;  --||--
$BE           ;  --||--
$BC           ;  --||--
$BA           ;  --||--
$00           ;End sound effect

Do not use maximum sustain or release ($F) or the ADSR will bug!


Playroutine functions
---------------------

Initialize song:     LDA #songnumber+1
                     STA <baseadr+$1>

Initialize effect:   LDA #$01
                     LDX #<effect
                     LDY #>effect

                     Channel 1           Channel 2           Channel 3
                     STX <baseadr+$2b0>  STX <baseadr+$2b7>  STX <baseadr+$2be>
                     STY <baseadr+$2b1>  STY <baseadr+$2b8>  STY <baseadr+$2bf>
                     STA <baseadr+$2af>  STA <baseadr+$2b6>  STA <baseadr+$2bd>

                     As the write of value #$01 actually triggers the sound,
                     the sound pointer must have been written first (in case
                     an interrupt comes between the writes.)

Play one frame:      JSR <baseadr>
