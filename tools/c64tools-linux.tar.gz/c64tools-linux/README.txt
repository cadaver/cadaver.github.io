original C64tools by Cadaver https://cadaver.github.io/tools.html

Compiled for gnu/Linux by Diego Accorinti 2018
