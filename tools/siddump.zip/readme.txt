SIDDump V1.06
by Cadaver (loorni@gmail.com) and Stein Pedersen

Version history:

V1.0    - Original
V1.01   - Fixed BIT instruction
V1.02   - Added incomplete illegal opcode support, enough for John Player
V1.03   - Some CPU bugs fixed
V1.04   - Improved command line handling, added illegal NOP instructions, fixed
          illegal LAX to work again
V1.05   - Partial support for multispeed tunes
V1.06   - Added CPU cycle profiling functionality by Stein Pedersen

