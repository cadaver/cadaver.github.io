These are commandline utilities especially in use for MW4.

INS2NT - convert GoatTracker instrument to NinjaTracker playroutine sound effect
OBJREQ - Print out object requirements in a level (debugging util)
SCRVIEW - Print out scripted objects in a level (debugging util)
SPRCONV - Converts SPREDIT2 sprites to format usable by MW4 new engine
SPRCONV2 - Converts the packed "weapon sprites" to format usable by MW4 new engine
TRUNCATE - Truncate a binary datafile to arbitrary length

