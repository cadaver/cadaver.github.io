#include <stdio.h>
#include <stdlib.h>

FILE *in;
FILE *out;
int c, s;

int main(int argc, char **argv)
{
        in = fopen("map16.bin", "rb");
        out = fopen("level16.map", "wb");

        if (!in) return 666;
        if (!out) return 666;

        for (s = 0; s < 2; s++) fgetc(in);       /* Discard start address */
        for (s = 0; s < 5*128; s++) fgetc(in);       /* Discard enemy info */
        for (;;)
        {
                c = fgetc(in);
                if (c == EOF) break;
                fputc(c, out);
        }
        fclose(in);
        fclose(out);

        in = fopen("blocks16.bin", "rb");
        out = fopen("level16.inf", "wb");

        if (!in) return 666;
        if (!out) return 666;

        for (s = 0; s < 2; s++) fgetc(in);       /* Discard start address */
        for (s = 0; s < 512; s++)
        {
                c = fgetc(in);
                fputc(c, out);
        }
        fclose(out);

        out = fopen("level16.blk", "wb");

        if (!out) return 666;

        for (s = 0; s < 192*16; s++)
        {
                c = fgetc(in);
                fputc(c, out);
        }
        fclose(out);

        out = fopen("level16.chr", "wb");

        if (!out) return 666;

        for (s = 0; s < 2048; s++)
        {
                c = fgetc(in);
                fputc(c, out);
        }
        fclose(out);

        fclose(in);
        return 0;
}

