#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

char buffer[16384];

int main(int argc, char **argv)
{
        int in, out;
        int c = 0;
        int d, e;

        if (argc < 3) return 666;

        in = open(argv[1], O_RDONLY | O_BINARY);
        if (in == -1) return 666;
        out = open(argv[2], O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        if (out == -1)
        {
                close(in);
                return 666;
        }
        for (;;)
        {
                int bytes = read(in, &buffer[c*64], 64);
                if (!bytes) break;
                c++;
        }
        for (d = 0; d < 30; d++)
        {
                for (e = 0; e < c; e++)
                {
                        write(out, &buffer[e*64+18+d], 1);
                }
        }
        for (e = 0; e < c; e++)
        {
                write(out, &buffer[e*64+63], 1);
        }
        printf("%d sprites processed.\n", c);
        close(in);
        close(out);
        return 0;
}
