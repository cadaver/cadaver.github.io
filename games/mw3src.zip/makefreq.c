#include <stdio.h>
#include <math.h>

int f[8*12];
int basefreq;

int main(int argc, char **argv)
{
    int c;

    if (argc < 2)
    {
        printf("No basefrequency given!\n");
        return 1;
    }

    sscanf(argv[1], "%d", &basefreq);

    for (c = 0; c < 8*12 ; c++)
    {
        double note = c;
        double freq = (double)basefreq * pow(2.0, note/12.0);
        f[c] = freq;
                if ((f[c]/256) > 0xff) f[c] = 0xffff;
    }

    printf("freqtbllo:      dc.b ");
    for (c = 0; c < 8*12; c++)
    {
        printf("$%02x", f[c]%256);
        if ((c) && (c < 95) && (!((c+1) % 12))) printf("\n                dc.b ");
        else if (c < 95) printf(",");
    }
    printf("\n\n");

    printf("freqtblhi:      dc.b ");
    for (c = 0; c < 8*12; c++)
    {
        printf("$%02x", f[c]/256);
        if ((c) && (c < 95) && (!((c+1) % 12))) printf("\n                dc.b ");
        else if (c < 95) printf(",");
    }
    return 0;
}
