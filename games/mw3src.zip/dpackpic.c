#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
        int c;
        char buffer[256];
        int k;
        FILE *in;
        FILE *out;

        if (argc < 3)
        {
                printf("Usage: dpackpic <src> <dest>\n");
                return 1;
        }

        in = fopen(argv[1], "rb");
        if (!in)
        {
                printf("Inputfile open error\n");
                return 2;
        }
        out = fopen(argv[2], "wb");
        if (!out)
        {
                printf("outputfile open error\n");
                return 2;
        }

        for (;;)
        {
                k = fgetc(in);
                if (k == EOF) break;

                if (k < 128)
                {
                        for (c = 0; c <= k; c++)
                        {
                                int d = fgetc(in);
                                fputc(d, out);
                        }
                }
                else
                {
                        int d = fgetc(in);
                        k -= 128;
                        for (c = 0; c <= k; c++)
                        {
                                fputc(d, out);
                        }
                }
        }
        fclose(in);
        fclose(out);
        return 0;
}
