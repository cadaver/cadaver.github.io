#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
        int c;
        unsigned char buffer[256];
        int length;
        int rlemode;
        int k;
        FILE *in;
        FILE *out;

        if (argc < 3)
        {
                printf("Usage: packpic <src> <dest>\n");
                return 1;
        }

        in = fopen(argv[1], "rb");
        if (!in)
        {
                printf("Inputfile open error\n");
                return 2;
        }
        out = fopen(argv[2], "wb");
        if (!out)
        {
                printf("outputfile open error\n");
                return 2;
        }

        rlemode = 0;
        length = 0;

        for (;;)
        {
                if (rlemode)
                {
                        if (length >= 128)
                        {
                                fputc(128+length-1, out);
                                fputc(buffer[length-1], out);
                                length = 0;
                        }

                        k = fgetc(in);
                        if (k == EOF)
                        {
                                if (length)
                                {
                                        fputc(128+length-1, out);
                                        fputc(buffer[length-1], out);
                                }
                                break;
                        }

                        if (length)
                        {
                                if (buffer[length-1] != k)
                                {
                                        rlemode = 0;

                                        if (length > 2)
                                        {
                                                fputc(128+length-1, out);
                                                fputc(buffer[length-1], out);
                                                length = 0;
                                                buffer[length] = k;
                                                length++;
                                        }
                                        else
                                        {
                                                buffer[length] = k;
                                                length++;
                                        }
                                }
                                else
                                {
                                        buffer[length] = k;
                                        length++;
                                }
                        }
                        else
                        {
                                buffer[length] = k;
                                length++;
                        }
                }
                else
                {
                        if (length >= 128)
                        {
                                fputc(length-1, out);
                                for (c = 0; c < length; c++)
                                {
                                        fputc(buffer[c], out);
                                }
                                length = 0;
                        }

                        k = fgetc(in);
                        if (k == EOF)
                        {
                                if (length)
                                {
                                        fputc(length-1, out);
                                        for (c = 0; c < length; c++)
                                        {
                                                fputc(buffer[c], out);
                                        }
                                }
                                break;
                        }

                        if (length > 1)
                        {
                                if ((buffer[length-1] == k) && (buffer[length-2] == k))
                                {
                                        rlemode = 1;

                                        if ((length-2) > 0)
                                        {
                                                fputc(length-3, out);
                                                for (c = 0; c < length-2; c++)
                                                {
                                                        fputc(buffer[c], out);
                                                }
                                                length = 0;
                                                buffer[length] = k;
                                                length++;
                                                buffer[length] = k;
                                                length++;
                                                buffer[length] = k;
                                                length++;
                                        }
                                        else
                                        {
                                                buffer[length] = k;
                                                length++;
                                        }
                                }
                                else
                                {
                                        buffer[length] = k;
                                        length++;
                                }
                        }
                        else
                        {
                                buffer[length] = k;
                                length++;
                        }
                }
        }
        fclose(in);
        fclose(out);
        return 0;
}
