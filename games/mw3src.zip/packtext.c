#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXWORDS 4096
#define MAXLINES 1024
#define LABELLENGTH 32
#define WORDLENGTH 32
#define MAXSORTEDWORDS 160

FILE *in, *out;
int quotes = 0;
int numlabels = 0;
int numwords = 0;
int totalwords = 0;
int sortedwords = 0;

char inbuffer[160];
char wordbuffer[WORDLENGTH];
char label[MAXLINES][LABELLENGTH];
char word[MAXWORDS][WORDLENGTH];
char sortedword[MAXSORTEDWORDS][WORDLENGTH];
int worduse[MAXWORDS];

int main(int argc, char **argv);
void compareword(void);
void storeword(void);

void compareword(void)
{
        int c;

        if (!strlen(wordbuffer)) return;

        totalwords++;
        strupr(wordbuffer);

        if (strlen(wordbuffer) == 1)
        {
                memset(wordbuffer, 0, sizeof(wordbuffer));
                return;
        }

        for (c = 0; c < numwords; c++)
        {
                if (!strcmp(word[c], wordbuffer))
                {
                        worduse[c]++;
                        memset(wordbuffer, 0, sizeof(wordbuffer));
                        return;
                }
        }
        strcpy(word[numwords], wordbuffer);
        worduse[numwords]++;
        numwords++;
        memset(wordbuffer, 0, sizeof(wordbuffer));
}

void storeword(void)
{
        int c;

        if (!strlen(wordbuffer)) return;

        strupr(wordbuffer);

        for (c = 0; c < sortedwords; c++)
        {
                if (!strcmp(sortedword[c], wordbuffer))
                {
                        fprintf(out, "\",%d,\"", 256-MAXSORTEDWORDS+c);
                        memset(wordbuffer, 0, sizeof(wordbuffer));
                        return;
                }
        }
        fprintf(out,"%s",wordbuffer);
        memset(wordbuffer, 0, sizeof(wordbuffer));
}

int main(int argc, char **argv)
{
        int c;

        memset(word, 0, sizeof word);
        memset(worduse, 0, sizeof worduse);
        memset(label, 0, sizeof label);

        if (argc < 3)
        {
                printf("Usage: textpack <src> <dest>\n");
                return 1;
        }

        in = fopen(argv[1], "rt");
        if (!in)
        {
                printf("Inputfile open error\n");
                return 2;
        }

        for (;;)
        {
                quotes = 0;
                if (!fgets(inbuffer, sizeof(inbuffer), in)) break;
                for (c = 0; c < strlen(inbuffer); c++)
                {
                        if (inbuffer[c] == ':')
                        {
                                inbuffer[c] = 0;
                                strcpy(label[numlabels], inbuffer);
                                inbuffer[c] = ':';

                                numlabels++;
                                c++;
                                memset(wordbuffer, 0, sizeof(wordbuffer));
                                for (; c < strlen(inbuffer); c++)
                                {
                                        if (inbuffer[c] == 34)
                                        {
                                                quotes ^= 1;
                                                if (!quotes)
                                                {
                                                        compareword();
                                                }
                                        }
                                        else
                                        {
                                                if (quotes)
                                                {
                                                        if (inbuffer[c] == '+')
                                                        {
                                                                compareword();
                                                                c++;
                                                        }
                                                        if ((inbuffer[c] != ',') && (inbuffer[c] != 39) && (inbuffer[c] != '.') && (inbuffer[c] != ' ') && (inbuffer[c] != '?') && (inbuffer[c] != '-') && (inbuffer[c] != '!') && (inbuffer[c] != ':'))
                                                        {
                                                                wordbuffer[strlen(wordbuffer)] = inbuffer[c];
                                                        }
                                                        else
                                                        {
                                                                compareword();
                                                        }
                                                }
                                        }
                                }
                                break;
                        }
                }
        }
        printf("%d labels found.\n", numlabels);
        printf("%d different words found.\n", numwords);
        printf("%d words total.\n", totalwords);
        sortedwords = 0;
        for (c = 0; c < numwords; c++)
        {
                if (worduse[c] > 1) sortedwords++;
        }

        if (sortedwords > MAXSORTEDWORDS) sortedwords = MAXSORTEDWORDS;
        for (c = 0; c < sortedwords; c++)
        {
                int d;
                int maxworduse = 0, maxwordnum = -1;
                for (d = 0; d < numwords; d++)
                {
                        if (worduse[d] > 1)
                        {
                                if (worduse[d] > maxworduse)
                                {
                                        maxwordnum = d;
                                        maxworduse = worduse[d];
                                }
                        }
                }
                if (maxwordnum != -1)
                {
                        printf("%d. %s (%d times)\n", c+1, word[maxwordnum], worduse[maxwordnum]);
                        strcpy(sortedword[c], word[maxwordnum]);
                        worduse[maxwordnum] = 0;
                }
        }
        printf("%d sorted words.\n", sortedwords);

        fclose(in);
        in = fopen(argv[1], "rt");
        out = fopen(argv[2], "wt");
        numlabels = 0;
        for (;;)
        {
                quotes = 0;
                if (!fgets(inbuffer, sizeof(inbuffer), in)) break;

                for (c = 0; c < strlen(inbuffer); c++)
                {
                         if (inbuffer[c] == 34)
                         {
                                 quotes ^= 1;
                                 if (!quotes)
                                 {
                                         storeword();
                                 }
                                 fputc(34, out);
                         }
                         else
                         {
                                 if (quotes)
                                 {
                                         if (inbuffer[c] == '+')
                                         {
                                                 storeword();
                                                 c++;
                                         }
                                         if ((inbuffer[c] != ',') && (inbuffer[c] != 39) && (inbuffer[c] != '.') && (inbuffer[c] != ' ') && (inbuffer[c] != '?') && (inbuffer[c] != '-') && (inbuffer[c] != '!') && (inbuffer[c] != ':'))
                                         {
                                                 wordbuffer[strlen(wordbuffer)] = inbuffer[c];
                                         }
                                         else
                                         {
                                                 storeword();
                                                 fputc(inbuffer[c], out);
                                         }
                                 }
                                 else
                                 fputc(inbuffer[c], out);
                        }
                }
        }
        fprintf(out, "\n");
        for (c = 0; c < sortedwords; c++)
        {
                fprintf(out,"mostusedword%d: dc.b \"%s\"\n", c, sortedword[c]);
        }
        fprintf(out, "\n");
        for (c = 0; c < sortedwords; c++)
        {
                if (!c)
                {
                        fprintf(out,"wordlengthtbl: dc.b %d\n", strlen(sortedword[c]));
                }
                else
                {
                        fprintf(out,"               dc.b %d\n", strlen(sortedword[c]));
                }
        }
        fprintf(out, "\n");
        return 0;
}


