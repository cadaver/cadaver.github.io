// Oldschoolengine datafile IO module

#define IO_C

#include <stdlib.h>
#include <string.h>
#include "gba.h"
#include "io.h"

static HEADER *header = NULL;
static GBAFILE *firstfile = NULL;

void initio()
{
    u8 *sptr = (u8 *)((u32)ROM & (-SEARCH_STEP));

    while (sptr < ROM + ROM_SIZE)
    {
        if ((((u32 *)sptr)[1] == 0x0055aaff) && (((u32 *)sptr)[0] == 0x21746144))
        {
            header = (HEADER *)sptr;
            firstfile = (GBAFILE *)(sptr + sizeof(HEADER));
            return;
        }
        sptr += SEARCH_STEP;
    }

    // Hang if datafile not found
    while (1);
}

GBAFILE *findfile(const char *name)
{
    char tempbuffer[FILENAME_LEN];
    int c = header->files;
    GBAFILE *fptr = firstfile;

    strcpy(tempbuffer, name);
    strlwr(tempbuffer);

    while (c--)
    {
        if (!strcmp(tempbuffer, fptr->name)) return fptr;
        fptr++;
    }
    return NULL;
}

u32 getfilesize(GBAFILE *fptr)
{
    return fptr->size;
}

void *getfilestart(GBAFILE *fptr)
{
    return (void *)(fptr->start + ((u32)header));
}

void readfile(GBAFILE *fptr, void *dest)
{
    void *src = getfilestart(fptr);
    int size = getfilesize(fptr);

    memcpy(dest, src, size);
}

int readfilename(const char *name, void *dest)
{
    GBAFILE *fptr = findfile(name);
    if (!fptr) return 0;
    readfile(fptr, dest);
    return 1;
}
