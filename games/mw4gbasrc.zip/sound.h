#ifndef SOUND_H
#define SOUND_H

#define SOUND_MIXRATE 18157     // Sound output rate (Hz)
#define SOUND_FRAMESIZE 304     // Samples played per frame
#define SOUND_LATENCY 2         // Amount of vblank buffers

#define SOUND_MUSICRATE 50      // Music calling frequency (Hz)

#define SOUND_CHANNELS 3        // SID channels
#define SOUND_FRAMESUBDIV 4     // How many pieces frame is subdivided for better ADSR
#define SOUND_FREQMUL 54        // Frequency multiplier for correct(?) SID tuning
#define SOUND_VOLUME 85         // Volume of one channel out of maximum amplitude 256

#define SOUND_VOLUMEDIV (65536 / SOUND_VOLUME)

#define SOUND_NOISESIZE 2048    // Sizes of precalculated waveforms
#define SOUND_WAVESIZE 256

#define ENV_ATTACK 1            // Envelope states
#define ENV_RELEASE 2
#define ENV_DECAY 3

void initsound(void);
void setplayroutine(u16 address);
void setsidbase(u8 basehi);
void refreshsound(void) CODE_IN_IWRAM;
void updatesound(void) CODE_IN_IWRAM;

#endif
