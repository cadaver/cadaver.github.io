#ifndef OLDSCHOOL_H
#define OLDSCHOOL_H

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "gba.h"
#include "io.h"
#include "cpu.h"
#include "loader.h"
#include "irq.h"
#include "screen.h"
#include "sound.h"

#endif
