// Oldschoolengine IRQ module

#define IRQ_C

#include "oldschool.h"

volatile int irqcount;
int irqinitted = 0;
u16 vblankroutine = 0;

void initirq(void)
{
    irqcount = 0;

    if (!irqinitted)
    {
        REG_IME = 0;
        ISR = (u32)&irqroutine;
        REG_DISPSTAT |= DISPSTAT_ENABLEVBLANKIRQ;
        REG_IE = IE_VBLANK;
        REG_IME = IME_ENABLE;

        irqinitted = 1;
    }
}

int waitvblank(void)
{
    int time = 0;

    if (irqinitted)
    {
        int oldirqcount = irqcount;
        while (irqcount == oldirqcount) time++;
    }

    return time;
}

void setvblankroutine(u16 address)
{
    vblankroutine = address;
}

