#ifndef SCREEN_H
#define SCREEN_H

#define SCREEN_SIZEX 240
#define SCREEN_SIZEY 160
#define COLORS 256
#define COLORLEVELS 32

#define COLUMNS 30
#define ROWS 20
#define PITCH 32
#define PITCHBITS 5

#define MAXHWSPRITES 128
#define MAXSPRITES 40

typedef struct
{
    u16 y;
    u16 x;
    u16 tile;
    u16 rotscale;
} OAMENTRY;

void initscreen(void);
void setscreenbase(u8 basehi);
void setcolorbase(u8 basehi);
void setcharbase(u8 basehi);
void setspritebase(u8 basehi);
void setgamescroll(u8 scrollx, u8 scrolly);
void setgamecolors(u8 bg, u8 multi1, u8 multi2);
void setscorecolors(u8 bg, u8 multi1, u8 multi2);
void setspritecolors(u8 multi1, u8 multi2);
void setspritelist(u8 size, u16 address);
void redraw(void);
void updatevideo(void) CODE_IN_IWRAM;
void updatepalette(void) CODE_IN_IWRAM;
void updatechars(void) CODE_IN_IWRAM;
void updatescreen(void) CODE_IN_IWRAM;
void updatesprites(void) CODE_IN_IWRAM;
void updateoam(void) CODE_IN_IWRAM;
void printoverlay(u8 srcrow, u8 destrow) CODE_IN_IWRAM;

#endif
