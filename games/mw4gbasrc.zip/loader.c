// Oldschoolengine byte-by-byte loader & savestate manager module

#define LOADER_C

#include "oldschool.h"

u8 *filedataptr;
u32 filebytesleft = 0;

u16 saveaddress = 0;
u32 savesize = 0;

int loadfile(const char *name, u16 dest)
{
    GBAFILE *fptr = findfile(name);

    if (!fptr) return 0;
    if (((u32)dest) + getfilesize(fptr) > CPUMEMSIZE) return 0;

    readfile(fptr, &cpumem[dest]);
    writerange(dest, dest + getfilesize(fptr) - 1);

    return 1;
}

int openfile(const char *name)
{
    if (!filebytesleft)
    {
        GBAFILE *fptr = findfile(name);
        if (!fptr) return 0;

        filebytesleft = getfilesize(fptr);
        filedataptr = (u8 *)getfilestart(fptr);
        return 1;
    }
    return 1;
}

int fileend(void)
{
    if (!filebytesleft) return 1;
    return 0;
}

u8 getbyte(void)
{
    if (!filebytesleft) return 0;
    filebytesleft--;
    return *filedataptr++;
}

int loadsubfile(u16 dest)
{
    if (fileend()) return 0;
    else
    {
        u16 filesize = getbyte() | (getbyte() << 8);
        
        if (((u32)dest) + ((u32)filesize) > CPUMEMSIZE) return 0;

        writerange(dest, dest + filesize - 1);
        while(filesize--) cpumem[dest++] = getbyte();
    }

    return 1;
}

void setsavestatestart(u16 start)
{
    saveaddress = start;
}

void setsavestatesize(u16 size)
{
    savesize = size;
}

int loadstate(u8 state)
{
    u8 *src = SRAM + (SAVEHEADERSIZE + savesize) * state + SAFETY;
    u8 *dest = &cpumem[saveaddress];
    u16 checksum;
    u16 verifysum = 0;
    int c;

    if ((SAVEHEADERSIZE + savesize) * (state + 1) + SAFETY > SRAM_SIZE) return 0;
    if (saveaddress + savesize > CPUMEMSIZE) return 0;

    if (src[0] != SAVEID1) return 0;
    if (src[1] != SAVEID2) return 0;
    checksum = src[2] | (src[3] << 8);
    src += SAVEHEADERSIZE;

    for (c = 0; c < savesize; c++)
        verifysum += src[c];
    verifysum ^= SAVECHECKSUMXOR;

    if (verifysum != checksum) return 0;
    
    for (c = 0; c < savesize; c++)
        dest[c] = src[c];

    writerange(saveaddress, saveaddress + savesize - 1);

    return 1;
}

int savestate(u8 state)
{
    u8 *dest = SRAM + (SAVEHEADERSIZE + savesize) * state + SAFETY;
    u8 *src = &cpumem[saveaddress];
    u16 checksum = 0;
    int c;

    if ((SAVEHEADERSIZE + savesize) * (state + 1) + SAFETY > SRAM_SIZE) return 0;
    if (saveaddress + savesize > CPUMEMSIZE) return 0;
    
    for (c = 0; c < savesize; c++)
        checksum += src[c];
    checksum ^= SAVECHECKSUMXOR;
    
    dest[0] = SAVEID1;
    dest[1] = SAVEID2;
    dest[2] = checksum & 0xff;
    dest[3] = checksum >> 8;
    dest += SAVEHEADERSIZE;

    for (c = 0; c < savesize; c++)
        dest[c] = src[c];

    return 1;
}
