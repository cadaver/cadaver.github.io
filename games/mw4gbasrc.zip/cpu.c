// Oldschoolengine CPU emulation module

#define CPU_C

#include "oldschool.h"

u8 BSS_IN_EWRAM cpumem[CPUMEMSIZE];
u8 BSS_IN_EWRAM cpuwritemap[CPUMEMSIZE >> 6];
u16 blittersrc;
u16 blitterdest;
char filename[3];

void initcpu(void)
{
  memset(cpumem, 0, sizeof cpumem);
  writerange(0, 0xffff);

  memset(filename, 0, sizeof filename);
}

int runblitter(u16 dest, u16 src, u16 size)
{
    if (size)
    {
        if ((src + size < src) || (!(src + size)))
            return 0;
        if ((dest + size < dest) || (!(dest + size)))
            return 0;

        memmove(&cpumem[dest], &cpumem[src], size);
        writerange(dest, dest + size - 1);
        return 1;
    }
    else return 0;
}

u8 getrandom(void)
{
    return rand();
}
