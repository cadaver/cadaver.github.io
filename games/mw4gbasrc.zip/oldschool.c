// Oldschoolengine main program

#define OLDSCHOOL_C

#include "oldschool.h"

int main(void)
{
    initio();
    initcpu();
    initirq();
    initscreen();
    initsound();

    loadfile("prg", ENTRYPOINT);
    runcpu(ENTRYPOINT, 0, 0, 0, MAIN_SP);

    return 0;
}
