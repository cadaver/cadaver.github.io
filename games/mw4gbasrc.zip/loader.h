#ifndef LOADER_H
#define LOADER_H

#define SAVEHEADERSIZE 4
// Don't use the very first bytes of SRAM, to avoid possible power cycling corruption
#define SAFETY 4

#define SAVEID1 0x55
#define SAVEID2 0xaa
#define SAVECHECKSUMXOR 0x1234

int loadfile(const char *name, u16 dest);
int openfile(const char *name);
int fileend(void);
u8 getbyte(void);
int loadsubfile(u16 dest);
void setsavestatestart(u16 start);
void setsavestatesize(u16 size);
int loadstate(u8 state);
int savestate(u8 state);

#endif
