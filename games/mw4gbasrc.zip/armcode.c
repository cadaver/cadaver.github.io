// Oldschoolengine ARM/IWRAM code (all stuff that should run fast)

#define ARMCODE_C

#include "oldschool.h"

#include "armirq.c"
#include "armcpu.c"
#include "armsound.c"
#include "armscreen.c"

