#ifndef CPU_H
#define CPU_H

#define CPUMEMSIZE 0x10000
#define ENTRYPOINT 0x0300

#define MAIN_SP 0xdf
#define IRQ_SP 0xff

#define FN 0x80
#define FV 0x40
#define FB 0x10
#define FD 0x08
#define FI 0x04
#define FZ 0x02
#define FC 0x01

#define CALL_DEBUGHALT 0x00
#define CALL_REDRAW 0x01
#define CALL_SETSCREENBASE 0x02
#define CALL_SETCOLORBASE 0x03
#define CALL_SETCHARBASE 0x04
#define CALL_SETSPRITEBASE 0x05
#define CALL_SETSIDBASE 0x06
#define CALL_SETGAMECOLORS 0x07
#define CALL_SETSCORECOLORS 0x08
#define CALL_SETGAMESCROLL 0x09
#define CALL_PRINTOVERLAY 0x0a
#define CALL_SETSPRITECOLORS 0x0b
#define CALL_SETSPRITELIST 0x0c
#define CALL_GETCONTROLS 0x0d
#define CALL_SETBLITTERSRC 0x0e
#define CALL_SETBLITTERDEST 0x0f
#define CALL_RUNBLITTER 0x10
#define CALL_SETVBLANKROUTINE 0x11
#define CALL_SETPLAYROUTINE 0x12
#define CALL_OPENFILE 0x13
#define CALL_GETBYTE 0x14
#define CALL_LOADSUBFILE 0x15
#define CALL_SETSAVESTATESTART 0x16
#define CALL_SETSAVESTATESIZE 0x17
#define CALL_LOADSTATE 0x18
#define CALL_SAVESTATE 0x19
#define CALL_RANDOM 0x1a

#define JOY_UP 1
#define JOY_DOWN 2
#define JOY_LEFT 4
#define JOY_RIGHT 8
#define JOY_FIRE1 16
#define JOY_FIRE2 32

#define JOY_L 1
#define JOY_R 2
#define JOY_SELECT 4
#define JOY_START 8

#ifndef CPU_C
extern u8 cpumem[];
extern u8 cpuwritemap[];
#endif

void initcpu(void);
int loadtocpumem(const char *name, u16 dest);
int runblitter(u16 dest, u16 src, u16 size);
int runcpu(u16 newpc, u8 newa, u8 newx, u8 newy, u8 newsp) CODE_IN_IWRAM;
void writerange(u16 start, u16 end) CODE_IN_IWRAM;
void clearrange(u16 start, u16 end) CODE_IN_IWRAM;
u8 getrandom(void);

#endif
