// Oldschoolengine sound output & SID emulation module

#define SOUND_C

#include "oldschool.h"

#define ADSRTIME(r) ((int)(65536.0 / CPU_FRAMESPERSECOND / r / SOUND_FRAMESUBDIV))

// ADSR tables
const int attacktable[] = {
    ADSRTIME(0.002), ADSRTIME(0.008), ADSRTIME(0.016), ADSRTIME(0.024),
    ADSRTIME(0.038), ADSRTIME(0.056), ADSRTIME(0.068), ADSRTIME(0.080),
    ADSRTIME(0.100), ADSRTIME(0.240), ADSRTIME(0.500), ADSRTIME(0.800),
    ADSRTIME(1.0), ADSRTIME(3.0), ADSRTIME(5.0), ADSRTIME(8.0)};

const int exptable[] = {
    5, 4, 3, 2,
    1, 1, 0, 0,
    0, 0, 0, 0,
    0, 0, 0, 0};

const int sustainlevel[] = {
    0x0000, 0x1111, 0x2222, 0x3333, 0x4444, 0x5555, 0x6666, 0x7777,
    0x8888, 0x9999, 0xaaaa, 0xbbbb, 0xcccc, 0xdddd, 0xeeee, 0xffff};

// Sound buffers
u8 outputbuffer[SOUND_FRAMESIZE * SOUND_LATENCY];

// Waveforms
u8 noise[SOUND_NOISESIZE];
u8 triangle[SOUND_WAVESIZE];
u8 sawtooth[SOUND_WAVESIZE];

int soundinitted = 0;
volatile int playcursor;
volatile int writecursor;
volatile int tempocounter;

u16 playroutine = 0;
u8 *sidbase = &cpumem[0xd400];

u32 wavecounter[SOUND_CHANNELS];
s32 volume[SOUND_CHANNELS];
u8 envstate[SOUND_CHANNELS];

void initsound(void)
{
    int c;

    if (soundinitted) return;

    // Init waveforms
    for (c = 0; c < SOUND_WAVESIZE; c++)
    {
        int d = (c + 64) & 0xff;

        triangle[c] = (d < SOUND_WAVESIZE/2 ? -128+d*2 : 127-(d-SOUND_WAVESIZE/2)*2) + 128;
        sawtooth[c] = c;
    }
    for (c = 0; c < SOUND_NOISESIZE; c++)
    {
        noise[c] = rand() & 0xff;
    }

    // Init channels
    for (c = 0; c < SOUND_CHANNELS; c++)
    {
        wavecounter[c] = 0;
        volume[c] = 0;
        envstate[c] = ENV_RELEASE;
    }

    // Make sure DMA & timer are stopped
    REG_TM0CNT = 0;
    REG_DMA1CNTH = 0;

    // Clear the buffers, make a ramp to first frame to reduce clicking
    memset(outputbuffer, 128, sizeof outputbuffer);
    for (c = 0; c < 128; c++) outputbuffer[c] = -c;

    // Reset cursors
    playcursor = 0;
    writecursor = 0;
    tempocounter = 0;

    // Set sound flags
    REG_SNDCNTH = SNDCNTH_DSARATIO | SNDCNTH_DSALEFT | SNDCNTH_DSARIGHT |
                  SNDCNTH_DSARESETFIFO;
    REG_SNDCNTX = SNDCNTX_ENABLESOUND;

    // DMA source & destination & flags
    REG_DMA1CNTH = DMACNTH_ONFIFO | DMACNTH_DWORD | DMACNTH_REPEAT | DMACNTH_DESTUNCHANGED;
    REG_DMA1SAD = (u32)outputbuffer;
    REG_DMA1DAD = (u32)(&REG_FIFOA);

    // DMA start
    REG_DMA1CNTH |= DMACNTH_ENABLE;

    // Timer rate & start
    REG_TM0D = 0x10000 - (CPU_CYCLESPERSECOND / SOUND_MIXRATE);
    REG_TM0CNT = TMCNT_ENABLE;

    soundinitted = 1;
}

void setplayroutine(u16 address)
{
    playroutine = address;
}

void setsidbase(u8 basehi)
{
    sidbase = &cpumem[basehi << 8];
}


