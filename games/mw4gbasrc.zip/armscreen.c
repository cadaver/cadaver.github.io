// Oldschoolengine screen routines in IWRAM

extern const u16 c64pal[];
extern u16 charsinglecolortbl[];
extern u16 charmulticolortbl[];
extern u16 screencolortbl[];
extern u8 *screenbase;
extern u8 *colorbase;
extern u8 *charbase;
extern u8 *spritebase;
extern u8 *spritelist;
extern u16 charbaseadr;
extern u16 spritebaseadr;
extern u16 irqgamebg;
extern u16 irqgamemulti1;
extern u16 irqgamemulti2;
extern u16 irqscorebg;
extern u16 irqscoremulti1;
extern u16 irqscoremulti2;
extern u16 irqspritemulti1;
extern u16 irqspritemulti2;
extern u8 gamescreen;
extern u8 scorelastrow;
extern u8 irqgamescrollx;
extern u8 irqgamescrolly;
extern u8 irqgamescreen;
extern u8 numsprites;
extern u8 irqnumsprites;
extern OAMENTRY shadowoam[];
extern int prevspriteframe[];
extern volatile int updateflag;

CODE_IN_IWRAM void updatevideo(void)
{
    if (updateflag)
    {
        REG_BG0HOFS = irqgamescrollx;
        REG_BG0VOFS = irqgamescrolly;
        REG_BG0CNT = BGCNT_TILESTART(1) | BGCNT_MAPSTART(irqgamescreen) | BGCNT_16COLORS | BGCNT_SIZE32X32 | BGCNT_PRIORITY(1);

        REG_BG1HOFS = 0;
        REG_BG1VOFS = 0;
        REG_BG1CNT = BGCNT_TILESTART(1) | BGCNT_MAPSTART(2) | BGCNT_16COLORS | BGCNT_SIZE32X32 | BGCNT_PRIORITY(0);

        if (irqnumsprites)
            REG_DISPCNT = DISPCNT_VIDEOMODE(0) | DISPCNT_ENABLEBG0 | DISPCNT_ENABLEBG1 | DISPCNT_1DSPRITES | DISPCNT_ENABLESPR;
        else
            REG_DISPCNT = DISPCNT_VIDEOMODE(0) | DISPCNT_ENABLEBG0 | DISPCNT_ENABLEBG1 | DISPCNT_1DSPRITES;

        updateoam();
        updatepalette();
        updateflag = 0;
    }
}

CODE_IN_IWRAM void updatescreen(void)
{
    u8 *sptr = screenbase;
    u8 *cptr = colorbase;
    u16 *dptr = VRAM + gamescreen * 0x400;
    int x, y;

    for (y = 0; y < ROWS + 1; y++)
    {
        for (x = 0; x < COLUMNS + 1; x++)
        {
            *dptr = (*sptr) | (screencolortbl[*cptr]);
            dptr++;
            sptr++;
            cptr++;
        }
        dptr += PITCH - (COLUMNS + 1);
        sptr += 40 - (COLUMNS + 1);
        cptr += 40 - (COLUMNS + 1);
    }
}

CODE_IN_IWRAM void printoverlay(u8 srcrow, u8 destrow)
{
    u8 *sptr = screenbase + srcrow * 40;
    u8 *cptr = colorbase + srcrow * 40;
    u16 *dptr = VRAM + 0x800 + destrow * PITCH;
    int x;

    if (srcrow >= 25) return;
    if (destrow >= ROWS) return;

    for (x = 0; x < COLUMNS; x++)
    {
        *dptr = (*sptr) | (screencolortbl[*cptr]) | 0x8000;
        dptr++;
        sptr++;
        cptr++;
    }
}

CODE_IN_IWRAM void updatechars(void)
{
    int c;

    for (c = 0; c < 256; c++)
    {
        if (cpuwritemap[(charbaseadr + (c << 3)) >> 6])
        {
            u8 *sptr = charbase + (c << 3);
            u16 *dptr = (VRAM + 0x2000) + (c << 4);
            u16 *cptr = charsinglecolortbl;

            // Singlecolor version
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;

            // Multicolor version
            sptr = charbase + (c << 3);
            dptr = (VRAM + 0x3000) + (c << 4);
            cptr = charmulticolortbl;

            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
            *dptr++ = cptr[(*sptr) >> 4];
            *dptr++ = cptr[(*sptr) & 0xf];
            sptr++;
        }
    }
    clearrange(charbaseadr, charbaseadr + 2047);
}

CODE_IN_IWRAM void updatesprites(void)
{
    int c;
    OAMENTRY *optr = shadowoam;

    // See which frames have changed in memory, and invalidate corresponding previousframe-value
    for (c = 0; c < numsprites; c++)
    {
        u8 f = spritelist[numsprites*3+c];
        
        if (cpuwritemap[(spritebaseadr >> 6) + f])
            prevspriteframe[c] = -1;
    }

    // Now display the sprites
    for (c = 0; c < numsprites; c++)
    {
        u16 x = spritelist[c] | (((u16)spritelist[numsprites+c]) << 8);
        u8 y = spritelist[numsprites*2+c];
        u8 f = spritelist[numsprites*3+c];
        u8 cl = spritelist[numsprites*4+c];

        y -= 54;
        x -= 31;
        x &= 511;

        if ((y > 256-21) || (y < SCREEN_SIZEY) || (x > 512-24) || (x < SCREEN_SIZEX))
        {
            optr[0].y = (y) | 0x4000;
            optr[1].y = ((y+16) & 255) | 0x4000;
            optr[0].x = x | 0x8000; // 32x16
            optr[1].x = x | 0x4000; // 32x8
            optr[0].tile &= 1023;
            optr[1].tile &= 1023;

            if (prevspriteframe[c] != f)
            {
                // Switch to unused half of sprite doublebuffer
                optr[0].tile ^= 8;
                optr[1].tile ^= 4;

                {
                    u8 *sptr = spritebase + f * 64;
                    u16 *dptr = VRAM + 0x8000 + (optr[0].tile << 4);
                    u16 *cptr = charmulticolortbl;
                    int y = 21;
                    int yc = 0;

                    while (y--)
                    {
                        dptr[0+yc] = cptr[(*sptr) >> 4];
                        dptr[1+yc] = cptr[(*sptr) & 0xf];
                        sptr++;
                        dptr[16+yc] = cptr[(*sptr) >> 4];
                        dptr[17+yc] = cptr[(*sptr) & 0xf];
                        sptr++;
                        dptr[32+yc] = cptr[(*sptr) >> 4];
                        dptr[33+yc] = cptr[(*sptr) & 0xf];
                        sptr++;
                        yc += 2;

                        if (y == 13)
                        {
                            yc = 0;
                            dptr += 64;
                        }
                        if (y == 5)
                        {
                            yc = 0;
                            dptr = VRAM + 0x8000 + (optr[1].tile << 4);
                        }
                    }
                }
                // Mark spritedata unmodified now
                cpuwritemap[(spritebaseadr >> 6) + f] = 0;
            }

            // Color & priority 1
            optr[0].tile |= (cl << 12) | 0x0400;
            optr[1].tile |= (cl << 12) | 0x0400;

            prevspriteframe[c] = f;
        }
        else
        {
            optr[0].y = SCREEN_SIZEY;
            optr[1].y = SCREEN_SIZEY;
            prevspriteframe[c] = -1;
        }
        optr += 2;
    }
}

CODE_IN_IWRAM void updatepalette(void)
{
    int c;

    for (c = 0; c < 128; c += 16)
    {
        PALRAM[c+0] = irqgamebg;
        PALRAM[c+1] = irqgamemulti1;
        PALRAM[c+2] = irqgamemulti2;
    }

    for (c = 128; c < 256; c += 16)
    {
        PALRAM[c+0] = irqscorebg;
        PALRAM[c+1] = irqscoremulti1;
        PALRAM[c+2] = irqscoremulti2;
    }

    for (c = 256; c < 512; c += 16)
    {
        PALRAM[c+1] = irqspritemulti1;
        PALRAM[c+3] = irqspritemulti2;
    }
}

CODE_IN_IWRAM void updateoam(void)
{
    if (irqnumsprites)
    {
        OAMENTRY *sptr = &shadowoam[(irqnumsprites-1)*2+1];
        OAMENTRY *dptr = (OAMENTRY *)OAM;
        int c = irqnumsprites;

        while (c--)
        {
            dptr->y = sptr->y;
            dptr->x = sptr->x;
            dptr->tile = sptr->tile;

            dptr++;
            sptr--;

            dptr->y = sptr->y;
            dptr->x = sptr->x;
            dptr->tile = sptr->tile;

            dptr++;
            sptr--;
        }
    }
}
