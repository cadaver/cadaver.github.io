// Oldschoolengine sound routines in IWRAM

#define NOISE(p) (noise[(p >> 20) & (SOUND_NOISESIZE-1)])
#define PULSE(p, pw) (((p & 0x00ffffff) < pw) ? 255 : 0)
#define SAWTOOTH(p) (sawtooth[(p >> 16) & (SOUND_WAVESIZE-1)])
#define TRIANGLE(p) (triangle[(p >> 16) & (SOUND_WAVESIZE-1)])
#define SIDREG(r) (sidbase[r])

extern const int attacktable[];
extern const int exptable[];
extern const int sustainlevel[];
extern u8 outputbuffer[];
extern u8 noise[];
extern u8 triangle[];
extern u8 sawtooth[];
extern int soundinitted;
extern volatile int playcursor;
extern volatile int writecursor;
extern volatile int tempocounter;
extern u16 playroutine;
extern u8 *sidbase;
extern u32 wavecounter[];
extern s32 volume[];
extern u8 envstate[];

void runchannels(u8 *dest) CODE_IN_IWRAM ;

CODE_IN_IWRAM void refreshsound(void)
{
    if (!soundinitted) return;

    // Advance cursors
    writecursor = playcursor;
    playcursor += SOUND_FRAMESIZE;

    // Wrap the playback when necessary
    if (playcursor >= SOUND_FRAMESIZE * SOUND_LATENCY)
    {
        REG_DMA1CNTH ^= DMACNTH_ENABLE;
        REG_DMA1SAD = (u32)outputbuffer;
        REG_DMA1CNTH ^= DMACNTH_ENABLE;
        playcursor = 0;
    }
}

CODE_IN_IWRAM void updatesound(void)
{
    int c = SOUND_FRAMESIZE;
    u8 *dptr = &outputbuffer[writecursor];

    if (!soundinitted) return;

    while (c--)
    {
        *dptr++ = 128;
    }

    dptr = &outputbuffer[writecursor];

    for (c = 0; c < SOUND_FRAMESUBDIV; c++)
    {
        tempocounter += (1000000 / CPU_FRAMESPERSECOND / SOUND_FRAMESUBDIV);
        if (tempocounter >= (1000000 / SOUND_MUSICRATE))
        {
            tempocounter -= (1000000 / SOUND_MUSICRATE);
            if (playroutine) runcpu(playroutine, 0, 0, 0, IRQ_SP);
        }
        runchannels(dptr);
        dptr += SOUND_FRAMESIZE / SOUND_FRAMESUBDIV;
    }
}

void CODE_IN_IWRAM runchannels(u8 *dest)
{
    int c;

    for (c = 0; c < SOUND_CHANNELS; c++)
    {
        // Testbit
        if (SIDREG(c*7+4) & 8)
            wavecounter[c] = 0;

        // ADSR state changes
        switch (envstate[c])
        {
            case ENV_ATTACK:
            case ENV_DECAY:
            if (!(SIDREG(c*7+4) & 1))
                envstate[c] = ENV_RELEASE;
            break;

            case ENV_RELEASE:
            if (SIDREG(c*7+4) & 1)
                envstate[c] = ENV_ATTACK;
            break;
        }

        // ADSR update
        switch (envstate[c])
        {
            case ENV_ATTACK:
            if (!(SIDREG(c*7+4) & 1))
                envstate[c] = ENV_RELEASE;
            else
            {
                int a = SIDREG(c*7+5) >> 4;
                volume[c] += attacktable[a];
                if (volume[c] >= 65535)
                {
                    volume[c] = 65535;
                    envstate[c] = ENV_DECAY;
                }
            }
            break;

            case ENV_DECAY:
            if (!(SIDREG(c*7+4) & 1))
                envstate[c] = ENV_RELEASE;
            else
            {
                int s = SIDREG(c*7+6) >> 4;

                if (volume[c] > sustainlevel[s])
                {
                    int d = SIDREG(c*7+5) & 0xf;

                    volume[c] -= attacktable[d] >> exptable[volume[c] >> 12];
                    if (volume[c] < sustainlevel[s]) volume[c] = sustainlevel[s];
                }
            }
            break;

            case ENV_RELEASE:
            if (SIDREG(c*7+4) & 1)
                envstate[c] = ENV_ATTACK;
            else
            {
                if (volume[c])
                {
                    int r = SIDREG(c*7+6) & 0xf;
                    volume[c] -= attacktable[r] >> exptable[volume[c] >> 12];
                    if (volume[c] < 0) volume[c] = 0;
                }
            }
            break;
        }

        // Waveform generation
        {
            u8 *dptr = dest;
            u32 d = SOUND_FRAMESIZE / SOUND_FRAMESUBDIV;
            u32 p = wavecounter[c];
            u32 f = (SIDREG(c*7) | ((SIDREG(c*7+1)) << 8)) * SOUND_FREQMUL;
            u32 v = (volume[c] / SOUND_VOLUMEDIV) * (SIDREG(24) & 0xf) / 15;
            u32 pw = ((SIDREG(c*7+2) | ((SIDREG(c*7+3)) << 8)) & 0xfff) << 12;

            if (v)
            {
                switch (SIDREG(c*7+4) & 0xf8)
                {
                    case 0x10:
                    while (d--)
                    {
                        *dptr += (TRIANGLE(p) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;

                    case 0x20:
                    while (d--)
                    {
                        *dptr += (SAWTOOTH(p) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;

                    case 0x40:
                    while (d--)
                    {
                        *dptr += (PULSE(p, pw) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;

                    case 0x50:
                    while (d--)
                    {
                        *dptr += ((PULSE(p, pw) & TRIANGLE(p)) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;

                    case 0x60:
                    while (d--)
                    {
                        *dptr += ((PULSE(p, pw) & SAWTOOTH(p)) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;

                    case 0x70:
                    while (d--)
                    {
                        *dptr += ((PULSE(p, pw) & SAWTOOTH(p) & TRIANGLE(p)) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;

                    case 0x80:
                    while (d--)
                    {
                        *dptr += (NOISE(p) * v) >> 8;
                        dptr++;
                        p += f;
                    }
                    break;
                }

                wavecounter[c] = p;
            }
        }
    }
}

