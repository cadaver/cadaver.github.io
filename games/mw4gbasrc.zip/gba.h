//
// gba.h
//
// Defines for the GBA system. Based on CowBite Virtual HW Spec.
//

#ifndef GBA_H
#define GBA_H

#pragma long_calls

#define INLINE static inline
#define DATA_IN_EWRAM __attribute__((section(".ewram")))
#define DATA_IN_IWRAM __attribute__((section(".iwram")))
#define BSS_IN_EWRAM __attribute__((section(".sbss")))
#define CODE_IN_IWRAM __attribute__ ((section (".iwram")))

// Type definitions

// Signed types

typedef signed char s8;
typedef short s16;
typedef int s32;

// Unsigned types

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned u32;

// System constants

#define CPU_CYCLESPERSECOND 16777216
#define CPU_CYCLESPERFRAME 280896
#define CPU_FRAMESPERSECOND 60

// Memory map of the GBA

// System BIOS ROM, 16KB size
#define BIOSROM ((u8 *)0x00000000)
#define BIOSROM_SIZE 0x4000

// External work RAM, 256KB size
#define EWRAM ((u8 *)0x02000000)
#define EWRAM_SIZE 0x40000

// Internal work RAM, 32KB size (is fast)
#define IWRAM ((u8 *)0x03000000)
#define IWRAM_SIZE 0x8000

// ISR address
#define ISR *((volatile u32 *)0x3007ffc)

// Hardware registers, 1KB size
#define IORAM ((volatile u16 *)0x04000000)
#define IORAM_SIZE 0x400

// Palette RAM, 1KB size, 16bit accesses
#define PALRAM ((u16 *)0x05000000)
#define PALRAM_SIZE 0x400

// Video RAM, 96KB size, 16bit accesses
#define VRAM ((u16 *)0x06000000)
#define VRAM_SIZE 0x18000

// OAM RAM, 1KB size, 16bit accesses
#define OAM ((u16 *)0x07000000)
#define OAM_SIZE 0x400

// Cart ROM, max. 32MB
#define ROM ((u8 *)0x08000000)
#define ROM_SIZE 0x02000000

// Save RAM, max. 32KB or 64KB
#define SRAM ((u8 *)0x0e000000)
#define SRAM_SIZE 0x8000

// Palette values
#define RGB(r,g,b) ((r) | (g << 5) | (b << 10))

// Memory mapped IO registers

// Display control
#define REG_DISPCNT *((volatile u16 *)0x4000000)
#define DISPCNT_VIDEOMODE(n) (n & 7)
#define DISPCNT_GBCOLORMODE 0x8
#define DISPCNT_BITMAPSTART 0x10
#define DISPCNT_FORCEHBLANK 0x20
#define DISPCNT_1DSPRITES 0x40
#define DISPCNT_BLANK 0x80
#define DISPCNT_ENABLEBG0 0x100
#define DISPCNT_ENABLEBG1 0x200
#define DISPCNT_ENABLEBG2 0x400
#define DISPCNT_ENABLEBG3 0x800
#define DISPCNT_ENABLESPR 0x1000
#define DISPCNT_ENABLEWIN0 0x2000
#define DISPCNT_ENABLEWIN1 0x4000
#define DISPCNT_ENABLEOAMWIN 0x8000

// Display status
#define REG_DISPSTAT *((volatile u16 *)0x4000004)
#define DISPSTAT_VBLANK 0x1
#define DISPSTAT_HBLANK 0x2
#define DISPSTAT_VCOUNTTRIGGER 0x4
#define DISPSTAT_ENABLEVBLANKIRQ 0x8
#define DISPSTAT_ENABLEHBLANKIRQ 0x10
#define DISPSTAT_ENABLEVCOUNTIRQ 0x20
#define DISPSTAT_VCOUNTLINE(n) (n << 8)

// Vertical line counter
#define REG_VCOUNT *((volatile u16 *)0x4000006)

// BG 0 control
#define REG_BG0CNT *((volatile u16 *)0x4000008)
#define BGCNT_PRIORITY(n) (n & 3)
#define BGCNT_TILESTART(n) ((n & 3) << 2)
#define BGCNT_MOSAIC 0x40
#define BGCNT_16COLORS 0x0
#define BGCNT_256COLORS 0x80
#define BGCNT_MAPSTART(n) ((n & 15) << 8)
#define BGCNT_SCREENOVER 0x2000
#define BGCNT_SIZE32X32 0x0000
#define BGCNT_SIZE64x32 0x4000
#define BGCNT_SIZE32x64 0x8000
#define BGCNT_SIZE64x64 0xc000

// BG 1-3 control
#define REG_BG1CNT *((volatile u16 *)0x400000a)
#define REG_BG2CNT *((volatile u16 *)0x400000c)
#define REG_BG3CNT *((volatile u16 *)0x400000e)

// BG scrolling
#define REG_BG0HOFS *((volatile u16 *)0x4000010)
#define REG_BG0VOFS *((volatile u16 *)0x4000012)
#define REG_BG1HOFS *((volatile u16 *)0x4000014)
#define REG_BG1VOFS *((volatile u16 *)0x4000016)
#define REG_BG2HOFS *((volatile u16 *)0x4000018)
#define REG_BG2VOFS *((volatile u16 *)0x400001a)
#define REG_BG3HOFS *((volatile u16 *)0x400001c)
#define REG_BG3VOFS *((volatile u16 *)0x400001e)

// Windowing control
#define REG_WIN0H *((volatile u16 *)0x4000040)
#define REG_WIN1H *((volatile u16 *)0x4000042)
#define REG_WIN0V *((volatile u16 *)0x4000044)
#define REG_WIN1V *((volatile u16 *)0x4000046)

#define REG_WININ *((volatile u16 *)0x4000048)
#define WININ_BG0WIN0 0x1
#define WININ_BG1WIN0 0x2
#define WININ_BG2WIN0 0x4
#define WININ_BG3WIN0 0x8
#define WININ_SPRITESWIN0 0x10
#define WININ_BLENDSWIN0 0x20
#define WININ_BG0WIN1 0x100
#define WININ_BG1WIN1 0x200
#define WININ_BG2WIN1 0x400
#define WININ_BG3WIN1 0x800
#define WININ_SPRITESWIN1 0x1000
#define WININ_BLENDSWIN1 0x2000

#define REG_WINOUT *((volatile u16 *)0x400004a)
#define WINOUT_BG0OUT 0x1
#define WINOUT_BG1OUT 0x2
#define WINOUT_BG2OUT 0x4
#define WINOUT_BG3OUT 0x8
#define WINOUT_SPRITESOUT 0x10
#define WINOUT_BLENDSOUT 0x20
#define WINOUT_BG0SPRITE 0x100
#define WINOUT_BG1SPRITE 0x200
#define WINOUT_BG2SPRITE 0x400
#define WINOUT_BG3SPRITE 0x800
#define WINOUT_SPRITESSPRITE 0x1000
#define WINOUT_BLENDSSPRITE 0x2000

// Blending control
#define REG_BLDMOD *((volatile u16 *)0x4000050)
#define BLDMOD_SOURCEBG0 0x1
#define BLDMOD_SOURCEBG1 0x2
#define BLDMOD_SOURCEBG2 0x4
#define BLDMOD_SOURCEBG3 0x8
#define BLDMOD_SOURCESPR 0x10
#define BLDMOD_SOURCEBACKDROP 0x20
#define BLDMOD_MODENONE 0x00
#define BLDMOD_MODEALPHA 0x40
#define BLDMOD_MODELIGHTEN 0x80
#define BLDMOD_MODEDARKEN 0xc0
#define BLDMOD_TARGETBG0 0x100
#define BLDMOD_TARGETBG1 0x200
#define BLDMOD_TARGETBG2 0x400
#define BLDMOD_TARGETBG3 0x800
#define BLDMOD_TARGETSPR 0x1000
#define BLDMOD_TARGETBACKDROP 0x2000

// Blending ratio
#define REG_COLEV *((volatile u16 *)0x4000052)
#define COLEV_SOURCE(n) (n & 31)
#define COLEV_TARGET(n) ((n & 31) << 8)

// Blending fade
#define REG_COLEY *((volatile u16 *)0x4000054)
#define COLEY_FADE(n) (n & 31)



// Joypad input
// Bits are 0 when corresponding keys are pressed
#define REG_KEY *((volatile u16 *)0x4000130)
#define KEY_A 0x1
#define KEY_B 0x2
#define KEY_SELECT 0x4
#define KEY_START 0x8
#define KEY_RIGHT 0x10
#define KEY_LEFT 0x20
#define KEY_UP 0x40
#define KEY_DOWN 0x80
#define KEY_R 0x100
#define KEY_L 0x200

// Sound control L
#define REG_SNDCNTL *((volatile u16 *)0x4000080)
#define SNDCNTL_DMGLEFTVOL 0x7
#define SNDCNTL_VINLEFT 0x8
#define SNDCNTL_DMGRIGHTVOL 0x70
#define SNDCNTL_VINRIGHT 0x80
#define SNDCNTL_DMG1LEFT 0x100
#define SNDCNTL_DMG2LEFT 0x200
#define SNDCNTL_DMG3LEFT 0x400
#define SNDCNTL_DMG4LEFT 0x800
#define SNDCNTL_DMG1RIGHT 0x1000
#define SNDCNTL_DMG2RIGHT 0x2000
#define SNDCNTL_DMG3RIGHT 0x4000
#define SNDCNTL_DMG4RIGHT 0x8000

// Sound control H
#define REG_SNDCNTH *((volatile u16 *)0x4000082)
#define SNDCNTH_DMGRATIO 0x3
#define SNDCNTH_DSARATIO 0x4
#define SNDCNTH_DSBRATIO 0x8
#define SNDCNTH_DSARIGHT 0x100
#define SNDCNTH_DSALEFT 0x200
#define SNDCNTH_DSATIMER0 0x0
#define SNDCNTH_DSATIMER1 0x400
#define SNDCNTH_DSARESETFIFO 0x800
#define SNDCNTH_DSBRIGHT 0x1000
#define SNDCNTH_DSBLEFT 0x2000
#define SNDCNTH_DSBTIMER0 0x0
#define SNDCNTH_DSBTIMER1 0x4000
#define SNDCNTH_DSBRESETFIFO 0x8000

// Sound control X
#define REG_SNDCNTX *((volatile u16 *)0x4000084)
#define SNDCNTX_DMG1STAT 0x1
#define SNDCNTX_DMG2STAT 0x2
#define SNDCNTX_DMG3STAT 0x4
#define SNDCNTX_DMG4STAT 0x8
#define SNDCNTX_ENABLESOUND 0x80

// Sound FIFO buffers
#define REG_FIFOA *((volatile u32 *)0x40000a0)
#define REG_FIFOB *((volatile u32 *)0x40000a4)

// DMA source address
#define REG_DMA0SAD *((volatile u32 *)0x40000B0)
#define REG_DMA1SAD *((volatile u32 *)0x40000BC)
#define REG_DMA2SAD *((volatile u32 *)0x40000C8)
#define REG_DMA3SAD *((volatile u32 *)0x40000D4)

// DMA destination address
#define REG_DMA0DAD *((volatile u32 *)0x40000B4)
#define REG_DMA1DAD *((volatile u32 *)0x40000C0)
#define REG_DMA2DAD *((volatile u32 *)0x40000CC)
#define REG_DMA3DAD *((volatile u32 *)0x40000D8)

// DMA count registers
#define REG_DMA0CNTL *((volatile u16 *)0x40000B8)
#define REG_DMA1CNTL *((volatile u16 *)0x40000C4)
#define REG_DMA2CNTL *((volatile u16 *)0x40000D0)
#define REG_DMA3CNTL *((volatile u16 *)0x40000DC)

// DMA control registers
#define REG_DMA0CNTH *((volatile u16 *)0x40000BA)
#define DMACNTH_DESTAUTOINC 0x0
#define DMACNTH_DESTAUTODEC 0x20
#define DMACNTH_DESTUNCHANGED 0x40
#define DMACNTH_DESTRESET 0x60
#define DMACNTH_SRCAUTOINC 0x0
#define DMACNTH_SRCAUTODEC 0x80
#define DMACNTH_SRCUNCHANGED 0x100
#define DMACNTH_SRCILLEGAL 0x180
#define DMACNTH_REPEAT 0x200
#define DMACNTH_DWORD 0x400
#define DMACNTH_IMMEDIATE 0x0
#define DMACNTH_ONVBLANK 0x1000
#define DMACNTH_ONHBLANK 0x2000
#define DMACNTH_ONFIFO 0x3000
#define DMACNTH_ENABLEIRQ 0x4000
#define DMACNTH_ENABLE 0x8000

#define REG_DMA1CNTH *((volatile u16 *)0x40000C6)
#define REG_DMA2CNTH *((volatile u16 *)0x40000D2)
#define REG_DMA3CNTH *((volatile u16 *)0x40000DE)

// Timer data
#define REG_TM0D *((volatile u16 *)0x4000100)
#define REG_TM1D *((volatile u16 *)0x4000104)
#define REG_TM2D *((volatile u16 *)0x4000108)
#define REG_TM3D *((volatile u16 *)0x400010C)

// Timer control
#define REG_TM0CNT *((volatile u16 *)0x4000102)
#define TMCNT_FREQFULL 0x0
#define TMCNT_FREQ64 0x1
#define TMCNT_FREQ256 0x2
#define TMCNT_FREQ1024 0x3
#define TMCNT_CASCADE 0x4
#define TMCNT_ENABLEIRQ 0x40
#define TMCNT_ENABLE 0x80

#define REG_TM1CNT *((volatile u16 *)0x4000106)
#define REG_TM2CNT *((volatile u16 *)0x400010A)
#define REG_TM3CNT *((volatile u16 *)0x400010E)

// Interrupt control
#define REG_IE *((volatile u16 *)0x4000200)
#define IE_VBLANK 0x1
#define IE_HBLANK 0x2
#define IE_VCOUNT 0x4
#define IE_TIMER0 0x8
#define IE_TIMER1 0x10
#define IE_TIMER2 0x20
#define IE_TIMER3 0x40
#define IE_SERIAL 0x80
#define IE_DMA0 0x100
#define IE_DMA1 0x200
#define IE_DMA2 0x400
#define IE_DMA3 0x800
#define IE_KEY 0x1000
#define IE_CASSETTE 0x2000

#define IRQ_VBLANK 0
#define IRQ_HBLANK 1
#define IRQ_VCOUNT 2
#define IRQ_TIMER0 3
#define IRQ_TIMER1 4
#define IRQ_TIMER2 5
#define IRQ_TIMER3 6
#define IRQ_SERIAL 7
#define IRQ_DMA0 8
#define IRQ_DMA1 9
#define IRQ_DMA2 10
#define IRQ_DMA3 11
#define IRQ_KEY 12
#define IRQ_CASSETTE 13
#define MAX_IRQ 14

// Interrupt flags
#define REG_IF *((volatile u16 *)0x4000202)
#define IF_VBLANK 0x1
#define IF_HBLANK 0x2
#define IF_VCOUNT 0x4
#define IF_TIMER0 0x8
#define IF_TIMER1 0x10
#define IF_TIMER2 0x20
#define IF_TIMER3 0x40
#define IF_SERIAL 0x80
#define IF_DMA0 0x100
#define IF_DMA1 0x200
#define IF_DMA2 0x400
#define IF_DMA3 0x800
#define IF_KEY 0x1000
#define IF_CASSETTE 0x2000

// Interrupt master enable
#define REG_IME *((volatile u8 *)0x4000208)
#define IME_ENABLE 0x1

// DMA operations
#define DMACOPY32(dest, src, size)  \
{                                   \
    REG_DMA3SAD = (u32)(src);       \
    REG_DMA3DAD = (u32)(dest);      \
    REG_DMA3CNTL = (size) >> 2;     \
    REG_DMA3CNTH = DMACNTH_DWORD |  \
        DMACNTH_ENABLE;             \
}

#define DMACOPY16(dest, src, size)  \
{                                   \
    REG_DMA3SAD = (u32)(src);       \
    REG_DMA3DAD = (u32)(dest);      \
    REG_DMA3CNTL = (size) >> 1;     \
    REG_DMA3CNTH = DMACNTH_ENABLE;  \
}

#endif
