//
// io.h
//
// Datafile IO for the GBA
//

#ifndef IO_H
#define IO_H

// Parameters for the datafile
#define SEARCH_STEP 256
#define ID_LEN 8
#define FILENAME_LEN 16

// Seek modes
#define SEEK_SET 0
#define SEEK_CURR 1
#define SEEK_END 2

// Datafile header structure
typedef struct
{
    char id[ID_LEN];   // Identification
    u32 files __attribute__ ((packed));         // Total amount of files
} HEADER;

// File entry structure
typedef struct
{
    char name[FILENAME_LEN];   // Name of file
    u32 start __attribute__ ((packed));                 // Offset from start of datafile
    u32 size __attribute__ ((packed));                  // Size of file in bytes
} GBAFILE;

void initio(void);
GBAFILE *findfile(const char *name);
u32 getfilesize(GBAFILE *fptr);
void *getfilestart(GBAFILE *fptr);
void readfile(GBAFILE *fptr, void *dest);
int readfilename(const char *name, void *dest);

#endif

