// Oldschoolengine screen output module

#define SCREEN_C

#include "oldschool.h"

const u16 c64orgpal[] = {
    RGB(0x00,0x00,0x00),
    RGB(0x1f,0x1f,0x1f),
    RGB(0x0d,0x06,0x05),
    RGB(0x0e,0x14,0x16),
    RGB(0x0d,0x07,0x10),
    RGB(0x0b,0x11,0x08),
    RGB(0x06,0x05,0x0f),
    RGB(0x17,0x18,0x0d),
    RGB(0x0d,0x09,0x04),
    RGB(0x08,0x07,0x00),
    RGB(0x13,0x0c,0x0b),
    RGB(0x08,0x08,0x08),
    RGB(0x0d,0x0d,0x0d),
    RGB(0x13,0x1a,0x10),
    RGB(0x0d,0x0b,0x16),
    RGB(0x12,0x12,0x12)};
    
u16 c64pal[16];

u16 charsinglecolortbl[16];
u16 charmulticolortbl[16];
u16 screencolortbl[256];

u8 *screenbase = &cpumem[0];
u8 *colorbase = &cpumem[0];
u8 *charbase = &cpumem[0];
u8 *spritebase = &cpumem[0];
u8 *spritelist = &cpumem[0];
u16 charbaseadr = 0;
u16 spritebaseadr = 0;

u16 gamebg;
u16 gamemulti1;
u16 gamemulti2;
u16 scorebg;
u16 scoremulti1;
u16 scoremulti2;
u16 spritemulti1;
u16 spritemulti2;
u16 irqgamebg;
u16 irqgamemulti1;
u16 irqgamemulti2;
u16 irqscorebg;
u16 irqscoremulti1;
u16 irqscoremulti2;
u16 irqspritemulti1;
u16 irqspritemulti2;

u8 gamescrollx;
u8 gamescrolly;
u8 gamescreen;
u8 irqgamescrollx;
u8 irqgamescrolly;
u8 irqgamescreen;

u8 numsprites;
u8 irqnumsprites;
OAMENTRY shadowoam[MAXSPRITES*2];
int prevspriteframe[MAXSPRITES];

volatile int updateflag = 0;

void initscreen(void)
{
    OAMENTRY *optr;
    int c;

    // Calculate brightened palette
    for (c = 0; c < 16; c++)
    {
        int r = c64orgpal[c] & (COLORLEVELS - 1);
        int g = (c64orgpal[c] >> 5) & (COLORLEVELS - 1);
        int b = (c64orgpal[c] >> 10) & (COLORLEVELS - 1);

        r = r * 25 / 16;
        if (r >= COLORLEVELS) r = COLORLEVELS-1;
        g = g * 25 / 16;
        if (g >= COLORLEVELS) g = COLORLEVELS-1;
        b = b * 25 / 16;
        if (b >= COLORLEVELS) b = COLORLEVELS-1;

        c64pal[c] = RGB(r,g,b);
    }

    // Set per-char/sprite controllable colors
    for (c = 0; c < 16; c++)
    {
        PALRAM[c*16+3] = c64pal[c & 7];
        PALRAM[256+c*16+2] = c64pal[c];
    }

    // Create char / sprite data conversion tables
    for (c = 0; c < 16; c++)
    {
        charsinglecolortbl[c] =
            ((c & 8) ? (0x03 << 0) : (0x00 << 0)) |
            ((c & 4) ? (0x03 << 4) : (0x00 << 4)) |
            ((c & 2) ? (0x03 << 8) : (0x00 << 8)) |
            ((c & 1) ? (0x03 << 12) : (0x00 << 12));

        charmulticolortbl[c] =
            (((c & 12) >> 2) << 0) |
            (((c & 12) >> 2) << 4)  |
            ((c & 3) << 8) |
            ((c & 3) << 12);
    }

    // Create screen data conversion table
    for (c = 0; c < 256; c++)
    {
        screencolortbl[c] = ((c & 7) << 12) | ((c & 8) << 5);
    }

    // Set all hardware sprites invisible
    optr = (OAMENTRY *)OAM;
    for (c = 0; c < MAXHWSPRITES; c++)
    {
        optr->x = 0;
        optr->y = SCREEN_SIZEY;
        optr->tile = 0;
        optr->rotscale = 0;
        optr++;
    }
    // Set initial tile numbers / doublebuffering for the shadow oam
    optr = shadowoam;
    for (c = 0; c < MAXSPRITES; c++)
    {
        optr[0].tile = 16*c;
        optr[1].tile = (MAXSPRITES*16)+8*c;
        prevspriteframe[c] = -1;

        optr += 2;
    }

    REG_DISPCNT = DISPCNT_VIDEOMODE(0) | DISPCNT_1DSPRITES;

    gamescrollx = 0;
    gamescrolly = 0;
    gamescreen = 0;
    numsprites = 0;
}

void setscreenbase(u8 basehi)
{
    if (basehi <= 0xfc)
        screenbase = &cpumem[basehi << 8];
}

void setcolorbase(u8 basehi)
{
    if (basehi <= 0xfc)
        colorbase = &cpumem[basehi << 8];
}

void setcharbase(u8 basehi)
{
    if (basehi <= 0xf8)
    {
        charbase = &cpumem[basehi << 8];
        charbaseadr = basehi << 8;
        writerange(charbaseadr, charbaseadr + 2047);
    }
}

void setspritebase(u8 basehi)
{
    if (basehi <= 0xc0)
    {
        spritebase = &cpumem[basehi << 8];
        spritebaseadr = basehi << 8;
        writerange(spritebaseadr, spritebaseadr + 16383);
    }
}

void setspritelist(u8 size, u16 address)
{
    spritelist = &cpumem[address];
    if (numsprites > MAXSPRITES) numsprites = MAXSPRITES;
    numsprites = size;
}

void setgamescroll(u8 scrollx, u8 scrolly)
{
    gamescrollx = (scrollx ^ 7) & 7;
    gamescrolly = (scrolly ^ 7) & 7;
}

void setgamecolors(u8 bg, u8 multi1, u8 multi2)
{
    gamebg = c64pal[bg & 0x0f];
    gamemulti1 = c64pal[multi1 & 0x0f];
    gamemulti2 = c64pal[multi2 & 0x0f];
}

void setscorecolors(u8 bg, u8 multi1, u8 multi2)
{
    scorebg = c64pal[bg & 0x0f];
    scoremulti1 = c64pal[multi1 & 0x0f];
    scoremulti2 = c64pal[multi2 & 0x0f];
}

void setspritecolors(u8 multi1, u8 multi2)
{
    spritemulti1 = c64pal[multi1 & 0x0f];
    spritemulti2 = c64pal[multi2 & 0x0f];
}

void redraw(void)
{
    while (updateflag)
    {
    }

    updatescreen();
    updatesprites();
    updatechars();

    irqspritemulti1 = spritemulti1;
    irqspritemulti2 = spritemulti2;

    irqgamebg = gamebg;
    irqgamemulti1 = gamemulti1;
    irqgamemulti2 = gamemulti2;
    
    irqscorebg = scorebg;
    irqscoremulti1 = scoremulti1;
    irqscoremulti2 = scoremulti2;
    
    irqgamescrollx = gamescrollx;
    irqgamescrolly = gamescrolly;
    irqgamescreen = gamescreen;
    irqnumsprites = numsprites;

    gamescreen ^= 1;
    updateflag = 1;
}

