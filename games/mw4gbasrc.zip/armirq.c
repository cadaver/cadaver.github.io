// Oldschoolengine IRQ routines in IWRAM

extern u16 vblankroutine;

CODE_IN_IWRAM void irqroutine(void)
{
    refreshsound();
    updatevideo();
    updatesound();
    if (vblankroutine) runcpu(vblankroutine, 0, 0, 0, IRQ_SP);
    irqcount++;

    REG_IF |= IE_VBLANK;
    REG_IME = IME_ENABLE;
}
