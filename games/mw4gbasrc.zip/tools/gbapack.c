#include <stdio.h>
#include <stdlib.h>
#include "endian.h"

int main(int argc, char **argv)
{
    FILE *in;
    FILE *out;
    int filesize;
    int c;
    char *buffer;

    if (argc < 3)
    {
        printf("Usage: gbapack <infile> <outfile>\n");
        return 1;
    }

    in = fopen(argv[1], "rb");
    if (!in)
    {
        printf("Couldn't open infile\n");
        return 1;
    }

    fseek(in, 0, SEEK_END);
    filesize = ftell(in);
    fseek(in, 0, SEEK_SET);

    buffer = malloc(filesize);
    if (!buffer)
    {
        printf("Out of memory!\n");
        fclose(in);
        return 1;
    }

    for (c = 0; c < filesize; c++)
        buffer[c] = fread8(in);
    fclose(in);

    out = fopen(argv[2], "wb");
    if (!out)
    {
        printf("Couldn't open outfile\n");
        return 1;
    }

    fwrite8(out, filesize & 0xff);
    fwrite8(out, filesize >> 8);
    
    for (c = 0; c < filesize; c++)
        fwrite8(out, buffer[c]);
    fclose(out);

    return 0;
}




