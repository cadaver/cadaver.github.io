These are commandline utilities especially in use for MW4.
The C64-tools from http://covertbitops.c64.org, DASM and Exomizer are also 
needed.

GBAFILE - makes a GBA datafile
GBALINK - links the datafile to a GBA rom
GBAPACK - prepare file for multi-subfile loading (many files into one). Could
          also pack, but doesn't currently do that for loading speed and ROM
          hackability
MAKEDATA - make the onefile version of datafile
CICHECK - Check if a certain charinfo exists in a .CHI file (debugging util)
DUMPACT - Print out actor/item count from LVLACT.DAT (debugging util)
OBJREQ - Print out object requirements in a level (debugging util)
SCRVIEW - Print out scripted objects in a level (debugging util)
SPRCONV2 - Convert packed "weapon sprites" to format usable by MW4 engine
SPRCONV3 - Convert packed sprites to format usable by MW4GBA engine
TRUNCATE - Truncate a binary datafile to arbitrary length
