#include <stdio.h>
#include <stdlib.h>

unsigned char ci[256];

int main(int argc, unsigned char **argv)
{
        FILE *in;
        FILE *out;
        int c;
        int i;
        int m = 0;

        sscanf(argv[2], "%d", &i);

        if (argc < 3) return 1;
        printf("Checking file %s for charinfo %d\n", argv[1], i);
        in = fopen(argv[1], "rb");
        fread(ci, 1, 256, in);
        fclose(in);

        for (c = 0; c < 256; c++)
        {
                if (ci[c] == i)
                {
                        m++;
                        printf("Charinfo %d found at char %d\n", i, c);
                }
        }
        if (m == 0) printf("No matches found\n");
        return 0;
}
