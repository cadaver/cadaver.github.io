#include <stdio.h>
#include <stdlib.h>
#include "endian.h"

char *actorname[256];
char *itemname[256];
char *modename[16];

int main()
{
    FILE *in = fopen("lvlact.dat", "rb");
    FILE *names = fopen("names.txt", "rt");

    int actors;
    int c = 0;
    int actorcount[128];
    int actorhiddencount[128];
    int itemcount[128];
    int itemhiddencount[128];

    for (c = 0; c < 128; c++)
    {
        actorcount[c] = 0;
        actorhiddencount[c] = 0;
        itemcount[c] = 0;
        itemhiddencount[c] = 0;
    }

    for (c = 0; c < 256; c++) actorname[c] = " ";
    for (c = 0; c < 256; c++) itemname[c] = " ";
    for (c = 0; c < 16; c++) modename[c] = " ";

    if (names)
    {
        for (c = 0; c < 256; c++)
        {
            actorname[c] = malloc(80);
            actorname[c][0] = 0;
            AGAIN1:
            if (!fgets(actorname[c], 80, names)) break;
            if (actorname[c][0] == ' ') goto AGAIN1;
            if (actorname[c][0] == ';') goto AGAIN1;
            if (strlen(actorname[c]) > 1) actorname[c][strlen(actorname[c])-1] = 0; /* Delete newline */
            if (!strcmp(actorname[c], "end")) break;
        }
        for (c = 0; c < 256; c++)
        {
            itemname[c] = malloc(80);
            itemname[c][0] = 0;
            AGAIN2:
            if (!fgets(itemname[c], 80, names)) break;
            if (itemname[c][0] == ' ') goto AGAIN2;
            if (itemname[c][0] == ';') goto AGAIN2;
            if (strlen(itemname[c]) > 1) itemname[c][strlen(itemname[c])-1] = 0; /* Delete newline */
            if (!strcmp(itemname[c], "end")) break;
        }
        for (c = 0; c < 16; c++)
        {
            modename[c] = malloc(80);
            modename[c][0] = 0;
            AGAIN5:
            if (!fgets(modename[c], 80, names)) break;
            if (modename[c][0] == ' ') goto AGAIN5;
            if (modename[c][0] == ';') goto AGAIN5;
            if (strlen(modename[c]) > 1) modename[c][strlen(modename[c])-1] = 0; /* Delete newline */
        }

        fclose(names);
    }

    if (!in)
    {
        printf("Couldn't open lvlact.dat\n");
        return 1;
    }

    fseek(in, 0, SEEK_END);
    actors = ftell(in) / 6;
    fseek(in, 0, SEEK_SET);
    
    for (c = 0; c < actors; c++)
    {
        unsigned char level = fread8(in);
        unsigned char x = fread8(in);
        unsigned char y = fread8(in);
        unsigned char fine = fread8(in);
        unsigned char type = fread8(in);
        unsigned char data = fread8(in);

        if (level != 0x7f)
        {
            if (type & 0x80)
            {
                itemcount[type & 0x7f]++;
                if (y & 0x80) itemhiddencount[type & 0x7f]++;
            }
            else
            {
                actorcount[type]++;
                if (y & 0x80) actorhiddencount[type]++;
            }
        }
    }
    fclose(in);

    printf("Actors:\n");
    for (c = 0; c < 128; c++)
    {
        if (actorcount[c])
        {
            printf("%-20s %d", actorname[c], actorcount[c]);
            if (actorhiddencount[c])
                printf(" (%d hidden)", actorhiddencount[c]);
            printf("\n");
        }
    }
    printf("\n");

    printf("Items:\n");
    for (c = 0; c < 128; c++)
    {
        if (itemcount[c])
        {
            printf("%-20s %d", itemname[c], itemcount[c]);
            if (itemhiddencount[c])
                printf(" (%d hidden)", itemhiddencount[c]);
            printf("\n");
        }
    }
    printf("\n");

    return 0;
}

