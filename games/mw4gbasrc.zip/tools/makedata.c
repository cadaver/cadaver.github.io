#include <stdio.h>
#include <io.h>
#include <string.h>

FILE *in;
FILE *out;
int handle;
char *dosname[64];
char *c64name[16];
char commandbuf[80];

int main(int argc, char **argv)
{
        /* Open command file */
        in = fopen(argv[1], "rt");
        if (!in)
        {
                printf("Couldn't open command file!\n");
                return 255;
        }
        out = fopen(argv[2], "wb");
        if (!out)
        {
                printf("Couldn't open datafile!\n");
                return 255;
        }
        fputc('M', out);        // ID/header
        fputc('W', out);


        /* Write files to image one by one */
        while(fgets(commandbuf, 80, in))
        {
                sscanf(commandbuf, "%s %s", &dosname[0], &c64name[0]);
                if (!writefile(dosname, c64name))
                {
                        printf("Error writing file %s\n", c64name);
                }
        }
        fclose(in);
        fclose(out);
}

int writefile(char *src, char *dest)
{
        FILE *srcfile = fopen(src, "rb");
        int len;
        int c;

        if (!srcfile) return 0;

        fseek(srcfile, 0, SEEK_END);
        len = ftell(srcfile);
        fseek(srcfile, 0, SEEK_SET);
        fputc(dest[0], out);    // 2-letter filename
        fputc(dest[1], out);
        fputc(len & 0xff, out);
        fputc(len >> 8, out);   // 16-bit length

        while (len--)
        {
                fputc(fgetc(srcfile), out);
        }
        fclose(srcfile);

        return 1;
}
