//
// adddata.c
//
// Append data to a ROM file, with 256 byte padding
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <SDL/SDL_types.h>
#include "endian.h"

#define SEARCH_STEP 256

int main(int argc, char **argv)
{
  FILE *datafile, *romfile;
  int pos, length, pad;
  char *buffer;

  if (argc < 3)
  {
    printf("Usage: adddata <romfile> <datafile>\n\n"
      "Append the datafile at the end of the rom file, with proper padding for\n"
      "use with the IO.C GBA library.\n");
    return 0;
  }

  // Open both files
  datafile = fopen(argv[2], "rb");
  if (!datafile)
  {
    printf("Couldn't open datafile!\n");
    return 1;
  }
  romfile = fopen(argv[1], "a+b");
  if (!romfile)
  {
    printf("Couldn't open romfile!\n");
    return 1;
  }

  // Find out length of datafile
  fseek(datafile, 0, SEEK_END);
  length = ftell(datafile);
  fseek(datafile, 0, SEEK_SET);

  // Allocate & read datafile
  buffer = malloc(length);
  if (!buffer)
  {
    printf("Out of memory!\n");
    fclose(datafile);
    fclose(romfile);
    return 1;
  }
  printf("- Reading %d bytes\n", length);
  fread(buffer, length, 1, datafile);
  fclose(datafile);

  // Find out end position (for padding)
  fseek(romfile, 0, SEEK_END);
  pos = ftell(romfile);

  // Pad romfile with zeros to next search step
  pad = SEARCH_STEP - (pos % SEARCH_STEP);
  if (pad == SEARCH_STEP) pad = 0;
  printf("- Padding ROM (datafile begins at %d)\n", pos+pad);
  while (pad--) fwrite8(romfile, 0);

  // Write datafile & close
  printf("- Writing %d bytes\n", length);
  fwrite(buffer, length, 1, romfile);
  fclose(romfile);
  return 0;
}
