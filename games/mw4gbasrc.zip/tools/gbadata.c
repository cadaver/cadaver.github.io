//
// makedata.c
//
// Datafile creator for GBA datafile IO
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <SDL/SDL_types.h>
#include "endian.h"

#define MAXFILES 16384
#define MAXFILENAME 128
#define DATAFILENAME 16

typedef struct
{
  char name[DATAFILENAME] __attribute__ ((packed));
  Uint32 offset __attribute__ ((packed));
  Uint32 length __attribute__ ((packed));
} HEADER;

static HEADER header[MAXFILES];
static char fullname[MAXFILES][MAXFILENAME];
static int files;

int main(int argc, char **argv);
int addfile(HEADER *header, FILE *dest, char *name);
void fwrite8(FILE *file, unsigned data);
void fwritele16(FILE *file, unsigned data);
void fwritele32(FILE *file, unsigned data);

int main(int argc, char **argv)
{
  FILE *datafile, *listfile;
  int c;

  if (argc < 3)
  {
    printf("Usage: MAKEDATA <datafile> <filelistfile>\n\n"
      "The purpose of this program is to gather many files into one datafile, like\n"
      "usually seen in games. Used for the IO.C GBA library only.\n\n"
      "Filelistfile shall contain a <filename> <gbaname> pair on each row.\n"
      "Maximum GBA filename length is 15 chars.\n");
    return 0;
  }
  listfile = fopen(argv[2], "rt");
  if (!listfile)
  {
    printf("ERROR: Couldn't open filelist.\n");
    return 1;
  }
  datafile = fopen(argv[1], "wb");
  if (!datafile)
  {
    printf("ERROR: Couldn't create datafile.\n");
    fclose(listfile);
    return 1;
  }
  memset(&header[0], 0, MAXFILES * sizeof(HEADER));
  /* Get names from list */
  for (;;)
  {
    char filename[128];
    char gbaname[128];
    FILE *test;

    if (fscanf(listfile, "%127s %127s", filename, gbaname) == EOF) break;
    if (strlen(filename))
    {
      test = fopen(filename, "rb");
      if (test)
      {
        fclose(test);

        strcpy(fullname[files], filename);

        memset(header[files].name, 0, DATAFILENAME);

        int c = 0;
        while (gbaname[c])
        {
          header[files].name[c] = tolower(gbaname[c]);
          c++;
        }
        files++;
        if (files == MAXFILES) break;
      }
      else
      {
        printf("ERROR: Couldn't open file %s\n", filename);
        return 0;
      }
      if (files == MAXFILES) break;
    }
  }

  fclose(listfile);
  /* Write datafile header */
  fwrite("Dat!", 4, 1, datafile);
  fwritele32(datafile, 0x0055aaff);
  fwritele32(datafile, files);
  /* Write incomplete fileheaders */
  for (c = 0; c < files; c++)
  {
    fwrite(header[c].name, DATAFILENAME, 1, datafile);
    fwritele32(datafile, header[c].offset);
    fwritele32(datafile, header[c].length);
  }
  /* Process each file */
  for (c = 0; c < files; c++)
  {
    printf("Adding %s...\n", header[c].name);
    if (!addfile(&header[c], datafile, fullname[c]))
    {    
      fclose(datafile);
      remove(argv[1]);
      return 1;
    }
  }
  /* Seek back to start & write correct headers */
  fseek(datafile, sizeof files + 8, SEEK_SET);
  for (c = 0; c < files; c++)
  {
    fwrite(header[c].name, DATAFILENAME, 1, datafile);
    fwritele32(datafile, header[c].offset);
    fwritele32(datafile, header[c].length);
  }
  fclose(datafile);
  return 0;
}

int addfile(HEADER *header, FILE *dest, char *name)
{
  FILE *src;
  unsigned char *originalbuf;
  int padbytes;

  src = fopen(name, "rb");
  if (!src)
  {
    printf("ERROR: Couldn't open file %s\n", name);
    return 0;
  }
  header->offset = ftell(dest);
  fseek(src, 0, SEEK_END);
  header->length = ftell(src);
  fseek(src, 0, SEEK_SET);
  originalbuf = malloc(header->length);
  if (!originalbuf)
  {
    printf("ERROR: No memory to load file!\n");
    fclose(src);
    return 0;
  }
  printf("- Loading file\n");
  fread(originalbuf, header->length, 1, src);
  fclose(src);
  printf("- Writing file (size was %d)\n", header->length);
  fwrite(originalbuf, header->length, 1, dest);
  free(originalbuf);

  // Pad the file on dword boundary
  padbytes = (4 - ftell(dest)) & 3;
  while (padbytes--)
  {
    fwrite8(dest, 0);
  }
  return 1;
}
