#ifndef IRQ_H
#define IRQ_H

void initirq(void);
int waitvblank(void);
void setvblankroutine(u16 address);
void irqroutine(void) CODE_IN_IWRAM;

#ifndef IRQ_C
extern volatile int irqcount;
#endif

#endif

