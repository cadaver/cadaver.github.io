//
// MW4:Agents of Metal Preview CovertScript code
//

// External (game engine) definitions
#include "mw4ext.cs"

// Game defines
#include "mw4def.cs"

// Entrypoint, has to be at $000000 in script memory address space
start()
{
  firsttimestartup();
  goto titlescreen;
}

// Bank 0 resident code & data
#include "mw4text.cs"
#include "mw4funct.cs"
#include "mw4conv.cs"
#include "mw4menu.cs"

// Initialization code
#include "mw4init.cs"

// Actual ingame code
#include "mw4title.cs"
#include "mw4prev.cs"
