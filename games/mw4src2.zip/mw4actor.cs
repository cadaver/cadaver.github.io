//
// CovertEngine chunk file: actors
// To be compiled with -h -o options as a chunk file.
//

#include "mw4def.cs"

extern thinker_player;
extern thinker_mammal;
extern move_human;
extern move_item;
extern move_bullet;
extern move_meleehit;
extern move_shuriken;
extern move_grenade;
extern move_smokecloud;
extern move_shrapnel;
extern move_gore;
extern move_explosion;
extern move_zsign;
extern move_balloon;

chunk(ACT_NONE) {}

chunk(ACT_AGENT)
{
  thinker_player,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_AGENT,                          // 1st part spritefile
  0,                                // 1st part color override
  FR_PLRLEGS,                       // 1st part frame
  C_AGENT,                          // 2nd part spritefile
  0,                                // 2nd part color override
  FR_PLRTORSO,                      // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_CLIMB|ACB_WALLFLIP|ACB_TALL|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC,
  64,                               // Walking speed
  -72,                              // Jump initial speed
  32,                               // Duckwalk speed
  128,                              // Climbing speed
  16,                               // Acceleration on ground
  8,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  PLR_MAXBATT,                      // Default armor level
  PLR_MAXHP,                        // Default hitpoints
  7,                                // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x60,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x40,                             // Duck-attack probability
  0xc0,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x50,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -2*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_STUDENTM1)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  0,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_STUDENTM,                       // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTBODIES,
  60,                               // Walking speed
  -64,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  16,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x80,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x30,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x70,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_STUDENTM2)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  2,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_STUDENTM,                       // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTBODIES,
  60,                               // Walking speed
  -64,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  16,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x80,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x30,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x70,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_STUDENTM3)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  5,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_STUDENTM,                       // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTBODIES,
  60,                               // Walking speed
  -64,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  16,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x80,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x30,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x70,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_STUDENTF1)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  0,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_STUDENTF,                       // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTBODIES,
  60,                               // Walking speed
  -64,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  16,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x80,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x30,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x70,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_STUDENTF2)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  2,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_STUDENTF,                       // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTBODIES,
  60,                               // Walking speed
  -64,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  16,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x80,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x30,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x70,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_STUDENTF3)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  5,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_STUDENTF,                       // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                    // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTBODIES,
  60,                               // Walking speed
  -64,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  16,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x0c,                             // Attack probability
  0x80,                             // Melee attack probability
  0xf0,                             // Ducking probability
  0xfd,                             // Ducking exit prob.
  0x30,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x70,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_SOKE)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_STUDENTM,                       // 1st part spritefile
  15,                               // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_SOKE,                           // 2nd part spritefile
  0,                                // 2nd part color override
  FR_SOKETORSO,                     // 2nd part frame
                                     // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                     // Fighting bits
  AFB_ORGANIC|AFB_INVINCIBLE|AFB_REACTVISUAL|AFB_REACTBODIES,
  68,                               // Walking speed
  -66,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  96,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x10,                              // Attack probability
  0x80,                              // Melee attack probability
  0xe8,                              // Ducking probability
  0xfd,                              // Ducking exit prob.
  0x30,                              // Duck-attack probability
  0x80,                              // Climb prob. in combat
  0x80,                              // Target change prob.
  0xc0,                              // Turn if far from target
  0x60,                              // Jump instead of duck
  0x07,                              // Patrol idle prob.
  SFX_TAKEDOWN,                      // Takedown sound
  -8*8,                              // Takedown Y-mod
  F_HIT                              // Hit flashing color
}

chunk(ACT_NINJA)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_NINJA,                          // 1st part spritefile
  0,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_NINJA,                          // 2nd part spritefile
  0,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                     // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                     // Fighting bits
  AFB_ORGANIC|AFB_DISAPPEAR|AFB_REACTVISUAL|AFB_REACTNOISE|AFB_REACTBODIES,
  68,                               // Walking speed
  -66,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  0,                                // Default armor level
  12,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x20,                             // Attack probability
  0x90,                             // Melee attack probability
  0xe8,                             // Ducking probability
  0xfc,                             // Ducking exit prob.
  0x40,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xc0,                             // Turn if far from target
  0x60,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_MASTERNINJA)
{
  thinker_mammal,                   // AI routine address
  move_human,                       // Move routine address
  ADB_WEAPON,                       // Display bits
  1,                                // Size left/right
  0,                                // Size down
  5,                                // Size up
  3,                                // Size up (ducking)
  C_NINJA,                          // 1st part spritefile
  2,                                // 1st part color override
  FR_STUDENTLEGS,                   // 1st part frame
  C_NINJA,                          // 2nd part spritefile
  2,                                // 2nd part color override
  FR_STUDENTTORSO,                  // 2nd part frame
                                    // Capabilities
  ACB_WALK|ACB_DUCK|ACB_JUMP|ACB_LONGJUMP,
                                     // Fighting bits
  AFB_ORGANIC|AFB_REACTVISUAL|AFB_REACTNOISE|AFB_REACTBODIES,
  76,                               // Walking speed
  -66,                              // Jump initial speed
  0,                                // Duckwalk speed
  0,                                // Climbing speed
  16,                               // Acceleration on ground
  4,                                // Acceleration in air
  16,                               // Braking
  0,                                // Attack X-mod
  29,                               // Normal attack Y-mod
  20,                               // Ducking attack Y-mod
  32,                               // Default armor level
  64,                               // Default hitpoints
  10,                               // Patrol radius
  25,                               // Patrol idle time
  0x24,                             // Attack probability
  0x80,                             // Melee attack probability
  0xe8,                             // Ducking probability
  0xfc,                             // Ducking exit prob.
  0x48,                             // Duck-attack probability
  0x80,                             // Climb prob. in combat
  0x80,                             // Target change prob.
  0xd0,                             // Turn if far from target
  0x64,                             // Jump instead of duck
  0x07,                             // Patrol idle prob.
  SFX_TAKEDOWN,                     // Takedown sound
  -8*8,                             // Takedown Y-mod
  F_HIT                             // Hit flashing color
}

chunk(ACT_ITEM)
{
  0,0,                              // AI routine address
  move_item,                        // Move routine address
  ADB_SIMPLE,                       // Display bits
  C_ITEM,                           // Spritefile number
  0,                                // Left frame add
  0,                                // None (never visible)
  11,                               // Fists
  0,                                // Baton
  1,                                // Knife
  2,                                // Katana
  3,                                // Shuriken
  8,                                // Grenade
  6,                                // Dart gun
  4,                                // 9mm pistol
  5,                                // 9mm SMG
  7,                                // Shotgun
  10,                               // 9mm ammo
  10,                               // 12 gauge ammo
  10,                               // Darts
  9,                                // First aid kit
  12,                               // Battery
  13                                // Scroll
}

chunk(ACT_MELEEHIT)
{
  0,0,                              // AI routine address
  move_meleehit,                    // Move routine address
  ADB_SIMPLE|ADB_INVISIBLE,         // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  4                                 // Frame numbers
}

chunk(ACT_BULLET)
{
  0,0,                              // AI routine address
  move_bullet,                      // Move routine address
  ADB_SIMPLE|ADB_INVISIBLE,         // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  2                                 // Frame numbers
}

chunk(ACT_SHURIKEN)
{
  0,0,                              // AI routine address
  move_shuriken,                    // Move routine address
  ADB_SIMPLE|ADB_FLICKER,           // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  2                                 // Frame numbers
}

chunk(ACT_DART)
{
  0,0,                              // AI routine address
  move_bullet,                      // Move routine address
  ADB_SIMPLE|ADB_FLICKER,           // Display bits
  C_COMMON,                         // Spritefile number
  3,                                // Left frame add
  5,6,7,5,7,6                       // Frame numbers
}

chunk(ACT_GRENADE)
{
  0,0,                              // AI routine address
  move_grenade,                     // Move routine address
  ADB_SIMPLE,                       // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  9                                 // Frame numbers
}

chunk(ACT_SMOKECLOUD)
{
  0,0,                              // AI routine address
  move_smokecloud,                  // Move routine address
  ADB_SIMPLE|ADB_FLICKER,           // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  0,1                               // Frame numbers
}

chunk(ACT_GORE)
{
  0,0,                              // AI routine address
  move_gore,                        // Move routine address
  ADB_SIMPLE,                       // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  3,4                               // Frame numbers
}

chunk(ACT_SHRAPNEL)
{
  0,0,                              // AI routine address
  move_shrapnel,                    // Move routine address
  ADB_SIMPLE|ADB_FLICKER,           // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  0,1                               // Frame numbers
}

chunk(ACT_EXPLOSION)
{
  0,0,                              // AI routine address
  move_explosion,                   // Move routine address
  ADB_SIMPLE,                       // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  10,11,12,13,14                    // Frame numbers
}

chunk(ACT_ZSIGN)
{
  0,0,                              // AI routine address
  move_zsign,                       // Move routine address
  ADB_SIMPLE|ADB_FLICKER,           // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  8                                 // Frame numbers
}

chunk(ACT_BALLOON)
{
  0,0,                              // AI routine address
  move_balloon,                     // Move routine address
  ADB_SIMPLE,                       // Display bits
  C_COMMON,                         // Spritefile number
  0,                                // Left frame add
  15                                // Frame numbers
}

