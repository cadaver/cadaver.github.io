// Common triggers (default door entry, item use, game over)

setcommontriggers()
{
  settrigger({T_USE,0xff,useitems});
  settrigger({T_DOOR,0xff,enterdoor});
  settrigger({T_TAKEDOWN,ID_AGENT,gameover});
  settrigger({T_TAKEDOWN,0xff,dropmedikits});
}

// Hide certain actor type from the leveldata

hideactortype(a)
{
  for (x = 0; x < NUMLEVELACT; x++)
  {
    if (lvlactt[x] == a)
    {
      // Actors are hidden when Y-coord >= 128
      lvlactyh[x] |= 0x80;
    }
  }
}

// Menu initialization (only on startup)

initmenu()
{
  for (x = MENU_OPTIONS; x <= MENU_CONFIRM; x++)
  {
    menumaxchoices[x] = firstmenuitem[x+1] - firstmenuitem[x] - 1;
  }
  menuselect[MENU_GAME] = 1;
  menuview[MENU_GAME] = 1;
}

// First-time game startup

firsttimestartup()
{
  acthp[ACTI_PLAYER] = PLR_MAXHP;
  actbatt[ACTI_PLAYER] = PLR_MAXBATT;

  initinventory();
  initpanel();

  // In case we have fastloading, play title music as soon as possible
  if (fastloadstatus) playtune(MF_TITLE|SONG_EXPLORE);

  // Print startup message
  printmsgptr({NPC_TIME, "MW4:Agents of Metal Prv.2   ",0});

  if (usereu)
  {
    if (usereu & 0x80)
      printmsgcont({"SuperRAM detected",0});
    else
      printmsgcont({"REU detected",0});
    printmsgcont({" - buffering",0});

    buffercategory('M'); // Music
    buffercategory('P'); // CovertScript bytecode pages
    buffercategory('C'); // Chunks
    buffercategory('L'); // Maps
    buffercategory('D'); // Weapon/Item etc. defines

    resetmsg();
  }

  // Some variables for the engine
  firstitemname = MSG_FIRSTITEM;
  firstotheritem = ITEM_9MMAMMO; // First non-weapon item
  firstpurgeablechunk = C_AGENT;
  plrmaxbatt = PLR_MAXBATT;

  // Init message pointers, item names & menu system
  setmsgptrs(msgptrs);
  initmenu();

  // Weapon/item etc. definitions
  loaddefs(0);

  // Sound FX, actor, frame definitions
  loadchunk(C_SOUNDS);
  loadchunk(C_ACTORS);
  loadchunk(C_FRAMES);

  // Common sprites
  loadsprites(C_WEAPON);
  loadsprites(C_ITEM);
  loadsprites(C_COMMON);

  settrigger({T_GAME, G_MENU, menu});

  resetmsg();
  goto titlescreen;
}

buffercategory(x)
{
  // Buffer all files in a category, until a file not found or REU memory full
  for (a = 0; a < 255; a++)
  {
    getcontrols();
    if (joystick & JOY_FIRE) break;
    makefilename();
    buffertoreu();
    if (flags) break;
  }
}


