//
// Useful subroutines
//

// Wait for A frames

wait(a)
{
  x = vmtime;
  while (vmtime - x < a)
  {
    release();
  }
}

// Wait for firebutton
waitfire()
{
  for (;;)
  {
    release();
    getfireclick();
    if (flags) break;
  }
}

// Default door entering (no locks etc.)

enterdoor()
{
  transportplayer();
}

// Usage of items other than weapons by player

useitems()
{
  // This is a trigger routine; variable 'a' is set with trigger ID

  switch (a)
  {
    case ITEM_MEDIKIT:
    // Must not be at full health
    if (acthp[ACTI_PLAYER] < PLR_MAXHP)
    {
      // Must either be healing complete or receiving prolonged damage
      if ((!acthptime[ACTI_PLAYER]) || (acthpdelta[ACTI_PLAYER] & 0x80))
      {
        acthptime[ACTI_PLAYER] = 7;
        acthpdelta[ACTI_PLAYER] = (PLR_MAXHP / 2) / 7;
        playsfx(SFX_HYPO);
        goto useitems_dec;
      }
    }
    break;

    case ITEM_BATTERY:
    // Must not be at full power
    if (actbatt[ACTI_PLAYER] < PLR_MAXBATT)
    {
      // Must either be recharging complete or receiving EMP damage
      if ((!plrbatttime) || (plrbattdelta & 0x80))
      {
        plrbatttime = 7;
        plrbattdelta = (PLR_MAXBATT / 2) / 7;
        playsfx(SFX_POWERUP);
        goto useitems_dec;
      }
    }
    break;
  }
}

useitems_dec()
{
  decreaseammo(invselect, 1);
}

// Set music within zone

setzonetune(a,x)
{
  zonemusic[x] = a;
  // Make change instantly active in the current zone
  playzonetune();
}

// Common enemy takedown routine: might drop rechargers/medikits instead of
// weapon
//
// Note the use of c_act variable as index: this is the actor number that
// called the script (may not be changed!)

dropmedikits()
{
  switch(random() & 15)
  {
    case 14:
    actwpn[c_act] = ITEM_BATTERY;
    break;

    case 15:
    actwpn[c_act] = ITEM_MEDIKIT;
    break;
  }
}

// Common gameover routine

gameover()
{
  gameon = 0;
  playgametune((tunenum & 8) | SONG_GAMEOVER);
  wait(5*12);
  cleartextscreen();
  stopallvm();
  spawn(titlescreen);
  goto menuexit_nosfx;
}

// Display game status

gamestatus()
{
  playsfx(SFX_SELECT);
  cleartextwindow();

  printfmttext({10,21,1,"Total Game Time   :  :",0,0xff});
  convert8bits(ti_hours);
  printbcddigits23(26);
  convert8bits(ti_minutes);
  printbcddigits23(29);
  convert8bits(ti_seconds);
  printbcddigits23(32);

  printfmttext({10,22,1,"Kills:    KO's:    Other:   ",0,0xff});
  convert8bits(td_lethal);
  printbcddigits123(56);
  convert8bits(td_nonlethal);
  printbcddigits123(65);
  convert8bits(td_nonorganic);
  printbcddigits123(75);

  printfmttext({10,23,1,"Conspiracy Unveiled    %",0,0xff});
  convert8bits(conspiracy >> 1);
  printbcddigits123(110);

  waitfire();
}


