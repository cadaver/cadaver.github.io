//
// Item names & menu texts (in the first bank, that's always resident)
//

#define MSG_LOADERROR   2
#define MSG_OFF         3
#define MSG_ON          4
#define MSG_MUSIC       5
#define MSG_SOUND       6
#define MSG_GORE        7
#define MSG_NEWGAME     8
#define MSG_LOADGAME    9
#define MSG_SAVEGAME    10
#define MSG_ENDGAME     11
#define MSG_EXITGAME    12
#define MSG_DIFF0       13
#define MSG_DIFF1       14
#define MSG_DIFF2       15
#define MSG_EXITMENU    16
#define MSG_CONFIRM     17
#define MSG_CANCEL      18
#define MSG_VIEWSTATUS  19
#define MSG_GAME        20
#define MSG_FIRSTITEM   21


msgptrs:
  {
    msg_pickedup,
    msg_plus,
    msg_gameerror,
    msg_off,
    msg_on,
    msg_music,
    msg_sound,
    msg_gore,
    msg_newgame,
    msg_loadgame,
    msg_savegame,
    msg_endgame,
    msg_exitgame,
    msg_diff0,
    msg_diff1,
    msg_diff2,
    msg_exitmenu,
    msg_confirm,
    msg_cancel,
    msg_viewstatus,
    msg_game,
    itemname0,
    itemname1,
    itemname2,
    itemname3,
    itemname4,
    itemname5,
    itemname6,
    itemname7,
    itemname8,
    itemname9,
    itemname10,
    itemname11,
    itemname12,
    itemname13,
    itemname14,
    itemname15,
    itemname16
  }

msg_pickedup:   {MSG_TIME,"Picked up ",0}
msg_gameerror:  {MSG_TIME,"Game file not found",0}
msg_plus:       {" + ",0}
msg_off:        {" Off",0}
msg_on:         {" On",0}
msg_music:      {"Music",0}
msg_sound:      {"Sound",0}
msg_gore:       {"Gore",0}
msg_newgame:    {"New Game",0}
msg_loadgame:   {"Load Game",0}
msg_savegame:   {"Save Game",0}
msg_endgame:    {"End Game",0}
msg_exitgame:   {"End Session",0}
msg_diff0:      {"Recruit (Easy)",0}
msg_diff1:      {"Agent (Medium)",0}
msg_diff2:      {"BlackOps (Hard)",0}
msg_exitmenu:   {"Exit Menu",0}
msg_confirm:    {"Confirm",0}
msg_cancel:     {"Cancel",0}
msg_viewstatus: {"View Status",0}
msg_game:       {"Game ",0}

itemname0:      {0}
itemname1:      {"Fists",0}
itemname2:      {"Baton",0}
itemname3:      {"Knife",0}
itemname4:      {"Katana",0}
itemname5:      {"Shuriken",0}
itemname6:      {"Grenades",0}
itemname7:      {"Dart Gun",0}
itemname8:      {"9mm Pistol",0}
itemname9:      {"9mm SMG",0}
itemname10:     {"Shotgun",0}
itemname11:     {"9mm Ammo",0}
itemname12:     {"12 Gauge Ammo",0}
itemname13:     {"Tranq. Darts",0}
itemname14:     {"First Aid Kit",0}
itemname15:     {"Battery Charger",0}
itemname16:     {"Scroll",0}
