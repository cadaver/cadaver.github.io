//
// CovertEngine chunk file: sound effects.
// To be compiled with -h -o options as a chunk file.
//

#include "mw4def.cs"

chunk(SFX_FOOTSTEP)
{
  #include "music/footstep.sfx"
}

chunk(SFX_JUMP)
{
  #include "music/jump.sfx"
}

chunk(SFX_DART)
{
  #include "music/dart.sfx"
}

chunk(SFX_SELECT)
{
  #include "music/select.sfx"
}

chunk(SFX_COCKWEAPON)
{
  #include "music/cock.sfx"
}

chunk(SFX_COCKFAST)
{
  #include "music/cockfast.sfx"
}

chunk(SFX_INSERTAMMO)
{
  #include "music/ammo.sfx"
}

chunk(SFX_INSERTCLIP)
{
  #include "music/clip.sfx"
}

chunk(SFX_PICKUP)
{
  #include "music/pickup.sfx"
}

chunk(SFX_HYPO)
{
  #include "music/hypo.sfx"
}

chunk(SFX_POWERUP)
{
  #include "music/powerup.sfx"
}

chunk(SFX_GRENADE)
{
  #include "music/grenade.sfx"
}

chunk(SFX_PUNCH)
{
  #include "music/punch.sfx"
}

chunk(SFX_THROW)
{
  #include "music/throw.sfx"
}

chunk(SFX_MELEE)
{
  #include "music/melee.sfx"
}

chunk(SFX_DAMAGE)
{
  #include "music/damage.sfx"
}

chunk(SFX_ALARM)
{
  #include "music/alarm.sfx"
}

chunk(SFX_GLASS)
{
  #include "music/glass.sfx"
}

chunk(SFX_PISTOL)
{
  #include "music/pistol.sfx"
}

chunk(SFX_SHOTGUN)
{
  #include "music/shotgun.sfx"
}

chunk(SFX_SMG)
{
  #include "music/smg.sfx"
}

chunk(SFX_TAKEDOWN)
{
  #include "music/takedown.sfx"
}

chunk(SFX_EXPLOSION)
{
  #include "music/explosio.sfx"
}


