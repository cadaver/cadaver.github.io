//
// Agents of Metal Preview ingame code
//

// Plotbits in use by the preview

#define B_INTRO 0
#define B_DOJOEXPLAIN 1
#define B_NOKATANA 2
#define B_SPARRED 3
#define B_NINJAS 4
#define B_MISSIONGIVEN 5
#define B_BOSSELIMINATED 6
#define B_ENTERCAVE 7

// Variables in use by the preview

var conspiracy; // Game complete percentage
var ninjaseliminated;
var bosseliminated;

newgame()
{
  endconv();

  initactors();
  loadsprites(C_AGENT);
  createactor(ACTI_PLAYER,ACT_AGENT,ID_AGENT);  // Create & init the Agent
  initcomplexactor(ACTI_PLAYER);
  actgrp[ACTI_PLAYER] = GRP_AGENTS;             // Agent belongs to Agents :)

  initinventory();
  additem(ITEM_FISTS,0);
  additem(ITEM_PISTOL,0);
  additem(ITEM_9MMAMMO,30);
  updatepanel();

  conspiracy = 0;                   // Clear "conspiracy unveiled" percentage

  td_nonlethal = 0;                 // Clear takedown counters
  td_lethal = 0;
  td_nonorganic = 0;

  for (x = 0; x < 4; x++)           // Clear total game time
  {
    ti_frame[x] = 0;
  }

  for (x = 0; x < 128; x++)         // Clear all plotbits
  {
    clearbit(x);
    clearbit(x+128);
  }
  gameon = 1;
  goto dojo_init;
}

dojo_init()
{
  playgametune(SONG_STOP);

  cleartriggers();
  settrigger({T_NEAR,ID_STUDENT1,dojo_studentnear});
  settrigger({T_APPEAR,ID_STUDENT1,dojo_studentappear});
  settrigger({T_CONV,ID_STUDENT1,dojo_studentconv});
  settrigger({T_CONV,ID_STUDENT2,dojo_student2conv});
  settrigger({T_CONV,ID_STUDENT3,dojo_student3conv});
  settrigger({T_CONV,ID_STUDENT4,dojo_student4conv});
  settrigger({T_CONV,ID_STUDENT5,dojo_student2conv});
  settrigger({T_CONV,ID_STUDENT6,dojo_student3conv});
  settrigger({T_CONV,ID_STUDENT7,dojo_student4conv});
  settrigger({T_CONV,ID_STUDENT8,dojo_meditateconv});
  settrigger({T_NEAR,ID_SOKE,dojo_sokenear});
  settrigger({T_POSTATTACK,ID_SOKE,dojo_sokecalmdown});
  settrigger({T_POSTATTACK,ID_AGENT,dojo_agentcalmdown});
  settrigger({T_TAKEDOWN,ID_NINJA1,dojo_ninjadown});
  settrigger({T_TAKEDOWN,ID_NINJA2,dojo_ninjadown});
  settrigger({T_TAKEDOWN,ID_NINJA3,dojo_masterninjadown});
  settrigger({T_GAME,G_LOAD,dojo_mapmods});
  settrigger({T_DOOR,13,dojo_entercave});
  settrigger({T_DOOR,14,dojo_entercave});
  setcommontriggers();

  loadlevel(0,0);
  loadsprites(C_STUDENTM);
  loadsprites(C_STUDENTF);
  loadsprites(C_SOKE);
  loadsprites(C_NINJA);

  hideactortype(ACT_NINJA);
  hideactortype(ACT_MASTERNINJA);
  ninjaseliminated = 0;
  hostileenv = 0;                   // Initially nonhostile enviroment

  // Set enemy hitpoints according to difficulty
  setactorbyte(ACT_NINJA,AD_DEFAULTHP,12+difficulty*4);
  setactorbyte(ACT_MASTERNINJA,AD_DEFAULTHP,64+difficulty*16);

  // Enemies attack more on higher levels
  setactorbyte(ACT_NINJA,AD_ATTACKPROB,$20+difficulty*8);
  setactorbyte(ACT_NINJA,AD_MELEEPROB,$90+difficulty*12);
  setactorbyte(ACT_NINJA,AD_DUCKATTACKPROB,$40+difficulty*8);
  setactorbyte(ACT_MASTERNINJA,AD_ATTACKPROB,$28+difficulty*8);
  setactorbyte(ACT_MASTERNINJA,AD_MELEEPROB,$90+difficulty*12);
  setactorbyte(ACT_MASTERNINJA,AD_DUCKATTACKPROB,$48+difficulty*8);

  // They also evade more on higher levels
  setactorbyte(ACT_NINJA,AD_DUCKPROB,$f8-difficulty*16);
  setactorbyte(ACT_MASTERNINJA,AD_DUCKPROB,$e8-difficulty*16);

  actd[ACTI_PLAYER] = 0;            // Player facing right
  destdoornum = 2;                  // Starting door
  transportplayer();
}

dojo_studentnear()
{
  triggerfocus();
  if (!checkbit(B_INTRO))
  {
    setbit(B_INTRO);
    beginconv();
    conspiracy += 50;
    say({NPC_TIME,34,
      "Welcome to the Agent martial arts training camp. Soke Ryu will "
      "see you in the Dojo at far right.",34,0
    });
    endconv();
  }
  neartriggerdone();
}

dojo_studentappear()
{
  triggerfocus();
  if (actmode[act] == M_SPARSEARCH) dojo_sparwithplayer();
}

dojo_studentconv()
{
  triggerfocus();

  if (checkbit(B_NINJAS))
    goto dojo_underattackconv;

  beginconv();
  if (actmode[act] == M_SPAR)
  {
    actmode[act] = M_IDLE;
    gototarget(ID_AGENT);

    say({NPC_TIME,34,"Had enough already?",34,0});
    addchoice(0,{PLR_TIME,34,"No, let's go on.",34,0});
    addchoice(1,{PLR_TIME,34,"Yeah.",34,0});

    switch(waitchoice())
    {
      case 0:
      dojo_sparwithplayer();
      break;

      case 1:
      actmode[act] = M_SIT; // Back to meditation
    }
  }
  else
  {
    if (checkbit(B_INTRO))
    {
      addchoice(0, {PLR_TIME,34,"Excuse me, where was that Soke again?",34,0});
    }
    addchoice(1, {PLR_TIME,34,"What are you meditating?",34,0});
    if (!checkbit(B_SPARRED))
    {
      if (!checkbit(B_NOKATANA))
      {
        addchoice(2, {PLR_TIME,34,"Interested in sparring?",34,0});
      }
      else
      {
        if (finditem(ITEM_KATANA))
        {
          addchoice(5, {PLR_TIME,34,"Now I have a Katana.",34,0});
        }
      }
    }
    else
      addchoice(2, {PLR_TIME,34,"Care to spar again?",34,0});
    if (!checkbit(B_DOJOEXPLAIN))
      addchoice(3, {PLR_TIME,34,"I thought Agents wouldn't need this Dojo stuff.",34,0});
    addchoice(4, {PLR_TIME,34,"Never mind.",34,0});

    switch(waitchoice())
    {
      case 0:
      say({NPC_TIME,34,
        "The big building at the far right of this area. You "
        "can't miss it. He should be upstairs.",34,0
      });
      break;

      case 1:
      switch(random() & 3)
      {
        case 0:
        say({NPC_TIME,34,"The perfect throw of the Shuriken.",34,0});
        break;
        case 1:
        say({NPC_TIME,34,"The delicate balance between Good & Evil.",34,0});
        break;
        case 2:
        say({NPC_TIME,34,"I'm focusing on the Sign of the Gun.",34,0});
        break;
        case 3:
        say({NPC_TIME,34,"I'm preparing for my next mission.",34,0});
      }
      break;

      case 2:
      if (!finditem(ITEM_KATANA))
      {
        say({NPC_TIME,34,
          "Sure. But get yourself a Katana from inside that hut first.",34,0
        });
        setbit(B_NOKATANA);
      }
      else
      {
        say({NPC_TIME,34,"Sure. Let's begin.",34,0});
        dojo_sparwithplayer();
      }
      break;

      case 3:
      say({NPC_TIME,34,
        "We Agents have our Guns, and that's enough? No, that's not "
        "correct. An Agent who has cultivated his mind through the "
        "training of martial arts will have an edge.",34,0
      });
      setbit(B_DOJOEXPLAIN);
      break;

      case 5:
      say({NPC_TIME,34,"Good. Let's begin.",34,0});
      dojo_sparwithplayer();
    }
  }
  endconv();
}

dojo_student2conv()
{
  triggerfocus();
  if (checkbit(B_NINJAS)) goto dojo_underattackconv;
  switch(random() & 3)
  {
    case 0: say({BARK_TIME,34,"you're the new guy?",34,0});
    break;
    case 1: say({BARK_TIME,34,"You'll learn the art of the blade.",34,0});
    break;
    case 2: say({BARK_TIME,34,"Ki is equally important to agents & ninjas.",34,0});
    break;
    case 3: say({BARK_TIME,34,"Visit http://www. realultimatepower.net",34,0});
  }
}

dojo_student3conv()
{
  triggerfocus();
  if (checkbit(B_NINJAS)) goto dojo_underattackconv;
  switch(random() & 3)
  {
    case 0: say({BARK_TIME,34,"An Agent doesn't always have to kill.",34,0});
    break;
    case 1: say({BARK_TIME,34,"Have you run into S.C.E.P.T.R.E yet?",34,0});
    break;
    case 2: say({BARK_TIME,34,"Watch and learn, Agent.",34,0});
    break;
    case 3: say({BARK_TIME,34,"We're busy training.",34,0});
  }
}

dojo_student4conv()
{
  triggerfocus();
  if (checkbit(B_NINJAS)) goto dojo_underattackconv;
  switch(random() & 3)
  {
    case 0: say({BARK_TIME,34,"That statue inspires.",34,0});
    break;
    case 1: say({BARK_TIME,34,"The gun is still an Agent's primary weapon.",34,0});
    break;
    case 2: say({BARK_TIME,34,"We're using blanks. for now.",34,0});
    break;
    case 3: say({BARK_TIME,34,"Seen any Ninjas?",34,0});
  }
}

dojo_meditateconv()
{
  triggerfocus();
  if (checkbit(B_NINJAS)) goto dojo_underattackconv;
  switch(random() & 7)
  {
    case 0: say({BARK_TIME,34,"The S.C.E.P.T.R.E is vast.",34,0});
    break;
    case 1: say({BARK_TIME,34,"We Agents are yet a small organization.",34,0});
    break;
    case 2: say({BARK_TIME,34,"Freedom, Metal and Might - brave ideals.",34,0});
    break;
    case 3: say({BARK_TIME,34,"Conspiracies of and out of this world...",34,0});
    break;
    case 4: say({BARK_TIME,34,"Soon you'll feel your Ki growing stronger.",34,0});
    break;
    case 5: say({BARK_TIME,34,"This place replenishes the Mind & Soul.",34,0});
    break;
    case 6: say({BARK_TIME,34,"An Agent can trust only the Gun and the Blade.",34,0});
    break;
    case 7: say({BARK_TIME,34,"The Soke will teach you much.",34,0});
  }
}

dojo_sparwithplayer()
{
  setbit(B_SPARRED);
  acttarget[act] = ACTI_PLAYER;
  actmode[act] = M_SPAR;
}

dojo_sokecalmdown()
{
  triggerfocus();
  actmode[act] = M_SIT;
}

dojo_agentcalmdown()
{
  triggerfocus();
  actmode[act] = M_IDLE;
}

dojo_sokenear()
{
  triggerfocus();
  if (!checkbit(B_NINJAS))
  {
    beginconv();
    say({NPC_TIME,34,"Ahm, field Agent Steel. I have seen recordings "
            "of your performance. You have skill, but lack "
            "the calm, effective quality of those who have "
            "practiced agent martial arts with diligence. but "
            "that will change now. This week you'll spend - ",34,0});
    setbit(B_NINJAS);
    conspiracy += 50;
    hostileenv = 1;
    unhideactors();

    // Add the Ninjas separately beforehand so that we can modify their
    // properties (the jump)
    addactor(ID_NINJA1);
    focus(ID_NINJA1);
    actsx[act] = 8*8;
    actsy[act] = -6*8;

    addactor(ID_NINJA2);
    focus(ID_NINJA2);
    actsx[act] = -8*8;
    actsy[act] = -6*8;

    dojo_mapmods();
    playsfx(SFX_GLASS);
    endconv();

    focus(ID_SOKE);
    actmode[act] = M_ALERT;
    say({BARK_TIME,34,"The assassins of S.C.E.P.T.R.E! Fight!",34,0});

    setzonetune(MF_DOJO+SONG_FIGHT, 0);
    setzonetune(MF_DOJO+SONG_FIGHT, 1);
    setzonetune(MF_DOJO+SONG_FIGHT, 2);
  }
  else
  {
    if (ninjaseliminated >= 2)
    {
      if (checkbit(B_BOSSELIMINATED))
      {
        conspiracy += 50;
        setzonetune(MF_DOJO+SONG_EXPLORE, 2);

        beginconv();
        focus(ID_AGENT);
        say({NPC_TIME,34,"I eliminated the Ninja who was about to steal the Scroll.",34,0});
        focus(ID_SOKE);
        say({NPC_TIME,34,"That was courageous, Agent. I'm sure it was a good fight.",34,0});

        goto previewcomplete;
      }
      if (finditem(ITEM_SCROLL))
      {
        conspiracy += 50;
        setzonetune(MF_DOJO+SONG_EXPLORE, 2);

        beginconv();
        focus(ID_AGENT);
        say({NPC_TIME,34,"A Ninja was about to steal the Scroll, "
                "but I got it first.",34,0});
        focus(ID_SOKE);
        say({NPC_TIME,34,"Good work, Agent. At times Combat to the End isn't "
                "the best alternative.",34,0});

        goto previewcomplete;
      }
      if (!checkbit(B_MISSIONGIVEN))
      {
        beginconv();
        say({NPC_TIME,34,
          "They must be after the Scrolls that describe "
          "the 'Way of the Agent' we practice here. The "
          "Scrolls must not fall into the wrong hands! They're "
          "hidden in a secret passage under the Agent statue - "
          "go check at once that the passage is undisturbed.",34,0});
        setbit(B_MISSIONGIVEN);
        endconv();
      }
    }
  }
  neartriggerdone();
}

dojo_mapmods()
{
  if (!checkbit(B_NINJAS)) return;

  // Break windows
  updateblock(0x39,68,11);
  updateblock(0x39,74,11);
  updateblock(0x39,67,16);
  updateblock(0x39,70,17);
  updateblock(0x39,74,16);

  // Open the secret door in the statue
  updateblock(0x58,34,4);
  updateblock(0x59,35,4);
  updateblock(0x5a,34,3);
  updateblock(0x5b,35,3);
}

dojo_underattackconv()
{
  switch(random() & 7)
  {
    case 0:
    say({BARK_TIME,34,"We're under attack!",34,0});
    break;
    case 1:
    say({BARK_TIME,34,"They're the Sectarian Elite!",34,0});
    break;
    case 2:
    say({BARK_TIME,34,"Fight with Power!",34,0});
    break;
    case 3:
    say({BARK_TIME,34,"Use your Blade!",34,0});
    break;
    case 4:
    say({BARK_TIME,34,"They're too many!",34,0});
    break;
    case 5:
    say({BARK_TIME,34,"Ninjas of the S.C.E.P.T.R.E!",34,0});
    break;
    case 6:
    say({BARK_TIME,34,"They'll pay for this!",34,0});
    break;
    case 7:
    say({BARK_TIME,34,"They're after the scrolls!",34,0});
  }
}

dojo_entercave()
{
  if (!checkbit(B_ENTERCAVE))
  {
    setbit(B_ENTERCAVE);
    conspiracy += 50;
  }
  transportplayer();
}

dojo_ninjadown()
{
  ninjaseliminated++;
}

dojo_masterninjadown()
{
  setbit(B_BOSSELIMINATED);
}

previewcomplete()
{
  focus(ID_AGENT);
  say({NPC_TIME,34,"But this S.C.E.P.T.R.E - what is it really?",34,0});
  focus(ID_SOKE);
  say({NPC_TIME,34,
    "S.C.E.P.T.R.E is the Sectarian "
    "Chosen Elite Privileged to Rule & Exterminate. It's an "
    "age-old secret society, bent on keeping mankind under "
    "its reign of terror. Its tentacles are everywhere. "
    "We Agents are not yet strong enough to attack S.C.E.P.T.R.E "
    "directly, but our time will come. Now you should rest, "
    "your training will commence tomorrow.",34,0});
  endconv();
  gameon = 0;
  initactors();
  cleartextscreen();
  playtune(MF_TITLE|SONG_EXPLORE);
  printfmttext({
    3,8,1, "Congratulations! You have finished",0,
    3,10,1,"   MW4:Agents of Metal preview.   ",0,0xff});
  neartriggerdone();
}
