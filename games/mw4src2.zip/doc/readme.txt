MW4 Preview version 2 sourcecode
--------------------------------

Released 14th August 2002.
Revised 1st September 2002.

All stuff (C) Lasse ��rni 2000-2002, except
SuperRAM code & parts of REU-code (C) Wolfram Sang 2002
"Agents of Metal"-concept (C) Lionel Gendre & Lasse ��rni 2001-2002.

It took some time, but at last the updated preview & source code have been
released. The most prominent feature of the new preview (although it doesn't
show externally in any way) is the CovertScript language, which is a C-like
language for programming all non-timecritical parts of the game: scripting,
highlevel logic, and part of the user interface.

This sourcecode release is "divided" into 2 parts:

- The MW4 engine (CovertEngine), consisting of all assembly language source-
  code (files with .s -extension), .txt files and the makefile in the root
  directory. This engine is freely usable for any C64 projects, including
  commercial use.

- The MW4 preview content: everything in BG,PICS,SPR,MUSIC subdirectories and
  all CovertScript source code files (files with .cs -extension in the root
  directory). This content may be used for learning but may NOT be directly
  used as a basis for any commercial project. Non-commercial use is allowed,
  but you should be critical of it; it's cooler to have your own content :)

Have fun examining the sourcecode! Somewhat full documentation of CovertEngine
(engine.txt) is included with this revised release.

What you need in recompiling: a 32bit port of DASM, the newest C64 utilities
package and GoatTracker for modifying music (http://covertbitops.cjb.net)
Note that the MW4-specific utilities are now part of the C64 utility collection
and therefore not in this package.

                                                   Lasse ��rni
                                                   loorni@student.oulu.fi

