//
// CovertEngine chunk file: frame sets for complex actors
// To be compiled with -h -o options as a chunk file.
//

#include "mw4def.cs"

chunk(FR_PLRLEGS)
{
  1,                                 // Amount of sprites
  44,                                // Amount of frames
  22,                                // Left frame add
  1,                                 // Continue flag
  29,30,31,32,30,31,32,36,37,38,33,34,35,41,42,41,42,36,39,40,43,42,
  44,45,46,47,45,46,47,51,52,53,48,49,50,56,57,56,57,51,54,55,58,57
}

chunk(FR_PLRTORSO)
{
  1,                                 // Amount of sprites
  64,                                // Amount of frames
  32,                                // Left frame add
  0,                                 // Continue flag
  0,1,1,0,2,2,0,3,2,0,3,3,3,11,12,13,12,4,4,5,14,0,
  6,7,8,9,10,21,22,23,24,25,
  15,16,16,15,17,17,15,18,17,15,18,18,18,26,27,28,27,19,19,20,29,15,
  21,22,23,24,25,6,7,8,9,10
}

chunk(FR_STUDENTLEGS)
{
  1,                                 // Amount of sprites
  44,                                // Amount of frames
  22,                                // Left frame add
  1,                                 // Continue flag
  24,25,26,27,25,26,27,29,29,29,28,28,28,24,25,24,25,29,30,31,32,33,
  34,35,36,37,35,36,37,39,39,39,38,38,38,34,35,34,35,39,40,41,32,33
}

chunk(FR_STUDENTTORSO)
{
  1,                                 // Amount of sprites
  64,                                // Amount of frames
  32,                                // Left frame add
  0,                                 // Continue flag
  0,1,1,0,2,2,0,3,2,0,3,3,3,0,0,0,0,4,4,5,11,12,
  6,7,8,9,10,19,20,21,22,23,
  13,14,14,13,15,15,13,16,15,13,16,16,16,13,13,13,13,17,17,18,11,12,
  19,20,21,22,23,6,7,8,9,10
}

chunk(FR_SOKETORSO)
{
  1,                                 // Amount of sprites
  64,                                // Amount of frames
  32,                                // Left frame add
  0,                                 // Continue flag
  0,1,1,0,2,2,0,3,2,0,3,3,3,0,0,0,0,1,1,2,9,10,
  4,5,6,7,8,15,16,17,18,19,
  11,12,12,11,13,13,11,14,13,11,14,14,14,11,11,11,11,12,12,13,9,10,
  15,16,17,19,10,4,5,6,7,8
}
