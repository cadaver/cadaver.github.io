//
// MW4:Agents of Metal Preview Menu system
//

#define MAX_MENUS 6

#define MENU_INVENTORY 0
#define MENU_OPTIONS 1
#define MENU_GAME 2
#define MENU_DIFF 3
#define MENU_GAMENUM 4
#define MENU_CONFIRM 5

var menuscreen;
var prevmenuitem;
var menuselect[MAX_MENUS];
var menuview[MAX_MENUS];
var menumaxchoices[MAX_MENUS];

// Menu routine

menu()
{
  // Update inventory pos & size
  menuselect[MENU_INVENTORY] = invselect;
  menumaxchoices[MENU_INVENTORY] = invsize;

  // Need to release firebutton to get into menu again
  menucounter = 0xff;

  // When game is on, pause while in menu
  if (gameon)
  {
    menuscreen = MENU_INVENTORY;
    pausemode = 1;
  }
  else
  {
    menuscreen = MENU_GAME;
  }
  resetmsg();

  for (;;)
  {
    playsfx(SFX_SELECT);

    menuredraw:

    // Menu redraw

    // Check for visibility
    temp = menuselect[menuscreen] - menuview[menuscreen];
    if (temp & 0x80)
    {
      menuview[menuscreen] = menuselect[menuscreen];
    }
    else
    {
      if (temp >= PANEL_ROWS)
      {
        menuview[menuscreen] = menuselect[menuscreen] - (PANEL_ROWS-1);
      }
    }

    // Draw all visible menuitems
    textwindowrow = 0;
    temp = menuview[menuscreen];
    drawmenurow();
    textwindowrow++;
    temp++;
    drawmenurow();
    textwindowrow++;
    temp++;
    drawmenurow();

    drawarrows(menuselect[menuscreen], menumaxchoices[menuscreen]);
    invselect = menuselect[MENU_INVENTORY];
    updateinventory();
    release();

    // Menu selection
    for (;;)
    {
      release();

      // Exit by spacebar
      if (keytype == KEY_SPACE) goto menuexit;

      if (!prevjoy)
      {
        // Submenu movement
        if ((gameon) && (menuscreen <= MENU_GAME))
        {
          if (joystick & JOY_LEFT)
          {
            menuscreen--;
            if (menuscreen & 0x80) menuscreen = MENU_GAME;
            break;
          }
          if (joystick & JOY_RIGHT)
          {
            menuscreen++;
            if (menuscreen > MENU_GAME) menuscreen = MENU_INVENTORY;
            break;
          }
        }
        // Selection of menu items
        if (joystick & JOY_FIRE)
        {
          // Inventory
          if (!menuscreen) goto menuexit;

          // Others
          temp = menuitems[firstmenuitem[menuscreen]+menuselect[menuscreen]];

          if (temp == MSG_EXITMENU) goto menuexit;
          if (temp == MSG_VIEWSTATUS) gamestatus();
          if (temp == MSG_NEWGAME) menuscreen = MENU_DIFF;
          if ((temp >= MSG_DIFF0) && (temp <= MSG_DIFF2))
          {
            difficulty = temp - MSG_DIFF0;
            stopallvm();
            spawn(newgame);
            goto menuexit;
          }
          if ((temp >= MSG_MUSIC) && (temp <= MSG_GORE))
          {
            musicmode[menuselect[menuscreen]] ^= 1;
            if (!menuselect[menuscreen]) togglemusic();
          }
          if ((temp == MSG_LOADGAME) || ((temp == MSG_SAVEGAME) && (gameon)))
          {
            prevmenuitem = temp;
            menuscreen = MENU_GAMENUM;
          }
          if ((temp == MSG_EXITGAME) || ((temp == MSG_ENDGAME) && (gameon)))
          {
            prevmenuitem = temp;
            menuscreen = MENU_CONFIRM;
          }
          if (temp == MSG_CONFIRM)
          {
            if (prevmenuitem == MSG_EXITGAME)
            {
              exitprogram();
            }
            else
            {
              stopallvm();
              spawn(titlescreen);
              goto menuexit;
            }
          }
          if (temp == MSG_GAME)
          {
            if (prevmenuitem == MSG_SAVEGAME)
            {
              savegame(menuselect[MENU_GAMENUM]);
              goto menuexit;
            }
            else
            {
              // This call never returns - VM state information is replaced
              loadgame(menuselect[MENU_GAMENUM]);

              // However, if it returns, it means the load failed.
              printmsg(MSG_LOADERROR);
              playsfx(SFX_SELECT);
              waitfire();
            }
          }

          if (temp == MSG_CANCEL) menuscreen = MENU_GAME;
          break;
        }
      }
      // Movement within menu
      if (joystick & JOY_UP)
      {
        if (menuselect[menuscreen])
        {
          menuselect[menuscreen]--;
          break;
        }
      }
      if (joystick & JOY_DOWN)
      {
        if (menuselect[menuscreen] < menumaxchoices[menuscreen])
        {
          menuselect[menuscreen]++;
          break;
        }
      }
    }
  }
  menuexit:
  playsfx(SFX_SELECT);
  menuexit_nosfx:
  cleartextwindow();
  pausemode = 0;
  menumode = 0;
}

drawmenurow()
{
  textwindowcolumn = textwindowleft;

  // Draw the menu selection arrow
  if (temp == menuselect[menuscreen])
  {
    ptw_outputchar(31);
  }
  else
  {
    ptw_outputchar(32);
  }

  // Draw the menu choice name
  if (temp <= menumaxchoices[menuscreen])
  {
    if (!menuscreen) // Inventory
    {
      getitemname(invtype[temp]);
      ptw_continue();
    }
    else
    {
      getmsgptr(menuitems[firstmenuitem[menuscreen]+temp]);
      ptw_continue();
      if (menuscreen == MENU_OPTIONS)
      {
        if (temp < 3)
        {
          getmsgptr(MSG_OFF+musicmode[temp]);
          ptw_continue();
        }
      }
      if (menuscreen == MENU_GAMENUM)
      {
        if (temp < 8) ptw_outputchar('1'+temp);
      }
    }
  }
  ptw_clearrestofrow();
}


menuitems:
{
  // Options menu
  MSG_MUSIC, MSG_SOUND, MSG_GORE, MSG_EXITMENU,
  // Game menu
  MSG_VIEWSTATUS, MSG_NEWGAME, MSG_LOADGAME, MSG_SAVEGAME, MSG_ENDGAME, MSG_EXITGAME, MSG_EXITMENU,
  // Difficulty menu
  MSG_DIFF0, MSG_DIFF1, MSG_DIFF2, MSG_EXITMENU,
  // Game number menu
  MSG_GAME, MSG_GAME, MSG_GAME, MSG_GAME, MSG_GAME, MSG_GAME, MSG_GAME, MSG_GAME, MSG_EXITMENU,
  // Confirm menu
  MSG_CONFIRM, MSG_CANCEL
}

firstmenuitem:
{
  0, 0, 4, 11, 15, 24, 26
}
