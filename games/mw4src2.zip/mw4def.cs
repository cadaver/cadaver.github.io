//
// MW4:Agents of Metal Preview definitions
//

// Player's health
#define PLR_MAXHP       56
#define PLR_MAXBATT     56

// Actor numbers
#define ACT_MELEEHIT    8
#define ACT_BULLET      9
#define ACT_SHURIKEN    10
#define ACT_DART        11
#define ACT_GRENADE     12
#define ACT_AGENT       13
#define ACT_STUDENTM1   14
#define ACT_STUDENTM2   15
#define ACT_STUDENTM3   16
#define ACT_STUDENTF1   17
#define ACT_STUDENTF2   18
#define ACT_STUDENTF3   19
#define ACT_SOKE        20
#define ACT_NINJA       21
#define ACT_MASTERNINJA 22

// Frameset numbers (for complex actors)
#define FR_PLRLEGS      0
#define FR_PLRTORSO     1
#define FR_STUDENTLEGS  2
#define FR_STUDENTTORSO 3
#define FR_SOKETORSO    4

// Item numbers
#define ITEM_NONE       0
#define ITEM_FISTS      1
#define ITEM_BATON      2
#define ITEM_KNIFE      3
#define ITEM_KATANA     4
#define ITEM_SHURIKEN   5
#define ITEM_GRENADE    6
#define ITEM_DARTGUN    7
#define ITEM_PISTOL     8
#define ITEM_SMG        9
#define ITEM_SHOTGUN    10
#define ITEM_9MMAMMO    11
#define ITEM_12GAUGEAMMO 12
#define ITEM_DARTS      13
#define ITEM_MEDIKIT    14
#define ITEM_BATTERY    15
#define ITEM_SCROLL     16

// Bullet numbers
#define BLT_FISTHIT     0
#define BLT_KNIFEHIT    1
#define BLT_KATANAHIT   2
#define BLT_9MM         3
#define BLT_DART        4
#define BLT_BATONHIT    5
#define BLT_SHURIKEN    6
#define BLT_SHOTGUN1    7
#define BLT_SHOTGUN2    8
#define BLT_GRENADE     9

// Special damage types
#define SPDMG_DARTS     0

// Bullet damages
#define DMG_FISTS       3
#define DMG_BATON       4
#define DMG_KNIFE       5+DMG_LETHAL
#define DMG_9MM         6+DMG_LETHAL
#define DMG_9MMAUTO     4+DMG_LETHAL
#define DMG_KATANA      8+DMG_LETHAL
#define DMG_SHURIKEN    5+DMG_LETHAL
#define DMG_DART        SPDMG_DARTS+DMG_SPECIAL
#define DMG_SHOTGUN     6+DMG_LETHAL
#define DMG_GRENADE     24+DMG_LETHAL

// Weapon spriteframes
#define WF_PISTOL       0
#define WF_SMG          12
#define WF_KNIFE        24
#define WF_KATANA       28
#define WF_DARTGUN      37
#define WF_BATON        43
#define WF_SHOTGUN      50

// Groups
#define GRP_AGENTS      1
#define GRP_NINJAS      2

// NPC actor IDs
#define ID_NONE         0
#define ID_AGENT        1
#define ID_SOKE         2
#define ID_STUDENT1     3
#define ID_STUDENT2     4
#define ID_STUDENT3     5
#define ID_STUDENT4     6
#define ID_STUDENT5     7
#define ID_STUDENT6     8
#define ID_STUDENT7     9
#define ID_STUDENT8     10
#define ID_NINJA1       11
#define ID_NINJA2       12
#define ID_NINJA3       13

// Default textspeeds for conversation & messages
#define INF_TIME        0xff    // Indefinite
#define NPC_TIME        0xff    // Indefinite
#define BARK_TIME       60      // 5 seconds
#define MSG_TIME        25      // 2 seconds
#define PLR_TIME        25      // 2 second

// Music files
#define MF_TITLE        0
#define MF_DOJO         8

// Subtunes
#define SONG_EXPLORE    1
#define SONG_FIGHT      2
#define SONG_GAMEOVER   3
#define SONG_CAVE       4

// Sprite chunk numbers
#define C_COMMON        5
#define C_AGENT         6
#define C_STUDENTM      7
#define C_STUDENTF      8
#define C_SOKE          9
#define C_NINJA         10

// Sound effects
#define SFX_DART        5
#define SFX_SELECT      6
#define SFX_COCKWEAPON  7
#define SFX_COCKFAST    8
#define SFX_INSERTAMMO  9
#define SFX_INSERTCLIP  10
#define SFX_HYPO        11
#define SFX_POWERUP     12
#define SFX_GRENADE     13
#define SFX_PUNCH       14
#define SFX_THROW       15
#define SFX_MELEE       16
#define SFX_ALARM       17
#define SFX_GLASS       18
#define SFX_PISTOL      19
#define SFX_SHOTGUN     20
#define SFX_SMG         21
#define SFX_TAKEDOWN    22
