//
// Conversation routines
//

#define MAX_CHOICES 8

var maxchoices;
var choicenum;
var chid;

var choiceid[MAX_CHOICES];
var choicel[MAX_CHOICES];
var choicem[MAX_CHOICES];
var choiceh[MAX_CHOICES];

// Begin conversation

beginconv()
{
  // Make sure player is idle and doesn't attack other actors
  // randomly (going to conversation mode switch the player to AI control)

  actmode[ACTI_PLAYER] = M_IDLE;
  actlastdmg[ACTI_PLAYER] = 0xff;
  convmode = CM_CONVERSATION;
  maxchoices = 0;
}

// End conversation

endconv()
{
  convmode = CM_INTERACTIVE;
  resetmsg();
}

// Add conversation choice


addchoice(chid,ptr)
{
  if (maxchoices < MAXCHOICES)
  {
    choiceid[maxchoices] = chid;
    choicel[maxchoices] = y; // Pointer parameter is passed in y,x,a
    choicem[maxchoices] = x;
    choiceh[maxchoices] = a;
    maxchoices++;
  }
}

// Wait for player conversation choice

waitchoice a()
{
  choicenum = 0;

  resetmsg();
  for (;;)
  {
    playsfx(SFX_SELECT);

    // Choice redraw
    textwindowright--; // Make room for the arrows
    getchoiceptr();
    printmsgnoptr();
    textwindowright++;
    drawarrows(choicenum, maxchoices-1);
    release();

    for (;;)
    {
      release();

      if (joystick & (JOY_LEFT|JOY_UP))
      {
        if (choicenum)
        {
          choicenum--;
          break;
        }
      }
      if (joystick & (JOY_RIGHT|JOY_DOWN))
      {
        if (choicenum < maxchoices-1)
        {
          choicenum++;
          break;
        }
      }
      getfireclick();
      if (flags) goto choicemade;
    }
  }

  choicemade:
  // Say player's line and display balloon
  getchoiceptr();
  saynoptr();
  spawnballoon(ACTI_PLAYER);
  saywait();
  maxchoices = 0;
  return choiceid[choicenum];
}

getchoiceptr()
{
  y = choicel[choicenum]; // Pointer parameter is passed in y,x,a
  x = choicem[choicenum];
  a = choiceh[choicenum];
}

// Say

say(ptr)
{
  saynoptr();
  saywait();
}

saywait()
{
  // Break if not in conversation (bark)
  if (!convmode) return;

  // Wait until text window clear, speed up with firebutton
  while (msgtime | msgcont)
  {
    release();
    getfireclick();
    if (flags) msgtime = 1; // Speed up texts
  }
}

// Say idle bark

sayidle(ptr)
{
  sayidlenoptr();
  // Wait until text window clear
  while (msgtime | msgcont)
  {
    release();
  }
}
