//
// MW4:Agents of Metal Preview Title Screen
//

// Wait for A frames, while checking cheatstring

var cheatindex;
var temp;

titlewait(x)
{
  y = vmtime;
  while (vmtime - y < x)
  {
    if ((keytype != KEY_NONE) && (!menumode))
    {
      if (keytype == cheatstring[cheatindex])
      {
        cheatindex++;
        if (cheatstring[cheatindex] == KEY_NONE)
        {
          // Make player invincible
          temp = getactorbyte(ACT_AGENT,AD_FIGHTBITS) ^ AFB_INVINCIBLE;
          setactorbyte(ACT_AGENT,AD_FIGHTBITS,temp);

          printmsgptr({MSG_TIME, "Cheat mode ",0});
          if (temp & AFB_INVINCIBLE)
            printmsgcont({"on",0});
          else
            printmsgcont({"off",0});

          cheatindex = 0;
        }
      }
      else cheatindex = 0;
    }
    release();
  }
}

cheatstring:
{
  KEY_J,
  KEY_C,
  KEY_D,
  KEY_E,
  KEY_N,
  KEY_T,
  KEY_O,
  KEY_N,
  KEY_NONE
}

// Title screen loop

titlescreen()
{
  initactors();
  endconv();
  gameon = 0;
  cheatindex = 0;

  menuselect[MENU_GAME] = 1; // New Game
  playtune(MF_TITLE|SONG_EXPLORE);

  for(;;)
  {
    cleartextscreen();
    printfmttext({
      9,9,1,  "Covert BitOps Presents",0,0xff
    });
    titlewait(3*12);

    cleartextscreen();
    printfmttext({
      22,1,1,75,0,
      18,2,1,76,77,78,79,80,0,
      18,3,1,81,82,83,84,85,0,
      8,6,1,  "Agents of Metal Preview 2",0,
      7,7,1,  "http://covertbitops.cjb.net",0,
      4,10,1,  "Agent Concept .... Lionel Gendre",0,
      4,11,1, "                   & Lasse \\rni",0,
      4,12,1, "Code,Gfx,Music ... Lasse \\rni",0,
      4,13,1, "SuperRAM Code .... Wolfram Sang",0,
      11,16,1,"Press Fire to Start",0,0xff
    });
    titlewait(10*12);

    cleartextscreen();
    printfmttext({
      0,0,1,  "       Thanks for Agent evidence:",0,
      0,2,1,  "Fastloaders .. Marko M[kela, Krzysztof",0,
      0,3,1,  "               Matula, Magnus Lind,",0,
      0,4,1,  "               Nathan Smith, Gunnar",0,
      0,5,1,  "               Ruthenberg, Kovacs Balazs",0,
      0,7,1,  "SuperCPU ..... Stefan Gutsch",0,
      0,9,1,  "Extra RAM .... Wolfram Sang",0,
      0,11,1, "VM/Compiler .. Jan Niestadt",0,
      0,13,1, "Compression .. Pasi Ojala, Magnus Lind",0,
      0,15,1, "Inspiration .. Roman Chlebec, Michael",0,
      0,16,1, "               Durrer, Richard Bayliss,",0,
      0,17,1, "               Agent Steel, Warren",0,
      0,18,1, "               Spector + Deus Ex Team",0,0xff
    });
    titlewait(10*12);

    cleartextscreen();
    printfmttext({
      0,2,1,  "Welcome to MW4:Agents of Metal preview.",0,
      0,4,1,  "This is a stand-alone mission that will",0,
      0,6,1,  "not actually appear in the full game.",0,
      0,8,1,  "The mission takes place 10 years before",0,
      0,10,1, "the events of the full game. You take",0,
      0,12,1, "the role of field Agent ",34,"Codename Steel",34,0,
      0,14,1, "who has been sent to the Agent Dojo for",0,
      0,16,1, "further training in martial arts.",0,0xff
    });
    titlewait(15*12);

    cleartextscreen();
    printfmttext({
      0,1,1,  "Use joystick in port 2 or keys QWEADZXC",0,
      0,3,1,  "+ Shift to control your Agent. Controls",0,
      0,5,1,  "without firebutton:",0,
      0,9,1,  "                 Climb                  ",0,
      0,11,1, "Jump Left                     Jump Right",0,
      0,13,1, "Go Left            +            Go Right",0,
      0,15,1, "Sneak Left                   Sneak Right",0,
      0,17,1, "          Climb/Crouch/Pick Up          ",0,0xff
    });
    titlewait(15*12);

    cleartextscreen();
    printfmttext({
      0,1,1,  "Controls with firebutton:",0,
      0,5,1,  "           Enter door/talk to           ",0,
      0,7,1,  "Attack Up-Left           Attack Up-Right",0,
      0,9,1,  "Attack Left        +        Attack Right",0,
      0,11,1, "Attack Down-Left       Attack Down-Right",0,
      0,13,1, "         Use Item/Reload Weapon         ",0,
      0,17,1, "Fire button alone does not attack, but",0,0xff
    });
    titlewait(15*12);

    cleartextscreen();
    printfmttext({
      0,1,1,  "enters the ingame menu instead if held",0,
      0,3,1,  "down for 1/2 second. Space bar also",0,
      0,5,1,  "enters/exits the menu. The ingame menu",0,
      0,7,1,  "contains 3 submenus:",0,
      0,11,1, "Inventory - Select items & weapons",0,
      0,13,1, "Options   - Toggle music,sound etc.",0,
      0,15,1, "Game      - Start,load,save,exit game",0,
      0,17,1, "Press Left/Right to switch submenus.",0,0xff
    });
    titlewait(15*12);

    cleartextscreen();
    printfmttext({
      0,2,1,  "Note that you have two energy bars. The",0,
      0,4,1,  "upper is Agent's health and the lower is",0,
      0,6,1,  "the Electromagnetic Ballistic Shield",0,
      0,8,1,  "(hidden in Agent's trenchcoat) power.",0,
      0,10,1, "Use first aid kits to replenish health",0,
      0,12,1, "and battery rechargers to restore power.",0,
      0,16,1, "Good luck on your agent missions!",0,0xff
    });
    titlewait(15*12);
  }
}

