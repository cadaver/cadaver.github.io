//
// MW4 engine extern definitions
//

// VM control & trigger functions
extern release();
extern spawn(ptr);
extern stopallvm();
extern cleartriggers();
extern settrigger(ptr);
extern neartriggerdone();

// System-related
extern loadgame(a);
extern savegame(a);
extern exitprogram();

// Math functions
extern random a();

// Screen & functions
extern cleartextscreen();
extern printfmttext(ptr);
extern setblanking();
extern setredraw();
extern updateblock(a,x,y);

// Message/message window/menu functions
extern resetmsg();
extern cleartextwindow();
extern printmsgcont(ptr);
extern printmsgptr(ptr);
extern printmsgnoptr();
extern printmsg(a);
extern setmsgptrs(ptr);
extern ptw_continue();
extern ptw_clearrestofrow();
extern ptw_outputchar(a);
extern getmsgptr(a);
extern getitemname(a);
extern drawarrows(a,x);

// BCD conversion & number printing
extern convert8bits(a);
extern convert16bits(a,x);
extern printbcddigits(y,x);
extern printbcddigit(y,x);
extern printbcddigits123(x);
extern printbcddigits23(x);

// Loading functions
extern makefilename();
extern openfile();
extern getbyte a();
extern buffertoreu();                     // Will be overwritten by sprites!
extern loadlevel(a,x);
extern loadchunk(y);
extern loadsprites(y);

// Music & sound functions
extern playgametune(a);
extern playzonetune();
extern playtune(a);
extern playsfx(a);
extern togglemusic();

// Joystick/control functions
extern getcontrols();
extern getfireclick();

// Actor functions
extern triggerfocus();
extern focus(a);
extern initactors();
extern createactor(y,a,x);
extern initbasicactor(y);
extern initcomplexactor(y);
extern unhideactors();
extern addactor(a);
extern addallactors();
extern getactorbyte a(a,x);
extern setactorbyte(a,x,y);

// Weapon & item define functions
extern loaddefs(a);

// Actor AI functions
extern gointoalert(a);
extern gototarget(a);
extern checkdistance a(a);
extern saynoptr();
extern sayidlenoptr();
extern spawnballoon(y);

// Inventory/status panel functions
extern initpanel();                       // Will be overwritten by sprites!
extern initinventory();
extern additem(x,a);
extern finditem a(a);
extern removeitem(a);
extern decreaseammo(y,a);
extern updatepanel();
extern updateinventory();

// Plot bit functions
extern setbit(a);
extern clearbit(a);
extern checkbit a(a);

// Game flow functions
extern transportplayer();

// Variables

// System
extern var fastloadstatus;
extern var usereu;
extern var ntscflag;

// Textwindow & messagesystem
extern var textwindowrow;
extern var textwindowcolumn;
extern var textwindowleft;
extern var textwindowright;
extern var msgtime;
extern var msgcont;

// Menu system
extern var menumode;
extern var menucounter;

// Input devices
extern var joystick;
extern var prevjoy;
extern var keypress;
extern var keytype;

// Currently executed virtual machine
extern var vmnum;

// Player inventory
extern var invtype[];
extern var invcountlo[];
extern var invcounthi[];
extern var invselect;
extern var invsize;

// Some engine variables that enhance mod-ability :)
extern var firstitemname;
extern var firstotheritem;
extern var firstpurgeablechunk;
extern var plrmaxbatt;

// Waypoints
extern var waypointxh[];
extern var waypointyh[];

// Zone info
extern var zonel[];
extern var zoner[];
extern var zoneu[];
extern var zoned[];
extern var zonebg1[];
extern var zonebg2[];
extern var zonebg3[];
extern var zonemusic[];

// Level door data
extern var lvldoorx[];
extern var lvldoory[];
extern var lvldoord[];

// Leveldata
extern var lvlactxh[];
extern var lvlactyh[];
extern var lvlactxlyl[];
extern var lvlactt[];
extern var lvlactp[];
extern var lvlactbits[];
extern var lvlactwpn[];
extern var lvlactid[];

// Actor variables
extern var actt[];
extern var actxl[];
extern var actxh[];
extern var actyl[];
extern var actyh[];
extern var actprevxl[];
extern var actprevxh[];
extern var actprevyl[];
extern var actprevyh[];
extern var actd[];
extern var actsx[];
extern var actsy[];
extern var actfls[];
extern var actbits[];
extern var acthitwalld[];
extern var actorg[];
extern var acthp[];
extern var acttime[];
extern var actgrp[];
extern var actfd[];
extern var actf1[];
extern var actf2[];
extern var acttarget[];
extern var actmode[];
extern var acthomemode[];
extern var actctrl[];
extern var actattklen[];
extern var actattkd[];
extern var actreload[];
extern var actwf[];
extern var actbatt[];
extern var actwpn[];
extern var actlastdmg[];
extern var actlastdmg2[];
extern var actid[];
extern var acthpdelta[];
extern var acthptime[];
extern var actclip[];

// Current actor number in takedown/postattack scripts
extern var c_act;

// Game statistics
extern var td_nonlethal;
extern var td_lethal;
extern var td_nonorganic;
extern var ti_frame;
extern var ti_seconds;
extern var ti_minutes;
extern var ti_hours;

// Misc. variables
extern var vmtime;
extern var gameon;
extern var pausemode;
extern var convmode;
extern var musicmode;
extern var soundmode;
extern var goremode;
extern var hostileenv;
extern var difficulty;
extern var zonenum;
extern var levelnum;
extern var tunenum;
extern var doornum;
extern var destdoornum;
extern var plrbattdelta;
extern var plrbatttime;
