//
// Weapon,Bullet,Item & Special Damage definitions
//
// This is just a raw binary datafile, to be compiled with the -o option. 0xff
// denotes the last in each of sections.
//

#include "mw4def.cs"

// Weapons

{
  ITEM_FISTS,
  0,                 // Noise
  1,                 // Ammo consumption
  BLT_FISTHIT,       // First bullet number
  0,                 // Reload time (insert new clip)
  0,                 // Reload time (after readying)
  0,                 // Reload amount
  0,                 // Reload sound (insert clip/bullet)
  0,                 // Reload sound (ready weapon)
  WF_NONE,           // Idle frame
  WF_NONE,           // Attack prepare frame
  WF_NONE,           // Attack frame (straight)
  WF_NONE,           // Attack frame (up)
  WF_NONE,           // Attack frame (down)
  0,                 // Directional?
  0,                 // Muzzle flash?
  2,                 // Is a melee weapon?
  SFX_PUNCH,         // Sound effect number
  2,                 // NPC maximum distance
  0,                 // NPC minimum distance
  3,                 // NPC attack time (time firebutton is held down)
  3                  // Attack delay
}

{
  ITEM_BATON,
  0,                 // Noise
  1,                 // Ammo consumption
  BLT_BATONHIT,      // First bullet number
  0,                 // Reload time (insert new clip)
  0,                 // Reload time (after readying)
  0,                 // Reload amount
  0,                 // Reload sound (insert clip/bullet)
  0,                 // Reload sound (ready weapon)
  WF_BATON+1,        // Idle frame
  WF_BATON,          // Attack prepare frame
  WF_BATON+3,        // Attack frame (straight)
  WF_BATON+1,        // Attack frame (up)
  WF_BATON+5,        // Attack frame (down)
  1,                 // Directional?
  0,                 // Muzzle flash?
  2,                 // Is a melee weapon?
  SFX_MELEE,         // Sound effect number
  2,                 // NPC maximum distance
  0,                 // NPC minimum distance
  3,                 // NPC attack time (time firebutton is held down)
  4                  // Attack delay
}

{
  ITEM_KNIFE,
  0,                 // Noise
  1,                 // Ammo consumption
  BLT_KNIFEHIT,      // First bullet number
  0,                 // Reload time (insert new clip)
  0,                 // Reload time (after readying)
  0,                 // Reload amount
  0,                 // Reload sound (insert clip/bullet)
  0,                 // Reload sound (ready weapon)
  WF_KNIFE,          // Idle frame
  WF_KNIFE+2,        // Attack prepare frame
  WF_KNIFE+2,        // Attack frame (straight)
  WF_NONE,           // Attack frame (up)
  WF_NONE,           // Attack frame (down)
  0,                 // Directional?
  0,                 // Muzzle flash?
  2,                 // Is a melee weapon?
  SFX_MELEE,         // Sound effect number
  2,                 // NPC maximum distance
  0,                 // NPC minimum distance
  3,                 // NPC attack time (time firebutton is held down)
  4                  // Attack delay
}

{
  ITEM_KATANA,
  0,                 // Noise
  1,                 // Ammo consumption
  BLT_KATANAHIT,     // First bullet number
  0,                 // Reload time (insert new clip)
  0,                 // Reload time (after readying)
  0,                 // Reload amount
  0,                 // Reload sound (insert clip/bullet)
  0,                 // Reload sound (ready weapon)
  WF_KATANA,         // Idle frame
  WF_KATANA+2,       // Attack prepare frame
  WF_KATANA+5,       // Attack frame (straight)
  WF_KATANA+3,       // Attack frame (up)
  WF_KATANA+7,       // Attack frame (down)
  1,                 // Directional?
  0,                 // Muzzle flash?
  2,                 // Is a melee weapon?
  SFX_MELEE,         // Sound effect number
  2,                 // NPC maximum distance
  0,                 // NPC minimum distance
  3,                 // NPC attack time (time firebutton is held down)
  5                  // Attack delay
}

{
  ITEM_SHURIKEN,
  0,                 // Noise
  1,                 // Ammo consumption
  BLT_SHURIKEN,      // First bullet number
  0,                 // Reload time (insert new clip)
  0,                 // Reload time (after readying)
  0,                 // Reload amount
  0,                 // Reload sound (insert clip/bullet)
  0,                 // Reload sound (ready weapon)
  WF_NONE,           // Idle frame
  WF_NONE,           // Attack prepare frame
  WF_NONE,           // Attack frame (straight)
  WF_NONE,           // Attack frame (up)
  WF_NONE,           // Attack frame (down)
  1,                 // Directional?
  0,                 // Muzzle flash?
  1,                 // Is a melee weapon?
  SFX_THROW,         // Sound effect number
  5,                 // NPC maximum distance
  1,                 // NPC minimum distance
  3,                 // NPC attack time (time firebutton is held down)
  4                  // Attack delay
}

{
  ITEM_GRENADE,
  NOISE_SILENT,      // Noise
  1,                 // Ammo consumption
  BLT_GRENADE,       // First bullet number
  0,                 // Reload time (insert new clip)
  0,                 // Reload time (after readying)
  0,                 // Reload amount
  0,                 // Reload sound (insert clip/bullet)
  0,                 // Reload sound (ready weapon)
  WF_NONE,           // Idle frame
  WF_NONE,           // Attack prepare frame
  WF_NONE,           // Attack frame (straight)
  WF_NONE,           // Attack frame (up)
  WF_NONE,           // Attack frame (down)
  1,                 // Directional?
  0,                 // Muzzle flash?
  1,                 // Is a melee weapon?
  SFX_GRENADE,       // Sound effect number
  6,                 // NPC maximum distance
  2,                 // NPC minimum distance
  3,                 // NPC attack time (time firebutton is held down)
  6                  // Attack delay
}

{
  ITEM_DARTGUN,
  NOISE_SILENT,      // Noise
  1,                 // Ammo consumption
  BLT_DART,          // First bullet number
  12,                // Reload time (insert new clip)
  3,                 // Reload time (after readying)
  255,               // Reload amount
  SFX_INSERTCLIP,    // Reload sound (insert clip/bullet)
  SFX_COCKFAST,      // Reload sound (ready weapon)
  WF_DARTGUN,        // Idle frame
  WF_DARTGUN+4,      // Attack prepare frame
  WF_DARTGUN,        // Attack frame (straight)
  WF_DARTGUN+2,      // Attack frame (up)
  WF_DARTGUN+4,      // Attack frame (down)
  1,                 // Directional?
  0,                 // Muzzle flash?
  0,                 // Is a melee weapon?
  SFX_DART,          // Sound effect number
  5,                 // NPC maximum distance
  1,                 // NPC minimum distance
  5,                 // NPC attack time (time firebutton is held down)
  7                  // Attack delay
}

{
  ITEM_PISTOL,
  NOISE_LOUD,        // Noise
  1,                 // Ammo consumption
  BLT_9MM,           // First bullet number
  8,                 // Reload time (insert new clip)
  3,                 // Reload time (after readying)
  255,               // Reload amount
  SFX_INSERTCLIP,    // Reload sound (insert clip/bullet)
  SFX_COCKFAST,      // Reload sound (ready weapon)
  WF_PISTOL,         // Idle frame
  WF_PISTOL+8,       // Attack prepare frame
  WF_PISTOL,         // Attack frame (straight)
  WF_PISTOL+4,       // Attack frame (up)
  WF_PISTOL+8,       // Attack frame (down)
  1,                 // Directional?
  1,                 // Muzzle flash?
  0,                 // Is a melee weapon?
  SFX_PISTOL,        // Sound effect number
  5,                 // NPC maximum distance
  1,                 // NPC minimum distance
  4,                 // NPC attack time (time firebutton is held down)
  4                  // Attack delay
}

{
  ITEM_SMG,
  NOISE_LOUD,        // Noise
  1,                 // Ammo consumption
  BLT_9MM,           // First bullet number
  8,                 // Reload time (insert new clip)
  3,                 // Reload time (after readying)
  255,               // Reload amount
  SFX_INSERTCLIP,    // Reload sound (insert clip/bullet)
  SFX_COCKFAST,      // Reload sound (ready weapon)
  WF_SMG,            // Idle frame
  WF_SMG+8,          // Attack prepare frame
  WF_SMG,            // Attack frame (straight)
  WF_SMG+4,          // Attack frame (up)
  WF_SMG+8,          // Attack frame (down)
  1,                 // Directional?
  1,                 // Muzzle flash?
  0,                 // Is a melee weapon?
  SFX_SMG,           // Sound effect number
  6,                 // NPC maximum distance
  1,                 // NPC minimum distance
  4,                 // NPC attack time (time firebutton is held down)
  1                  // Attack delay
}

{
  ITEM_SHOTGUN,
  NOISE_LOUD,        // Noise
  2,                 // Ammo consumption
  BLT_SHOTGUN1,      // First bullet number
  2,                 // Reload time (insert new clip)
  3,                 // Reload time (after readying)
  1,                 // Reload amount
  SFX_INSERTAMMO,    // Reload sound (insert clip/bullet)
  SFX_COCKWEAPON,    // Reload sound (ready weapon)
  WF_SHOTGUN,        // Idle frame
  WF_SHOTGUN+8,      // Attack prepare frame
  WF_SHOTGUN,        // Attack frame (straight)
  WF_SHOTGUN+4,      // Attack frame (up)
  WF_SHOTGUN+8,      // Attack frame (down)
  1,                 // Directional?
  1,                 // Muzzle flash?
  0,                 // Is a melee weapon?
  SFX_SHOTGUN,       // Sound effect number
  5,                 // NPC maximum distance
  1,                 // NPC minimum distance
  5,                 // NPC attack time (time firebutton is held down)
  6                  // Attack delay
}

{0xff}  //End weapon defs.

// Bullets

{
  BLT_FISTHIT,
  14*8 & 0xff,         // X modification lowbyte
  14*8 >> 8,           // X modification highbyte
  0 & 0xff,            // Y modification lowbyte
  0 >> 8,              // Y modification highbyte
  4*8,                 // X speed
  0,                   // Y speed
  0,                   // Y aiming speed modification
  0,                   // Y aiming pos. modification
  0,                   // Y aiming affects bullet frame?
  ACT_MELEEHIT,        // Bullet actor number
  DMG_FISTS,           // Bullet damage
  1,                   // Bullet duration
  0                    // Next bullet (multi-bullet weapons)
}

{
  BLT_KNIFEHIT,
  20*8 & 0xff,        // X modification lowbyte
  20*8 >> 8,          // X modification highbyte
  0 & 0xff,           // Y modification lowbyte
  0 >> 8,             // Y modification highbyte
  8*8,                // X speed
  0,                  // Y speed
  0,                  // Y aiming speed modification
  12*8,               // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_MELEEHIT,       // Bullet actor number
  DMG_KNIFE,          // Bullet damage
  1,                  // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_KATANAHIT,
  26*8 & 0xff,        // X modification lowbyte
  26*8 >> 8,          // X modification highbyte
  0 & 0xff,           // Y modification lowbyte
  0 >> 8,             // Y modification highbyte
  10*8,               // X speed
  0,                  // Y speed
  0,                  // Y aiming speed modification
  12*8,               // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_MELEEHIT,       // Bullet actor number
  DMG_KATANA,         // Bullet damage
  1,                  // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_9MM,
  24*8 & 0xff,        // X modification lowbyte
  24*8 >> 8,          // X modification highbyte
  (-2*8) & 0xff,      // Y modification lowbyte
  (-2*8) >> 8,        // Y modification highbyte
  15*8,               // X speed
  0,                  // Y speed
  15*8/2,             // Y aiming speed modification
  12*8,               // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_BULLET,         // Bullet actor number
  DMG_9MM,            // Bullet damage
  10,                 // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_DART,
  20*8 & 0xff,        // X modification lowbyte
  20*8 >> 8,          // X modification highbyte
  (-2*8) & 0xff,      // Y modification lowbyte
  (-2*8) >> 8,        // Y modification highbyte
  15*8,               // X speed
  0,                  // Y speed
  12*8/2,             // Y aiming speed modification
  8*8,                // Y aiming pos. modification
  1,                  // Y aiming affects bullet frame?
  ACT_DART,           // Bullet actor number
  DMG_DART,           // Bullet damage
  8,                  // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_BATONHIT,
  22*8 & 0xff,        // X modification lowbyte
  22*8 >> 8,          // X modification highbyte
  0 & 0xff,           // Y modification lowbyte
  0 >> 8,             // Y modification highbyte
  10*8,               // X speed
  0,                  // Y speed
  0,                  // Y aiming speed modification
  10*8,               // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_MELEEHIT,       // Bullet actor number
  DMG_BATON,          // Bullet damage
  1,                  // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_SHURIKEN,
  14*8 & 0xff,        // X modification lowbyte
  14*8 >> 8,          // X modification highbyte
  0 & 0xff,           // Y modification lowbyte
  0 >> 8,             // Y modification highbyte
  14*8,               // X speed
  0,                  // Y speed
  12*8/2,             // Y aiming speed modification
  7*8,                // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_SHURIKEN,       // Bullet actor number
  DMG_SHURIKEN,       // Bullet damage
  8,                  // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_SHOTGUN1,
  26*8 & 0xff,        // X modification lowbyte
  26*8 >> 8,          // X modification highbyte
  (-2*8) & 0xff,      // Y modification lowbyte
  (-2*8) >> 8,        // Y modification highbyte
  15*8,               // X speed
  8,                  // Y speed
  15*8/2,             // Y aiming speed modification
  13*8,               // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_BULLET,         // Bullet actor number
  DMG_SHOTGUN,        // Bullet damage
  6,                  // Bullet duration
  BLT_SHOTGUN2        // Next bullet (multi-bullet weapons)
}

{
  BLT_SHOTGUN2,
  26*8 & 0xff,        // X modification lowbyte
  26*8 >> 8,          // X modification highbyte
  (-2*8) & 0xff,      // Y modification lowbyte
  (-2*8) >> 8,        // Y modification highbyte
  15*8,               // X speed
  -8,                 // Y speed
  15*8/2,             // Y aiming speed modification
  13*8,               // Y aiming pos. modification
  0,                  // Y aiming affects bullet frame?
  ACT_BULLET,         // Bullet actor number
  DMG_SHOTGUN,        // Bullet damage
  6,                  // Bullet duration
  0                   // Next bullet (multi-bullet weapons)
}

{
  BLT_GRENADE,
  14*8 & 0xff,         // X modification lowbyte
  14*8 >> 8,           // X modification highbyte
  0 & 0xff,            // Y modification lowbyte
  0 >> 8,              // Y modification highbyte
  10*8,                // X speed
  -10*8,               // Y speed
  2*8,                 // Y aiming speed modification
  7*8,                 // Y aiming pos. modification
  0,                   // Y aiming affects bullet frame?
  ACT_GRENADE,         // Bullet actor number
  DMG_GRENADE,         // Bullet damage
  16,                  // Bullet duration
  0                    // Next bullet (multi-bullet weapons)
}

{0xff} // End bullet defs.

// Items

{
  ITEM_FISTS,
  0,                   // Default pickup amount
  0 & 0xff,            // Maximum carried lowbyte
  0 >> 8,              // Maximum carried highbyte
  AMMO_INFINITE        // Ammo item type
}

{
  ITEM_BATON,
  1,                   // Default pickup amount
  1 & 0xff,            // Maximum carried lowbyte
  1 >> 8,              // Maximum carried highbyte
  AMMO_INFINITE        // Ammo item type
}

{
  ITEM_KNIFE,
  1,                   // Default pickup amount
  1 & 0xff,            // Maximum carried lowbyte
  1 >> 8,              // Maximum carried highbyte
  AMMO_INFINITE        // Ammo item type
}

{
  ITEM_KATANA,
  1,                   // Default pickup amount
  1 & 0xff,            // Maximum carried lowbyte
  1 >> 8,              // Maximum carried highbyte
  AMMO_INFINITE        // Ammo item type
}

{
  ITEM_SHURIKEN,
  3,                   // Default pickup amount
  20 & 0xff,           // Maximum carried lowbyte
  20 >> 8,             // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_GRENADE,
  2,                   // Default pickup amount
  10 & 0xff,           // Maximum carried lowbyte
  10 >> 8,             // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_DARTGUN,
  5,                   // Default pickup amount
  5 & 0xff,            // Maximum carried lowbyte
  5 >> 8,              // Maximum carried highbyte
  ITEM_DARTS           // Ammo item type
}

{
  ITEM_PISTOL,
  15,                  // Default pickup amount
  15 & 0xff,           // Maximum carried lowbyte
  15 >> 8,             // Maximum carried highbyte
  ITEM_9MMAMMO         // Ammo item type
}

{
  ITEM_SMG,
  30,                  // Default pickup amount
  30 & 0xff,           // Maximum carried lowbyte
  30 >> 8,             // Maximum carried highbyte
  ITEM_9MMAMMO         // Ammo item type
}

{
  ITEM_SHOTGUN,
  8,                   // Default pickup amount
  8 & 0xff,            // Maximum carried lowbyte
  8 >> 8,              // Maximum carried highbyte
  ITEM_12GAUGEAMMO     // Ammo item type
}

{
  ITEM_9MMAMMO,
  50,                  // Default pickup amount
  300 & 0xff,          // Maximum carried lowbyte
  300 >> 8,            // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_12GAUGEAMMO,
  20,                  // Default pickup amount
  100 & 0xff,          // Maximum carried lowbyte
  100 >> 8,            // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_DARTS,
  10,                  // Default pickup amount
  50 & 0xff,           // Maximum carried lowbyte
  50 >> 8,             // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_MEDIKIT,
  1,                   // Default pickup amount
  3 & 0xff,            // Maximum carried lowbyte
  3 >> 8,              // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_BATTERY,
  1,                   // Default pickup amount
  3 & 0xff,            // Maximum carried lowbyte
  3 >> 8,              // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{
  ITEM_SCROLL,
  1,                   // Default pickup amount
  1 & 0xff,            // Maximum carried lowbyte
  1 >> 8,              // Maximum carried highbyte
  AMMO_NONE            // Ammo item type
}

{0xff}  // End item defs.

// Special damage

{
  SPDMG_DARTS,
  AFB_ORGANIC,         // Fightbits that must be on for damage to work
  10,                  // Damage time
  -2,                  // Damage hitpoints delta
  2                    // Initial damage
}

{0xff}  // End special damage defs.

