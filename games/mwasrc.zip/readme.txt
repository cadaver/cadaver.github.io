MW Amiga V1.1 sourcecode
------------------------

- Use phxass (on Amiga) to compile:
  phxass mw to bin/Metalwarrior

- To pack all datafiles, go to data subdirectory
  and execute pack.bat (cpack.exe is in utility dir)

- The code is still quite horrible, do not use it
  for learning purposes!!!
