#include <stdio.h>

int main(int argc, char **argv)
{
  unsigned char rawdata[320];
  unsigned char bplane1[40];
  unsigned char bplane2[40];
  unsigned char bplane3[40];
  unsigned char bplane4[40];

  FILE *in, *out;

  if (argc < 3)
  {
    printf("Usage: raster <input> <output>\n"
           "Takes a 256 color raw data picture and outputs 4-bitplane picture with\n"
           "bitplane interleaving (rastersave)\n");
    return 1;
  }

  in = fopen(argv[1], "rb");
  if (!in)
  {
    printf("Input open error!\n");
    return 1;
  }
  out = fopen(argv[2], "wb");
  if (!out)
  {
    printf("Input open error!\n");
    return 1;
  }

  for (;;)
  {
    int c;

    fread(rawdata, 320, 1, in);
    if (feof(in)) break;

    for (c = 0; c < 40; c++)
    {
      bplane1[c] = (rawdata[c*8+7] & 1)
                | ((rawdata[c*8+6] & 1) << 1)
                | ((rawdata[c*8+5] & 1) << 2)
                | ((rawdata[c*8+4] & 1) << 3)
                | ((rawdata[c*8+3] & 1) << 4)
                | ((rawdata[c*8+2] & 1) << 5)
                | ((rawdata[c*8+1] & 1) << 6)
                | ((rawdata[c*8+0] & 1) << 7);

      bplane2[c] = ((rawdata[c*8+7] & 2) >> 1)
                 | ((rawdata[c*8+6] & 2))
                 | ((rawdata[c*8+5] & 2) << 1)
                 | ((rawdata[c*8+4] & 2) << 2)
                 | ((rawdata[c*8+3] & 2) << 3)
                 | ((rawdata[c*8+2] & 2) << 4)
                 | ((rawdata[c*8+1] & 2) << 5)
                 | ((rawdata[c*8+0] & 2) << 6);

      bplane3[c] = ((rawdata[c*8+7] & 4) >> 2)
                 | ((rawdata[c*8+6] & 4) >> 1)
                 | ((rawdata[c*8+5] & 4))
                 | ((rawdata[c*8+4] & 4) << 1)
                 | ((rawdata[c*8+3] & 4) << 2)
                 | ((rawdata[c*8+2] & 4) << 3)
                 | ((rawdata[c*8+1] & 4) << 4)
                 | ((rawdata[c*8+0] & 4) << 5);

      bplane4[c] = ((rawdata[c*8+7] & 8) >> 3)
                 | ((rawdata[c*8+6] & 8) >> 2)
                 | ((rawdata[c*8+5] & 8) >> 1)
                 | ((rawdata[c*8+4] & 8))
                 | ((rawdata[c*8+3] & 8) << 1)
                 | ((rawdata[c*8+2] & 8) << 2)
                 | ((rawdata[c*8+1] & 8) << 3)
                 | ((rawdata[c*8+0] & 8) << 4);
    }

    fwrite(bplane1, 40, 1, out);
    fwrite(bplane2, 40, 1, out);
    fwrite(bplane3, 40, 1, out);
    fwrite(bplane4, 40, 1, out);
  }
  fclose(in);
  fclose(out);
  return 0;
}
