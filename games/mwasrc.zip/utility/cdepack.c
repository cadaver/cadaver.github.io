/*
 * Covert Depacker V2.0
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXOUTPUT 2*1024*1024

int main(int argc, char **argv);

int main(int argc, char **argv)
{
  unsigned char *inbuffer;
  unsigned char *outbuffer;

  FILE *in;
  FILE *out;
  int length;
  unsigned char depackbits = 0;

  int inbytes = 0;
  int outbytes = 0;

  int literal = 0;
  int onebyte = 0;
  int twobyte = 0;
  int threebyte = 0;

  if (argc < 3)
  {
    printf("CDepack V2.0\n"
           "Usage: cdepack <in> <out>\n");
    return 1;
  }

  in = fopen(argv[1], "rb");
  if (!in)
  {
    return 0;
  }
  inbuffer = malloc(MAXOUTPUT);
  outbuffer = malloc(MAXOUTPUT);

  if ((!inbuffer) || (!outbuffer))
  {
    printf("Out of memory\n");
    return 1;
  }

  fseek(in, 0, SEEK_END);
  length = ftell(in);
  fseek(in, 0, SEEK_SET);
  fread(inbuffer, length, 1, in);
  fclose(in);

  out = fopen(argv[2], "wb");
  if (!out)
  {
    printf("Destination open error\n");
    return 1;
  }
  for (;;)
  {
    int bit = depackbits & 1;
    depackbits >>= 1;
    if (!depackbits)
    {
      depackbits = inbuffer[inbytes];
      inbytes++;
      bit = depackbits & 1;
      depackbits >>= 1;
      depackbits |= 0x80;
    }
    if (!bit)
    {
      literal++;

      outbuffer[outbytes] = inbuffer[inbytes];
      outbytes++;
      inbytes++;
    }
    else
    {
      int length, index;

      if (!inbuffer[inbytes])
      {
        inbytes++;
        break; /* EOF */
      }

      switch(inbuffer[inbytes] & 0xf0)
      {
        case 0x80:
        case 0x90:
        case 0xa0:
        case 0xb0:
        case 0xc0:
        case 0xd0:
        case 0xe0:
        case 0xf0:
        twobyte++;
        length = 3 + ((inbuffer[inbytes] >> 4) & 7);
        index = inbuffer[inbytes+1] | ((inbuffer[inbytes] & 15) << 8);
        inbytes += 2;
        index++;
        break;

        case 0x40:
        case 0x50:
        case 0x60:
        case 0x70:
        onebyte++;
        length = 2;
        index = inbuffer[inbytes] & 0x3f;
        inbytes++;
        index++;
        break;

        case 0x20:
        case 0x30:
        twobyte++;
        length = 2 + (inbuffer[inbytes] & 31);
        inbytes++;
        index = inbuffer[inbytes];
        inbytes++;
        index++;
        break;

        case 0x10:
        threebyte++;
        index = inbuffer[inbytes+1] | ((inbuffer[inbytes] & 15) << 8);
        inbytes += 2;
        length = inbuffer[inbytes] + 1;
        inbytes++;
        index++;
        break;

        default:
        if (inbuffer[inbytes] == 15)
        {
          twobyte++;
          length = index = inbuffer[inbytes+1] + 1;
          inbytes += 2;
        }
        else
        {
          if (inbuffer[inbytes] > 1)
          {
            onebyte++;
            length = index = inbuffer[inbytes];
            inbytes++;
          }
          else
          {
            onebyte++;
            length = index = 256;
            inbytes++;
          }
        }
        break;
      }

      while(length)
      {
        outbuffer[outbytes] = outbuffer[outbytes-index];
        outbytes++;
        length--;
      }
    }
  }
  fwrite(outbuffer, outbytes, 1, out);
  printf("In: %d Out: %d\n", inbytes, outbytes);
  printf("Literals: %d 1-byte: %d 2-byte: %d 3-byte: %d\n", literal, onebyte, twobyte, threebyte);
  fclose(out);
  return 0;
}
