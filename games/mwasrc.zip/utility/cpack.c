#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SEEKBACK 4096
#define MAXSTRING 256

int matches[256];
int matchtable[256][SEEKBACK];

int main(int argc, char **argv);

int main(int argc, char **argv)
{
  FILE *in;
  FILE *out;
  unsigned char codebuffer[24];
  unsigned char bits;
  int count;
  int bitcount;
  int codecount;
  int length;
  int packlength;
  int literal = 0;
  int onebyte = 0;
  int twobyte = 0;
  int threebyte = 0;
  int matchtablestart = 0, matchtableend = 0, oldmatchtablestart;
  int c = 0;
  unsigned char *inbuffer;

  for (c = 0; c < 256; c++) matches[c] = 0;

  if (argc < 3)
  {
    printf("CPack V2.0\n"
           "Usage: cpack <in> <out>\n");
    return 1;
  }
  in = fopen(argv[1], "rb");
  if (!in)
  {
    printf("Can't open source!\n");
    return 0;
  }

  fseek(in, 0, SEEK_END);
  length = ftell(in);
  fseek(in, 0, SEEK_SET);

  inbuffer = malloc(length);
  if (!inbuffer)
  {
    printf("Out of memory!\n");
    return 1;
  }
  fread(inbuffer, length, 1, in);
  fclose(in);

  out = fopen(argv[2], "wb");
  if (!out)
  {
    printf("Can't open destination!\n");
    return 1;
  }

  packlength = 0;
  bitcount = 0;
  codecount = 0;
  bits = 0;
  count = 0;

  for(;;)
  {
    // Add characters to the match-table
    for (c = matchtableend; c < count; c++)
    {
      int b = inbuffer[c];

      matchtable[b][matches[b]] = c;
      matches[b]++;
    }
    matchtableend = count;

    if (count >= 2)
    {
      // Try to find the longest string
      int stlen = 0;
      int stpos = 0;
      int stlen2 = 0;
      int bb = inbuffer[count]; // Beginning byte to be compared against

      for (c = matches[bb]-1; c >= 0; c--)
      {
        int start = matchtable[bb][c];
        int end = start + MAXSTRING;
        if (end > count) end = count;

        if (end-start >= stlen)
        {
          int max = end - start;
          int d;

          for (d = 1; d < max; d++)
          {
            if (inbuffer[start+d] != inbuffer[count+d]) break;
          }
          if ((d >= 2) && (d > stlen))
          {
            stlen = d;
            stpos = count - start;
          }
          // Try to find as low position as possible (uses shorter encoding)
          if ((d == stlen) && (count - start < stpos))
          {
            stpos = count - start;
          }
        }

        // Exit if already the best possible match
        if ((stlen == MAXSTRING) && (stpos == stlen)) break;
      }

      // Lazy matching: try the next offset
      if (count+1 < length)
      {
        bb = inbuffer[count+1]; // Beginning byte to be compared against

        for (c = matches[bb]-1; c >= 0; c--)
        {
          int start = matchtable[bb][c];
          int end = start + MAXSTRING;
          if (end > count+1) end = count+1;

          if (end-start >= stlen2)
          {
            int max = end - start;
            int d;

            for (d = 1; d < max; d++)
            {
              if (inbuffer[start+d] != inbuffer[count+d+1]) break;
            }
            if ((d >= 2) && (d >= stlen2))
            {
              stlen2 = d;
            }
          }
          // Exit if already the best possible match
          if (stlen2 == MAXSTRING) break;
        }
        // If next match is significantly better, output current byte as literal
        if (stlen2-1 > stlen) stlen = 0;
      }

      // Encode the string match, or a literal
      if (stlen > 1)
      {
        if ((stlen == 2) && (stpos >= 256)) goto LITERAL;

        if (stpos == stlen)
        {
          if (stlen == MAXSTRING)
          {
            onebyte++;
            codebuffer[codecount] = 0x1;
            codecount++;
          }
          else
          {
            if (stlen <= 14)
            {
              onebyte++;
              codebuffer[codecount] = stlen;
              codecount++;
            }
            else
            {
              twobyte++;
              codebuffer[codecount] = 0xf;
              codecount++;
              codebuffer[codecount] = stlen - 1;
              codecount++;
            }
          }
        }
        else
        {
        if ((stlen == 2) && (stpos < 65))
        {
          onebyte++;
          codebuffer[codecount] = 0x40 + stpos - 1;
          codecount++;
        }
        else
        {
          if ((stlen <= 33) && (stpos < 257))
          {
            twobyte++;
            codebuffer[codecount] = 0x20 + stlen-2;
            codecount++;
            codebuffer[codecount] = stpos - 1;
            codecount++;
          }
          else
          {
            if ((stlen >= 3) && (stlen <= 10))
            {
              twobyte++;
              codebuffer[codecount] = 0x80 + ((stlen - 3) << 4) + ((stpos-1) >> 8);
              codecount++;
              codebuffer[codecount] = (stpos-1) & 0xff;
              codecount++;
            }
            else
            {
              threebyte++;
              codebuffer[codecount] = 0x10 + ((stpos-1) >> 8);
              codecount++;
              codebuffer[codecount] = (stpos-1) & 0xff;
              codecount++;
              codebuffer[codecount] = stlen-1;
              codecount++;
            }
          }
        }
        }

        bits |= 1 << bitcount;
        bitcount++;
        count += stlen;

      }
      else
      {
        LITERAL:
        literal++;
        codebuffer[codecount] = inbuffer[count];
        codecount++;
        bitcount++;
        count++;
      }
    }
    else
    {
      literal++;
      codebuffer[codecount] = inbuffer[count];
      codecount++;
      bitcount++;
      count++;
    }
    if (bitcount == 8)
    {
      fputc(bits, out);
      fwrite(codebuffer, codecount, 1, out);
      packlength += 1 + codecount;
      fflush(stdout);
      bitcount = 0;
      codecount = 0;
      bits = 0;
    }
    // Ready?
    if (count >= length) break;

    // Remove too old matches
    oldmatchtablestart = matchtablestart;
    matchtablestart = count - SEEKBACK;
    if (matchtablestart < 0) matchtablestart = 0;

    for (c = oldmatchtablestart; c < matchtablestart; c++)
    {
      int b = inbuffer[c];
      int d;

      for (d = 0; d < matches[b]; d++)
      {
        // Find the first OK entry and copy it+the rest to the start
        if (matchtable[b][d] >= matchtablestart)
        {
          memmove(&matchtable[b][0], &matchtable[b][d], (matches[b]-d)*sizeof(int));
          break;
        }
      }
      matches[b] -= d;
    }
  }
  // EOF code
  codebuffer[codecount] = 0;
  codecount++;
  bits |= 1 << bitcount;
  if (codecount)
  {
    fputc(bits, out);
    fwrite(codebuffer, codecount, 1, out);
    packlength += 1 + codecount;
    fflush(stdout);
  }
  fclose(out);
  printf("In:%d Out:%d\n", length, packlength);
  printf("Literals: %d 1-byte: %d 2-byte: %d 3-byte: %d\n", literal, onebyte, twobyte, threebyte);
  return 0;
}

