#include <stdio.h>
#include <string.h>

#define REST 0
#define QUIET 1
#define LOUD 10
#define MUTE 11

#define MAX_PATTLEN 256
#define MAX_ROW 256

#define MAX_DRUMS 64
#define MAX_CHANNELS 64
#define MAX_GROUPS 16
#define MAX_SAMPLES 128

#define MODE_SEQUENCE 0
#define MODE_RANDOM 1
#define MODE_VELOCITY 2

typedef struct
{
  char *name;
  char *sample[MAX_SAMPLES];
  char *id;
  int channel;
  int samples;
  int group;
  int instr;
  int mode;
  int volume;
  int powerreduce;
  int randomvolume;
  int randomdelay;
  int maxdelay;
  int nextsample;
  int mutespeed;
  int delaycount;
} DRUM;

typedef struct
{
  int power;
  int powerrecover;
  int randompowerrecover;
  int powermin;
  int playing;
} GROUP;

DRUM drum[MAX_DRUMS];
GROUP group[MAX_GROUPS];

int main(int argc, char **argv);
char *getparam(char *pos);
char *getstring(char *pos);
int findkey(char *src, char *cmp);

int debug = 0;

int pattern[MAX_PATTLEN][MAX_DRUMS];

int main(int argc, char **argv)
{
  FILE *in, *out, *cfg;
  int c;
  int d = 0;
  int drums = 0;
  int maxchan = 0;

  srand(666);

  // Check for args
  if (argc < 4)
  {
    printf("Usage: DRUMTRK <cfg> <in> <out>\n");
    return 1;
  }

  // Initialize groups & drums
  for (c = 0; c < MAX_DRUMS; c++)
  {
    drum[c].id = NULL;
    drum[c].group = 0;
    drum[c].samples = 0;
    drum[c].channel = c;
    drum[c].instr = 1;
    drum[c].mode = MODE_SEQUENCE;
    drum[c].volume = 64;
    drum[c].powerreduce = 0;
    drum[c].randomvolume = 0;
    drum[c].randomdelay = 0;
    drum[c].maxdelay = 1;
    drum[c].nextsample = 0;
    drum[c].delaycount = 0;
    drum[c].mutespeed = 2;
  }
  for (c = 0; c < MAX_GROUPS; c++)
  {
    group[c].power = 100;
    group[c].powerrecover = 10;
    group[c].randompowerrecover = 0;
    group[c].powermin = 75;
    group[c].playing = 0;
  }

  // Read config
  cfg = fopen(argv[1], "rt");
  if (cfg)
  {
    char buffer[MAX_ROW];
    while (fgets(buffer, MAX_ROW, cfg))
    {
      char *pos = buffer;

      // Switch to lowercase
      strlwr(buffer);

      // Check for changing the current drum being defined
      if (buffer[0] == '[')
      {
        // Get the name
        char drumname[MAX_ROW];
        char *srcptr = &buffer[1];
        char *destptr = drumname;

        if (debug) printf("Section change");

        while ((*srcptr) && (*srcptr != ']'))
        {
          *destptr++ = *srcptr++;
        }
        *destptr = 0;

        // Check against previous names
        d = -1;
        for (c = 0; c < drums; c++)
        {
          if (!strcmp(drumname, drum[c].name))
          {
            if (debug) printf(" - existing drum\n");
            d = c;
            break;
          }
        }
        // If no drum found, define new
        if (d == -1)
        {
          d = drums;
          if (d > MAX_DRUMS) d = MAX_DRUMS-1;
          drums++;

          if (debug) printf(" - new drum\n");

          // Give name
          drum[d].name = strdup(drumname);
        }
      }

      // Check for commands
      if (findkey(buffer, "group"))
      {
        if (debug) printf("Group definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].group);
        if (drum[d].group >= MAX_GROUPS) drum[d].group = MAX_GROUPS-1;
      }

      if (findkey(buffer, "channel"))
      {
        if (debug) printf("Channel definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].channel);
        if (drum[d].channel < 0) drum[d].channel = 0;
        if (drum[d].channel >= MAX_CHANNELS) drum[d].group = MAX_CHANNELS-1;
      }

      if (findkey(buffer, "instr"))
      {
        if (debug) printf("Instr definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].instr);
      }

      if (findkey(buffer, "id"))
      {
        if (debug) printf("ID definition\n");

        pos = getparam(pos);
        if (pos) drum[d].id = getstring(pos);
      }

      if (findkey(buffer, "samples"))
      {
        int e = 0;

        if (debug) printf("Sample list definition\n");

        while (pos = getparam(pos))
        {
          drum[d].sample[e] = getstring(pos);
          drum[d].samples++;
          strupr(drum[d].sample[e]);
          e++;
        }
      }

      if (findkey(buffer, "mode"))
      {
        if (debug) printf("Sample mode definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].mode);
        if (drum[d].mode < MODE_SEQUENCE) drum[d].mode = MODE_SEQUENCE;
        if (drum[d].mode > MODE_VELOCITY) drum[d].mode = MODE_VELOCITY;
      }

      if (findkey(buffer, "vol"))
      {
        if (debug) printf("Volume definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].volume);
      }

      if (findkey(buffer, "randomvol"))
      {
        if (debug) printf("Random volume definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].randomvolume);
      }

      if (findkey(buffer, "randomdelay"))
      {
        if (debug) printf("Random delay definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].randomdelay);
      }

      if (findkey(buffer, "maxdelay"))
      {
        if (debug) printf("Maximum delay definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].maxdelay);
      }

      if (findkey(buffer, "mutespeed"))
      {
        if (debug) printf("Muting speed definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].mutespeed);
      }

      if (findkey(buffer, "powerreduce"))
      {
        if (debug) printf("Power reduce definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &drum[d].powerreduce);
      }

      if (findkey(buffer, "powerrecover"))
      {
        if (debug) printf("Power recover definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &group[drum[d].group].powerrecover);
      }

      if (findkey(buffer, "powerrandom"))
      {
        if (debug) printf("Power random recover definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &group[drum[d].group].randompowerrecover);
      }

      if (findkey(buffer, "powermin"))
      {
        if (debug) printf("Power minimum level definition\n");

        pos = getparam(pos);
        if (pos) sscanf(pos, "%d", &group[drum[d].group].powermin);
      }
    }
    fclose(cfg);
  }
  printf("Checking drum definitions...\n");
  for (c = 0; c < drums; c++)
  {
    if (!drum[c].id)
    {
      printf("ERROR: drum %d (%s) has no ID\n", c, drum[c].name);
      return 1;
    }
    if (drum[c].samples == 0)
    {
      printf("ERROR: drum %d (%s) has no samples defined\n", c, drum[c].name);
      return 1;
    }
    printf("Drum %d (%s), Instr %d Group %d ID %s\n", c, drum[c].name, drum[c].instr, drum[c].group, drum[c].id);
    for (d = 0; d < drum[c].samples; d++)
    {
      if (strlen(drum[c].sample[d]) != 3)
      {
        printf("ERROR: sample/note name %s is not 3 chars long\n", drum[c].sample[d]);
        return 1;
      }
    }
    if (drum[c].channel >= maxchan) maxchan = drum[c].channel + 1;
  }

  in = fopen(argv[2], "rt");
  out = fopen(argv[3], "wt");

  if ((in) && (out))
  {
    int inpattern = 0;
    int pattlen = 0;
    char *pos;

    char buffer[MAX_ROW];

    printf("Reading input & outputting...\n");

    while (pos = fgets(buffer, MAX_ROW, in))
    {
      int e = 0;
      int mute = 0;
      char ch[MAX_CHANNELS][16]; // Channel strings

      d = -1;

      if (debug) printf("Row\n");

      // Switch to lowercase
      strlwr(buffer);

      // Recognize drum ID
      for (c = 0; c < drums; c++)
      {
        if (findkey(buffer, drum[c].id))
        {
          d = c;

          // If first row in a pattern, init the pattern
          if (!inpattern)
          {
            if (debug) printf("Pattern begin\n");
            inpattern = 1;
            pattlen = 0;
            memset(pattern, 0, sizeof pattern);
          }

          // Now skip forward to the note data
          pos = getparam(pos);
          if (debug) printf("Reading pattern for drum %d\n", d);
          while(pos)
          {
            // Read note data (rest, mute, drum hits etc.)

            switch (*pos)
            {
              case 0:
              case 10:
              case 13:
              pos = NULL;
              break;

              case '-':
              if (!mute)
                pattern[d][e] = REST;
              else
                pattern[d][e] = MUTE;
              e++;
              break;

              case '0':
              case '1':
              case '2':
              case '3':
              case '4':
              case '5':
              case '6':
              case '7':
              case '8':
              case '9':
              pattern[d][e] = *pos - '0' + QUIET;
              mute = 0;
              e++;
              break;

              case 'm':
              case '\\':
              pattern[d][e] = MUTE;
              mute = 1;
              e++;
              break;
            }
            if (pos) pos++;
          }
          if (e > pattlen) pattlen = e;
        }
      }
      // First non-drum line or EOF closes the pattern, and it will be output
      if ((d == -1) || (feof(in)))
      {
        if (inpattern)
        {
          if (debug) printf("Dumping pattern\n", d);

          inpattern = 0;
          fprintf(out, "ModPlug Tracker  IT\n");

          // Now "play" the pattern
          for (e = 0; e < pattlen; e++)
          {
            // Put rests on all pattern-columns
            for (c = 0; c < maxchan; c++)
            {
              sprintf(ch[c], "|...........");
            }

            // Clear play indicator on all groups
            for (c = 0; c < MAX_GROUPS; c++)
            {
              group[c].playing = 0;
            }
            for (d = 0; d < drums; d++)
            {
              int s; // Sample number
              int de = 0; // Delay
              int hitvol = 0;
              char *cptr = ch[drum[d].channel]; // Channel to use

              switch (pattern[d][e])
              {
                case MUTE:
                // Mute will never override a note on the same channel
                if (cptr[1] == '.')
                {
                  sprintf(cptr, "|.....d%02d...", drum[d].mutespeed);
                }
                break;

                case REST:
                break;

                default:
                // Select original hitvolume according to notation (0-9)
                hitvol = drum[d].volume * pattern[d][e] / 10;

                // Reduce hitvolume according to random variation
                if (drum[d].randomvolume)
                  hitvol -= (rand() % drum[d].randomvolume);

                // Reduce hitvolume according to group power
                hitvol = hitvol * group[drum[d].group].power / 100;

                // Keep volume within limits
                if (hitvol < 1) hitvol = 1;
                if (hitvol > 64) hitvol = 64;

                // Create delay if necessary
                if ((drum[d].maxdelay) && (drum[d].randomdelay))
                {
                  drum[d].delaycount += (rand() % drum[d].randomdelay);
                  if (drum[d].delaycount >= 100)
                  {
                    drum[d].delaycount -= 100;
                    de = (rand() % drum[d].maxdelay) + 1;
                  }
                }

		// Handle power reduce
		group[drum[d].group].playing = 1;
                group[drum[d].group].power -= drum[d].powerreduce;
                if (group[drum[d].group].power < group[drum[d].group].powermin)
                  group[drum[d].group].power = group[drum[d].group].powermin;

		// Select a sample, according to samplemode
                switch(drum[d].mode)
                {
                  case MODE_RANDOM:
                  s = rand() % drum[d].samples;
                  break;

                  case MODE_SEQUENCE:
                  s = drum[d].nextsample;
                  drum[d].nextsample++;
                  drum[d].nextsample %= drum[d].samples;
                  break;

                  case MODE_VELOCITY:
                  s = drum[d].samples * hitvol / 64;
                  if (s >= drum[d].samples) s = drum[d].samples-1;
                  hitvol = 64;
                  break;
                }
                if (!de)
                {
                  if (hitvol != 64)
                    sprintf(cptr, "|%s%02dv%02d...", drum[d].sample[s], drum[d].instr, hitvol);
                  else
                    sprintf(cptr, "|%s%02d......", drum[d].sample[s], drum[d].instr);
                }
                else
                {
                  if (hitvol != 64)
                    sprintf(cptr, "|%s%02dv%02dSD%1d", drum[d].sample[s], drum[d].instr, hitvol, de);
                  else
                    sprintf(cptr, "|%s%02d...SD%1d", drum[d].sample[s], drum[d].instr, de);
                }
                break;
              }
            }
            // Now handle power recovery of all groups
            for (d = 0; d < MAX_GROUPS; d++)
            {
              if (!group[d].playing)
              {
                group[d].power += group[d].powerrecover;
              }
              if (group[d].randompowerrecover)
              {
                group[d].power += (rand() % group[d].randompowerrecover) + 1;
              }
              if (group[d].power > 100) group[d].power = 100;
            }

            // Output the columns of the pattern
            for (c = 0; c < maxchan; c++)
            {
              fprintf(out, ch[c]);
            }
            fprintf(out, "\n");
          }
          fprintf(out, "\n");
        }
      }
    }
  }
  printf("Done!\n");
  fclose(in);
  fclose(out);
  return 0;
}

char *getparam(char *pos)
{
  if (pos == NULL) return NULL;

  while ((*pos) && (*pos != ' '))
  {
    pos++;
  }
  if (*pos == ' ') pos++;
  if (*pos == 0) return NULL;
  else return pos;
}

char *getstring(char *pos)
{
  char buffer[MAX_ROW];
  int c = 0;

  if (pos == NULL) return NULL;

  while ((*pos) && (*pos != ' ') && (*pos != 10) && (*pos != 13))
  {
    buffer[c] = *pos;
    pos++;
    c++;
  }
  buffer[c] = 0;
  return strdup(buffer);
}

int findkey(char *src, char *cmp)
{
  for (;;)
  {
    if (!(*cmp)) return 1;
    if (*src != *cmp) return 0;
    src++;
    cmp++;
  }
}

