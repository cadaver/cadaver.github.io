#ifndef CFGFILE_H
#define CFGFILE_H

/* Configuration file handling for BME utilities.  Internal header.  */

FILE *cfgfile_open(const char *filename, const char *opentype);

#endif
