extern const int sintable[];
extern const int atantable[];
