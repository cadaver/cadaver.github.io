#ifndef BME_TBL_H
#define BME_TBL_H

// Internal header file: tables needed in module playing

extern signed char retrigaddtable[];
extern signed char retrigmultable[];
extern unsigned char vibratotypetable[];
extern signed char vibratotable[4][256];

#endif
