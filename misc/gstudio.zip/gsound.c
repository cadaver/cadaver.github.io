/*
 * GOATSTUDIO sound routines & trackfile handling
 */

#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mem.h>
#include <conio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

#define MINSPEED 5000
#define MAXSPEED 48000
#define MAXBUFFERS 50
#define MAXTRACKS 12

#define DEFAULTPLAYBUFFERS 3
#define DEFAULTRECORDBUFFERS 10
#define DEFAULTPER_SECOND 5

#define REC_NONE 0
#define REC_LEFT 1
#define REC_RIGHT 2

/* Multitrack file header */
typedef struct
{
  char ident[8];
  char songname[30];
  short tracks;
  unsigned short playspeed;
} HEADER;

/* WAV header (for mixdown) */
typedef struct
{
  char riffid[4];
  int totalsize;
  char waveid[4];
  char formatid[4];
  int formatsize;
  short format;
  short channels;
  int playspeed;
  unsigned short avgbytes;
  short channels2;
  short blockalign;
  short bits;
  char dataid[4];
  int datasize;
} WAVHEADER;


/* These are now configurable from command line */
int buffers;
int playbuffers;
int recordbuffers;
int per_second;

char ident[] = "GSTUDIO!";
WAVHEADER wavheader = {"RIFF", 0, "WAVE", "fmt ", 16, 1, 2, 0, 0, 2, 4, 16, "data", 0};
HEADER header = {"GSTUDIO!", "Untitled", 0, 22050};
int bfragment;
int maxfragment;
int record = 0;
int play = 0;
int monitor = 0;
int mixdown = 0;
int mixdownpos = 0;
int buffernum;
int filehandle = -1;
int mixfilehandle = -1;
char filename[256] = {0};
int pos = 0;
int playpos = 0;
int maxpos;
int outsamplesize = 1;
int insamplesize = 1;
int punchin = -1;
int punchout = -1;
int bufferpos[MAXBUFFERS];
int bufferrecorded[MAXBUFFERS];
int inbufferprepared[MAXBUFFERS];
int outbufferprepared[MAXBUFFERS];
short trackvol[MAXTRACKS];
short trackpan[MAXTRACKS];
short trackleftvol[MAXTRACKS];
short trackrightvol[MAXTRACKS];
int trackrecord[MAXTRACKS];
int trackvumeter[MAXTRACKS];
int leftvumeter;
int rightvumeter;
int buffertrackvumeter[MAXBUFFERS][MAXTRACKS];
int bufferleftvumeter[MAXBUFFERS];
int bufferrightvumeter[MAXBUFFERS];
int leftinputvumeter;
int rightinputvumeter;
int initted = 0;
int lag = 0;

short *trackbuffer[MAXBUFFERS];
char *inbuffer[MAXBUFFERS];
char *outbuffer[MAXBUFFERS];
HGLOBAL hinbuffer[MAXBUFFERS];
HGLOBAL houtbuffer[MAXBUFFERS];
HWAVEOUT hwaveout = NULL;
HWAVEIN hwavein = NULL;
WAVEHDR waveinhdr[MAXBUFFERS];
WAVEHDR waveouthdr[MAXBUFFERS];
WAVEFORMATEX waveinfmt;
WAVEFORMATEX waveoutfmt;
HANDLE hprocess = NULL;

int openwaveout(int sixteenbit, int stereo);
int openwavein(int sixteenbit, int stereo);
void closewaveout(void);
void closewavein(void);
void fillplaybuffer(void);
void fillplaybuffer16(void);
void fillplaybuffer8(void);
void fillrecordbuffer(void);
void readtrackbuffer(void);
void writetrackbuffer(void);

int sound_init(unsigned ps, unsigned b, unsigned rb);
void sound_uninit(void);
void sound_play(void);
void sound_record(void);
void sound_monitor(void);
void sound_stop(void);
void sound_update(void);
void sound_setspeed(unsigned newspeed);
void sound_setpos(int pos);
int sound_getpos(void);
int sound_createnew(void);
int sound_loadold(void);
void sound_closefile(void);
void sound_closemixdownfile(void);
int sound_mixdown(char *name, int fast);

int sound_getpos(void)
{
  if (filehandle == -1) return 0;
  return pos / (header.tracks * 2);
}

void sound_setpos(int newpos)
{
  if (play) return;
  if (filehandle == -1) return;
  newpos *= header.tracks * 2;
  maxpos = lseek(filehandle, 0, SEEK_END) - sizeof header - (2 * sizeof(short) * header.tracks);
  if (newpos > maxpos) newpos = maxpos;
  if (newpos < 0) newpos = 0;
  pos = newpos;
  lseek(filehandle, pos + sizeof header, SEEK_SET);
}

int sound_loadold(void)
{
  int c;

  if (play) return 0;
  if (filehandle != -1) sound_closefile();

  header.tracks = 0;
  filehandle = open(filename, O_BINARY | O_RDWR);
  if (filehandle == -1)
  {
        filehandle = open(filename, O_BINARY | O_RDONLY);
  }
  if (filehandle == -1) return 0;

  read(filehandle, &header, 8);
  if (memcmp(header.ident, ident, 8))
  {
    close(filehandle);
    filehandle = -1;
    return 0;
  }
  read(filehandle, &header.songname, (sizeof header)-8);

  for (c = 0; c < header.tracks; c++)
  {
    read(filehandle, &trackvol[c], sizeof(short));
    read(filehandle, &trackpan[c], sizeof(short));
    trackrecord[c] = REC_NONE;
  }
  sound_setspeed(header.playspeed);
  sound_setpos(0);
  return 1;
}

int sound_createnew(void)
{
  int c;

  if (play) return 0;
  if (header.tracks < 1) header.tracks = 1;
  if (header.tracks > MAXTRACKS) header.tracks = MAXTRACKS;
  if (filehandle != -1) sound_closefile();
  memcpy(header.ident, ident, 8);
  filehandle = open(filename, O_CREAT | O_BINARY | O_TRUNC | O_RDWR, S_IREAD | S_IWRITE);
  if (filehandle == -1)
  {
    header.tracks = 0;
    return 0;
  }
  write(filehandle, &header, sizeof header);
  for (c = 0; c < header.tracks; c++)
  {
    trackvol[c] = 128;
    trackpan[c] = 128;
    trackrecord[c] = REC_NONE;
    write(filehandle, &trackvol[c], sizeof(short));
    write(filehandle, &trackpan[c], sizeof(short));
  }
  sound_setspeed(header.playspeed);
  sound_setpos(0);
  return 1;
}

void sound_closefile(void)
{
  int c;

  if (filehandle == -1) return;

  punchin = -1;
  lseek(filehandle, 0, SEEK_SET);
  write(filehandle, &header, sizeof header);
  for (c = 0; c < header.tracks; c++)
  {
    write(filehandle, &trackvol[c], sizeof(short));
    write(filehandle, &trackpan[c], sizeof(short));
  }
  close(filehandle);
  filehandle = -1;
}

void sound_update(void)
{
  int nowork = 1;
  int buffersprocessed = 0;
  int buffercount;
  int firstbuffer = buffernum;
  int c;
  MMTIME mmtimeout;
  MMTIME mmtimein;

  mmtimeout.wType = TIME_SAMPLES;
  mmtimein.wType = TIME_SAMPLES;

  if (!hprocess) hprocess = GetCurrentProcess();

  if (filehandle != -1)
  {
    if (play)
    {
      if (record)
      {
        if ((!hwaveout) || (!hwavein)) return;

        waveInGetPosition(hwavein, &mmtimein, sizeof mmtimein);
        waveOutGetPosition(hwaveout, &mmtimeout, sizeof mmtimeout);
        lag = abs(mmtimein.u.sample - mmtimeout.u.sample);

        /* Buffer writing phase */
        while ((waveouthdr[buffernum].dwFlags & WHDR_DONE) && (waveinhdr[buffernum].dwFlags & WHDR_DONE))
        {
          nowork = 0;
          if (outbufferprepared[buffernum])
          {
            waveOutUnprepareHeader(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
            outbufferprepared[buffernum] = 0;
          }
          if (inbufferprepared[buffernum])
          {
            waveInUnprepareHeader(hwavein, &waveinhdr[buffernum], sizeof(WAVEHDR));
            inbufferprepared[buffernum] = 0;
          }

          if (bufferrecorded[buffernum])
          {
            fillrecordbuffer();
            writetrackbuffer();
            bufferrecorded[buffernum] = 0;
          }

          buffernum++;
          buffernum %= recordbuffers;
          buffersprocessed++;

          if (buffersprocessed == recordbuffers) break;
        }

        /* Buffer reading phase */
        buffernum = firstbuffer;
        buffercount = buffersprocessed;
        while (buffercount)
        {
          readtrackbuffer();
          fillplaybuffer();
          buffernum++;
          buffernum %= recordbuffers;
          buffercount--;
        }

        /* Buffer sending phase */
        buffernum = firstbuffer;
        buffercount = buffersprocessed;

        SetPriorityClass(hprocess, HIGH_PRIORITY_CLASS);
        while (buffercount)
        {
          waveinhdr[buffernum].dwFlags = 0;
          waveInPrepareHeader(hwavein, &waveinhdr[buffernum], sizeof(WAVEHDR));
          inbufferprepared[buffernum] = 1;
          waveouthdr[buffernum].dwFlags = 0;
          waveOutPrepareHeader(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
          outbufferprepared[buffernum] = 1;

          waveInAddBuffer(hwavein, &waveinhdr[buffernum], sizeof(WAVEHDR));
          waveInStart(hwavein);
          waveOutWrite(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));

          bufferrecorded[buffernum] = 1;
          buffernum++;
          buffernum %= recordbuffers;
          buffercount--;
        }
        SetPriorityClass(hprocess, NORMAL_PRIORITY_CLASS);
      }
      else
      {
        if (!hwaveout) return;

        /* Reading phase */
        while ((waveouthdr[buffernum].dwFlags & WHDR_DONE))
        {
          nowork = 0;
          if (outbufferprepared[buffernum])
          {
            waveOutUnprepareHeader(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
            outbufferprepared[buffernum] = 0;
          }
          readtrackbuffer();
          fillplaybuffer();
          if (mixdown)
          {
            write(mixfilehandle, outbuffer[buffernum], bfragment*sizeof(short)*2);
            mixdownpos += bfragment*sizeof(short)*2;
          }
          buffernum++;
          buffernum %= playbuffers;
          buffersprocessed++;

          if (buffersprocessed == playbuffers) break;
        }

        /* Sending phase */
        buffernum = firstbuffer;
        buffercount = buffersprocessed;
        while (buffercount)
        {
          waveouthdr[buffernum].dwFlags = 0;
          waveOutPrepareHeader(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
          outbufferprepared[buffernum] = 1;

          waveOutWrite(hwaveout, &waveouthdr[buffernum], sizeof(WAVEHDR));
          buffernum++;
          buffernum %= playbuffers;
          buffercount--;
        }
      }
    }
  }
  if ((!play) && (!record) && (monitor))
  {
    if (!hwavein) return;
    while ((waveinhdr[buffernum].dwFlags & WHDR_DONE))
    {
      nowork = 0;
      if (inbufferprepared[buffernum])
      {
        waveInUnprepareHeader(hwavein, &waveinhdr[buffernum], sizeof(WAVEHDR));
        inbufferprepared[buffernum] = 0;
      }

      if (bufferrecorded[buffernum])
      {
        fillrecordbuffer();
      }

      waveinhdr[buffernum].dwFlags = 0;
      waveInPrepareHeader(hwavein, &waveinhdr[buffernum], sizeof(WAVEHDR));
      inbufferprepared[buffernum] = 1;
      waveInAddBuffer(hwavein, &waveinhdr[buffernum], sizeof(WAVEHDR));
      waveInStart(hwavein);
      bufferrecorded[buffernum] = 1;

      buffernum++;
      buffernum %= playbuffers;
      buffersprocessed++;

      if (buffersprocessed == playbuffers) break;
    }
  }
  /* If there was no work to be done, delay for 10 ms */
  if (nowork) Sleep(10);
}

void sound_stop(void)
{
  int c,d;

  closewaveout();
  closewavein();

  play = 0;
  record = 0;
  monitor = 0;
  if (mixdown) sound_closemixdownfile();

  for (c = 0; c < MAXTRACKS; c++) trackvumeter[c] = 0;
  for (c = 0; c < MAXBUFFERS; c++)
  {
    for (d = 0; d < MAXTRACKS; d++)
    {
      buffertrackvumeter[c][d] = 0;
    }
    bufferleftvumeter[c] = 0;
    bufferrightvumeter[c] = 0;
  }

  leftvumeter = 0;
  rightvumeter = 0;
  leftinputvumeter = 0;
  rightinputvumeter = 0;
  lag = 0;

  sound_setpos(sound_getpos());
}

void sound_play(void)
{
  int c;

  if (filehandle == -1) return;
  if (play) sound_stop();
  if (monitor) sound_stop();

  if (!openwaveout(1, 1)) return; /* Sixteenbit stereo */

  buffernum = 0;
  playpos = pos;
  play = 1;
}

void sound_record(void)
{
  int c;

  if (filehandle == -1) return;

  if (play) sound_stop();
  if (monitor) sound_stop();

  if (openwavein(1, 1)) goto RECOK;
  if (!openwavein(1, 0)) return;

  RECOK:
  if (openwaveout(1, 1)) goto OK;
  if (!openwaveout(0, 0)) return; /* No full-duplex available */

  OK:
  for (c = 0; c < buffers;c++) bufferrecorded[c] = 0;
  buffernum = 0;
  lag = 0;
  playpos = pos;
  play = 1;
  record = 1;
}

int sound_mixdown(char *name, int fast)
{
  int c;

  if (filehandle == -1) return 0;
  if (mixfilehandle != -1) sound_closemixdownfile();
  mixfilehandle = open(name, O_CREAT | O_BINARY | O_TRUNC | O_RDWR, S_IREAD | S_IWRITE);
  if (mixfilehandle == -1) return 0;
  wavheader.playspeed = header.playspeed;
  wavheader.avgbytes = header.playspeed * 4;
  write(mixfilehandle, &wavheader, sizeof wavheader);
  if (play) sound_stop();
  if (monitor) sound_stop();

  if (!openwaveout(1, 1))
  {
    sound_closemixdownfile();
    return 0;
  }
  if (fast)
  {
    for (c = 0; c < buffers; c++)
    {
      waveouthdr[c].dwBufferLength = (bfragment / 16) * outsamplesize;
    }
  }
  buffernum = 0;
  mixdownpos = 0;
  playpos = pos;
  play = 1;
  mixdown = 1;

  return 1;
}

void sound_closemixdownfile(void)
{
  if (mixfilehandle != -1)
  {
    wavheader.datasize = mixdownpos;
    wavheader.totalsize = mixdownpos+36;
    lseek(mixfilehandle, 0, SEEK_SET);
    write(mixfilehandle, &wavheader, sizeof wavheader);
    close(mixfilehandle);
    mixfilehandle = -1;
    mixdown = 0;
  }
}

void sound_monitor(void)
{
  if (play) sound_stop();
  if (monitor) sound_stop();

  if (openwavein(1, 1)) goto MONITOROK;
  if (!openwavein(1, 0)) return;
  MONITOROK:
  buffernum = 0;
  monitor = 1;
}

int sound_init(unsigned ps, unsigned b, unsigned rb)
{
  int c;
  char *envstr;

  sound_uninit();

  for (c = 0; c < MAXBUFFERS; c++)
  {
    hinbuffer[c] = NULL;
    inbuffer[c] = NULL;
    houtbuffer[c] = NULL;
    outbuffer[c] = NULL;
    trackbuffer[c] = NULL;
    bufferrecorded[c] = 0;
    inbufferprepared[c] = 0;
    outbufferprepared[c] = 0;
  }
  for (c = 0; c < MAXTRACKS; c++)
  {
    trackvumeter[c] = 0;
    trackrecord[c] = REC_NONE;
  }

  per_second = ps;
  playbuffers = b;
  recordbuffers = rb;
  if (playbuffers < 2) playbuffers = 2;
  if (playbuffers > MAXBUFFERS) playbuffers = MAXBUFFERS;
  if (recordbuffers < 2) recordbuffers = 2;
  if (recordbuffers > MAXBUFFERS) recordbuffers = MAXBUFFERS;
  buffers = recordbuffers;
  if (playbuffers > buffers) buffers = playbuffers;
  if (per_second < 1) per_second = 1;
  if (per_second > 50) per_second = 50;
  maxfragment = MAXSPEED / per_second;

  sound_setspeed(MAXSPEED);

  for (c = 0; c < buffers; c++)
  {
    trackbuffer[c] = malloc(maxfragment*sizeof(short)*MAXTRACKS);
    if (!trackbuffer[c])
    {
      printf("Not enough memory for trackbuffers. Decrease amount of BUFFERS.\n");
      return 0;
    }
    hinbuffer[c] = GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE |
      GMEM_ZEROINIT, maxfragment*sizeof(short)*2);
    if (!hinbuffer[c])
    {
      printf("Not enough memory for wavein buffers. Decrease amount of BUFFERS.\n");
      return 0;
    }
    inbuffer[c] = GlobalLock(hinbuffer[c]);
    if (!inbuffer[c])
    {
      printf("Not enough memory for wavein buffers. Decrease amount of BUFFERS.\n");
      return 0;
    }
    houtbuffer[c] = GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE |
      GMEM_ZEROINIT, maxfragment*sizeof(short)*2);
    if (!houtbuffer[c])
    {
      printf("Not enough memory for waveout buffers. Decrease amount of BUFFERS.\n");
      return 0;
    }
    outbuffer[c] = GlobalLock(houtbuffer[c]);
    if (!outbuffer[c])
    {
      printf("Not enough memory for waveout buffers. Decrease amount of BUFFERS.\n");
      return 0;
    }
  }
  initted = 1;
  return 1;
}

void sound_uninit(void)
{
  int c;

  if (!initted) return;

  sound_stop();
  sound_closefile();

  for (c = 0; c < buffers; c++)
  {
    if (trackbuffer[c])
    {
      free(trackbuffer[c]);
      trackbuffer[c] = NULL;
    }
    if (inbuffer[c])
    {
      GlobalUnlock(hinbuffer[c]);
      inbuffer[c] = NULL;
    }
    if (hinbuffer[c])
    {
      GlobalFree(hinbuffer[c]);
      hinbuffer[c] = NULL;
    }
    if (outbuffer[c])
    {
      GlobalUnlock(houtbuffer[c]);
      outbuffer[c] = NULL;
    }
    if (houtbuffer[c])
    {
      GlobalFree(houtbuffer[c]);
      houtbuffer[c] = NULL;
    }
  }

  initted = 0;
}

void sound_setspeed(unsigned newspeed)
{
  if (play) return;
  if (record) return;
  if (monitor) return;

  if (newspeed < MINSPEED) newspeed = MINSPEED;
  if (newspeed > MAXSPEED) newspeed = MAXSPEED;

  header.playspeed = newspeed;
  bfragment = newspeed / per_second;
}

int openwaveout(int sixteenbit, int stereo)
{
  int c;

  closewaveout();

  outsamplesize = 1;
  waveoutfmt.wFormatTag = WAVE_FORMAT_PCM;
  if (stereo)
  {
    waveoutfmt.nChannels = 2;
    outsamplesize <<= 1;
  }
  else waveoutfmt.nChannels = 1;
  waveoutfmt.nSamplesPerSec = header.playspeed;
  if (sixteenbit)
  {
    waveoutfmt.wBitsPerSample = 16;
    outsamplesize <<= 1;
  }
  else waveoutfmt.wBitsPerSample = 8;
  waveoutfmt.nAvgBytesPerSec = outsamplesize * header.playspeed;
  waveoutfmt.nBlockAlign = outsamplesize;
  if (waveOutOpen(&hwaveout, WAVE_MAPPER, &waveoutfmt, NULL, NULL, CALLBACK_NULL | WAVE_ALLOWSYNC) != MMSYSERR_NOERROR) return 0;

  /* Set up waveout buffers */
  for (c = 0; c < buffers; c++)
  {
    waveouthdr[c].lpData = outbuffer[c];
    waveouthdr[c].dwBufferLength = bfragment * outsamplesize;
    waveouthdr[c].dwFlags = WHDR_DONE;
    waveouthdr[c].dwLoops = 0;
  }
  return 1;
}

int openwavein(int sixteenbit, int stereo)
{
  int c;

  closewavein();

  insamplesize = 1;
  waveinfmt.wFormatTag = WAVE_FORMAT_PCM;
  if (stereo)
  {
    waveinfmt.nChannels = 2;
    insamplesize <<= 1;
  }
  else waveinfmt.nChannels = 1;
  waveinfmt.nSamplesPerSec = header.playspeed;
  if (sixteenbit)
  {
    waveinfmt.wBitsPerSample = 16;
    insamplesize <<= 1;
  }
  else waveinfmt.wBitsPerSample = 8;
  waveinfmt.nAvgBytesPerSec = insamplesize * header.playspeed;
  waveinfmt.nBlockAlign = insamplesize;
  if (waveInOpen(&hwavein, WAVE_MAPPER, &waveinfmt, NULL, NULL, CALLBACK_NULL | WAVE_ALLOWSYNC) != MMSYSERR_NOERROR) return 0;

  /* Set up wavein buffers */
  for (c = 0; c < buffers; c++)
  {
    waveinhdr[c].lpData = inbuffer[c];
    waveinhdr[c].dwBufferLength = bfragment * insamplesize;
    waveinhdr[c].dwFlags = WHDR_DONE;
    waveinhdr[c].dwLoops = 0;
  }
  return 1;
}

void closewaveout(void)
{
  int c;

  if (hwaveout)
  {
    waveOutReset(hwaveout);
    for (c = 0; c < MAXBUFFERS; c++)
    {
      if (outbufferprepared[c])
      {
        waveOutUnprepareHeader(hwaveout, &waveouthdr[c], sizeof(WAVEHDR));
        outbufferprepared[c] = 0;
      }
    }
    waveOutClose(hwaveout);
    hwaveout = NULL;
  }
}

void closewavein(void)
{
  int c;

  if (hwavein)
  {
    waveInReset(hwavein);
    for (c = 0; c < MAXBUFFERS; c++)
    {
      if (inbufferprepared[c])
      {
        waveInUnprepareHeader(hwavein, &waveinhdr[c], sizeof(WAVEHDR));
        inbufferprepared[c] = 0;
      }
    }
    waveInClose(hwavein);
    hwaveout = NULL;
  }
}

void readtrackbuffer(void)
{
  int c;
  int maxbuffers;

  short *pptr = trackbuffer[buffernum];
  memset(pptr, 0, bfragment*header.tracks*2);

  lseek(filehandle, playpos + sizeof header + (2 * sizeof(short) * header.tracks), SEEK_SET);
  bufferpos[buffernum] = playpos;
  read(filehandle, pptr, bfragment*header.tracks*2);
  playpos += bfragment*header.tracks*2;

  maxbuffers = playbuffers;
  if (record) maxbuffers = recordbuffers;

  pos = playpos;
  for (c = 0; c < maxbuffers; c++)
  {
    if (bufferpos[c] < pos)
    {
      int d;

      for (d = 0; d < header.tracks; d++)
      {
        trackvumeter[d] = buffertrackvumeter[c][d];
      }
      leftvumeter = bufferleftvumeter[c];
      rightvumeter = bufferrightvumeter[c];
      pos = bufferpos[c];
    }
  }
}

void writetrackbuffer(void)
{
  short *rptr = trackbuffer[buffernum];
  int truepos = bufferpos[buffernum] / (header.tracks*2);
  if (((punchin == -1) || (truepos >= punchin)) &&
      ((punchout == -1) || (truepos < punchout)))
  {
    lseek(filehandle, bufferpos[buffernum] + sizeof header + (2 * sizeof(short) * header.tracks), SEEK_SET);
    write(filehandle, rptr, bfragment*header.tracks*2);
  }
}

void fillplaybuffer(void)
{
  if (outsamplesize == 4) fillplaybuffer16();
  else fillplaybuffer8();
}

void fillplaybuffer16(void)
{
  short *pptr = trackbuffer[buffernum];
  short *dmaptr = (short *)outbuffer[buffernum];
  int c,t;
  int leftsample,rightsample;

  for (t=0; t < header.tracks; t++)
  {
    trackleftvol[t] = (trackvol[t]*(256-trackpan[t]))/128;
    trackrightvol[t] = (trackvol[t]*trackpan[t])/128;
    buffertrackvumeter[buffernum][t] = 0;
  }
  bufferleftvumeter[buffernum] = 0;
  bufferrightvumeter[buffernum] = 0;

  c = bfragment;
  while(c--)
  {
    leftsample = 0;
    rightsample = 0;
    for (t=0; t < header.tracks; t++)
    {
      if ((!record) || (trackrecord[t] == 0))
      {
        leftsample += *pptr * trackleftvol[t];
        rightsample += *pptr * trackrightvol[t];
        if (abs(*pptr) > buffertrackvumeter[buffernum][t]) buffertrackvumeter[buffernum][t] = abs(*pptr);
      }

      pptr++;
    }
    leftsample >>= 8;
    rightsample >>= 8;
    if (leftsample > 32767) leftsample = 32767;
    if (leftsample < -32768) leftsample = -32768;
    if (rightsample > 32767) rightsample = 32767;
    if (rightsample < -32768) rightsample = -32768;
    if (abs(leftsample) > bufferleftvumeter[buffernum]) bufferleftvumeter[buffernum] = abs(leftsample);
    if (abs(rightsample) > bufferrightvumeter[buffernum]) bufferrightvumeter[buffernum] = abs(rightsample);
    *dmaptr++ = leftsample;
    *dmaptr++ = rightsample;
  }
}

void fillplaybuffer8(void)
{
  short *pptr = trackbuffer[buffernum];
  unsigned char *dmaptr = outbuffer[buffernum];
  int c,t;
  int sample;

  for (t=0; t < header.tracks; t++)
  {
    buffertrackvumeter[buffernum][t] = 0;
  }
  bufferleftvumeter[buffernum] = 0;
  bufferrightvumeter[buffernum] = 0;

  c = bfragment;
  while(c--)
  {
    sample = 0;
    for (t=0; t < header.tracks; t++)
    {
      if ((!record) || (trackrecord[t] == 0))
      {
        sample += *pptr * trackvol[t];
        if (abs(*pptr) > buffertrackvumeter[buffernum][t]) buffertrackvumeter[buffernum][t] = abs(*pptr);
      }
      pptr++;
    }
    sample >>= 8;
    if (sample > 32767) sample = 32767;
    if (sample < -32768) sample = -32768;
    if (abs(sample) > bufferleftvumeter[buffernum])
    {
      bufferleftvumeter[buffernum] = abs(sample);
      bufferrightvumeter[buffernum] = abs(sample);
    }

    *dmaptr++ = (sample >> 8) + 0x80;
  }
}

void fillrecordbuffer(void)
{
  short *rptr = trackbuffer[buffernum];
  short *dmaptr = (short *)inbuffer[buffernum];
  int c, t;

  leftinputvumeter = 0;
  rightinputvumeter = 0;

  if (insamplesize < 4)
  {
    if (record)
    {
      c = bfragment;

      while (c--)
      {
        if (abs(*dmaptr) > leftinputvumeter)
        {
          leftinputvumeter = abs(*dmaptr);
          rightinputvumeter = abs(*dmaptr);
        }

        for (t = 0; t < header.tracks; t++)
        {
          if (trackrecord[t] != REC_NONE) rptr[t] = *dmaptr;
        }
        rptr += header.tracks;
        dmaptr++;
      }
    }
    else
    {
      c = bfragment;

      while (c--)
      {
        if (abs(*dmaptr) > leftinputvumeter)
        {
          leftinputvumeter = abs(*dmaptr);
          rightinputvumeter = abs(*dmaptr);
        }
        dmaptr++;
      }
    }
  }
  else
  {
    if (record)
    {
      c = bfragment;

      while (c--)
      {
        if (abs(dmaptr[0]) > leftinputvumeter) leftinputvumeter = abs(dmaptr[0]);
        if (abs(dmaptr[1]) > rightinputvumeter) rightinputvumeter = abs(dmaptr[1]);

        for (t = 0; t < header.tracks; t++)
        {
          if (trackrecord[t] == REC_LEFT) rptr[t] = dmaptr[0];
          if (trackrecord[t] == REC_RIGHT) rptr[t] = dmaptr[1];
        }
        rptr += header.tracks;
        dmaptr += 2;
      }
    }
    else
    {
      c = bfragment;

      while (c--)
      {
        if (abs(dmaptr[0]) > leftinputvumeter) leftinputvumeter = abs(dmaptr[0]);
        if (abs(dmaptr[1]) > rightinputvumeter) rightinputvumeter = abs(dmaptr[1]);

        dmaptr += 2;
      }
    }
  }
}


