#define MAXTRACKS 12
#define MINSPEED 5000
#define MAXSPEED 44100

#define DEFAULTPLAYBUFFERS 3
#define DEFAULTRECORDBUFFERS 10
#define DEFAULTPER_SECOND 5

#define REC_NONE 0
#define REC_LEFT 1
#define REC_RIGHT 2


typedef struct
{
  char ident[8];
  char songname[30];
  unsigned short tracks;
  unsigned short playspeed;
} HEADER;

typedef struct
{
  char riffid[4];
  int totalsize;
  char waveid[4];
  char formatid[4];
  int formatsize;
  short format;
  short channels;
  int playspeed;
  unsigned short avgbytes;
  short channels2;
  short blockalign;
  short bits;
  char dataid[4];
  int datasize;
} WAVHEADER;

int sound_init(unsigned ps, unsigned b, unsigned rb);
void sound_uninit(void);
void sound_play(void);
void sound_record(void);
void sound_stop(void);
void sound_monitor(void);
void sound_update(void);
void sound_setspeed(unsigned newspeed);
void sound_setpos(int pos);
int sound_getpos(void);
int sound_createnew(void);
int sound_loadold(void);
void sound_closefile(void);
void sound_closemixdownfile(void);
int sound_mixdown(char *name, int fast);

extern int play;
extern int record;
extern int mixdown;
extern short trackvol[];
extern short trackpan[];
extern int trackvumeter[];
extern int trackrecord[];
extern int leftvumeter;
extern int rightvumeter;
extern int leftinputvumeter;
extern int rightinputvumeter;
extern HEADER header;
extern char filename[];
extern int filehandle;
extern short *trackbuffer[];
extern int bfragment;
extern int pos;
extern int punchin;
extern int punchout;
extern int lag;
