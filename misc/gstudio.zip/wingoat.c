/*
 * GOATSTUDIO main program & user interface
 */

#include <windows.h>
#include <wincon.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <conio.h>
#include <mem.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "gsound.h"

#define TRACKXPOS 2
#define MASTERVOLXPOS 7
#define HELPXPOS 43
#define MIXERXPOS 30

#define MAX_COLUMNS 80
#define MAX_ROWS 25

short *virtualscreen;

char textbuffer[80];
char inputbuffer[80];
int min, sec, hundredth;
int ctrack = 0;
char exitprogram = 0;
int key;
int virtualkey;
int oldvol[MAXTRACKS] = {0};
char oldfilename[50];
char newfilename[50];
int oldmixdown = 0;
int oldpunchin = 0;
int oldpunchout = 0;

char *programname = "GOATSTUDIO for Windows v1.14 by Cadaver";
short *scrbuffer = NULL;
HANDLE hconsole = NULL;
HANDLE hconsoleinput = NULL;

int main(int argc, char **argv);
void docommand(void);
void buildmainscreen(void);
void getkey(void);
void waitkey(void);
void handle_int(void);
int initscreen(void);
void clearscreen(void);
void fliptoscreen(void);
void printtext(int x, int y, int color, const char *text);
void printtextc(int y, int color, const char *text);
void printblank(int x, int y, int length);
void printblankc(int x, int y, int color, int length);
void closescreen(void);
void printtracks(void);
void printtrack(int num);
void printplayinfo(void);
void printsonginfo(void);
void calculatetime(void);
void drawlight(int x, int y, int on);
void drawlightchar(int x, int y, int chr);
void drawvumeter(int x, int y, unsigned level);
void inputtext(int x, int y, int color, char *buffer, int maxlength, char *message);
void inputtext2(int x, int y, int color, char *buffer, int maxlength, char *message);
void cursoroff(void);
void cursoron(int x, int y);
void cursormove(int x, int y);

int main(int argc, char **argv)
{
  unsigned ps = DEFAULTPER_SECOND;
  unsigned b = DEFAULTPLAYBUFFERS;
  unsigned rb = DEFAULTRECORDBUFFERS;
  FILE *configfile;
  int c;
  char *filenameptr = NULL;

  /* Set signal handler */
  signal(SIGINT, handle_int);

  /* Get configuration info */
  argv[0][strlen(argv[0])-3] = 'c';
  argv[0][strlen(argv[0])-2] = 'f';
  argv[0][strlen(argv[0])-1] = 'g';
  configfile = fopen(argv[0], "rt");
  if (configfile)
  {
        fscanf(configfile, "%d", &b);
        fscanf(configfile, "%d", &rb);
        fscanf(configfile, "%d", &ps);
        fclose(configfile);
  }

  if (argc > 1)
  {
    int info = 0;

    for (c = 1; c < argc; c++)
    {
      strupr(argv[c]);
      if ((argv[c][0] == '-') || (argv[c][0] == '/'))
      {
        switch(argv[c][1])
        {
          case '?':
          printf("Usage: WINGOAT [tapefilename] [options]\n\n"
                 "Options:\n"
                 "/Bxx Set number of playback buffers DEFAULT=3\n"
                 "/Rxx Set number of recording buffers DEFAULT=10\n"
                 "/Pxx Set number of buffers played per second, affects buffer size DEFAULT=5\n"
                 "/?   Show this info again\n\n"
                 "Buffer settings will be stored into a file called WINGOAT.CFG in the same\n"
                 "directory as the executable file.\n");
          info = 1;
          break;

          case 'B':
          sscanf(&argv[c][2], "%u", &b);
          break;

          case 'R':
          sscanf(&argv[c][2], "%u", &rb);
          break;

          case 'P':
          sscanf(&argv[c][2], "%u", &ps);
          break;
        }
      }
      else
      {
        filenameptr = argv[c];
      }
    }
    if (info) return 0;
  }

  /* Store configuration to config file */
  configfile = fopen(argv[0], "wt");
  if (configfile)
  {
        fprintf(configfile, "%d %d %d", b, rb, ps);
        fclose(configfile);
  }

  if (!sound_init(ps,b,rb))
  {
        printf("Sound device initialization failure!\n");
        return 1;
  }
  atexit(sound_uninit);

  if (!initscreen())
  {
    printf("Cannot open console!\n");
    return 1;
  }
  atexit(closescreen);

  if (filenameptr)
  {
    if (strlen(filenameptr)+1 < 256)
    {
      strcpy(filename, filenameptr);
      sound_loadold();
    }
  }

  sound_monitor();
  buildmainscreen();

  while (!exitprogram)
  {
    waitkey();
    docommand();
    printplayinfo();
    printtracks();
    fliptoscreen();
  }

  END:
  clearscreen();
  fliptoscreen();
  cursoron(0,0);
  return 0;
}

void docommand(void)
{
  if (key == '<')
  {
    if (!play)
    {
      sound_setpos(sound_getpos() - header.playspeed/10L);
    }
  }

  if (key == '>')
  {
    if (!play)
    {
      sound_setpos(sound_getpos() + header.playspeed/10L);
    }
  }
  if (key == 'z')
  {
    if (!play)
    {
      sound_setpos(sound_getpos() - header.playspeed);
    }
  }

  if (key == 'x')
  {
    if (!play)
    {
      sound_setpos(sound_getpos() + header.playspeed);
    }
  }
  if (key == 'Z')
  {
    if (!play)
    {
      sound_setpos(sound_getpos() - header.playspeed * 3);
    }
  }
  if (key == 'X')
  {
    if (!play)
    {
      sound_setpos(sound_getpos() + header.playspeed * 3);
    }
  }

  if ((key >= '1') && (key <= '9'))
  {
    int newtrack = key - '1';
    if (newtrack < header.tracks) ctrack = newtrack;
  }

  if (key == '+')
  {
    if (trackvol[ctrack] < 256-2) trackvol[ctrack] += 2;
    else trackvol[ctrack] = 256;
  }

  if (key == '-')
  {
    if (trackvol[ctrack] > 2) trackvol[ctrack] -= 2;
    else trackvol[ctrack] = 0;
  }

  switch(virtualkey)
  {
    case VK_UP:
    if (trackvol[ctrack] < 256-16) trackvol[ctrack] += 16;
    else trackvol[ctrack] = 256;
    break;

    case VK_DOWN:
    if (trackvol[ctrack] > 16) trackvol[ctrack] -= 16;
    else trackvol[ctrack] = 0;
    break;

    case VK_RIGHT:
    if (trackpan[ctrack] < 256-8) trackpan[ctrack] += 8;
    else trackpan[ctrack] = 256;
    break;

    case VK_LEFT:
    if (trackpan[ctrack] > 8) trackpan[ctrack] -= 8;
    else trackpan[ctrack] = 0;
    break;

    case '0':
    {
      int newtrack = 9;
      if (newtrack < header.tracks) ctrack = newtrack;
    }
    break;

    case 'Q':
    {
      int newtrack = 10;
      if (newtrack < header.tracks) ctrack = newtrack;
    }
    break;

    case 'W':
    {
      int newtrack = 11;
      if (newtrack < header.tracks) ctrack = newtrack;
    }

    case 'R':
    trackrecord[ctrack]++;
    if (trackrecord[ctrack] > REC_RIGHT) trackrecord[ctrack] = REC_NONE;
    break;

    case 'M':
    if (trackvol[ctrack])
    {
      oldvol[ctrack] = trackvol[ctrack];
      trackvol[ctrack] = 0;
    }
    else
    {
      trackvol[ctrack] = oldvol[ctrack];
    }
    break;

    case VK_SPACE:
    if (!play)
    {
      sound_play();
    }
    else sound_monitor();
    break;

    case VK_RETURN:
    if (!record) sound_record();
    else sound_monitor();
    break;

    case VK_ESCAPE:
    printtextc(20, 15, "Really Quit (y/n)?");
    waitkey();
    printblank(0, 20, 80);
    if ((key == 'y') || (key == 'Y')) exitprogram = 1;
    break;

    case 'S':
    if (filehandle != -1)
    {
      sprintf(inputbuffer, "%u", header.playspeed);
      inputtext(12, 23, 14, inputbuffer, 6, "Enter Samplerate!");
      sscanf(inputbuffer, "%u", &header.playspeed);
      sound_stop();
      sound_setspeed(header.playspeed);
      sound_monitor();
      printsonginfo();
    }
    break;

    case 'T':
    if (filehandle != -1)
    {
      strcpy(inputbuffer, header.songname);
      inputtext(12, 22, 14, inputbuffer, 30, "Enter Song Title!");
      memset(header.songname, 0, 30);
      strcpy(header.songname, inputbuffer);
      printsonginfo();
    }
    break;

    case VK_F1:
    if (!play)
    {
      int tracks;
      int testhandle;

      sound_stop();
      sound_closefile();

      filename[0] = 0;
      header.songname[0] = 0;

      inputtext(12, 21, 14, filename, 50, "Enter Tapefilename To CREATE!");
      testhandle = open(filename, O_RDONLY | O_BINARY);
      if (testhandle != -1)
      {
        close(testhandle);
        printtextc(20, 15, "File Exists. Overwrite (y/n)?");
        waitkey();
        printblank(0, 20, 80);
        if ((key != 'y') && (key != 'Y')) break;
      }

      strcpy(inputbuffer, header.songname);
      inputtext(12, 22, 14, inputbuffer, 30, "Enter Song Title For New Tape!");
      memset(header.songname, 0, 30);
      strcpy(header.songname, inputbuffer);

      header.playspeed = 44100;
      sprintf(inputbuffer, "%u", header.playspeed);
      inputtext(12, 23, 14, inputbuffer, 6, "Enter Samplerate For New Tape!");
      sscanf(inputbuffer, "%u", &header.playspeed);

      {
        int newtracks = 4;
        sprintf(inputbuffer, "%d", newtracks);
        inputtext(12, 24, 14, inputbuffer, 3, "Enter Tracks For New Tape (CANNOT BE CHANGED LATER!)");
        sscanf(inputbuffer, "%d", &newtracks);
        header.tracks = newtracks;
      }

      sound_createnew();
      sound_monitor();
      printsonginfo();
    }
    break;

    case VK_F2:
    if (!play)
    {
      int tracks;

      sound_stop();
      sound_closefile();
      filename[0] = 0;

      inputtext(12, 21, 14, filename, 50, "Enter Tapefilename To Load!");

      sound_loadold();
      sound_monitor();
      printsonginfo();
    }
    break;

    case VK_F3:
    if ((filehandle != -1) && (!play))
    {
      short channels = -1;
      int importhandle;
      char ident[5];
      ident[4] = 0;

      inputbuffer[0] = 0;
      inputtext2(10, 20, 15, inputbuffer, 50, "Import WAV/RAWfile:");
      printblank(0, 20, 80);

      importhandle = open(inputbuffer, O_RDONLY | O_BINARY);
      if (importhandle != -1)
      {
        read(importhandle, ident, 4);
        /* Skip over WAV header if necessary */
        if (!memcmp(ident, "RIFF", 4))
        {
          lseek(importhandle, 12, SEEK_SET);
          for (;;)
          {
            int bytesread;
            int chunksize;

            bytesread = read(importhandle, ident, 4);
            if (bytesread < 4) break;
            read(importhandle, &chunksize, sizeof chunksize);
            if (!memcmp(ident, "data", 4)) break;
            if (!memcmp(ident, "fmt", 3))
            {
              int oldpos = tell(importhandle);
              lseek(importhandle, 2, SEEK_CUR); /* Seek to n. of channels */
              read(importhandle, &channels, sizeof channels);
              lseek(importhandle, oldpos, SEEK_SET);
            }
            lseek(importhandle, chunksize, SEEK_CUR);
          }
        }
        else lseek(importhandle, 0, SEEK_SET);

        if (channels == -1)
        {
          printtextc(20,15,"Mono or stereo (m/s)?");
          waitkey();
          printblank(0, 20, 80);
          if ((key == 's') || (key == 'S'))
          {
            channels = 2;
          }
          else channels = 1;
        }

        if (channels == 2)
        {
          int track1 = -1;
          int track2 = -1;

          inputbuffer[0] = 0;
          inputtext2(15, 20, 15, inputbuffer, 3, "Enter Track For Imported LEFT Channel:");
          sscanf(inputbuffer, "%d", &track1);
          track1--;
          printblank(0, 20, 80);
          inputbuffer[0] = 0;
          inputtext2(15, 20, 15, inputbuffer, 3, "Enter Track For Imported RIGHT Channel:");
          sscanf(inputbuffer, "%d", &track2);
          track2--;
          printblank(0, 20, 80);

          if ((track1 >= 0) && (track1 < header.tracks) &&
              (track2 >= 0) && (track2 < header.tracks))
          {
            short *srcptr = trackbuffer[0];
            short *destptr = trackbuffer[1];
            int c;
            int bytesread;
            int writepos = pos;
            int sourcestart = tell(importhandle);
            int sourceend = lseek(importhandle, 0, SEEK_END);
            int sourcelen = sourceend - sourcestart;
            sourcelen /= 100L;

            if (!sourcelen) sourcelen = 1;
            lseek(importhandle, sourcestart, SEEK_SET);

            for (;;)
            {
              sprintf(textbuffer, "Working (%ld%% done)", (tell(importhandle)-sourcestart)/sourcelen);
              printblank(0, 20, 80);
              printtextc(20, 15, textbuffer);
              fliptoscreen();
              lseek(filehandle, writepos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
              memset(srcptr, 0, bfragment * 4);
              memset(destptr, 0, bfragment*header.tracks * 2);
              read(filehandle, destptr, bfragment*header.tracks * 2);
              bytesread = read(importhandle, srcptr, bfragment * 4);
              if (!bytesread) break;
              for (c = 0; c < bfragment; c++)
              {
                destptr[c*header.tracks+track1] = srcptr[0+2*c];
                destptr[c*header.tracks+track2] = srcptr[1+2*c];
              }
              lseek(filehandle, writepos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
              write(filehandle, destptr, bfragment*header.tracks * 2);
              writepos += bfragment*header.tracks * 2;

              if (bytesread < bfragment * 4) break;
            }
            printblank(0, 20, 80);
          }
        }
        else
        {
          int track1 = -1;

          inputbuffer[0] = 0;
          inputtext2(15, 20, 15, inputbuffer, 3, "Enter Track For Imported Sound:");
          sscanf(inputbuffer, "%d", &track1);
          track1--;
          printblank(0, 20, 80);
          if ((track1 >= 0) && (track1 < header.tracks))
          {
            short *srcptr = trackbuffer[0];
            short *destptr = trackbuffer[1];
            int c;
            int bytesread;
            int writepos = pos;
            int sourcestart = tell(importhandle);
            int sourceend = lseek(importhandle, 0, SEEK_END);
            int sourcelen = sourceend - sourcestart;
            sourcelen /= 100L;

            if (!sourcelen) sourcelen = 1;
            lseek(importhandle, sourcestart, SEEK_SET);

            for (;;)
            {
              sprintf(textbuffer, "Working (%ld%% done)", (tell(importhandle)-sourcestart)/sourcelen);
              printblank(0, 20, 80);
              printtextc(20, 15, textbuffer);
              fliptoscreen();
              lseek(filehandle, writepos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
              memset(srcptr, 0, bfragment * 2);
              memset(destptr, 0, bfragment*header.tracks * 2);
              read(filehandle, destptr, bfragment*header.tracks * 2);
              bytesread = read(importhandle, srcptr, bfragment * 2);
              if (!bytesread) break;
              for (c = 0; c < bfragment; c++)
              {
                destptr[c*header.tracks+track1] = srcptr[c];
              }
              lseek(filehandle, writepos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
              write(filehandle, destptr, bfragment*header.tracks * 2);
              writepos += bfragment*header.tracks * 2;

              if (bytesread < bfragment * 2) break;
            }
            printblank(0, 20, 80);
          }
        }
      }
      close(importhandle);
    }
    break;

    case VK_F5:
    if ((filehandle != -1) && (!play))
    {
      short channels = -1;
      int lastopenhandle = -1;
      int importhandle[MAXTRACKS];
      char name[80];
      char buffer[80];
      char ident[5];
      int track;
      unsigned c;
      ident[4] = 0;

      printtextc(20, 15, "Confirm Import All (y/n)");
      waitkey();
      printblank(0, 20, 80);
      if ((key != 'y') && (key != 'Y')) break;

      for (track = 0; track < header.tracks; track++)
      {
        strcpy(name, filename);
        for (c = 0; c < strlen(name); c++)
        {
          if (name[c] == '.') name[c] = 0;
        }
        sprintf(buffer, "_track%02d.wav", track+1);
        strcat(name, buffer);
        importhandle[track] = open(name, O_RDONLY | O_BINARY);
        if (importhandle[track] != -1)
        {
          lastopenhandle = track;
          read(importhandle[track], ident, 4);
          /* Skip over WAV header if necessary */
          if (!memcmp(ident, "RIFF", 4))
          {
            lseek(importhandle[track], 12, SEEK_SET);
            for (;;)
            {
              int bytesread;
              int chunksize;

              bytesread = read(importhandle[track], ident, 4);
              if (bytesread < 4) break;
              read(importhandle[track], &chunksize, sizeof chunksize);
              if (!memcmp(ident, "data", 4)) break;
              if (!memcmp(ident, "fmt", 3))
              {
                int oldpos = tell(importhandle[track]);
                lseek(importhandle[track], 2, SEEK_CUR); /* Seek to n. of channels */
                read(importhandle[track], &channels, sizeof channels);
                lseek(importhandle[track], oldpos, SEEK_SET);
              }
              lseek(importhandle[track], chunksize, SEEK_CUR);
            }
          }
          else lseek(importhandle[track], 0, SEEK_SET);
        }
      }
      if (lastopenhandle == -1) break;
      {
        short *srcptr = trackbuffer[0];
        short *destptr = trackbuffer[1];
        int c;
        int bytesread;
        int writepos = pos;
        int sourcestart = tell(importhandle[lastopenhandle]);
        int sourceend = lseek(importhandle[lastopenhandle], 0, SEEK_END);
        int sourcelen = sourceend - sourcestart;
        sourcelen /= 100L;

        if (!sourcelen) sourcelen = 1;
        lseek(importhandle[lastopenhandle], sourcestart, SEEK_SET);

        for (;;)
        {
          sprintf(textbuffer, "Working (%ld%% done)", (tell(importhandle[lastopenhandle])-sourcestart)/sourcelen);
          printblank(0, 20, 80);
          printtextc(20, 15, textbuffer);
          fliptoscreen();
          lseek(filehandle, writepos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
          memset(srcptr, 0, bfragment * 2);
          memset(destptr, 0, bfragment*header.tracks * 2);
          read(filehandle, destptr, bfragment*header.tracks * 2);
          for (track = 0; track < header.tracks; track++)
          {
            if (importhandle[track] != -1)
            {
              bytesread = read(importhandle[track], srcptr, bfragment * 2);
              if (!bytesread) goto END;
              for (c = 0; c < bfragment; c++)
              {
                destptr[c*header.tracks+track] = srcptr[c];
              }
            }
          }
          lseek(filehandle, writepos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
          write(filehandle, destptr, bfragment*header.tracks * 2);
          writepos += bfragment*header.tracks * 2;
          if (bytesread < bfragment * 2) break;
        }
        END:
      }
      for (track = 0; track < header.tracks; track++)
      {
        if (importhandle[track] != -1)
          close(importhandle[track]);
      }
      printblank(0, 20, 80);
      fliptoscreen();
    }
    break;

    case VK_F4:
    if ((filehandle != -1) && (!play))
    {
      int exporthandle;

      inputbuffer[0] = 0;
      inputtext2(10, 20, 15, inputbuffer, 50, "Export To WAVfile:");
      printblank(0, 20, 80);

      exporthandle = open(inputbuffer, O_CREAT | O_BINARY | O_TRUNC | O_RDWR, S_IREAD | S_IWRITE);

      if (exporthandle != -1)
      {
        int track = -1;

        inputbuffer[0] = 0;
        inputtext2(15, 20, 15, inputbuffer, 3, "Enter Track To Export:");
        sscanf(inputbuffer, "%d", &track);
        printblank(0, 20, 80);
        track--;

        if ((track >= 0) && (track < header.tracks))
        {
          WAVHEADER exportheader = {"RIFF", 0, "WAVE", "fmt ", 16, 1, 1, 0, 0, 1, 2, 16, "data", 0};
          int datalength;
          int written = 0;
          int startpos, endpos;
          short *srcptr = trackbuffer[0];
          short *destptr = trackbuffer[1];

          startpos = lseek(filehandle, pos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
          endpos = lseek(filehandle, 0, SEEK_END);
          datalength = (endpos - startpos) / header.tracks;
          datalength &= 0xfffffffe;
          lseek(filehandle, startpos, SEEK_SET);

          exportheader.playspeed = header.playspeed;
          exportheader.avgbytes = header.playspeed * 2;
          exportheader.datasize = datalength;
          exportheader.totalsize = datalength + 36;
          write(exporthandle, &exportheader, sizeof exportheader);

          for (;;)
          {
            int c;
            unsigned samples;

            if (datalength/100L)
              sprintf(textbuffer, "Working (%ld%% done)", written/(datalength/100L));
            printblank(0, 20, 80);
            printtextc(20, 15, textbuffer);
            fliptoscreen();
            memset(srcptr, 0, bfragment*header.tracks * 2);
            memset(destptr, 0, bfragment * 2);
            read(filehandle, srcptr, bfragment*header.tracks * 2);

            for (c = 0; c < bfragment; c++)
            {
              destptr[c] = srcptr[c*header.tracks+track];
            }

            if (datalength-written >= bfragment * 2)
            {
              write(exporthandle, destptr, bfragment * 2);
              written += bfragment * 2;
            }
            else
            {
              write(exporthandle, destptr, datalength-written);
              written += datalength-written;
            }
            if (written >= datalength) break;
          }
          printblank(0, 20, 80);
        }
        close(exporthandle);
      }
    }
    break;

    case VK_F9:
    if ((filehandle != -1) && (!play))
    {
      int exporthandle;

      inputbuffer[0] = 0;
      inputtext2(10, 20, 15, inputbuffer, 50, "Export To WAVfile:");
      printblank(0, 20, 80);

      exporthandle = open(inputbuffer, O_CREAT | O_BINARY | O_TRUNC | O_RDWR, S_IREAD | S_IWRITE);

      if (exporthandle != -1)
      {
        int track1 = -1;
        int track2 = -1;

        inputbuffer[0] = 0;
        inputtext2(15, 20, 15, inputbuffer, 3, "Enter LEFT Track To Export:");
        sscanf(inputbuffer, "%d", &track1);
        printblank(0, 20, 80);
        inputbuffer[0] = 0;
        inputtext2(15, 20, 15, inputbuffer, 3, "Enter RIGHT Track To Export:");
        sscanf(inputbuffer, "%d", &track2);
        printblank(0, 20, 80);
        track1--;
        track2--;

        if ((track1 >= 0) && (track1 < header.tracks) && (track2 >= 0) && (track2 < header.tracks))
        {
          WAVHEADER exportheader = {"RIFF", 0, "WAVE", "fmt ", 16, 1, 2, 0, 0, 2, 4, 16, "data", 0};
          int datalength;
          int written = 0;
          int startpos, endpos;
          short *srcptr = trackbuffer[0];
          short *destptr = trackbuffer[1];

          startpos = lseek(filehandle, pos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
          endpos = lseek(filehandle, 0, SEEK_END);
          datalength = (endpos - startpos) / header.tracks;
          datalength &= 0xfffffffe;
          lseek(filehandle, startpos, SEEK_SET);

          exportheader.playspeed = header.playspeed;
          exportheader.avgbytes = header.playspeed * 4;
          exportheader.datasize = datalength * 2;
          exportheader.totalsize = datalength * 2 + 36;
          write(exporthandle, &exportheader, sizeof exportheader);

          for (;;)
          {
            int c;
            unsigned samples;

            if (datalength/100L)
              sprintf(textbuffer, "Working (%ld%% done)", written/(datalength/100L));
            printblank(0, 20, 80);
            printtextc(20, 15, textbuffer);
            fliptoscreen();
            memset(srcptr, 0, bfragment*header.tracks * 2);
            memset(destptr, 0, bfragment * 2);
            read(filehandle, srcptr, bfragment*header.tracks * 2);

            for (c = 0; c < bfragment; c++)
            {
              destptr[c * 2] = srcptr[c * header.tracks + track1];
              destptr[c * 2 + 1] = srcptr[c * header.tracks + track2];
            }

            if (datalength-written >= bfragment * 2)
            {
              write(exporthandle, destptr, bfragment * 4);
              written += bfragment * 2;
            }
            else
            {
              write(exporthandle, destptr, (datalength-written) * 2);
              written += datalength-written;
            }
            if (written >= datalength) break;
          }
          printblank(0, 20, 80);
        }
        close(exporthandle);
      }
    }
    break;

    case VK_F6:
    if ((filehandle != -1) && (!play))
    {
      int exporthandle[MAXTRACKS];
      char name[80];
      char buffer[80];
      int track;
      unsigned c;

      printtextc(20, 15, "Confirm Export All (y/n)");
      waitkey();
      printblank(0, 20, 80);
      if ((key != 'y') && (key != 'Y')) break;

      for (track = 0; track < header.tracks; track++)
      {
        strcpy(name, filename);
        for (c = 0; c < strlen(name); c++)
        {
          if (name[c] == '.') name[c] = 0;
        }
        sprintf(buffer, "_track%02d.wav", track+1);
        strcat(name, buffer);
        exporthandle[track] = open(name, O_CREAT | O_BINARY | O_TRUNC | O_RDWR, S_IREAD | S_IWRITE);
      }
      {
        WAVHEADER exportheader = {"RIFF", 0, "WAVE", "fmt ", 16, 1, 1, 0, 0, 1, 2, 16, "data", 0};

        int datalength;
        int written = 0;
        int startpos, endpos;
        short *srcptr = trackbuffer[0];
        short *destptr = trackbuffer[1];

        startpos = lseek(filehandle, pos + sizeof header + (2 * sizeof(int) * header.tracks), SEEK_SET);
        endpos = lseek(filehandle, 0, SEEK_END);
        datalength = (endpos - startpos) / header.tracks;
        datalength &= 0xfffffffe;
        lseek(filehandle, startpos, SEEK_SET);

        exportheader.playspeed = header.playspeed;
        exportheader.avgbytes = header.playspeed * 2;
        exportheader.datasize = datalength;
        exportheader.totalsize = datalength+36;

        for (track = 0; track < header.tracks; track++)
        {
          if (exporthandle[track] != -1)
            write(exporthandle[track], &exportheader, sizeof exportheader);
        }

        for (;;)
        {
          int c;
          unsigned samples;

          if (datalength/100L)
            sprintf(textbuffer, "Working (%ld%% done)", written/(datalength/100L));
          printblank(0, 20, 80);
          printtextc(20, 15, textbuffer);
          fliptoscreen();
          memset(srcptr, 0, bfragment*header.tracks * 2);
          memset(destptr, 0, bfragment * 2);
          read(filehandle, srcptr, bfragment*header.tracks * 2);

          for (track = 0; track < header.tracks; track++)
          {
            for (c = 0; c < bfragment; c++)
            {
              destptr[c] = srcptr[c*header.tracks+track];
            }

            if (exporthandle[track] != -1)
            {
              if (datalength-written >= bfragment * 2)
              {
                write(exporthandle[track], destptr, bfragment * 2);
              }
              else
              {
                write(exporthandle[track], destptr, datalength-written);
              }
            }
          }
          if (datalength-written >= bfragment * 2)
            written += bfragment * 2;
          else
            written += datalength-written;
          if (written >= datalength) break;
        }
      }
      for (track = 0; track < header.tracks; track++)
      {
        if (exporthandle[track] != -1)
          close(exporthandle[track]);
      }
      printblank(0, 20, 80);
      fliptoscreen();
    }
    break;

    case VK_F7:
    if (filehandle != -1)
    {
      inputbuffer[0] = 0;
      inputtext2(15, 20, 15, inputbuffer, 50, "Mix To WAVfile:");
      printblank(0, 20, 80);
      sound_mixdown(inputbuffer, 0);
    }
    break;

    case VK_F8:
    if (filehandle != -1)
    {
      inputbuffer[0] = 0;
      inputtext2(15, 20, 15, inputbuffer, 45, "Fast mix To WAVfile:");
      printblank(0, 20, 80);
      sound_mixdown(inputbuffer, 1);
    }
    break;

    case VK_INSERT:
    if (filehandle != -1) punchin = sound_getpos();
    break;

    case VK_HOME:
    if (filehandle != -1) sound_setpos(punchin);
    break;

    case VK_PRIOR:
    punchin = -1;
    break;

    case VK_DELETE:
    if (filehandle != -1) punchout = sound_getpos();
    break;

    case VK_END:
    if (filehandle != -1) sound_setpos(punchout);
    break;

    case VK_NEXT:
    punchout = -1;
    break;

  }
}

void buildmainscreen(void)
{
  clearscreen();
  printblankc(0, 0, 15+16, 80);
  printtextc(0, 15+16, programname);
  printtext(TRACKXPOS, 1, 15, "#  VOL  PAN  REC  DST  LEVEL");

  printtext(HELPXPOS, 1, 15, "[0-9]");
  printtext(HELPXPOS, 2, 15, "[Z X]");
  printtext(HELPXPOS, 3, 15, "[< >]");
  printtext(HELPXPOS, 4, 15, "[SPC]");
  printtext(HELPXPOS, 5, 15, "[<��]");
  printtext(HELPXPOS, 6, 15, "[\x1b \x1a]");
  printtext(HELPXPOS, 7, 15, "[\x18 \x19]");
  printtext(HELPXPOS, 8, 15, "[- +]");
  printtext(HELPXPOS, 9,15, "[ R ]");
  printtext(HELPXPOS, 10,15, "[ M ]");
  printtext(HELPXPOS, 11,15, "[ T ]");
  printtext(HELPXPOS, 12,15, "[ S ]");
  printtext(HELPXPOS, 13,15, "[INS]");
  printtext(HELPXPOS, 14,15, "[HOM]");
  printtext(HELPXPOS, 15,15, "[PGU]");
  printtext(HELPXPOS, 16,15, "[DEL]");
  printtext(HELPXPOS, 17,15, "[END]");
  printtext(HELPXPOS, 18,15, "[PGD]");

  printtext(HELPXPOS+18, 1, 15, "[Q W]");
  printtext(HELPXPOS+18, 2, 15, "[F 1]");
  printtext(HELPXPOS+18, 3, 15, "[F 2]");
  printtext(HELPXPOS+18, 4, 15, "[F 3]");
  printtext(HELPXPOS+18, 5, 15, "[F 4]");
  printtext(HELPXPOS+18, 6, 15, "[F 5]");
  printtext(HELPXPOS+18, 7, 15, "[F 6]");
  printtext(HELPXPOS+18, 8, 15, "[F 7]");
  printtext(HELPXPOS+18, 9, 15, "[F 8]");
  printtext(HELPXPOS+18, 10, 15, "[F 9]");
  printtext(HELPXPOS+18, 11, 15, "[ESC]");

  printtext(HELPXPOS+6, 1,10, "Sel. Track");
  printtext(HELPXPOS+6, 2,10, "Rev/Fwd");
  printtext(HELPXPOS+6, 3,10, "Fine R/F");
  printtext(HELPXPOS+6, 4,10, "Play/Stop");
  printtext(HELPXPOS+6, 5,10, "Record");
  printtext(HELPXPOS+6, 6,10, "Panning");
  printtext(HELPXPOS+6, 7,10, "Volume");
  printtext(HELPXPOS+6, 8,10, "Fine Vol");
  printtext(HELPXPOS+6, 9,10, "Set Record");
  printtext(HELPXPOS+6,10,10, "Mute Track");
  printtext(HELPXPOS+6,11,10, "Edit Title");
  printtext(HELPXPOS+6,12,10, "Samplerate");
  printtext(HELPXPOS+6,13,10, "Set Punch-In");
  printtext(HELPXPOS+6,14,10, "Goto Punch-In");
  printtext(HELPXPOS+6,15,10, "Clear Punch-In");
  printtext(HELPXPOS+6,16,10, "Set Punch-Out");
  printtext(HELPXPOS+6,17,10, "Goto Punch-Out");
  printtext(HELPXPOS+6,18,10, "Clear Punch-Out");

  printtext(HELPXPOS+24, 1,10, "Sel. Track");
  printtext(HELPXPOS+24, 2, 10, "New Tape");
  printtext(HELPXPOS+24, 3, 10, "Load Tape");
  printtext(HELPXPOS+24, 4, 10, "Import Track");
  printtext(HELPXPOS+24, 5, 10, "Export Track");
  printtext(HELPXPOS+24, 6, 10, "Import All");
  printtext(HELPXPOS+24, 7, 10, "Export All");
  printtext(HELPXPOS+24, 8, 10, "Mix To WAV");
  printtext(HELPXPOS+24, 9, 10, "Fast Mix");
  printtext(HELPXPOS+24, 10, 10, "Export Stereo");
  printtext(HELPXPOS+24, 11, 10, "End Session");

  printtext(0, 21, 15, "  Filename:");
  printtext(0, 22, 15, "     Title:");
  printtext(0, 23, 15, "Samplerate:");
  printtext(0, 24, 15, "    Tracks:");
  printsonginfo();
  oldmixdown = -1;
}


void printsonginfo(void)
{
  printblank(12, 21, 50);
  printblank(12, 22, 30);
  printblank(12, 23, 5);
  printblank(12, 24, 2);
  printtext(12, 21, 14, filename);
  if (filehandle != -1)
  {
    printtext(12, 22, 14, header.songname);
    sprintf(textbuffer, "%u", header.playspeed);
    printtext(12, 23, 14, textbuffer);
    sprintf(textbuffer, "%d", header.tracks);
    printtext(12, 24, 14, textbuffer);
  }
  else
  {
    printtext(12, 22, 14, "-");
    printtext(12, 23, 14, "-");
    printtext(12, 24, 14, "-");
  }
}

void printplayinfo(void)
{
  if (play)
  {
    if (record) printtext(64, 21, 12, "RECORDING");
    else printtext(64, 21, 14, " PLAYING ");
  }
  else printtext(64, 21, 10, " STOPPED ");
  calculatetime();
  sprintf(textbuffer, "%02d.%02d.%02d", min, sec, hundredth);
  printtext(65, 22, 15, textbuffer);
  if (lag)
  {
    float lagseconds = ((float)lag) / ((float)header.playspeed);
    sprintf(textbuffer, "LAG: %.03fs", lagseconds);
    printtext(64, 24, 15, textbuffer);
  }
  else
  {
    printblank(64, 24, 11);
  }
}

void printtracks(void)
{
  int c;

  for (c = 0; c < MAXTRACKS; c++)
  {
    printtrack(c);
  }

  printtext(MASTERVOLXPOS+13, 15, 15, "DST  LEVEL");
  printtext(TRACKXPOS, 16, 15, "LEFT OUTPUT");
  drawlight(MASTERVOLXPOS+13, 16, leftvumeter>=32767);
  drawvumeter(MASTERVOLXPOS+18, 16, leftvumeter);
  printtext(TRACKXPOS, 17, 15, "RIGHT OUTPUT");
  drawlight(MASTERVOLXPOS+13, 17, rightvumeter>=32767);
  drawvumeter(MASTERVOLXPOS+18, 17, rightvumeter);
  printtext(TRACKXPOS, 18, 15, "LEFT INPUT");
  drawlight(MASTERVOLXPOS+13, 18, leftinputvumeter>=32767);
  drawvumeter(MASTERVOLXPOS+18, 18, leftinputvumeter);
  printtext(TRACKXPOS, 19, 15, "RIGHT INPUT");
  drawlight(MASTERVOLXPOS+13, 19, rightinputvumeter>=32767);
  drawvumeter(MASTERVOLXPOS+18, 19, rightinputvumeter);
  if (mixdown != oldmixdown)
  {
    if (mixdown)
    {
      printtextc(20, 15, "**MIXDOWN IN PROGRESS**");
    }
    else
    {
      printblank(0, 20, 80);
    }
    oldmixdown = mixdown;
  }
  if (punchin != oldpunchin)
  {
    if (punchin != -1)
    {
      int speed = header.playspeed;
      min = punchin / speed / 60;
      sec = punchin / speed - min*60;
      hundredth = ((punchin % speed)*100) / speed;
      sprintf(textbuffer, "Punch-In %02d.%02d.%02d", min, sec, hundredth);
      printtext(2, 14, 12, textbuffer);
    }
    else printblank(2, 14, 18);
    oldpunchin = punchin;
  }
  if (punchout != oldpunchout)
  {
    if (punchout != -1)
    {
      int speed = header.playspeed;
      min = punchout / speed / 60;
      sec = punchout / speed - min*60;
      hundredth = ((punchout % speed)*100) / speed;
      sprintf(textbuffer, "Punch-Out %02d.%02d.%02d", min, sec, hundredth);
      printtext(23, 14, 12, textbuffer);
    }
    else printblank(23, 14, 18);
    oldpunchout = punchout;
  }
}

void printtrack(int num)
{
  if (num < 0) return;
  if (num > MAXTRACKS) return;

  if ((ctrack == num) && (ctrack < header.tracks))
    printtext(TRACKXPOS-2, 2+num, 14, ">");
  else printtext(TRACKXPOS-2, 2+num, 14, " ");

  if (num >= header.tracks)
  {
    printblank(TRACKXPOS-2, 2+num, 42);
  }
  else
  {
    sprintf(textbuffer, "%d", num+1);
    printtext(TRACKXPOS, 2+num, 15, textbuffer);
    sprintf(textbuffer, "%3d", trackvol[num]*100/256);
    printtext(TRACKXPOS+3, 2+num, 15, textbuffer);
    sprintf(textbuffer, "%3d", trackpan[num]*100/256);
    printtext(TRACKXPOS+8, 2+num, 15, textbuffer);
    switch (trackrecord[num])
    {
      case REC_NONE:
      drawlightchar(TRACKXPOS+13, 2+num, ' ');
      break;

      case REC_LEFT:
      drawlightchar(TRACKXPOS+13, 2+num, 'L');
      break;

      case REC_RIGHT:
      drawlightchar(TRACKXPOS+13, 2+num, 'R');
      break;
    }
    drawlight(TRACKXPOS+18, 2+num, trackvumeter[num]>=32767);
    drawvumeter(TRACKXPOS+23, 2+num, trackvumeter[num]);
  }
}

int initscreen(void)
{
  scrbuffer = malloc(MAX_COLUMNS * MAX_ROWS * 2 * sizeof(short));

  if (!scrbuffer) return 0;

  hconsole = GetStdHandle(STD_OUTPUT_HANDLE);
  hconsoleinput = GetStdHandle(STD_INPUT_HANDLE);

  if (hconsole == INVALID_HANDLE_VALUE) return 0;
  if (hconsoleinput == INVALID_HANDLE_VALUE) return 0;

  SetConsoleTitle(programname);
  SetConsoleMode(hconsoleinput, 0);

  cursoroff();
  clearscreen();
  fliptoscreen();
  return 1;
}

void closescreen(void)
{
  if (scrbuffer)
  {
    free(scrbuffer);
    scrbuffer = NULL;
  }
}

void clearscreen(void)
{
  int c;
  short *dptr = scrbuffer;

  for (c = 0; c < MAX_ROWS * MAX_COLUMNS; c++)
  {
    *dptr++ = 0x20;
    *dptr++ = 0x7;
  }
}

void printtext(int x, int y, int color, const char *text)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  while (*text)
  {
    *dptr++ = *text++;
    *dptr++ = color;
  }
}

void drawlight(int x, int y, int on)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  *dptr++ = '[';
  *dptr++ = 15;

  *dptr++ = 254;
  if (on) *dptr++ = 12;
  else *dptr++ = 8;

  *dptr++ = ']';
  *dptr = 15;
}

void drawlightchar(int x, int y, int chr)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  *dptr++ = '[';
  *dptr++ = 15;

  *dptr++ = chr;
  *dptr++ = 12;

  *dptr++ = ']';
  *dptr = 15;
}

void drawvumeter(int x, int y, unsigned level)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);
  int len;
  int count = 16;
  char color = 10;

  if (level == 32767) level = 32768;
  len = level >> 11;

  while (count--)
  {
    *dptr++ = 254;

    if (len)
    {
      *dptr++ = color;
      len--;
    }
    else *dptr++ = 8;

    if (count == 8) color = 14;
    if (count == 4) color = 12;
  }
}

void printblank(int x, int y, int length)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  while (length--)
  {
    *dptr++ = 32;
    *dptr++ = 0;
  }
}

void printblankc(int x, int y, int color, int length)
{
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  while (length--)
  {
    *dptr++ = 32;
    *dptr++ = color;
  }
}

void printtextc(int y, int color, const char *text)
{
  int x = (80 - strlen(text)) / 2;
  short *dptr = scrbuffer + ((x + y * MAX_COLUMNS) << 1);

  while (*text)
  {
    *dptr++ = *text++;
    *dptr++ = color;
  }
}

void fliptoscreen(void)
{
  SMALL_RECT writeregion = {0, 0, MAX_COLUMNS-1, MAX_ROWS-1};
  COORD buffersize = {MAX_COLUMNS, MAX_ROWS};
  COORD buffercoord = {0,0};
  WriteConsoleOutput(hconsole, (CHAR_INFO *)scrbuffer, buffersize, buffercoord, &writeregion);
}


void inputtext(int x, int y, int color, char *buffer, int maxlength, char *message)
{
  int len = strlen(buffer);

  printtextc(20, 15, message);
  cursoron(x+len, y);

  for (;;)
  {
    sound_update();

    getkey();
    if (key)
    {
      if (key == 13) break;
      if (key == 27) break;
      if ((key >= 32) && (key < 256))
      {
        if (len < maxlength-1)
        {
          buffer[len] = key;
          buffer[len+1] = 0;
        }
      }
      if ((key == 8) && (len > 0))
      {
        buffer[len-1] = 0;
      }
      len = strlen(buffer);
      cursoron(x+len, y);
    }
    printblankc(x, y, color, maxlength);
    printtext(x, y, color, buffer);
    printplayinfo();
    printtracks();
    fliptoscreen();
  }
  cursoroff();
  printblank(0, 20, 80);
}

void inputtext2(int x, int y, int color, char *buffer, int maxlength, char *message)
{
  int len = strlen(buffer);

  printtext(x, y, color, message);
  x += strlen(message);
  cursoron(x+len, y);

  for (;;)
  {
    sound_update();

    getkey();
    if (key)
    {
      if (key == 13) break;
      if (key == 27) break;
      if ((key >= 32) && (key < 256))
      {
        if (len < maxlength-1)
        {
          buffer[len] = key;
          buffer[len+1] = 0;
        }
      }
      if ((key == 8) && (len > 0))
      {
        buffer[len-1] = 0;
      }
      len = strlen(buffer);
      cursoron(x+len, y);
    }
    printblankc(x, y, color, maxlength);
    printtext(x, y, color, buffer);
    printplayinfo();
    printtracks();
    fliptoscreen();
  }
  cursoroff();
  printblank(0, 20, 80);
}

void waitkey(void)
{
  for (;;)
  {
    sound_update();

    getkey();
    if (key) break;
    printplayinfo();
    printtracks();
    fliptoscreen();
  }
}

void getkey(void)
{
  HANDLE input = GetStdHandle(STD_INPUT_HANDLE);
  INPUT_RECORD record;
  DWORD events;
  DWORD readevents;

  key = 0;
  virtualkey = 0;

  if (!GetNumberOfConsoleInputEvents(input, &events)) return;

  while (events--)
  {
    ReadConsoleInput(input, &record, 1, &readevents);
    if ((record.EventType == KEY_EVENT) && (record.Event.KeyEvent.bKeyDown))
    {
      key = record.Event.KeyEvent.uChar.AsciiChar & 255;
      virtualkey = record.Event.KeyEvent.wVirtualKeyCode;
      if (!key) key = 256;
      if (key == 224) key = 256;
      return;
    }
  }
}

void calculatetime(void)
{
  int pos = sound_getpos();
  int speed = header.playspeed;
  min = pos / speed / 60;
  sec = pos / speed - min*60;
  hundredth = ((pos % speed)*100) / speed;
}

void cursoroff(void)
{
  CONSOLE_CURSOR_INFO ccinfo;
  ccinfo.dwSize = 20;
  ccinfo.bVisible = FALSE;

  SetConsoleCursorInfo(hconsole, &ccinfo);
}

void cursoron(int x, int y)
{
  COORD coord;
  CONSOLE_CURSOR_INFO ccinfo;
  coord.X = x;
  coord.Y = y;
  ccinfo.dwSize = 20;
  ccinfo.bVisible = TRUE;

  SetConsoleCursorPosition(hconsole,coord);
  SetConsoleCursorInfo(hconsole, &ccinfo);
}

void handle_int(void)
{
  exit(0); /* Atexit functions will be called! */
}

